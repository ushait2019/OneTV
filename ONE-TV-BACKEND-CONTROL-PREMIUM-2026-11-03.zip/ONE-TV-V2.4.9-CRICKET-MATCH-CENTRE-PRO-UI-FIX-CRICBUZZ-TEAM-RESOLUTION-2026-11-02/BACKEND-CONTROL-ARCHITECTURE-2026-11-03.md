# One TV Backend Control Architecture — 2026-11-03

## Goal
The Android APK is a client. Runtime content, sports provider priority, fallback/enrichment selection, channels, notices, and ad platform activation are controlled server-side wherever technically possible.

## Source control
`backend/sports_providers` is the provider registry. The desktop panel exposes **Sources**. Each provider has Active, Role and Priority. Roles: `Primary`, `Enrichment`, `Fallback`.

Default cricket plan:
1. SportScore — Primary
2. Cricbuzz / RapidAPI — Enrichment
3. CricketData — Enrichment
4. OpenCricket — Fallback

The app consumes the same normalized `/cricket/live`, `/cricket/upcoming`, `/cricket/results`, and match-detail responses, so provider switching does not require an APK rebuild.

## Credentials
RapidAPI/Cricbuzz, CricketData, OpenCricket and YouTube credentials remain Worker secrets. They are never returned by public endpoints and channel API keys are no longer exposed by the admin listing.

## Ads
The existing `ad_platforms` registry remains backend controlled. The Android app can only activate an SDK that is already bundled in the APK. Therefore backend priority cannot magically add a new native ad SDK. New SDK families require one APK update; after that, active/priority/placement configuration can be changed server-side.

## Practical verification
- `GET /health` checks D1.
- `GET /config` reports provider order and credential configuration status without secret values.
- `GET /providers` reports public provider status.
- `GET /ads` reports active ad platforms.
- `/admin/providers` allows authenticated source control.
- `/admin/ads` allows authenticated ad priority control.
