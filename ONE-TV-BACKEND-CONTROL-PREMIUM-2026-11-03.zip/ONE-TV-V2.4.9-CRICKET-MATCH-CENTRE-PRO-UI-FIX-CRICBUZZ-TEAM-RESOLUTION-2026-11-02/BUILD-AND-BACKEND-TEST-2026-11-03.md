# One TV Updated Build Baseline — 2026-11-03

This package preserves the supplied One TV Android UI/source baseline and adds backend source-control hardening.

## Runtime model
Build/install the Android app once against the Worker URL. After installation, these can change without rebuilding the APK:
- channels and authorized stream/API sources
- notices and personal-ad content
- sports provider active/role/priority settings
- server-side Cricbuzz/CricketData/OpenCricket credentials
- ad platform active/priority/banner configuration

A new native ad SDK still requires an APK update. The backend cannot install a new SDK into an already-installed application.

## Default cricket provider plan
- SportScore: Primary
- Cricbuzz / RapidAPI: Enrichment
- CricketData: Enrichment
- OpenCricket: Fallback

The PC Admin Panel now exposes a **Sources** tab for these controls.

## QA performed in this package
- Backend JavaScript syntax check: PASS
- Electron main/renderer JavaScript syntax checks: PASS
- Android source static feature checks: PASS
- No supplied RapidAPI credential retained in the project: PASS
- SQLite schema parse: PASS
- Mock backend `/health`, `/config`, `/providers`, `/ads`, `/admin/providers`: PASS
- Practical normalized cricket output using the supplied Cricbuzz response collection: PASS
- Practical provider fallback test with simulated SportScore outage and OpenCricket response: PASS

## Important limitation
A live Cloudflare Worker/D1 deployment and the user's real provider credentials were not available in this build environment, so live upstream network availability and the final phone screen cannot be truthfully marked as tested here. The included smoke tests exercise the Worker route/normalization/fallback behavior locally with controlled provider responses.

## Deployment
For an existing D1 database, apply:
`backend/migration-provider-control.sql`

Then deploy the Worker and keep all provider credentials in Cloudflare Worker secrets. The Android build should use the existing GitHub Actions `ONETV_BACKEND_URL` secret.
