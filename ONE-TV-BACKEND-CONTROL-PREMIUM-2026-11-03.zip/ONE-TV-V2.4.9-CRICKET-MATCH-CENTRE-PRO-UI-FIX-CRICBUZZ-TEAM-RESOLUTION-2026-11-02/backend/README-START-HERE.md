# One TV Backend: Start Here

This folder is the production-ready Cloudflare Worker + D1 backend package for One TV.

## What is already prepared
- Dynamic TV/movie channel database and admin CRUD
- Published Notice Board data for the TV page only
- Viewer heartbeat + per-channel view analytics
- YouTube Data API metadata resolution with official embedded playback in the Android app
- Sports score proxy for cricket, football, basketball and tennis
- SportScore public API for sports data, no API key required, using the documented v1 fixtures/match contract
- SportScore edge-cached responses to reduce upstream usage
- CORS for the Android client
- Windows Electron admin panel
- PowerShell deployment helper

## What cannot be pre-filled
Cloudflare D1 `database_id`, Worker URL, `ADMIN_TOKEN` and YouTube API key belong to your accounts and are intentionally not stored in this ZIP. SportScore requires no API key.

## First deployment
1. Install Node.js and Wrangler: `npm install -g wrangler`
2. Run `wrangler login`.
3. Run `wrangler d1 create one-tv-db`.
4. Copy the returned `database_id` into `wrangler.toml`.
5. Run `./deploy.ps1` on Windows PowerShell.
6. Wrangler will ask for the two required secrets.
7. Copy the deployed Worker URL.
8. Add that URL as the GitHub Actions secret `ONETV_BACKEND_URL`.
9. Re-run the Android workflow.

## Verification
- `GET /health` should report `database: connected`.
- `GET /cricket/health` should report SportScore as the provider. No cricket API key is required.
- Open `/admin`, enter the `ADMIN_TOKEN`, and press **Connect**.

## Sports score provider
SportScore is the primary sports-data provider. For cricket only, the Worker falls back to OpenCricket when SportScore fails, times out, returns invalid data, or returns an empty result. Its current public documentation states that the API requires no API key, supports cricket, football, basketball and tennis, and provides approximately 10,000 requests per 24 hours per IP on the free tier. A visible “Powered by SportScore” attribution is required. The Worker uses the documented `/api/v1/fixtures/` endpoint for live/upcoming/results and `/api/v1/match/` for details.

The Android app refreshes the active sports list every 20 seconds and also provides a manual refresh button on sports screens. The Worker returns the actual provider used for each response so the admin panel can verify fallback behavior.

## Important
Do not put Cloudflare, YouTube, or cricket API secrets in the Android APK, GitHub source, or desktop JavaScript.

## Sports multi-source enrichment (2026-11-02)
SportScore remains the primary provider. Optional CricketData and Cricbuzz credentials enable field-level enrichment for missing cricket fields. OpenCricket remains the cricket-only full-provider fallback.

Secrets:
- `CRICKETDATA_API_KEY`
- `CRICBUZZ_RAPIDAPI_KEY`
Optional variable:
- `CRICBUZZ_RAPIDAPI_HOST=cricbuzz-cricket.p.rapidapi.com`


## Backend-controlled sources (new)
The Worker now maintains a `sports_providers` registry. Use the PC Admin Panel **Sources** tab to enable/disable a provider, assign `Primary`, `Enrichment`, or `Fallback` role, and set priority. The Android app continues to call the same normalized endpoints, so these source changes do not require an APK rebuild.

Default cricket chain: SportScore (Primary) → CricketData/Cricbuzz (Enrichment) → OpenCricket (Fallback). A provider is skipped automatically when its required server-side credential is not configured.

For an existing D1 database, run `wrangler d1 execute one-tv-db --remote --file=migration-provider-control.sql` once, then deploy the Worker.

## Ads: what backend control can and cannot do
The ad registry is backend-controlled for active/priority/banner/interstitial/rewarded configuration. The Android APK can only serve an ad network whose native SDK/adapter is already bundled in that APK. A backend switch cannot install a new native SDK. This version therefore keeps the 10-network registry configuration-ready while AdMob remains the currently executable bundled network. A future APK update can add another SDK without changing the backend control model.
