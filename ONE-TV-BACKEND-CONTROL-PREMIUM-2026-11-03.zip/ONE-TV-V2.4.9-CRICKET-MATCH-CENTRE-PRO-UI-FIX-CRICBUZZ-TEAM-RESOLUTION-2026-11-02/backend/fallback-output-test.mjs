import worker from './src/index.js';
const state={providers:[
 {provider_key:'sportscore',name:'SportScore',sport:'all',role:'primary',active:1,priority:1,api_key_configured:1,notes:'',updated_at:'test'},
 {provider_key:'cricbuzz',name:'Cricbuzz / RapidAPI',sport:'cricket',role:'enrichment',active:0,priority:2,api_key_configured:0,notes:'',updated_at:'test'},
 {provider_key:'cricketdata',name:'CricketData',sport:'cricket',role:'enrichment',active:0,priority:3,api_key_configured:0,notes:'',updated_at:'test'},
 {provider_key:'opencricket',name:'OpenCricket',sport:'cricket',role:'fallback',active:1,priority:4,api_key_configured:1,notes:'',updated_at:'test'}]};
class Stmt{constructor(sql){this.sql=sql;this.args=[]}bind(...a){this.args=a;return this}async run(){return{success:true}}async first(){if(/SELECT COUNT\(\*\) AS n FROM sports_providers/i.test(this.sql))return{n:state.providers.length};if(/SELECT \* FROM sports_providers WHERE provider_key/i.test(this.sql))return state.providers.find(x=>x.provider_key===this.args[0])||null;if(/SELECT 1 AS ok/i.test(this.sql))return{ok:1};return null}async all(){if(/SELECT id,provider_key,name,sport,role,active,priority,api_key_configured,notes,updated_at FROM sports_providers/i.test(this.sql))return{results:state.providers};return{results:[]}}}
const env={APP_NAME:'One TV',OPENCRICKET_API_KEY:'test-open',DB:{prepare:(sql)=>new Stmt(sql)}};
globalThis.caches={default:{async match(){return null},async put(){}}};
globalThis.fetch=async (url)=>{const u=String(url);if(u.includes('sportscore.com/api/v1/fixtures/'))return new Response('upstream unavailable',{status:503});if(u.includes('opencricketapi.com/v1/matches'))return new Response(JSON.stringify({matches:[{id:'match_1',home_team:{name:'Oman'},away_team:{name:'Netherlands'},status:'live',start_time:'2026-11-03T00:00:00Z'}]}),{status:200,headers:{'content-type':'application/json'}});return new Response('{}',{status:404})};
const r=await worker.fetch(new Request('https://test.local/cricket/live'),env);const out=await r.json();
console.log(JSON.stringify({status:r.status,provider:out.provider,matchCount:out.matches?.length,firstMatch:out.matches?.[0]},null,2));
