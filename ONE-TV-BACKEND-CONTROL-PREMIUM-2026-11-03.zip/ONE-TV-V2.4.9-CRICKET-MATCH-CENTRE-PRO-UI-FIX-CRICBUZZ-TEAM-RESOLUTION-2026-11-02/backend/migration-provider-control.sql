-- One TV provider control migration
-- Safe to run after schema.sql. It creates the backend-controlled provider registry.
CREATE TABLE IF NOT EXISTS sports_providers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  provider_key TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  sport TEXT NOT NULL DEFAULT 'cricket',
  role TEXT NOT NULL DEFAULT 'fallback',
  active INTEGER NOT NULL DEFAULT 0,
  priority INTEGER NOT NULL DEFAULT 99,
  api_key_configured INTEGER NOT NULL DEFAULT 0,
  notes TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_sports_providers_active_priority ON sports_providers(active, priority);
