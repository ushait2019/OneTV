CREATE TABLE IF NOT EXISTS channels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_number TEXT NOT NULL,
  name TEXT NOT NULL,
  country TEXT NOT NULL DEFAULT 'International',
  category TEXT NOT NULL DEFAULT 'TV',
  logo_url TEXT NOT NULL DEFAULT '',
  stream_url TEXT NOT NULL DEFAULT '',
  source_type TEXT NOT NULL DEFAULT 'link',
  source_value TEXT NOT NULL DEFAULT '',
  api_key TEXT NOT NULL DEFAULT '',
  program_name TEXT NOT NULL DEFAULT '',
  program_api_url TEXT NOT NULL DEFAULT '',
  show_viewers INTEGER NOT NULL DEFAULT 0,
  loop_playback INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_channels_active_sort ON channels(active, sort_order, id);

CREATE TABLE IF NOT EXISTS notices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL DEFAULT 'text',
  title TEXT NOT NULL DEFAULT '',
  html_content TEXT NOT NULL DEFAULT '',
  media_url TEXT NOT NULL DEFAULT '',
  link_url TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notices_active_sort ON notices(active, sort_order, id);


CREATE TABLE IF NOT EXISTS viewer_sessions (
  viewer_id TEXT PRIMARY KEY,
  channel_id INTEGER NOT NULL,
  last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_viewer_sessions_channel_seen ON viewer_sessions(channel_id, last_seen);

CREATE TABLE IF NOT EXISTS channel_views (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_id INTEGER NOT NULL,
  viewer_id TEXT NOT NULL,
  started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_channel_views_channel ON channel_views(channel_id);
CREATE INDEX IF NOT EXISTS idx_channel_views_started ON channel_views(started_at);

CREATE TABLE IF NOT EXISTS ad_platforms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  platform_key TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 0,
  priority INTEGER NOT NULL DEFAULT 99,
  banner_enabled INTEGER NOT NULL DEFAULT 1,
  interstitial_enabled INTEGER NOT NULL DEFAULT 0,
  rewarded_enabled INTEGER NOT NULL DEFAULT 0,
  app_id TEXT NOT NULL DEFAULT '',
  banner_unit_id TEXT NOT NULL DEFAULT '',
  interstitial_unit_id TEXT NOT NULL DEFAULT '',
  rewarded_unit_id TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sports_event_state (
  event_key TEXT PRIMARY KEY,
  sport TEXT NOT NULL,
  match_id TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_sports_event_state_sport ON sports_event_state(sport);

CREATE TABLE IF NOT EXISTS sports_providers (
  id INTEGER PRIMARY KEY AUTOINCREMENT, provider_key TEXT NOT NULL UNIQUE, name TEXT NOT NULL, sport TEXT NOT NULL DEFAULT 'cricket', role TEXT NOT NULL DEFAULT 'fallback', active INTEGER NOT NULL DEFAULT 0, priority INTEGER NOT NULL DEFAULT 99, api_key_configured INTEGER NOT NULL DEFAULT 0, notes TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_sports_providers_active_priority ON sports_providers(active, priority);
