import worker from './src/index.js';

const state = { providers: [], ads: [] };
class Stmt {
  constructor(sql){this.sql=sql;this.args=[]}
  bind(...args){this.args=args;return this}
  async run(){
    const s=this.sql;
    if (/CREATE TABLE IF NOT EXISTS sports_providers/i.test(s)) return {success:true};
    if (/CREATE TABLE IF NOT EXISTS ad_platforms/i.test(s)) return {success:true};
    if (/SELECT COUNT\(\*\) AS n FROM sports_providers/i.test(s)) return {n: state.providers.length};
    if (/SELECT COUNT\(\*\) AS n FROM ad_platforms/i.test(s)) return {n: state.ads.length};
    if (/INSERT INTO sports_providers/i.test(s)){state.providers.push({provider_key:this.args[0],name:this.args[1],sport:this.args[2],role:this.args[3],active:this.args[4],priority:this.args[5],api_key_configured:0,notes:this.args[6],updated_at:'test'});return {success:true};}
    if (/INSERT INTO ad_platforms/i.test(s)){state.ads.push({platform_key:this.args[0],name:this.args[1],active:0,priority:this.args[2],banner_enabled:1,interstitial_enabled:0,rewarded_enabled:0,app_id:'',banner_unit_id:'',interstitial_unit_id:'',rewarded_unit_id:''});return {success:true};}
    if (/UPDATE sports_providers SET api_key_configured/i.test(s)) { for(const p of state.providers){p.api_key_configured=p.provider_key==='cricbuzz'?this.args[0]:p.provider_key==='cricketdata'?this.args[1]:p.provider_key==='opencricket'?this.args[2]:1;} return {success:true}; }
    return {success:true};
  }
  async first(){
    const s=this.sql;
    if (/SELECT 1 AS ok/i.test(s)) return {ok:1};
    if (/SELECT COUNT\(\*\) AS n FROM sports_providers/i.test(s)) return {n:state.providers.length};
    if (/SELECT COUNT\(\*\) AS n FROM ad_platforms/i.test(s)) return {n:state.ads.length};
    if (/SELECT \* FROM sports_providers WHERE provider_key/i.test(s)) return state.providers.find(p=>p.provider_key===this.args[0]) || null;
    return null;
  }
  async all(){
    const s=this.sql;
    if (/SELECT id,provider_key,name,sport,role,active,priority,api_key_configured,notes,updated_at FROM sports_providers/i.test(s)) return {results:state.providers};
    if (/SELECT \* FROM ad_platforms/i.test(s)) return {results:state.ads};
    return {results:[]};
  }
}
const env={APP_NAME:'One TV',ADMIN_TOKEN:'test-token',DB:{prepare:(sql)=>new Stmt(sql)}};
for (const [path,init] of [
  ['/health',{}],
  ['/config',{}],
  ['/providers',{}],
  ['/ads',{}],
  ['/admin/providers',{headers:{Authorization:'Bearer test-token'}}],
]){
  const r=await worker.fetch(new Request('https://test.local'+path,init),env);
  console.log(path,r.status,await r.text());
}
