# Cricbuzz / RapidAPI integration reference

The supporting collection supplied for this build contains the official RapidAPI Cricbuzz endpoints used for cricket enrichment/detail resolution. The live credential is intentionally not stored in this project. Configure it only as the Cloudflare Worker secret `CRICBUZZ_RAPIDAPI_KEY`.

Host: `cricbuzz-cricket.p.rapidapi.com`

Primary collection used by this backend:
- `/matches/v1/live`
- `/matches/v1/upcoming`
- `/matches/v1/recent`
- `/mcenter/v1/{matchId}`
- `/mcenter/v1/{matchId}/scard`
- `/teams/v1/{type}`
- `/teams/v1/{teamId}/{mode}`
- `/schedule/v1/{type}`

The Worker keeps credentials server-side and normalizes the response into the same match model consumed by One TV.
