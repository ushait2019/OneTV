# ONE TV Final UI/UX + Backend Handoff

Date: 2026-10-31

## Final source
The final source pass is in `source/` and is version `1.7` / versionCode `8`.

Implemented in this pass:
- Premium ONE TV Sports + Entertainment shell matching the approved visual direction.
- Sports Home with Cricket, Football, Basketball and Tennis.
- Per-sport Live / Upcoming / Results / Match Details actions.
- Dedicated Match Center with Back navigation.
- Cricket tabs: Overview, Live, Scorecard, Squads, Overs, Commentary, Highlights, Stats, Info.
- Other sports tabs: Overview, Live, Stats, Lineups, H2H, Standings, Timeline, Info.
- Fixed Sports top/bottom chrome with a scrollable middle region.
- Two-finger pinch zoom restricted to Sports middle content.
- Backend/provider data is never invented when unavailable.
- Team/player image fallback behavior.
- Backend-controlled entertainment channel/category flow.
- Dedicated two-card bottom ad area.
- Fullscreen video hides all surrounding UI and restores it on exit.
- `© 2026 USHA IT. All Rights Reserved.` footer.

See `source/FINAL-UI-SPEC-IMPLEMENTED-2026-10-31.md` for the detailed behavior specification.

## Binary status
`original-release-artifacts/OneTV-release.apk` and `OneTV-release.aab` are the original binaries supplied with the previous handoff. They are retained only for reference/signature verification and are NOT the newly modified version 1.7 binaries.

A newly compiled APK/AAB must be generated from `source/` using the included GitHub Actions workflow or another Android build environment. This execution environment does not contain the Android SDK/Gradle toolchain, so a new binary is not falsely claimed as compiled here.

## Backend
The Cloudflare Worker/D1 source remains included. Sports data stays backend-first with SportScore as primary and OpenCricket as a cricket-only fallback. Entertainment channels and notices remain backend controlled.
