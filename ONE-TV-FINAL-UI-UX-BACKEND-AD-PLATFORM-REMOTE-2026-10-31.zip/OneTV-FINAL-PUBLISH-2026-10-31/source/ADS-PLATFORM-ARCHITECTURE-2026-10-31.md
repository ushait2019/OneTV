# ONE TV Ad Platform Architecture

The app is built around a remote ad-platform registry so platform configuration can be enabled, disabled, reprioritized, put into maintenance mode, or changed without changing the app's normal content configuration.

## Pre-registered platforms
1. Google AdMob
2. AppLovin
3. Unity Ads / LevelPlay
4. Meta Audience Network
5. Liftoff Monetize
6. InMobi
7. Pangle
8. Mintegral
9. Digital Turbine / DT Exchange
10. BIGO Ads

## Important SDK boundary
The registry is backend-controlled, but Android native SDK code cannot be installed into an already-published APK remotely. The current binary has the AdMob SDK executable. The other nine are registered as SDK adapters pending native SDK integration. They can be configured, enabled/disabled and prioritized in the backend, but they must not be marked executable until their SDK/adapters are included in a future build.

This prevents a false "active" state that would silently fail at runtime.

## Runtime contract
`GET /ads/config?app=onetv` returns platform status and public unit configuration. Secrets remain server-side. The Android client uses the registry to decide whether an eligible adapter may request an ad, while preserving AdMob as the current executable fallback.

## Admin API
- `GET /admin/ad-platforms`
- `PATCH /admin/ad-platforms`
- `PATCH /admin/ad-units`

All admin routes require `Authorization: Bearer <ADMIN_TOKEN>`.
