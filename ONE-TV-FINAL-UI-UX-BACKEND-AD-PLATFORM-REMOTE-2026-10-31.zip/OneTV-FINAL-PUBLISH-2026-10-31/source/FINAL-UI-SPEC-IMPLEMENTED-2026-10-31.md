# ONE TV Final UI/UX Implementation Pass

Date: 2026-10-31

## Product shell
- ONE TV / All in One branded header.
- Main navigation: Sports and Entertainment.
- Search and light/dark control are present in the application shell.
- Dark premium UI is the default; light mode remains available.

## Sports
- Sports Home dashboard with Cricket, Football, Basketball and Tennis.
- Each sport has Live, Upcoming, Results and Match Details actions.
- Every selected match opens a dedicated Match Center with a back control.
- Cricket Match Center tabs: Overview, Live, Scorecard, Squads, Overs, Commentary, Highlights, Stats, Info.
- Other sports: Overview, Live, Stats, Lineups, H2H, Standings, Timeline, Info.
- Provider data is displayed only when supplied by the backend/provider. Missing data is shown as unavailable rather than invented.
- Team logos/avatars use provider data when available and a neutral fallback when not.
- Text is constrained with responsive max lines/ellipsizing where appropriate.
- Sports middle content is scrollable.
- Two-finger pinch zoom applies only to the Sports middle content and does not scale the fixed top/bottom shell.
- Sports top and bottom shell remains fixed while the middle content scrolls.
- SportsScore attribution is plain non-clickable text above the ad area.

## Entertainment
- TV, Movies, Drama and Songs remain backend-driven categories.
- Entertainment filter row supports All, Live TV, Movies, News, Kids and Sports TV.
- Channel cards open the player and show backend-provided channel metadata.
- Notice Board remains restricted to TV/Home.
- Entertainment does not use the Sports pinch-zoom behavior.

## Player
- Play/pause, volume, seek, quality and fullscreen controls remain available.
- Fullscreen removes the surrounding app chrome and leaves only the player.
- Exiting fullscreen restores normal application chrome.
- Ads, attribution and footer are hidden in fullscreen.

## Ads/footer
- Dedicated two-card bottom ad section.
- No USHA IT branding inside ad cards.
- Footer: `© 2026 USHA IT. All Rights Reserved.`
- Bottom ad section is outside the player and does not overlay playback controls.

## Backend control
- Sports content comes from the ONE TV Worker sports endpoints.
- SportScore is primary and OpenCricket remains a cricket-only fallback at the backend.
- TV/entertainment channels and notices remain backend-controlled through existing Worker/D1 CRUD.
- Provider/API secrets are not stored in the Android source.

## Build note
This pass changes Android source code and backend documentation. A new APK/AAB must still be compiled in an Android build environment. This environment does not contain the Android SDK/Gradle toolchain, so no newly compiled binary is claimed here.
