package com.ushait.onetv;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;

import androidx.core.graphics.Insets;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final String ADMOB_LIVE_BANNER_ID = "ca-app-pub-5981864080922785/5178976268";
    private static final String ADMOB_TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111";
    private static final String ADMOB_LIVE_INTERSTITIAL_ID = "ca-app-pub-5981864080922785/7592231664";
    private static final String ADMOB_TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712";
    private static final String ADMOB_LIVE_NATIVE_ID = "ca-app-pub-5981864080922785/1737269754";
    private static final String ADMOB_TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110";
    private static final String BACKEND_URL = BuildConfig.BACKEND_URL;
    // Ad platform execution is selected from backend configuration. The current binary
    // contains the AdMob SDK; other registered platforms remain non-executable until
    // their native SDK/adapter is included in a future build.
    private volatile boolean remoteAdMobEnabled = true;
    private volatile boolean remoteAdMobMaintenance = false;
    private volatile String remoteBannerUnitId = ADMOB_LIVE_BANNER_ID;
    private volatile String remoteInterstitialUnitId = ADMOB_LIVE_INTERSTITIAL_ID;
    private volatile String remoteNativeUnitId = ADMOB_LIVE_NATIVE_ID;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final List<Channel> channels = new ArrayList<>();
    private final String viewerId = UUID.randomUUID().toString();

    private ExoPlayer player;
    private PlayerView playerView;
    private WebView youtubeWebView;
    private LinearLayout playerContainer;
    private LinearLayout playerControls;
    private LinearLayout contentHost;
    private LinearLayout adSection;
    private LinearLayout nowPlayingBlock;
    private TextView channelsTitle;
    private ScrollView channelScroll;
    private FrameLayout videoFrame;
    private int normalPlayerHeight;
    private TextView footerView;
    private FrameLayout noticeContainer;
    private WebView noticeWebView;
    private LinearLayout channelList;
    private LinearLayout categoryList;
    private HorizontalScrollView categoryScroll;
    private ImageButton pauseResumeButton;
    private LinearLayout cricketContainer;
    private LinearLayout cricketList;
    private TextView cricketHeader;
    private TextView cricketUpdated;
    private TextView nowPlayingName;
    private TextView nowPlayingProgram;
    private TextView viewerCountView;
    private Button sportsRefreshButton;
    private Button themeToggleButton;
    private LinearLayout rootLayout;
    private SwipeRefreshLayout sportsSwipeRefresh;
    private SeekBar timelineSeekBar;
    private PopupWindow volumePopup;
    private int lastVolume = 100;
    private final Runnable timelineUpdater = new Runnable() {
        @Override public void run() {
            updateTimeline();
            handler.postDelayed(this, 500);
        }
    };
    private SharedPreferences prefs;
    private boolean darkMode = false;
    private int sportsRefreshMs = 20000;

    private int currentIndex = 0;
    private boolean controlsVisible = false;
    private boolean playbackPaused = false;
    private String currentCategory = "TV";
    private String cricketMode = "live";
    private String currentSport = "cricket";
    private boolean cricketDetail = false;
    private boolean teamDetail = false;
    private InterstitialAd interstitialAd;
    private int navigationAdCounter = 0;
    private long lastInterstitialShownAt = 0L;
    private static final long INTERSTITIAL_COOLDOWN_MS = 120000L;
    private NativeAd nativeAd;
    private NativeAdView nativeAdView;
    private NativeAd bottomNativeAd1;
    private NativeAd bottomNativeAd2;
    private NativeAdView bottomNativeView1;
    private NativeAdView bottomNativeView2;
    private FrameLayout bottomAdSlot1;
    private FrameLayout bottomAdSlot2;
    private TextView sportsAttributionView;
    private ScaleGestureDetector sportsScaleDetector;
    private float sportsZoom = 1f;
    private boolean isFullscreen = false;
    private ViewGroup videoFrameOriginalParent;
    private int videoFrameOriginalIndex = 0;
    private boolean youtubeReady = false;
    private String pendingYoutubeCommand = null;
    private long sportsRequestToken = 0L;
    private Notice activeNotice;
    private JSONObject currentDetailMatch;
    private String currentDetailSport = "cricket";

    private final Runnable refreshContent = new Runnable() {
        @Override public void run() {
            loadBackendContent();
            handler.postDelayed(this, 60000);
        }
    };
    private final Runnable cricketRefresh = new Runnable() {
        @Override public void run() {
            if ("Cricket Live".equals(currentCategory) && !cricketDetail) loadCricket(cricketMode);
            else if (currentCategory.startsWith("SPORT:") && !cricketDetail) loadSport(currentSport, cricketMode);
            handler.postDelayed(this, sportsRefreshMs);
        }
    };
    private final Runnable viewerHeartbeat = new Runnable() {
        @Override public void run() {
            pingViewer();
            handler.postDelayed(this, 30000);
        }
    };
    private final Runnable hideControls = new Runnable() {
        @Override public void run() { setControlsVisible(false); }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("onetv_preferences", MODE_PRIVATE);
        darkMode = prefs.getBoolean("dark_mode", true);
        applySystemTheme();
        MobileAds.initialize(this, status -> {});
        buildUi();
        loadInterstitialAd();
        loadNativeAd();
        loadBottomNativeAds();
        loadRemoteConfig();
        loadBackendContent();
        handler.postDelayed(refreshContent, 60000);
        handler.postDelayed(cricketRefresh, sportsRefreshMs);
        handler.post(timelineUpdater);
        handler.postDelayed(viewerHeartbeat, 30000);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        rootLayout = root;
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(themeBackground());
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(0, bars.top, 0, bars.bottom);
            return insets;
        });

        // ONE TV application chrome. Sports keeps this chrome locked while its middle
        // content scrolls/zooms. Entertainment uses the same shell but normal content flow.
        FrameLayout brandHeader = new FrameLayout(this);
        brandHeader.setPadding(dp(10), dp(4), dp(10), dp(2));
        brandHeader.setBackgroundColor(themeBackground());

        Button menu = iconTextButton("☰", 22, "Open main menu");
        FrameLayout.LayoutParams menuLp = new FrameLayout.LayoutParams(dp(46), dp(46), Gravity.START | Gravity.CENTER_VERTICAL);
        menuLp.leftMargin = dp(4);
        brandHeader.addView(menu, menuLp);
        menu.setOnClickListener(v -> showMainMenu(menu));

        LinearLayout centerBrand = new LinearLayout(this);
        centerBrand.setOrientation(LinearLayout.VERTICAL);
        centerBrand.setGravity(Gravity.CENTER);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.onetv_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        centerBrand.addView(logo, new LinearLayout.LayoutParams(dp(138), dp(44)));
        TextView slogan = text("All in One", 11, themeSecondaryText(), true);
        slogan.setGravity(Gravity.CENTER);
        centerBrand.addView(slogan, new LinearLayout.LayoutParams(-1, dp(18)));
        brandHeader.addView(centerBrand, new FrameLayout.LayoutParams(dp(190), -1, Gravity.CENTER));

        Button search = iconTextButton("⌕", 27, "Search");
        FrameLayout.LayoutParams searchLp = new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.END | Gravity.CENTER_VERTICAL);
        searchLp.rightMargin = dp(50);
        brandHeader.addView(search, searchLp);
        search.setOnClickListener(v -> Toast.makeText(this, "Search is controlled by the ONE TV backend in the next content release.", Toast.LENGTH_SHORT).show());

        themeToggleButton = iconTextButton(darkMode ? "☀" : "☾", 18, darkMode ? "Switch to light mode" : "Switch to dark mode");
        FrameLayout.LayoutParams themeLp = new FrameLayout.LayoutParams(dp(42), dp(42), Gravity.END | Gravity.CENTER_VERTICAL);
        themeLp.rightMargin = dp(4);
        brandHeader.addView(themeToggleButton, themeLp);
        themeToggleButton.setOnClickListener(v -> toggleTheme());
        root.addView(brandHeader, new LinearLayout.LayoutParams(-1, dp(70)));

        LinearLayout mainNav = new LinearLayout(this);
        mainNav.setGravity(Gravity.CENTER);
        mainNav.setPadding(dp(10), dp(4), dp(10), dp(8));
        Button sportsMenu = sectionButton("🏆  SPORTS", 14.5f, true);
        Button entertainmentMenu = sectionButton("▣  ENTERTAINMENT", 14.5f, false);
        sportsMenu.setOnClickListener(v -> selectSportsCategory("SPORTS_HOME"));
        entertainmentMenu.setOnClickListener(v -> showEntertainmentMenu(entertainmentMenu));
        LinearLayout.LayoutParams navLp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        navLp.setMargins(0, 0, dp(4), 0);
        mainNav.addView(sportsMenu, navLp);
        LinearLayout.LayoutParams navLp2 = new LinearLayout.LayoutParams(0, dp(46), 1f);
        navLp2.setMargins(dp(4), 0, 0, 0);
        mainNav.addView(entertainmentMenu, navLp2);
        root.addView(mainNav, new LinearLayout.LayoutParams(-1, dp(58)));

        categoryScroll = new HorizontalScrollView(this);
        categoryScroll.setHorizontalScrollBarEnabled(false);
        categoryList = new LinearLayout(this);
        categoryList.setGravity(Gravity.CENTER_VERTICAL);
        categoryList.setPadding(dp(12), 0, dp(12), dp(8));
        categoryScroll.addView(categoryList, new ViewGroup.LayoutParams(-2, -2));
        categoryScroll.setVisibility(View.GONE);
        root.addView(categoryScroll, new LinearLayout.LayoutParams(-1, dp(54)));

        FrameLayout contentFrame = new FrameLayout(this);
        root.addView(contentFrame, new LinearLayout.LayoutParams(-1, 0, 1f));

        playerContainer = new LinearLayout(this);
        playerContainer.setOrientation(LinearLayout.VERTICAL);
        playerContainer.setBackgroundColor(themeBackground());
        buildPlayerArea();
        contentFrame.addView(playerContainer, new FrameLayout.LayoutParams(-1, -1));

        nowPlayingBlock = new LinearLayout(this);
        nowPlayingBlock.setOrientation(LinearLayout.VERTICAL);
        nowPlayingBlock.setPadding(dp(16), dp(8), dp(16), dp(8));
        nowPlayingName = text("ONE TV", 17, themePrimaryText(), true);
        nowPlayingProgram = text("Select a channel to start watching", 12, themeSecondaryText(), false);
        viewerCountView = text("", 11, themeSecondaryText(), false);
        nowPlayingBlock.addView(nowPlayingName);
        nowPlayingBlock.addView(nowPlayingProgram);
        nowPlayingBlock.addView(viewerCountView);
        playerContainer.addView(nowPlayingBlock);

        noticeContainer = new FrameLayout(this);
        noticeWebView = new WebView(this);
        WebSettings ws = noticeWebView.getSettings();
        ws.setJavaScriptEnabled(false);
        ws.setDomStorageEnabled(false);
        ws.setAllowFileAccess(false);
        noticeWebView.setBackgroundColor(Color.TRANSPARENT);
        noticeWebView.setWebViewClient(new WebViewClient());
        noticeContainer.addView(noticeWebView, new FrameLayout.LayoutParams(-1, -1));
        playerContainer.addView(noticeContainer, new LinearLayout.LayoutParams(-1, 0));

        channelsTitle = text("TV Channels", 18, themePrimaryText(), true);
        channelsTitle.setPadding(dp(18), dp(12), dp(18), dp(8));
        playerContainer.addView(channelsTitle);

        channelScroll = new ScrollView(this);
        channelList = new LinearLayout(this);
        channelList.setOrientation(LinearLayout.VERTICAL);
        channelList.setPadding(dp(12), 0, dp(12), dp(18));
        channelScroll.addView(channelList);
        playerContainer.addView(channelScroll, new LinearLayout.LayoutParams(-1, 0, 1));

        cricketContainer = buildCricketArea();
        contentFrame.addView(cricketContainer, new FrameLayout.LayoutParams(-1, -1));
        cricketContainer.setVisibility(View.GONE);

        sportsAttributionView = text("Powered by SportsScore", 10, themeSecondaryText(), false);
        sportsAttributionView.setGravity(Gravity.CENTER);
        sportsAttributionView.setPadding(dp(8), dp(2), dp(8), dp(2));
        sportsAttributionView.setClickable(false);
        sportsAttributionView.setFocusable(false);
        sportsAttributionView.setVisibility(View.GONE);
        root.addView(sportsAttributionView, new LinearLayout.LayoutParams(-1, dp(24)));

        adSection = buildAdSection(root);
        root.addView(adSection, new LinearLayout.LayoutParams(-1, -2));

        footerView = text("© 2026 USHA IT. All Rights Reserved.", 11, themeSecondaryText(), false);
        footerView.setGravity(Gravity.CENTER);
        footerView.setPadding(dp(8), dp(7), dp(8), dp(9));
        root.addView(footerView, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        if (player != null) playerView.setPlayer(player);
        rebuildCategories();
        showCategory(currentCategory);
        hideNotice();
        applyThemeToViewTree(root, false);
    }

    private Button iconTextButton(String label, float size, String description) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(size);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(0); b.setMinWidth(0);
        b.setPadding(0,0,0,0);
        b.setTextColor(themePrimaryText());
        b.setContentDescription(description);
        b.setBackground(round(Color.TRANSPARENT, 14));
        return b;
    }

    private Button sectionButton(String label, float size, boolean active) {
        Button b = pillButton(label, size, dp(46));
        b.setTextColor(Color.WHITE);
        b.setBackground(round(active ? Color.rgb(16,116,245) : Color.rgb(27,40,56), 14));
        return b;
    }

    private void showMainMenu(View anchor) {
        showMenu(anchor,
                new String[]{"Sports Home", "Cricket", "Football", "Basketball", "Tennis", "TV", "Movies", "Drama", "Songs"},
                new String[]{"SPORTS_HOME", "Cricket Live", "SPORT:football", "SPORT:basketball", "SPORT:tennis", "TV", "Movies", "Drama", "Songs"});
    }

    private void buildPlayerArea() {
        videoFrame = new FrameLayout(this);
        videoFrame.setBackgroundColor(Color.BLACK);
        int playerHeight = Math.max(dp(220), (int) (getResources().getDisplayMetrics().widthPixels * 0.5625f));
        normalPlayerHeight = playerHeight;

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        videoFrame.addView(playerView, new FrameLayout.LayoutParams(-1, playerHeight));

        youtubeWebView = new WebView(this);
        WebSettings yws = youtubeWebView.getSettings();
        yws.setJavaScriptEnabled(true);
        yws.setDomStorageEnabled(true);
        yws.setMediaPlaybackRequiresUserGesture(false);
        yws.setAllowFileAccess(false);
        youtubeWebView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                youtubeReady = true;
                if (pendingYoutubeCommand != null) {
                    String cmd = pendingYoutubeCommand; pendingYoutubeCommand = null;
                    handler.postDelayed(() -> sendYouTubeCommand(cmd, "[]"), 500);
                }
            }
        });
        youtubeWebView.setBackgroundColor(Color.BLACK);
        videoFrame.addView(youtubeWebView, new FrameLayout.LayoutParams(-1, playerHeight));
        youtubeWebView.setVisibility(View.GONE);

        playerControls = new LinearLayout(this);
        playerControls.setOrientation(LinearLayout.HORIZONTAL);
        playerControls.setGravity(Gravity.CENTER_VERTICAL);
        playerControls.setPadding(dp(8), dp(4), dp(8), dp(4));
        playerControls.setBackgroundColor(Color.argb(225, 0, 0, 0));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, dp(50), Gravity.BOTTOM);
        videoFrame.addView(playerControls, cp);

        pauseResumeButton = playerIconButton(R.drawable.ic_play, "Play or pause", v -> togglePlayback());
        playerControls.addView(pauseResumeButton, controlFixed(dp(36)));

        ImageButton volumeIcon = playerIconButton(R.drawable.ic_volume, "Mute or unmute and show volume", v -> { toggleMute(); showVolumePopup(v); });
        playerControls.addView(volumeIcon, controlFixed(dp(36)));

        timelineSeekBar = new SeekBar(this);
        timelineSeekBar.setMax(1000);
        timelineSeekBar.setProgress(0);
        timelineSeekBar.setPadding(0, 0, 0, 0);
        timelineSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || player == null || !player.isCurrentMediaItemSeekable()) return;
                long duration = player.getDuration();
                if (duration > 0) player.seekTo((duration * progress) / 1000L);
            }
            public void onStartTrackingTouch(SeekBar seekBar) { handler.removeCallbacks(hideControls); }
            public void onStopTrackingTouch(SeekBar seekBar) { showControlsTemporarily(); }
        });
        LinearLayout.LayoutParams timelineLp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        timelineLp.setMargins(dp(3), 0, dp(6), 0);
        playerControls.addView(timelineSeekBar, timelineLp);

        ImageButton quality = playerIconButton(R.drawable.ic_settings, "Quality", v -> showQualityMenu(v));
        playerControls.addView(quality, controlFixed(dp(36)));

        ImageButton fullscreen = playerIconButton(R.drawable.ic_fullscreen, "Fullscreen", v -> toggleFullscreen());
        playerControls.addView(fullscreen, controlFixed(dp(36)));

        playerView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) toggleControls();
            return true;
        });
        youtubeWebView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) showControlsTemporarily();
            return false;
        });

        playerContainer.addView(videoFrame, 0, new LinearLayout.LayoutParams(-1, playerHeight));
        playerControls.setVisibility(View.GONE);
    }

    private void loadInterstitialAd() {
        boolean debug = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        String unit = debug ? ADMOB_TEST_INTERSTITIAL_ID : remoteInterstitialUnitId;
        if (!remoteAdMobEnabled || remoteAdMobMaintenance) return;
        AdRequest request = new AdRequest.Builder().build();
        InterstitialAd.load(this, unit, request, new InterstitialAdLoadCallback() {
            @Override public void onAdLoaded(InterstitialAd ad) { interstitialAd = ad; }
            @Override public void onAdFailedToLoad(LoadAdError error) { interstitialAd = null; }
        });
    }

    private void maybeShowInterstitial() {
        if (isFullscreen || interstitialAd == null) return;
        long now = System.currentTimeMillis();
        if (now - lastInterstitialShownAt < INTERSTITIAL_COOLDOWN_MS) return;
        InterstitialAd ad = interstitialAd;
        interstitialAd = null;
        lastInterstitialShownAt = now;
        ad.setFullScreenContentCallback(new com.google.android.gms.ads.FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() { loadInterstitialAd(); }
            @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) { loadInterstitialAd(); }
        });
        ad.show(this);
    }

    private void loadNativeAd() {
        boolean debug = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        String unit = debug ? ADMOB_TEST_NATIVE_ID : remoteNativeUnitId;
        if (!remoteAdMobEnabled || remoteAdMobMaintenance) return;
        AdLoader loader = new AdLoader.Builder(this, unit)
                .forNativeAd(ad -> {
                    if (nativeAdView != null && nativeAdView.getParent() != null) {
                        ((ViewGroup) nativeAdView.getParent()).removeView(nativeAdView);
                    }
                    if (nativeAd != null) nativeAd.destroy();
                    nativeAd = ad;
                    runOnUiThread(this::insertNativeAdIntoCurrentList);
                })
                .withAdListener(new AdListener() {
                    @Override public void onAdFailedToLoad(LoadAdError error) { nativeAd = null; }
                })
                .build();
        loader.loadAd(new AdRequest.Builder().build());
    }

    private void insertNativeAdIntoCurrentList() {
        if (nativeAd == null || isFullscreen) return;
        if ("SPORTS_HOME".equals(currentCategory) || "Cricket Live".equals(currentCategory) || currentCategory.startsWith("SPORT:")) {
            if (cricketList == null || cricketDetail) return;
            addNativeAdToList(cricketList, Math.min(4, cricketList.getChildCount()));
        } else {
            if (channelList == null) return;
            addNativeAdToList(channelList, 5);
        }
    }

    private void addNativeAdToList(LinearLayout list, int preferredIndex) {
        if (nativeAd == null || list == null) return;
        if (nativeAdView != null && nativeAdView.getParent() != null) {
            ((ViewGroup) nativeAdView.getParent()).removeView(nativeAdView);
        }
        nativeAdView = buildNativeAdView(nativeAd);
        int index = Math.min(preferredIndex, list.getChildCount());
        list.addView(nativeAdView, index);
    }

    private NativeAdView buildNativeAdView(NativeAd ad) {
        NativeAdView adView = new NativeAdView(this);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(16, 14, 16, 14);
        card.setBackground(round(themeCard(), 16));

        TextView label = text("ADVERTISEMENT", 9, Color.GRAY, true);
        card.addView(label, new LinearLayout.LayoutParams(-1, 22));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        top.addView(icon, new LinearLayout.LayoutParams(44, 44));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(10, 0, 0, 0);
        TextView headline = text("", 15, Color.WHITE, true);
        TextView advertiser = text("", 11, Color.GRAY, false);
        copy.addView(headline);
        copy.addView(advertiser);
        top.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(top);

        TextView body = text("", 12, Color.LTGRAY, false);
        body.setPadding(0, 8, 0, 8);
        card.addView(body);

        Button cta = pillButton("Learn more", 12, 44);
        cta.setTextColor(Color.WHITE);
        card.addView(cta, new LinearLayout.LayoutParams(-1, 44));

        adView.addView(card, new ViewGroup.LayoutParams(-1, -2));
        adView.setHeadlineView(headline);
        adView.setBodyView(body);
        adView.setIconView(icon);
        adView.setAdvertiserView(advertiser);
        adView.setCallToActionView(cta);

        headline.setText(ad.getHeadline());
        if (ad.getBody() != null && !ad.getBody().trim().isEmpty()) {
            body.setText(ad.getBody());
            body.setVisibility(View.VISIBLE);
        } else body.setVisibility(View.GONE);
        if (ad.getAdvertiser() != null && !ad.getAdvertiser().trim().isEmpty()) advertiser.setText(ad.getAdvertiser());
        else advertiser.setVisibility(View.GONE);
        if (ad.getCallToAction() != null && !ad.getCallToAction().trim().isEmpty()) cta.setText(ad.getCallToAction());
        else cta.setVisibility(View.GONE);
        if (ad.getIcon() != null && ad.getIcon().getDrawable() != null) icon.setImageDrawable(ad.getIcon().getDrawable());
        else icon.setVisibility(View.GONE);
        adView.setNativeAd(ad);
        return adView;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout smallHeaderAdSlot() {
        LinearLayout box = new LinearLayout(this); box.setGravity(Gravity.CENTER); box.setBackground(round(Color.rgb(18,24,31), 10));
        TextView t = text("AD", 9, Color.GRAY, true); t.setGravity(Gravity.CENTER); box.addView(t, new LinearLayout.LayoutParams(-1,-1)); return box;
    }
    private LinearLayout.LayoutParams controlFixed(int w) { LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,dp(36)); p.setMargins(dp(2),0,dp(2),0); return p; }

    private LinearLayout buildAdSection(ViewGroup parent) {
        LinearLayout section = new LinearLayout(this);
        section.setOrientation(LinearLayout.VERTICAL);
        section.setGravity(Gravity.CENTER);
        section.setBackgroundColor(darkMode ? Color.rgb(13,18,24) : Color.rgb(243,246,249));
        section.setPadding(dp(8), dp(5), dp(8), dp(6));

        TextView label = text("ADVERTISEMENT", 9, themeSecondaryText(), true);
        label.setGravity(Gravity.CENTER);
        section.addView(label, new LinearLayout.LayoutParams(-1, dp(18)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setWeightSum(2f);
        bottomAdSlot1 = new FrameLayout(this);
        bottomAdSlot2 = new FrameLayout(this);
        bottomAdSlot1.setBackground(round(themeCard(), 14));
        bottomAdSlot2.setBackground(round(themeCard(), 14));
        bottomAdSlot1.addView(adPlaceholder("AD CARD 01"), new FrameLayout.LayoutParams(-1, -1));
        bottomAdSlot2.addView(adPlaceholder("AD CARD 02"), new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, dp(82), 1f);
        a.setMargins(0, 0, dp(4), 0);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, dp(82), 1f);
        b.setMargins(dp(4), 0, 0, 0);
        row.addView(bottomAdSlot1, a);
        row.addView(bottomAdSlot2, b);
        section.addView(row);
        return section;
    }

    private View adPlaceholder(String label) {
        TextView t = text(label, 9, themeSecondaryText(), true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(darkMode ? Color.rgb(20,27,35) : Color.rgb(232,236,240), 14));
        return t;
    }

    private void loadBottomNativeAds() {
        boolean debug = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        String unit = debug ? ADMOB_TEST_NATIVE_ID : remoteNativeUnitId;
        if (!remoteAdMobEnabled || remoteAdMobMaintenance) return;
        loadBottomNativeAd(unit, true);
        loadBottomNativeAd(unit, false);
    }

    private void loadBottomNativeAd(String unit, boolean first) {
        AdLoader loader = new AdLoader.Builder(this, unit)
                .forNativeAd(ad -> {
                    if (first) {
                        if (bottomNativeAd1 != null) bottomNativeAd1.destroy();
                        bottomNativeAd1 = ad;
                        runOnUiThread(() -> renderBottomNativeAd(true));
                    } else {
                        if (bottomNativeAd2 != null) bottomNativeAd2.destroy();
                        bottomNativeAd2 = ad;
                        runOnUiThread(() -> renderBottomNativeAd(false));
                    }
                })
                .withAdListener(new AdListener() {
                    @Override public void onAdFailedToLoad(LoadAdError error) { }
                }).build();
        loader.loadAd(new AdRequest.Builder().build());
    }

    private void renderBottomNativeAd(boolean first) {
        FrameLayout slot = first ? bottomAdSlot1 : bottomAdSlot2;
        NativeAd ad = first ? bottomNativeAd1 : bottomNativeAd2;
        if (slot == null || ad == null || isFullscreen) return;
        if (first && bottomNativeView1 != null && bottomNativeView1.getParent() != null) ((ViewGroup) bottomNativeView1.getParent()).removeView(bottomNativeView1);
        if (!first && bottomNativeView2 != null && bottomNativeView2.getParent() != null) ((ViewGroup) bottomNativeView2.getParent()).removeView(bottomNativeView2);
        NativeAdView view = buildCompactNativeAdView(ad);
        if (first) bottomNativeView1 = view; else bottomNativeView2 = view;
        slot.removeAllViews();
        slot.addView(view, new FrameLayout.LayoutParams(-1, -1));
    }

    private NativeAdView buildCompactNativeAdView(NativeAd ad) {
        NativeAdView adView = new NativeAdView(this);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(8), dp(6), dp(8), dp(6));
        TextView label = text("ADVERTISEMENT", 8, themeSecondaryText(), true);
        card.addView(label, new LinearLayout.LayoutParams(-1, dp(15)));
        LinearLayout body = new LinearLayout(this);
        body.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        body.addView(icon, new LinearLayout.LayoutParams(dp(34), dp(34)));
        TextView headline = text(ad.getHeadline() == null ? "Sponsored" : ad.getHeadline(), 11, themePrimaryText(), true);
        headline.setMaxLines(2);
        headline.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, -2, 1f);
        hp.setMargins(dp(7), 0, 0, 0);
        body.addView(headline, hp);
        card.addView(body, new LinearLayout.LayoutParams(-1, dp(40)));
        Button cta = pillButton(ad.getCallToAction() == null || ad.getCallToAction().trim().isEmpty() ? "Learn more" : ad.getCallToAction(), 9.5f, dp(28));
        cta.setTextColor(Color.WHITE);
        card.addView(cta, new LinearLayout.LayoutParams(-1, dp(28)));
        adView.addView(card, new ViewGroup.LayoutParams(-1, -1));
        adView.setHeadlineView(headline);
        adView.setIconView(icon);
        adView.setCallToActionView(cta);
        if (ad.getIcon() != null && ad.getIcon().getDrawable() != null) icon.setImageDrawable(ad.getIcon().getDrawable()); else icon.setVisibility(View.GONE);
        adView.setNativeAd(ad);
        return adView;
    }

    private LinearLayout buildCricketArea() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundColor(themeBackground());

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(8), dp(16), dp(4));
        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.VERTICAL);
        TextView eyebrow = text("ONE TV  •  SPORTS", 10, Color.rgb(30, 205, 138), true);
        cricketHeader = text("Sports", 24, themePrimaryText(), true);
        heading.addView(eyebrow);
        heading.addView(cricketHeader);
        header.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        sportsRefreshButton = iconTextButton("↻", 22, "Refresh sports data");
        sportsRefreshButton.setTextColor(themePrimaryText());
        sportsRefreshButton.setBackground(round(themePill(), 14));
        sportsRefreshButton.setOnClickListener(v -> refreshCurrentSportsPage());
        header.addView(sportsRefreshButton, new LinearLayout.LayoutParams(dp(44), dp(40)));
        outer.addView(header);

        cricketUpdated = text("Live, upcoming and results", 11, themeSecondaryText(), false);
        cricketUpdated.setPadding(dp(16), 0, dp(16), dp(6));
        outer.addView(cricketUpdated, new LinearLayout.LayoutParams(-1, dp(26)));

        sportsSwipeRefresh = new SwipeRefreshLayout(this);
        sportsSwipeRefresh.setColorSchemeColors(Color.rgb(16,116,245), Color.rgb(30,205,138));
        sportsSwipeRefresh.setOnRefreshListener(() -> {
            refreshCurrentSportsPage();
            handler.postDelayed(() -> sportsSwipeRefresh.setRefreshing(false), 900);
        });

        ScrollView scroll = new ScrollView(this);
        cricketList = new LinearLayout(this);
        cricketList.setOrientation(LinearLayout.VERTICAL);
        cricketList.setPadding(dp(12), dp(4), dp(12), dp(28));
        cricketList.setPivotX(0f); cricketList.setPivotY(0f);

        sportsScaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScaleBegin(ScaleGestureDetector detector) {
                if (sportsSwipeRefresh != null) sportsSwipeRefresh.setEnabled(false);
                return true;
            }
            @Override public boolean onScale(ScaleGestureDetector detector) {
                sportsZoom = Math.max(0.85f, Math.min(1.35f, sportsZoom * detector.getScaleFactor()));
                cricketList.setScaleX(sportsZoom); cricketList.setScaleY(sportsZoom);
                return true;
            }
            @Override public void onScaleEnd(ScaleGestureDetector detector) {
                if (sportsSwipeRefresh != null) sportsSwipeRefresh.setEnabled(true);
            }
        });
        scroll.setOnTouchListener((v, event) -> { if (sportsScaleDetector != null) sportsScaleDetector.onTouchEvent(event); return false; });
        scroll.addView(cricketList);
        sportsSwipeRefresh.addView(scroll, new ViewGroup.LayoutParams(-1, -1));
        outer.addView(sportsSwipeRefresh, new LinearLayout.LayoutParams(-1, 0, 1));
        return outer;
    }

    private void renderSportsHome() {
        cricketDetail = false; teamDetail = false;
        if (sportsRefreshButton != null) sportsRefreshButton.setVisibility(View.VISIBLE);
        cricketHeader.setText("Sports");
        cricketUpdated.setText("Live • Upcoming • Results • Match Details");
        cricketList.removeAllViews();

        TextView intro = text("Choose a sport", 18, themePrimaryText(), true);
        intro.setPadding(dp(4), dp(4), dp(4), dp(10));
        cricketList.addView(intro);

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        addSportHomeRow(grid, "🏏", "Cricket", "Cricket Live");
        addSportHomeRow(grid, "⚽", "Football", "SPORT:football");
        addSportHomeRow(grid, "🏀", "Basketball", "SPORT:basketball");
        addSportHomeRow(grid, "🎾", "Tennis", "SPORT:tennis");
        cricketList.addView(grid);

        LinearLayout note = new LinearLayout(this);
        note.setPadding(dp(14), dp(12), dp(14), dp(12));
        note.setBackground(round(darkMode ? Color.rgb(18,32,46) : Color.rgb(237,244,250), 16));
        TextView n = text("Tap any sport or feature. Every match opens its own detailed Match Center.", 11, themeSecondaryText(), false);
        n.setMaxLines(3); note.addView(n);
        cricketList.addView(note);
    }

    private void addSportHomeRow(LinearLayout parent, String icon, String name, String target) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(round(themeCard(), 18));
        card.setElevation(dp(2));
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text(icon + "  " + name, 17, themePrimaryText(), true);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(40), 1));
        Button arrow = iconTextButton("›", 26, name + " details");
        top.addView(arrow, new LinearLayout.LayoutParams(dp(40), dp(40)));
        card.addView(top);

        LinearLayout buttons = new LinearLayout(this); buttons.setGravity(Gravity.CENTER);
        addSportAction(buttons, "◉\nLive", () -> openSportMode(target, "live"));
        addSportAction(buttons, "▣\nUpcoming", () -> openSportMode(target, "upcoming"));
        addSportAction(buttons, "▥\nResults", () -> openSportMode(target, "results"));
        addSportAction(buttons, "▤\nDetails", () -> openSportMode(target, "details"));
        card.addView(buttons);
        View.OnClickListener open = v -> openSportMode(target, "live");
        title.setOnClickListener(open); arrow.setOnClickListener(open);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.setMargins(0,0,0,dp(10)); card.setLayoutParams(cp);
        parent.addView(card);
    }

    private void addSportAction(LinearLayout parent, String label, Runnable action) {
        Button b = pillButton(label, 9.5f, dp(48));
        b.setTextColor(themePrimaryText());
        b.setMaxLines(2); b.setLineSpacing(0, 0.9f);
        b.setBackground(round(themePill(), 14));
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f); lp.setMargins(dp(3),0,dp(3),0); parent.addView(b, lp);
    }

    private void openSportMode(String target, String mode) {
        if ("details".equals(mode)) mode = "live";
        if ("Cricket Live".equals(target)) cricketMode = mode;
        selectSportsCategory(target);
    }

    private android.graphics.drawable.Drawable initialsDrawable(String value) {
        TextView t = new TextView(this);
        t.setText(value == null ? "TV" : value);
        t.setTextColor(Color.WHITE); t.setTextSize(12); t.setTypeface(null, Typeface.BOLD); t.setGravity(Gravity.CENTER);
        t.setBackground(round(Color.rgb(16,116,245), 18));
        t.measure(View.MeasureSpec.makeMeasureSpec(dp(52), View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(dp(52), View.MeasureSpec.EXACTLY));
        t.layout(0,0,dp(52),dp(52));
        android.graphics.Bitmap b=android.graphics.Bitmap.createBitmap(dp(52),dp(52),android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c=new android.graphics.Canvas(b); t.draw(c);
        return new android.graphics.drawable.BitmapDrawable(getResources(),b);
    }

    private Button sportsSegmentButton(String label) {
        Button b = pillButton(label, 12.5f, dp(44));
        b.setTextColor(themePrimaryText());
        return b;
    }

    private void rebuildCategories() {
        if (categoryList == null) return;
        categoryList.removeAllViews();
    }

    private void showSportsMenu(View anchor) {
        showMenu(anchor, new String[]{"Sports Home", "Cricket", "Football", "Basketball", "Tennis"},
                new String[]{"SPORTS_HOME", "Cricket Live", "SPORT:football", "SPORT:basketball", "SPORT:tennis"});
    }

    private void showEntertainmentMenu(View anchor) {
        showMenu(anchor, new String[]{"TV", "Movies", "Drama", "Songs"},
                new String[]{"TV", "Movies", "Drama", "Songs"});
    }

    private void showMenu(View anchor, String[] labels, String[] values) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(8), dp(8), dp(8));
        box.setBackground(round(themeCard(), 14));
        for (int i = 0; i < labels.length; i++) {
            final String value = values[i];
            Button item = pillButton(labels[i], 14, dp(50));
            item.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            item.setPadding(dp(16), 0, dp(16), 0);
            item.setOnClickListener(v -> {
                showCategory(value);
                ((PopupWindow) v.getTag()).dismiss();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
            lp.setMargins(0, dp(3), 0, dp(3));
            box.addView(item, lp);
            final PopupWindow[] holder = new PopupWindow[1];
            item.setTag(holder);
        }
        PopupWindow popup = new PopupWindow(box, Math.min(dp(240), getResources().getDisplayMetrics().widthPixels - dp(24)), ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(true);
        popup.setElevation(dp(10));
        for (int i = 0; i < box.getChildCount(); i++) ((View)box.getChildAt(i)).setTag(popup);
        popup.showAsDropDown(anchor, 0, dp(4));
    }

    private void selectSportsCategory(String cat) {
        cricketDetail = false; teamDetail = false;
        if (cat == null) cat = "SPORTS_HOME";
        currentCategory = cat;
        boolean sports = cat.equals("SPORTS_HOME") || cat.startsWith("SPORT:") || "Cricket Live".equals(cat);
        if (!sports) { showCategory(cat); return; }
        if (sportsAttributionView != null) sportsAttributionView.setVisibility(View.VISIBLE);
        if (cricketContainer != null) cricketContainer.setVisibility(View.VISIBLE);
        if (playerContainer != null) playerContainer.setVisibility(View.GONE);
        if (cat.equals("SPORTS_HOME")) {
            currentSport = "cricket";
            if (sportsRefreshButton != null) sportsRefreshButton.setVisibility(View.VISIBLE);
            renderSportsHome();
            return;
        }
        currentSport = cat.equals("Cricket Live") ? "cricket" : cat.substring("SPORT:".length()).toLowerCase();
        cricketMode = cricketMode == null ? "live" : cricketMode;
        if (sportsRefreshButton != null) sportsRefreshButton.setVisibility(View.VISIBLE);
        cricketList.removeAllViews();
        if ("cricket".equals(currentSport)) loadCricket(cricketMode); else loadSport(currentSport, cricketMode);
    }

    private void showCategory(String cat) {
        if (cat == null) cat = "TV";
        currentCategory = cat;
        boolean sports = cat.equals("SPORTS_HOME") || cat.startsWith("SPORT:") || "Cricket Live".equals(cat);
        if (sports) { selectSportsCategory(cat); return; }
        if (sportsAttributionView != null) sportsAttributionView.setVisibility(View.GONE);
        if (sportsRefreshButton != null) sportsRefreshButton.setVisibility(View.GONE);
        if (cricketContainer != null) cricketContainer.setVisibility(View.GONE);
        if (playerContainer == null) return;
        playerContainer.setVisibility(View.VISIBLE);
        categoryScroll.setVisibility(View.GONE);
        channelList.removeAllViews();
        buildEntertainmentHome(cat);
        if ("TV".equals(cat) && activeNotice != null) renderNotice(activeNotice); else hideNotice();
    }

    private void buildEntertainmentHome(String cat) {
        boolean tv = "TV".equalsIgnoreCase(cat);
        boolean movies = "Movies".equalsIgnoreCase(cat) || "Drama".equalsIgnoreCase(cat);
        channelsTitle.setText(tv ? "TV Channels" : movies ? cat : "Entertainment");
        LinearLayout hero = new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL); hero.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView h = text(tv ? "Featured Channels" : (movies ? "Featured " + cat : "Featured Entertainment"), 20, themePrimaryText(), true); hero.addView(h);
        TextView sub = text("Backend-controlled content. Tap any card to open its dedicated player.", 11, themeSecondaryText(), false); sub.setPadding(0,dp(3),0,dp(8)); hero.addView(sub);
        channelList.addView(hero);

        LinearLayout categories = new LinearLayout(this); categories.setGravity(Gravity.CENTER_VERTICAL); categories.setPadding(dp(0),0,dp(0),dp(8));
        String[] labels = {"All", "Live TV", "Movies", "News", "Kids", "Sports TV"};
        for (String label : labels) {
            Button b = pillButton(label, 10, dp(38));
            b.setTextColor(themePrimaryText());
            b.setBackground(round(themePill(), 14));
            final String filter = label;
            b.setOnClickListener(v -> renderEntertainmentFilter(filter));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(38)); lp.setMargins(0,0,dp(6),0); categories.addView(b,lp);
        }
        HorizontalScrollView catScroll = new HorizontalScrollView(this); catScroll.setHorizontalScrollBarEnabled(false); catScroll.addView(categories); channelList.addView(catScroll);
        renderEntertainmentFilter(tv ? "Live TV" : movies ? "Movies" : "All");
    }

    private void renderEntertainmentFilter(String filter) {
        LinearLayout list = channelList;
        // Preserve hero + category row, remove previously rendered content below them.
        while (list.getChildCount() > 2) list.removeViewAt(2);
        TextView title = text(filter + "  •  Latest", 17, themePrimaryText(), true); title.setPadding(dp(2),dp(8),dp(2),dp(8)); list.addView(title);
        boolean any = false;
        for (int i = 0; i < channels.size(); i++) {
            Channel c = channels.get(i);
            if (!entertainmentMatches(c, filter)) continue;
            any = true;
            list.addView(entertainmentCard(c, i));
        }
        if (!any) {
            TextView empty = text("No content is currently configured for this category. Add or change it from the ONE TV backend.", 12, themeSecondaryText(), false);
            empty.setPadding(dp(14),dp(30),dp(14),dp(30)); list.addView(empty);
        }
    }

    private boolean entertainmentMatches(Channel c, String filter) {
        String cat = String.valueOf(c.category == null ? "TV" : c.category).toLowerCase();
        if ("all".equalsIgnoreCase(filter)) return true;
        if ("live tv".equalsIgnoreCase(filter)) return cat.contains("tv");
        if ("movies".equalsIgnoreCase(filter)) return cat.contains("movie") || cat.contains("drama");
        if ("news".equalsIgnoreCase(filter)) return cat.contains("news");
        if ("kids".equalsIgnoreCase(filter)) return cat.contains("kid");
        if ("sports tv".equalsIgnoreCase(filter)) return cat.contains("sport");
        return cat.contains(filter.toLowerCase());
    }

    private View entertainmentCard(Channel c, int index) {
        LinearLayout card = new LinearLayout(this); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(12),dp(10),dp(12),dp(10)); card.setBackground(round(themeCard(),16));
        ImageView logo = new ImageView(this); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); logo.setImageDrawable(initialsDrawable(initials(c.name))); if (c.url != null && !c.url.isEmpty()) { /* channel logo is loaded from backend in future metadata pass */ }
        card.addView(logo,new LinearLayout.LayoutParams(dp(52),dp(52)));
        LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(10),0,dp(8),0);
        TextView name=text(c.name,14,themePrimaryText(),true);name.setMaxLines(1);name.setEllipsize(android.text.TextUtils.TruncateAt.END);tx.addView(name);
        String meta=(c.country==null?"":c.country)+(c.programName==null||c.programName.isEmpty()?"":"  •  "+c.programName); TextView m=text(meta,10,themeSecondaryText(),false);m.setMaxLines(2);m.setEllipsize(android.text.TextUtils.TruncateAt.END);tx.addView(m);
        card.addView(tx,new LinearLayout.LayoutParams(0,-2,1));
        Button play=iconTextButton("▶",18,"Play "+c.name);play.setTextColor(Color.rgb(16,116,245));card.addView(play,new LinearLayout.LayoutParams(dp(44),dp(44)));
        View.OnClickListener open=v->playChannel(index);card.setOnClickListener(open);play.setOnClickListener(open);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(8));card.setLayoutParams(lp);return card;
    }

    private void refreshCurrentSportsPage() {
        if (cricketDetail) return;
        if (sportsRefreshButton != null) sportsRefreshButton.setEnabled(false);
        if ("SPORTS_HOME".equals(currentCategory)) { renderSportsHome(); }
        else if ("Cricket Live".equals(currentCategory) || currentCategory.startsWith("SPORT:")) { selectSportsCategory(currentCategory); }
        handler.postDelayed(() -> { if (sportsRefreshButton != null) sportsRefreshButton.setEnabled(true); if (sportsSwipeRefresh != null) sportsSwipeRefresh.setRefreshing(false); }, 900);
    }

    private void loadSport(String sport, String mode) {
        final long requestToken = ++sportsRequestToken;
        if (cricketHeader != null) cricketHeader.setText(sportName(sport));
        if (cricketContainer != null) cricketContainer.setVisibility(View.VISIBLE);
        cricketDetail = false;
        currentSport = sport;
        cricketMode = mode;
        cricketHeader.setText(cap(sport));
        cricketList.removeAllViews();
        showCricketMessage("Loading " + mode + " matches…");
        network.execute(() -> {
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/sports/" + sport + "/" + mode));
                JSONArray matches = root.optJSONArray("matches");
                runOnUiThread(() -> { if (requestToken == sportsRequestToken && currentSport.equals(sport) && currentCategory.equals("SPORT:" + sport)) renderCricketMatches(matches, mode); });
            } catch (Exception e) { runOnUiThread(() -> { if (requestToken == sportsRequestToken && currentSport.equals(sport) && currentCategory.equals("SPORT:" + sport)) showCricketMessage("Sports data is temporarily unavailable."); }); }
        });
    }

    private String cap(String s) { return s == null || s.isEmpty() ? "Sports" : Character.toUpperCase(s.charAt(0)) + s.substring(1); }

    private String sportName(String sport) {
        if (sport == null || sport.trim().isEmpty()) return "Sports";
        String s = sport.trim().toLowerCase(java.util.Locale.US);
        if ("cricket".equals(s)) return "Cricket";
        if ("football".equals(s) || "soccer".equals(s)) return "Football";
        if ("basketball".equals(s)) return "Basketball";
        if ("tennis".equals(s)) return "Tennis";
        return cap(s);
    }

    private Button pillButton(String label, float size, int height) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(themePrimaryText());
        b.setTextSize(size);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setIncludeFontPadding(false);
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setBackground(round(themePill(), 18));
        return b;
    }

    private void loadRemoteImage(ImageView target, String url) {
        if (target == null || url == null || url.trim().isEmpty()) return;
        final String imageUrl = url.trim();
        target.setImageDrawable(initialsDrawable("TV"));
        network.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(imageUrl).openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(12000);
                c.setRequestMethod("GET");
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", "OneTV/1.5");
                c.connect();
                if (c.getResponseCode() >= 200 && c.getResponseCode() < 300) {
                    try (InputStream in = c.getInputStream()) {
                        Bitmap bitmap = BitmapFactory.decodeStream(in);
                        if (bitmap != null) {
                            runOnUiThread(() -> {
                                if (!isFinishing() && !isDestroyed()) {
                                    target.setImageBitmap(bitmap);
                                }
                            });
                        }
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    private void loadRemoteConfig() {
        if (BACKEND_URL.contains("REPLACE-WITH-YOUR-WORKER")) return;
        network.execute(() -> {
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/config"));
                JSONObject sports = root.optJSONObject("sports");
                if (sports != null) sportsRefreshMs = Math.max(10000, sports.optInt("refreshMs", 20000));
                try {
                    JSONObject ads = new JSONObject(getUrl(BACKEND_URL + "/ads/config?app=onetv"));
                    JSONArray platforms = ads.optJSONArray("platforms");
                    if (platforms != null) {
                        for (int i = 0; i < platforms.length(); i++) {
                            JSONObject p = platforms.optJSONObject(i);
                            if (p == null || !"admob".equalsIgnoreCase(p.optString("key"))) continue;
                            remoteAdMobEnabled = p.optBoolean("enabled", true);
                            remoteAdMobMaintenance = p.optBoolean("maintenanceMode", false);
                            JSONArray units = p.optJSONArray("units");
                            if (units != null) for (int j = 0; j < units.length(); j++) {
                                JSONObject u = units.optJSONObject(j); if (u == null || !u.optBoolean("enabled", true)) continue;
                                String format = u.optString("format", ""); String unitId = u.optString("unitId", "");
                                if (unitId.isEmpty()) continue;
                                if ("banner".equals(format) && !unitId.isEmpty()) remoteBannerUnitId = unitId;
                                if ("native".equals(format) && !unitId.isEmpty()) remoteNativeUnitId = unitId;
                                if ("interstitial".equals(format) && !unitId.isEmpty()) remoteInterstitialUnitId = unitId;
                            }
                        }
                    }
                } catch (Exception ignored) {}
            } catch (Exception ignored) {}
        });
    }

    private void loadBackendContent() {
        if (BACKEND_URL.contains("REPLACE-WITH-YOUR-WORKER")) {
            channels.clear();
            showCategory("TV");
            hideNotice();
            Toast.makeText(this, "Connect the One TV backend to load TV channels.", Toast.LENGTH_LONG).show();
            return;
        }
        network.execute(() -> {
            List<Channel> loaded = new ArrayList<>();
            Notice loadedNotice = null;
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/channels"));
                JSONArray arr = root.optJSONArray("channels");
                if (arr != null) for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    loaded.add(new Channel(o.optInt("id"), o.optString("number"), o.optString("name"), o.optString("country"), o.optString("category", "TV"), o.optString("streamUrl"), o.optString("sourceType", "link"), o.optString("youtubeVideoId"), o.optString("programName"), o.optInt("viewerCount"), o.optBoolean("showViewerCount"), o.optBoolean("loop")));
                }
            } catch (Exception ignored) { loaded = null; }
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/notice"));
                if (root.optBoolean("enabled")) loadedNotice = new Notice(root.optString("type"), root.optString("title"), root.optString("html"), root.optString("mediaUrl"), root.optString("linkUrl"));
            } catch (Exception ignored) {}
            final List<Channel> result = loaded;
            final Notice notice = loadedNotice;
            runOnUiThread(() -> {
                if (result != null) {
                    channels.clear(); channels.addAll(result);
                    if (!"Cricket Live".equals(currentCategory)) showCategory(currentCategory);
                    if (player == null && !channels.isEmpty()) {
                        int first = firstIndexForCategory("TV");
                        if (first >= 0) playChannel(first);
                    }
                }
                activeNotice = notice;
                if (notice != null && "TV".equals(currentCategory)) renderNotice(notice); else hideNotice();
            });
        });
    }

    private int firstIndexForCategory(String cat) {
        for (int i = 0; i < channels.size(); i++) {
            Channel c = channels.get(i);
            if ("TV".equals(cat) && "TV".equalsIgnoreCase(c.category)) return i;
            if ("Movie & Drama".equals(cat) && ("Movies".equalsIgnoreCase(c.category) || "Movie & Drama".equalsIgnoreCase(c.category))) return i;
        }
        return channels.isEmpty() ? -1 : 0;
    }

    private void playChannel(int index) {
        if (channels.isEmpty()) return;
        currentIndex = (index + channels.size()) % channels.size();
        Channel c = channels.get(currentIndex);
        if (player == null) {
            player = new ExoPlayer.Builder(this).build();
            playerView.setPlayer(player);
            player.addListener(new Player.Listener() {
                @Override public void onPlayerError(PlaybackException error) { Toast.makeText(MainActivity.this, "Unable to play this stream", Toast.LENGTH_SHORT).show(); }
            });
        }
        if ("youtube".equalsIgnoreCase(c.sourceType) && c.youtubeVideoId != null && !c.youtubeVideoId.isEmpty()) {
            player.pause();
            playerView.setVisibility(View.GONE);
            youtubeWebView.setVisibility(View.VISIBLE);
            loadYouTubeVideo(c.youtubeVideoId, c.loop || "Movies".equalsIgnoreCase(c.category));
            if (pauseResumeButton != null) pauseResumeButton.setImageResource(R.drawable.ic_pause);
            playbackPaused = false;
        } else {
            youtubeWebView.setVisibility(View.GONE);
            playerView.setVisibility(View.VISIBLE);
            if (c.url == null || c.url.trim().isEmpty()) {
                Toast.makeText(this, "No playable stream configured", Toast.LENGTH_SHORT).show();
                return;
            }
            player.setMediaItem(MediaItem.fromUri(Uri.parse(c.url)));
            player.setRepeatMode(c.loop || "Movies".equalsIgnoreCase(c.category) ? Player.REPEAT_MODE_ONE : Player.REPEAT_MODE_OFF);
            player.prepare(); player.play();
            if (pauseResumeButton != null) pauseResumeButton.setImageResource(R.drawable.ic_pause);
            playbackPaused = false;
        }
        updateNowPlaying(c);
        pingViewer();
        showControlsTemporarily();
    }

    private void loadYouTubeVideo(String id, boolean loop) {
        String safe = id.replaceAll("[^A-Za-z0-9_-]", "");
        if (safe.length() != 11) return;
        String loopParam = loop ? "&loop=1&playlist=" + safe : "";
        youtubeReady = false;
        String html = "<html><body style='margin:0;background:#000;overflow:hidden'><iframe width='100%' height='100%' src='https://www.youtube.com/embed/" + safe + "?autoplay=1&playsinline=1&rel=0&modestbranding=1&controls=0&enablejsapi=1&origin=https%3A%2F%2Fwww.youtube.com" + loopParam + "' frameborder='0' allow='autoplay; encrypted-media; picture-in-picture; fullscreen' allowfullscreen></iframe></body></html>";
        youtubeWebView.loadDataWithBaseURL("https://www.youtube.com/", html, "text/html", "UTF-8", null);
    }

    private void loadCricket(String mode) {
        final long requestToken = ++sportsRequestToken;
        if (cricketHeader != null) cricketHeader.setText("Cricket");
        if (cricketList == null || BACKEND_URL.contains("REPLACE-WITH-YOUR-WORKER")) {
            showCricketMessage("Connect the One TV Worker to load live cricket scores.");
            return;
        }
        cricketList.removeAllViews();
        showCricketMessage("Loading " + mode + " matches…");
        network.execute(() -> {
            try {
                String body = getUrl(BACKEND_URL + "/cricket/" + mode);
                JSONObject root = new JSONObject(body);
                JSONArray matches = root.optJSONArray("matches");
                runOnUiThread(() -> { if (requestToken == sportsRequestToken && "cricket".equals(currentSport) && "Cricket Live".equals(currentCategory)) renderCricketMatches(matches, mode); });
            } catch (Exception e) {
                runOnUiThread(() -> { if (requestToken == sportsRequestToken && "cricket".equals(currentSport) && "Cricket Live".equals(currentCategory)) showCricketMessage("Cricket data is temporarily unavailable."); });
            }
        });
    }

    private void renderCricketMatches(JSONArray matches, String mode) {
        if (sportsRefreshButton != null) sportsRefreshButton.setVisibility(View.VISIBLE);
        cricketList.removeAllViews();
        cricketUpdated.setText("Updated just now");
        if (matches == null || matches.length() == 0) {
            showCricketMessage(mode.equals("live") ? "No live matches right now." : "No matches found.");
            return;
        }
        for (int i = 0; i < matches.length(); i++) {
            try { cricketList.addView(matchCard(matches.getJSONObject(i))); }
            catch (Exception ignored) {}
        }
        insertNativeAdIntoCurrentList();
    }

    private View matchCard(JSONObject m) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(round(themeCard(), 18));
        card.setElevation(dp(2));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(cp);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView comp = text(m.optString("competition", "LIVE MATCH"), 11, Color.GRAY, true);
        top.addView(comp, new LinearLayout.LayoutParams(0, -2, 1));
        String rawStatus = m.optString("status", m.optString("state", ""));
        boolean live = isLiveStatus(rawStatus);
        TextView status = liveBadge(live ? "● LIVE" : prettyStatus(rawStatus));
        top.addView(status, new LinearLayout.LayoutParams(-2, dp(30)));
        card.addView(top);

        LinearLayout matchup = new LinearLayout(this);
        matchup.setGravity(Gravity.CENTER_VERTICAL);
        matchup.setPadding(0, dp(12), 0, dp(6));
        JSONObject home = teamFromMatch(m, true);
        JSONObject away = teamFromMatch(m, false);
        matchup.addView(teamBlock(home, true), new LinearLayout.LayoutParams(0, -2, 1));
        TextView vs = text("VS", 13, Color.rgb(20, 112, 196), true);
        vs.setGravity(Gravity.CENTER);
        matchup.addView(vs, new LinearLayout.LayoutParams(dp(38), -2));
        matchup.addView(teamBlock(away, false), new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(matchup);

        TextView meta = text(matchMetaText(m), 11, Color.GRAY, false);
        meta.setGravity(Gravity.CENTER);
        meta.setPadding(0, dp(4), 0, dp(10));
        card.addView(meta);

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        footer.setBackground(round(darkMode ? Color.rgb(26,39,51) : Color.rgb(239,246,252), 13));
        TextView state = text(live ? "LIVE NOW" : prettyStatus(rawStatus), 12, Color.rgb(0, 137, 123), true);
        TextView tap = text("VIEW SCORECARD  ›", 11, Color.rgb(20, 112, 196), true);
        tap.setGravity(Gravity.RIGHT);
        footer.addView(state, new LinearLayout.LayoutParams(0, dp(48), 1));
        footer.addView(tap, new LinearLayout.LayoutParams(0, dp(48), 1));
        card.addView(footer);

        String matchId = m.optString("id", m.optString("match", ""));
        if (!matchId.isEmpty()) {
            card.setOnClickListener(v -> {
                if ("cricket".equals(currentSport)) loadCricketDetail(matchId, m);
                else loadSportDetail(currentSport, matchId, m);
            });
            card.setClickable(true);
        }
        card.setAlpha(0f);
        card.setTranslationY(dp(8));
        card.animate().alpha(1f).translationY(0f).setDuration(260).start();
        return card;
    }

    private boolean isLiveStatus(String s) {
        String x = String.valueOf(s).toLowerCase();
        return x.contains("live") || x.contains("in play") || x.contains("playing") || x.contains("started") || x.equals("1");
    }

    private String prettyStatus(String s) {
        if (s == null || s.trim().isEmpty()) return "SCHEDULED";
        String x = s.replace('_', ' ').trim();
        return x.length() > 18 ? x.substring(0, 18) : x.toUpperCase();
    }

    private TextView liveBadge(String label) {
        TextView t = text(label, 11, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), 0, dp(10), 0);
        t.setBackground(round(isLiveStatus(label) ? Color.rgb(224, 52, 76) : Color.rgb(20,112,196), 18));
        if (label.startsWith("●")) {
            t.animate().alpha(0.72f).setDuration(700).withEndAction(() -> t.animate().alpha(1f).setDuration(700).start()).start();
        }
        return t;
    }

    private JSONObject teamFromMatch(JSONObject m, boolean home) {
        JSONObject t = m.optJSONObject(home ? "home" : "away");
        if (t != null) return t;
        JSONArray teams = m.optJSONArray("teams");
        if (teams != null && teams.length() > (home ? 0 : 1)) return teams.optJSONObject(home ? 0 : 1);
        return new JSONObject();
    }

    private View teamBlock(JSONObject t, boolean left) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        String name = t.optString("name", "Team");
        ImageView logo = teamLogoView(t.optString("logo", ""), name);
        box.addView(logo, new LinearLayout.LayoutParams(dp(52), dp(52)));
        TextView nameView = text(name, 14, themePrimaryText(), true);
        nameView.setGravity(Gravity.CENTER);
        nameView.setMaxLines(2);
        nameView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nameView.setPadding(dp(2), dp(5), dp(2), 0);
        box.addView(nameView, new LinearLayout.LayoutParams(-1, dp(42)));
        String score = t.optString("score", "");
        TextView scoreView = text(score.isEmpty() ? "-" : score, 19, themePrimaryText(), true);
        scoreView.setGravity(Gravity.CENTER);
        box.addView(scoreView, new LinearLayout.LayoutParams(-1, -2));
        String slug = t.optString("slug", t.optString("id", ""));
        if (!slug.isEmpty()) {
            View.OnClickListener listener = v -> loadTeamSummary(currentSport, slug, name, t.optString("logo", ""));
            nameView.setOnClickListener(listener);
            logo.setOnClickListener(listener);
            nameView.setContentDescription("Open " + name + " team summary");
            logo.setContentDescription("Open " + name + " team summary");
        }
        return box;
    }

    private ImageView teamLogoView(String url, String name) {
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        iv.setPadding(dp(5), dp(5), dp(5), dp(5));
        iv.setBackground(round(darkMode ? Color.rgb(31,42,54) : Color.rgb(239,245,249), 24));
        if (url != null && !url.trim().isEmpty()) loadRemoteImage(iv, url);
        else iv.setImageDrawable(initialsDrawable(name));
        return iv;
    }

    private android.graphics.drawable.Drawable initialsDrawable(String name) {
        TextView dummy = new TextView(this);
        dummy.setText(initials(name)); dummy.setTextSize(13); dummy.setTextColor(Color.rgb(20,112,196)); dummy.setGravity(Gravity.CENTER);
        dummy.setTypeface(null, Typeface.BOLD);
        dummy.setBackground(round(darkMode ? Color.rgb(31,42,54) : Color.rgb(239,245,249), 24));
        dummy.measure(View.MeasureSpec.makeMeasureSpec(dp(48), View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(dp(48), View.MeasureSpec.EXACTLY));
        dummy.layout(0,0,dp(48),dp(48));
        android.graphics.Bitmap b = Bitmap.createBitmap(dp(48), dp(48), Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c = new android.graphics.Canvas(b); dummy.draw(c);
        return new android.graphics.drawable.BitmapDrawable(getResources(), b);
    }

    private String initials(String name) {
        String[] p = String.valueOf(name).trim().split("\\s+");
        if (p.length == 0) return "TV";
        if (p.length == 1) return p[0].substring(0, Math.min(2, p[0].length())).toUpperCase();
        return (p[0].substring(0,1) + p[p.length-1].substring(0,1)).toUpperCase();
    }

    private String matchMetaText(JSONObject m) {
        String time = m.optString("startsAt", m.optString("time", ""));
        String venue = m.optString("venue", "");
        if (!venue.isEmpty() && !time.isEmpty()) return time + "  •  " + venue;
        if (!venue.isEmpty()) return venue;
        return time;
    }

    private void loadSportDetail(String sport, String matchId) { loadSportDetail(sport, matchId, null); }

    private void loadSportDetail(String sport, String matchId, JSONObject fallbackMatch) {
        cricketDetail = true;
        if (sportsRefreshButton != null) sportsRefreshButton.setVisibility(View.GONE);
        cricketList.removeAllViews();
        showCricketMessage("Loading match center…");
        network.execute(() -> {
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/sports/" + sport + "/match/" + Uri.encode(matchId)));
                runOnUiThread(() -> renderSportsDetail(root, sport));
            } catch (Exception e) {
                runOnUiThread(() -> { if (fallbackMatch != null) renderSportsDetail(wrapMatch(fallbackMatch), sport); else showCricketMessage("Match information is temporarily unavailable."); });
            }
        });
    }

    private void loadCricketDetail(String matchId) { loadCricketDetail(matchId, null); }

    private void loadCricketDetail(String matchId, JSONObject fallbackMatch) {
        if (matchId == null || matchId.isEmpty()) return;
        cricketDetail = true;
        if (sportsRefreshButton != null) sportsRefreshButton.setVisibility(View.GONE);
        cricketList.removeAllViews();
        showCricketMessage("Loading scorecard…");
        network.execute(() -> {
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/cricket/match/" + Uri.encode(matchId)));
                runOnUiThread(() -> renderSportsDetail(root, "cricket"));
            } catch (Exception e) {
                runOnUiThread(() -> { if (fallbackMatch != null) renderSportsDetail(wrapMatch(fallbackMatch), "cricket"); else showCricketMessage("Scorecard is temporarily unavailable."); });
            }
        });
    }

    private JSONObject wrapMatch(JSONObject match) {
        JSONObject root = new JSONObject();
        try { root.put("match", match); } catch (Exception ignored) {}
        return root;
    }

    private void renderSportsDetail(JSONObject root, String sport) {
        if (sportsRefreshButton != null) sportsRefreshButton.setVisibility(View.GONE);
        cricketDetail = true; currentDetailSport = sport;
        cricketList.removeAllViews();
        JSONObject m = root.optJSONObject("match"); if (m == null) m = root;
        currentDetailMatch = m;

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(0,dp(2),0,dp(4));
        Button back = iconTextButton("‹", 28, "Back to matches");
        back.setOnClickListener(v -> { cricketDetail=false; teamDetail=false; selectSportsCategory("cricket".equals(sport)?"Cricket Live":"SPORT:"+sport); });
        top.addView(back,new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout titleBox=new LinearLayout(this);titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.addView(text(firstString(m,"name","match","title",sportName(sport)+" Match"),16,themePrimaryText(),true));
        titleBox.addView(text(firstString(m,"competition","series","tournament","Match Center"),10,themeSecondaryText(),false));
        top.addView(titleBox,new LinearLayout.LayoutParams(0,-2,1));
        TextView live=liveBadge(isLiveStatus(m.optString("status",""))?"● LIVE":"MATCH");top.addView(live,new LinearLayout.LayoutParams(-2,dp(30)));
        cricketList.addView(top);

        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setPadding(dp(14),dp(12),dp(14),dp(12));hero.setBackground(round(darkMode?Color.rgb(12,45,36):Color.rgb(235,248,243),18));
        LinearLayout teams=new LinearLayout(this);teams.setGravity(Gravity.CENTER_VERTICAL);
        JSONObject ht=teamFromMatch(m,true),at=teamFromMatch(m,false);teams.addView(detailTeam(ht,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView vs=text("VS",13,Color.rgb(30,205,138),true);vs.setGravity(Gravity.CENTER);teams.addView(vs,new LinearLayout.LayoutParams(dp(38),-2));teams.addView(detailTeam(at,false),new LinearLayout.LayoutParams(0,-2,1));hero.addView(teams);
        String meta=matchMetaText(m);if(!meta.isEmpty()){TextView mt=text(meta,10,themeSecondaryText(),false);mt.setGravity(Gravity.CENTER);mt.setPadding(0,dp(7),0,0);hero.addView(mt);}
        String result=firstString(m,"result","status_text","status","");if(!result.isEmpty()){TextView rt=text(result,11,Color.rgb(30,205,138),true);rt.setGravity(Gravity.CENTER);rt.setPadding(0,dp(5),0,0);hero.addView(rt);}
        cricketList.addView(hero);

        HorizontalScrollView tabScroll=new HorizontalScrollView(this);tabScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs=new LinearLayout(this);tabs.setPadding(0,dp(8),0,dp(8));
        String[] labels="cricket".equals(sport)?new String[]{"Overview","Live","Scorecard","Squads","Overs","Commentary","Highlights","Stats","Info"}:new String[]{"Overview","Live","Stats","Lineups","H2H","Standings","Timeline","Info"};
        for(String label:labels){Button b=pillButton(label,10,dp(38));b.setTextColor(themePrimaryText());b.setBackground(round(themePill(),14));b.setOnClickListener(v->renderDetailTab(label,m,sport));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(38));lp.setMargins(dp(3),0,dp(3),0);tabs.addView(b,lp);}tabScroll.addView(tabs);cricketList.addView(tabScroll);
        renderDetailTab("Overview",m,sport);
        cricketUpdated.setText("Match Center • data supplied by the ONE TV sports backend");
    }

    private void renderDetailTab(String tab, JSONObject m, String sport) {
        // Remove content after the tab strip while preserving the header/hero/tabs.
        while (cricketList.getChildCount() > 4) cricketList.removeViewAt(4);
        if ("Overview".equals(tab)) renderMatchOverview(m,sport);
        else if ("Live".equals(tab)) renderLiveTab(m,sport);
        else if ("Scorecard".equals(tab) && "cricket".equals(sport)) renderCricketScorecardSections(m);
        else if ("Squads".equals(tab) || "Lineups".equals(tab)) renderLineups(m);
        else if ("Overs".equals(tab)) renderOversTab(m);
        else if ("Commentary".equals(tab)) renderCommentaryTab(m);
        else if ("Highlights".equals(tab)) renderHighlightsTab(m);
        else if ("Stats".equals(tab)) renderStatsTab(m,sport);
        else if ("H2H".equals(tab)) renderH2HTab(m);
        else if ("Standings".equals(tab)) renderStandingsTab(m);
        else if ("Timeline".equals(tab)) renderTimelineTab(m);
        else renderInfoTab(m);
    }

    private void renderMatchOverview(JSONObject m,String sport){
        addSectionTitle("MATCH OVERVIEW","Essential information");
        String[][] rows={{"Date",firstString(m,"date","startDate","startsAt","time","Not available")},{"Venue",firstString(m,"venue","venue_name","stadium","Not available")},{"Series",firstString(m,"competition","series","tournament","Not available")},{"Toss",firstString(m,"toss","toss_result","Not available")},{"Status",firstString(m,"status_text","status","state","Scheduled")},{"Result",firstString(m,"result","result_text","Not available")}};
        for(String[] r:rows)cricketList.addView(statRow(r[0],r[1],"INFO"));
        if(!"cricket".equals(sport))renderGenericSportsSections(m,sport);
    }

    private void renderLiveTab(JSONObject m,String sport){
        addSectionTitle("LIVE STATE","Current match state");
        cricketList.addView(statRow("Status",firstString(m,"status_text","status","state","Not available"),"LIVE"));
        cricketList.addView(statRow("Current score",firstString(m,"score","home_score","away_score","Not available"),"SCORE"));
        cricketList.addView(statRow("Required",firstString(m,"required","required_runs","requiredRunRate","Not available"),"INFO"));
        JSONArray current=firstArray(m,"currentPlayers","current_players","batters","batsmen");
        if(current!=null){addSectionTitle("CURRENT PLAYERS","Live player state");for(int i=0;i<Math.min(6,current.length());i++){JSONObject p=current.optJSONObject(i);if(p!=null)cricketList.addView(playerRow(firstString(p,"name","player","player_name","Player"),firstString(p,"role","position",""),firstString(p,"photo","image","avatar","")));}}
    }

    private void renderOversTab(JSONObject m){
        addSectionTitle("OVER BY OVER","Delivery-level data when supplied by the provider");
        JSONArray balls=firstArray(m,"balls","ball_by_ball","ballByBall","deliveries","overs","commentary");
        if(balls!=null)for(int i=0;i<Math.min(60,balls.length());i++)cricketList.addView(cricketBallRow(balls.opt(i),i));else cricketList.addView(statRow("Overs","Not available from provider","INFO"));
    }
    private void renderCommentaryTab(JSONObject m){
        addSectionTitle("COMMENTARY","Ball-by-ball commentary");
        JSONArray a=firstArray(m,"commentary","comments","timeline","balls");
        if(a!=null)for(int i=0;i<Math.min(60,a.length());i++){Object x=a.opt(i);cricketList.addView(cricketBallRow(x,i));}else cricketList.addView(statRow("Commentary","Not available from provider","INFO"));
    }
    private void renderHighlightsTab(JSONObject m){
        addSectionTitle("HIGHLIGHTS","Key match moments");
        JSONArray a=firstArray(m,"highlights","keyMoments","moments");
        if(a!=null)for(int i=0;i<Math.min(20,a.length());i++){Object x=a.opt(i);String v=x instanceof JSONObject?firstString((JSONObject)x,"title","text","description","event",""):String.valueOf(x);cricketList.addView(statRow(String.valueOf(i+1),v,"HIGHLIGHT"));}else cricketList.addView(statRow("Highlights","No provider highlights available","INFO"));
    }
    private void renderStatsTab(JSONObject m,String sport){
        addSectionTitle("MATCH STATS","Provider statistics");
        String[] keys={"possession","shots","shotsOnTarget","corners","fouls","yellowCards","redCards","points","period1","period2","period3","period4"};
        for(String k:keys){if(m.has(k))cricketList.addView(statRow(k, String.valueOf(m.opt(k)),"STAT"));}
        if("cricket".equals(sport)){renderCricketScorecardSections(m);}else if(m.optJSONArray("stats")!=null){JSONArray a=m.optJSONArray("stats");for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)cricketList.addView(statRow(firstString(o,"name","label","Stat"),firstString(o,"value","home","text","Not available"),"STAT"));}}
    }
    private void renderH2HTab(JSONObject m){
        addSectionTitle("HEAD TO HEAD","Historical meetings when supplied");JSONArray a=firstArray(m,"h2h","headToHead","head_to_head");
        if(a!=null)for(int i=0;i<Math.min(20,a.length());i++){Object x=a.opt(i);String v=x instanceof JSONObject?firstString((JSONObject)x,"name","result","text","match",""):String.valueOf(x);cricketList.addView(statRow(String.valueOf(i+1),v,"H2H"));}else cricketList.addView(statRow("Head to head","Not available from provider","INFO"));
    }
    private void renderStandingsTab(JSONObject m){
        addSectionTitle("STANDINGS","Competition table when supplied");JSONArray a=firstArray(m,"standings","table","leagueTable");
        if(a!=null)for(int i=0;i<Math.min(30,a.length());i++){JSONObject o=a.optJSONObject(i);if(o!=null)cricketList.addView(statRow(firstString(o,"team","name","Team"),firstString(o,"points","pts","position","Not available"),"TABLE"));}else cricketList.addView(statRow("Standings","Open the competition page when supported by the provider","INFO"));
    }
    private void renderTimelineTab(JSONObject m){
        addSectionTitle("MATCH TIMELINE","Goals, cards, substitutions or major events");JSONArray a=firstArray(m,"timeline","events","incidents");
        if(a!=null)for(int i=0;i<Math.min(40,a.length());i++){Object x=a.opt(i);String v=x instanceof JSONObject?firstString((JSONObject)x,"text","description","event","type",""):String.valueOf(x);cricketList.addView(eventRow(v,i+1));}else cricketList.addView(statRow("Timeline","Not available from provider","INFO"));
    }
    private void renderInfoTab(JSONObject m){
        addSectionTitle("MATCH INFORMATION","Detailed metadata");
        cricketList.addView(statRow("Venue",firstString(m,"venue","venue_name","stadium","Not available"),"INFO"));
        cricketList.addView(statRow("Competition",firstString(m,"competition","series","tournament","Not available"),"INFO"));
        cricketList.addView(statRow("Date / time",firstString(m,"date","startsAt","time","Not available"),"INFO"));
        cricketList.addView(statRow("Provider",firstString(m,"provider","source","SportScore"),"INFO"));
    }

    private View detailTeam(JSONObject t, boolean left) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        String teamName = t.optString("name", "Team");
        ImageView logo = teamLogoView(t.optString("logo", ""), teamName);
        box.addView(logo, new LinearLayout.LayoutParams(dp(64), dp(64)));
        TextView name = text(teamName, 16, themePrimaryText(), true);
        name.setGravity(Gravity.CENTER);
        name.setMaxLines(2);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        box.addView(name, new LinearLayout.LayoutParams(-1, dp(44)));
        TextView score = text(t.optString("score", "-"), 26, themePrimaryText(), true);
        score.setGravity(Gravity.CENTER);
        box.addView(score, new LinearLayout.LayoutParams(-1, -2));
        String slug = t.optString("slug", t.optString("id", ""));
        if (!slug.isEmpty()) {
            View.OnClickListener listener = v -> loadTeamSummary(currentSport, slug, teamName, t.optString("logo", ""));
            name.setOnClickListener(listener);
            logo.setOnClickListener(listener);
        }
        return box;
    }

    private void renderCricketScorecardSections(JSONObject m) {
        addSectionTitle("SCORECARD", "Live innings and match state");
        JSONArray innings = firstArray(m, "innings", "scorecard", "innings_data");
        if (innings != null && innings.length() > 0) {
            for (int i = 0; i < innings.length(); i++) {
                JSONObject in = innings.optJSONObject(i);
                if (in == null) continue;
                String team = firstString(in, "team", "team_name", "name", "batting_team", "Innings " + (i + 1));
                String score = firstString(in, "score", "score_text", "total", "runs", "");
                String overs = firstString(in, "overs", "over", "overs_text", "");
                cricketList.addView(scorecardInningsRow(team, score, overs));
                renderBattingTable(in);
                renderBowlingTable(in);
            }
        } else {
            JSONArray teams = m.optJSONArray("teams");
            if (teams != null) {
                for (int i = 0; i < teams.length(); i++) {
                    JSONObject t = teams.optJSONObject(i);
                    if (t == null) continue;
                    cricketList.addView(scorecardInningsRow(t.optString("name", "Team"), t.optString("score", "-"), firstString(t, "overs", "over", "overs_text", "")));
                }
            }
        }
        addSectionTitle("BALL BY BALL", "Latest delivery-by-delivery commentary");
        JSONArray balls = firstArray(m, "balls", "ball_by_ball", "ballByBall", "deliveries", "commentary", "timeline");
        if (balls != null && balls.length() > 0) {
            int shown = Math.min(30, balls.length());
            for (int i = 0; i < shown; i++) cricketList.addView(cricketBallRow(balls.opt(i), i));
        } else {
            cricketList.addView(statRow("Ball-by-ball", "Not available from provider", "INFO"));
        }
        addSectionTitle("MATCH INFO", "Official match information");
        String venue = firstString(m, "venue", "venue_name", "stadium", "");
        String competition = firstString(m, "competition", "league", "tournament", "");
        if (!venue.isEmpty()) cricketList.addView(statRow("Venue", venue, "INFO"));
        if (!competition.isEmpty()) cricketList.addView(statRow("Competition", competition, "INFO"));
        String status = firstString(m, "status", "status_text", "state", "");
        if (!status.isEmpty()) cricketList.addView(statRow("Status", status, "STATUS"));
        renderLineups(m);
    }

    private JSONArray firstArray(JSONObject o, String... keys) {
        for (String key : keys) {
            JSONArray a = o.optJSONArray(key);
            if (a != null && a.length() > 0) return a;
        }
        return null;
    }

    private String firstString(JSONObject o, String... keys) {
        String fallback = "";
        if (keys.length > 0) fallback = keys[keys.length - 1];
        for (int i = 0; i < keys.length - 1; i++) {
            String v = o.optString(keys[i], "").trim();
            if (!v.isEmpty()) return v;
        }
        return fallback;
    }

    private View scorecardInningsRow(String team, String score, String overs) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(14), dp(12), dp(14), dp(12));
        r.setBackground(round(darkMode ? Color.rgb(25,37,49) : Color.rgb(239,246,252), 14));
        r.addView(text(team, 14, themePrimaryText(), true));
        r.addView(text(score.isEmpty() ? "-" : score, 23, Color.rgb(0,137,123), true));
        if (!overs.isEmpty()) r.addView(text("Overs " + overs, 11, Color.GRAY, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(8)); r.setLayoutParams(lp); return r;
    }

    private void renderBattingTable(JSONObject in) {
        JSONArray bats = firstArray(in, "batsmen", "batters", "batting");
        if (bats == null) return;
        addSectionTitle("BATTING", "Current batsmen");
        for (int i = 0; i < Math.min(11, bats.length()); i++) {
            JSONObject p = bats.optJSONObject(i); if (p == null) continue;
            cricketList.addView(cricketStatLine(
                    firstString(p, "name", "player", "player_name", "Batsman"),
                    firstString(p, "runs", "score", "r", "-"),
                    firstString(p, "balls", "b", "ball_count", "-"),
                    firstString(p, "fours", "4s", "four", "-"),
                    firstString(p, "sixes", "6s", "six", "-"),
                    firstString(p, "strike_rate", "strikeRate", "sr", "-")));
        }
    }

    private void renderBowlingTable(JSONObject in) {
        JSONArray bowlers = firstArray(in, "bowlers", "bowling");
        if (bowlers == null) return;
        addSectionTitle("BOWLING", "Current bowlers");
        for (int i = 0; i < Math.min(8, bowlers.length()); i++) {
            JSONObject p = bowlers.optJSONObject(i); if (p == null) continue;
            cricketList.addView(cricketStatLine(
                    firstString(p, "name", "player", "player_name", "Bowler"),
                    firstString(p, "overs", "o", "-"),
                    firstString(p, "maidens", "m", "-"),
                    firstString(p, "runs", "r", "-"),
                    firstString(p, "wickets", "w", "-"),
                    firstString(p, "economy", "econ", "-")));
        }
    }

    private View cricketStatLine(String name, String a, String b, String c, String d, String e) {
        LinearLayout r = new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(dp(10), dp(8), dp(10), dp(8));
        r.addView(text(name, 12, themePrimaryText(), true), new LinearLayout.LayoutParams(0, dp(42), 1));
        for (String v : new String[]{a,b,c,d,e}) {
            TextView x = text(v, 10, themePrimaryText(), false); x.setGravity(Gravity.CENTER); r.addView(x, new LinearLayout.LayoutParams(dp(42), dp(42)));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0,0,0,dp(2)); r.setLayoutParams(lp); return r;
    }

    private View cricketBallRow(Object x, int index) {
        JSONObject o = x instanceof JSONObject ? (JSONObject) x : null;
        String over = o == null ? String.valueOf(index + 1) : firstString(o, "over", "ball", "delivery", "number", String.valueOf(index + 1));
        String textValue = o == null ? String.valueOf(x) : firstString(o, "commentary", "text", "description", "event", "result", "");
        String runs = o == null ? "" : firstString(o, "runs", "score", "total", "");
        String wicket = o == null ? "" : firstString(o, "wicket", "wickets", "dismissal", "");
        if (textValue.isEmpty()) textValue = (runs.isEmpty() ? "Delivery" : runs + " run(s)") + (wicket.isEmpty() ? "" : " • " + wicket);
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(10),dp(8),dp(10),dp(8));
        TextView ov = text(over,11,Color.rgb(20,112,196),true); ov.setGravity(Gravity.CENTER); ov.setBackground(round(darkMode?Color.rgb(30,47,63):Color.rgb(232,241,249),12)); row.addView(ov,new LinearLayout.LayoutParams(dp(52),dp(36)));
        TextView body=text(textValue,12,themePrimaryText(),false); body.setPadding(dp(10),0,0,0); row.addView(body,new LinearLayout.LayoutParams(0,-2,1));
        if(!runs.isEmpty()){TextView rv=text(runs,12,Color.rgb(0,137,123),true);rv.setGravity(Gravity.CENTER);row.addView(rv,new LinearLayout.LayoutParams(dp(42),dp(36)));}
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(3));row.setLayoutParams(lp);return row;
    }

    private void loadTeamSummary(String sport, String slug, String fallbackName, String logoUrl) {
        if (slug == null || slug.trim().isEmpty()) return;
        teamDetail = true; cricketDetail = true;
        if (sportsRefreshButton != null) sportsRefreshButton.setVisibility(View.GONE);
        cricketList.removeAllViews(); showCricketMessage("Loading team summary…");
        network.execute(() -> {
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/sports/" + sport + "/team/" + Uri.encode(slug)));
                runOnUiThread(() -> renderTeamSummary(root, sport, fallbackName, logoUrl));
            } catch (Exception e) {
                runOnUiThread(() -> showCricketMessage("Team summary is temporarily unavailable."));
            }
        });
    }

    private void renderTeamSummary(JSONObject root, String sport, String fallbackName, String logoUrl) {
        cricketList.removeAllViews();
        JSONObject team = root.optJSONObject("team");
        String name = team == null ? fallbackName : team.optString("name", fallbackName);
        String logo = team == null ? logoUrl : team.optString("logo", logoUrl);
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        Button back = pillButton("‹",20,dp(42));
        back.setOnClickListener(v -> { teamDetail=false; cricketDetail=false; selectSportsCategory("cricket".equals(sport)?"Cricket Live":"SPORT:"+sport); });
        top.addView(back,new LinearLayout.LayoutParams(dp(44),dp(42)));
        TextView h=text(sportName(sport)+"  •  TEAM SUMMARY",12,Color.rgb(0,137,123),true);h.setGravity(Gravity.CENTER);top.addView(h,new LinearLayout.LayoutParams(0,dp(42),1));
        cricketList.addView(top);
        LinearLayout hero=new LinearLayout(this);hero.setGravity(Gravity.CENTER_VERTICAL);hero.setPadding(dp(16),dp(16),dp(16),dp(16));hero.setBackground(round(darkMode?Color.rgb(19,31,42):Color.WHITE,20));
        ImageView iv=teamLogoView(logo,name);hero.addView(iv,new LinearLayout.LayoutParams(dp(70),dp(70)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(14),0,0,0);info.addView(text(name,20,themePrimaryText(),true));
        String form=firstString(root,"form","recentForm","record",""); if(!form.isEmpty())info.addView(text(form,12,Color.rgb(0,137,123),true));
        String competition=firstString(root,"competition","league","");if(!competition.isEmpty())info.addView(text(competition,11,Color.GRAY,false));
        hero.addView(info,new LinearLayout.LayoutParams(0,-2,1));cricketList.addView(hero);
        JSONArray recent=root.optJSONArray("recent");if(recent==null)recent=root.optJSONArray("results");JSONArray upcoming=root.optJSONArray("upcoming");JSONArray matches=root.optJSONArray("matches");
        if(recent!=null&&recent.length()>0){addSectionTitle("RECENT MATCHES","Latest team results");for(int i=0;i<Math.min(10,recent.length());i++)cricketList.addView(teamMatchRow(recent.optJSONObject(i)));}
        if(upcoming!=null&&upcoming.length()>0){addSectionTitle("UPCOMING","Next scheduled matches");for(int i=0;i<Math.min(10,upcoming.length());i++)cricketList.addView(teamMatchRow(upcoming.optJSONObject(i)));}
        if((recent==null||recent.length()==0)&&(upcoming==null||upcoming.length()==0)&&matches!=null){addSectionTitle("MATCHES","Team schedule");for(int i=0;i<Math.min(15,matches.length());i++)cricketList.addView(teamMatchRow(matches.optJSONObject(i)));}
        if((recent==null||recent.length()==0)&&(upcoming==null||upcoming.length()==0)&&(matches==null||matches.length()==0))cricketList.addView(statRow("Team schedule","Not available from provider","INFO"));
    }

    private View teamMatchRow(JSONObject m) {
        if(m==null)return statRow("Match","Not available","INFO");
        JSONObject h=m.optJSONObject("home"),a=m.optJSONObject("away");String hn=h!=null?h.optString("name","Home"):m.optString("home","Home");String an=a!=null?a.optString("name","Away"):m.optString("away","Away");String hs=h!=null?h.optString("score",""):m.optString("home_score","");String as=a!=null?a.optString("score",""):m.optString("away_score","");String status=firstString(m,"status","status_text","state","Scheduled");String time=firstString(m,"time","startsAt","start_time","");
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(12),dp(10),dp(12),dp(10));r.setBackground(round(darkMode?Color.rgb(25,37,49):Color.rgb(239,246,252),14));
        TextView teams=text(hn+"   "+(hs.isEmpty()?"-":hs)+"  VS  "+(as.isEmpty()?"-":as)+"   "+an,12,themePrimaryText(),true);teams.setGravity(Gravity.CENTER);teams.setMaxLines(2);r.addView(teams);r.addView(text(status+(time.isEmpty()?"":" • "+time),10,Color.GRAY,false));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(6));r.setLayoutParams(lp);return r;
    }

    private void renderGenericSportsSections(JSONObject m, String sport) {
        addSectionTitle("MATCH TIMELINE", "Live events");
        JSONArray timeline=m.optJSONArray("timeline");
        if(timeline!=null && timeline.length()>0) for(int i=0;i<Math.min(12,timeline.length());i++) cricketList.addView(eventRow(String.valueOf(timeline.opt(i)), i+1));
        else cricketList.addView(statRow("Match status", m.optString("status","Scheduled"), "STATUS"));
        addSectionTitle("LINEUPS", "Players");
        renderLineups(m);
        addSectionTitle("MATCH INFO", "Venue and competition");
        cricketList.addView(statRow("Venue", m.optString("venue","Not available"), "INFO"));
        cricketList.addView(statRow("Competition", m.optString("competition","Not available"), "INFO"));
    }

    private void renderLineups(JSONObject m) {
        JSONArray lineups=m.optJSONArray("lineups");
        if(lineups==null || lineups.length()==0) return;
        addSectionTitle("PLAYERS", "Squads and key players");
        for(int i=0;i<Math.min(22,lineups.length());i++) {
            JSONObject p=lineups.optJSONObject(i);
            if(p==null) continue;
            String name=p.optString("name",p.optString("player",p.optString("player_name","Player")));
            String role=p.optString("role",p.optString("position",""));
            String image=p.optString("photo",p.optString("image",p.optString("avatar","")));
            cricketList.addView(playerRow(name,role,image));
        }
    }

    private void addSectionTitle(String title, String subtitle) {
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(4),dp(14),dp(4),dp(7));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL);
        tx.addView(text(title,15,themePrimaryText(),true)); tx.addView(text(subtitle,10,themeSecondaryText(),false));
        row.addView(tx,new LinearLayout.LayoutParams(0,-2,1)); cricketList.addView(row);
    }

    private View statRow(String left,String right,String tag) {
        LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(dp(14),dp(9),dp(14),dp(9)); r.setBackground(round(darkMode?Color.rgb(24,35,46):Color.rgb(240,246,250),14));
        TextView l=text(left,13,Color.WHITE,false); TextView rr=text(right,14,Color.rgb(0,137,123),true); rr.setGravity(Gravity.RIGHT); r.addView(l,new LinearLayout.LayoutParams(0,dp(42),1)); r.addView(rr,new LinearLayout.LayoutParams(0,dp(42),1));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(6)); r.setLayoutParams(lp); return r;
    }

    private View eventRow(String event,int index) {
        LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(dp(10),dp(7),dp(10),dp(7));
        TextView n=text(String.valueOf(index),11,Color.WHITE,true); n.setGravity(Gravity.CENTER); n.setBackground(round(Color.rgb(20,112,196),20)); r.addView(n,new LinearLayout.LayoutParams(dp(28),dp(28)));
        TextView e=text(event,12,Color.WHITE,false); e.setPadding(dp(10),0,0,0); r.addView(e,new LinearLayout.LayoutParams(0,dp(38),1)); return r;
    }

    private View playerRow(String name,String role,String imageUrl) {
        LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(dp(10),dp(7),dp(10),dp(7)); r.setBackground(round(themeCard(),14));
        ImageView iv=teamLogoView(imageUrl,name); r.addView(iv,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(10),0,0,0); tx.addView(text(name,13,Color.WHITE,true)); tx.addView(text(role,10,Color.GRAY,false)); r.addView(tx,new LinearLayout.LayoutParams(0,dp(50),1));
        return r;
    }

    private void showCricketMessage(String message) {
        cricketList.removeAllViews();
        TextView t = text(message, 14, Color.LTGRAY, false); t.setGravity(Gravity.CENTER); t.setPadding(dp(20), dp(60), dp(20), dp(60)); cricketList.addView(t);
    }

    private String getUrl(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(15000); c.setRequestMethod("GET");
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()))) {
            StringBuilder b = new StringBuilder(); String line;
            while ((line = r.readLine()) != null) b.append(line);
            return b.toString();
        } finally { c.disconnect(); }
    }

    private void pingViewer() {
        if (BACKEND_URL.contains("REPLACE-WITH-YOUR-WORKER") || channels.isEmpty()) return;
        if (currentIndex < 0 || currentIndex >= channels.size()) return;
        int id = channels.get(currentIndex).id;
        if (id <= 0) return;
        network.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(BACKEND_URL + "/viewer/ping").openConnection();
                c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json");
                byte[] body = new JSONObject().put("viewerId", viewerId).put("channelId", id).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
                try (OutputStream out = c.getOutputStream()) { out.write(body); }
                c.getResponseCode();
            } catch (Exception ignored) {} finally { if (c != null) c.disconnect(); }
        });
    }

    private void updateNowPlaying(Channel c) {
        nowPlayingName.setText(c.name);
        nowPlayingProgram.setText("Now Playing: " + (c.programName == null || c.programName.trim().isEmpty() ? "—" : c.programName));
        if (c.showViewers && c.viewerCount > 0) {
            viewerCountView.setVisibility(View.VISIBLE);
            viewerCountView.setText("👁 " + c.viewerCount + " viewers");
        } else viewerCountView.setVisibility(View.GONE);
    }

    private void renderNotice(Notice n) {
        if (!"TV".equals(currentCategory)) { hideNotice(); return; }
        if (n == null) { hideNotice(); return; }
        String type = n.type == null ? "text" : n.type.toLowerCase();
        String html; int fallbackHeightDp;
        if ("banner".equals(type)) {
            html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head><body style='margin:0;background:#0b0f14'><img src='" + esc(n.mediaUrl) + "' style='width:100%;height:auto;display:block'></body></html>"; fallbackHeightDp = 100;
        } else if ("video".equals(type)) {
            html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head><body style='margin:0;background:#000'><video src='" + esc(n.mediaUrl) + "' controls autoplay muted playsinline loop style='width:100%;height:auto;display:block'></video></body></html>"; fallbackHeightDp = 170;
        } else {
            html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head><body style='margin:0;background:#0b0f14;color:#fff'><div style='padding:10px 14px;box-sizing:border-box'>" + n.html + "</div></body></html>"; fallbackHeightDp = 100;
        }
        noticeContainer.setVisibility(View.VISIBLE);
        ViewGroup.LayoutParams lp = noticeContainer.getLayoutParams(); lp.height = 0; noticeContainer.setLayoutParams(lp);
        noticeWebView.loadDataWithBaseURL("https://onetv.local/", html, "text/html", "UTF-8", null);
        resizeNoticeToContent(fallbackHeightDp, 250);
        resizeNoticeToContent(fallbackHeightDp, 900);
    }

    private void resizeNoticeToContent(int fallbackHeightDp, long delayMs) {
        handler.postDelayed(() -> {
            if (noticeContainer == null || noticeWebView == null || noticeContainer.getVisibility() != View.VISIBLE) return;
            float density = getResources().getDisplayMetrics().density;
            int contentPx = (int) (noticeWebView.getContentHeight() * density);
            int fallbackPx = (int) (fallbackHeightDp * density);
            ViewGroup.LayoutParams lp = noticeContainer.getLayoutParams();
            lp.height = Math.max(contentPx, fallbackPx);
            noticeContainer.setLayoutParams(lp);
        }, delayMs);
    }

    private void hideNotice() {
        if (noticeContainer == null) return;
        noticeContainer.setVisibility(View.GONE);
        ViewGroup.LayoutParams lp = noticeContainer.getLayoutParams(); lp.height = 0; noticeContainer.setLayoutParams(lp);
    }

    private String esc(String s) { return s == null ? "" : s.replace("&", "&amp;").replace("\"", "&quot;").replace("'", "&#39;").replace("<", "&lt;").replace(">", "&gt;"); }

    private Button playerControlButton(String label) { Button b = new Button(this); b.setText(label); b.setTextSize(17); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setMinHeight(0); b.setMinWidth(0); b.setGravity(Gravity.CENTER); b.setIncludeFontPadding(false); b.setPadding(0,0,0,0); b.setBackground(round(Color.argb(105, 255, 255, 255), 11)); return b; }
    private ImageButton playerIconButton(int iconRes, String description, View.OnClickListener listener) { ImageButton b = new ImageButton(this); b.setImageResource(iconRes); b.setContentDescription(description); b.setScaleType(ImageButton.ScaleType.CENTER_INSIDE); b.setPadding(dp(7),dp(7),dp(7),dp(7)); b.setBackground(round(Color.argb(105, 255, 255, 255), 11)); b.setOnClickListener(listener); return b; }
    private Button controlButton(String label) { Button b = new Button(this); b.setText(label); b.setTextSize(12); b.setAllCaps(false); return b; }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); int resolved = (color == Color.WHITE) ? themePrimaryText() : (color == Color.LTGRAY || color == Color.GRAY ? themeSecondaryText() : color); t.setTextColor(resolved); t.setTextSize(size); if (bold) t.setTypeface(null, Typeface.BOLD); return t; }
    private GradientDrawable round(int color, float radius) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }

    private void setControlsVisible(boolean visible) { controlsVisible = visible; playerControls.setVisibility(visible ? View.VISIBLE : View.GONE); }
    private void toggleControls() { if (controlsVisible) { setControlsVisible(false); handler.removeCallbacks(hideControls); } else showControlsTemporarily(); }
    private void showControlsTemporarily() { setControlsVisible(true); handler.removeCallbacks(hideControls); handler.postDelayed(hideControls, 3500); }
    private void togglePlayback() {
        if (youtubeWebView != null && youtubeWebView.getVisibility() == View.VISIBLE) {
            if (!playbackPaused) { sendYouTubeCommand("pauseVideo", "[]"); pauseResumeButton.setImageResource(R.drawable.ic_play); playbackPaused = true; }
            else { sendYouTubeCommand("playVideo", "[]"); pauseResumeButton.setImageResource(R.drawable.ic_pause); playbackPaused = false; }
        } else if (player != null) {
            if (player.isPlaying()) { player.pause(); pauseResumeButton.setImageResource(R.drawable.ic_play); playbackPaused = true; }
            else { player.play(); pauseResumeButton.setImageResource(R.drawable.ic_pause); playbackPaused = false; }
        }
        showControlsTemporarily();
    }
    private void sendYouTubeCommand(String func, String args) {
        if (youtubeWebView == null) return;
        if (!youtubeReady) { pendingYoutubeCommand = func; return; }
        String payload = "{\"event\":\"command\",\"func\":\"" + func + "\",\"args\":" + args + "}";
        String js = "(function(){var f=document.querySelector('iframe');if(f){f.contentWindow.postMessage('" + payload.replace("'", "\\'") + "','*');}})()";
        youtubeWebView.evaluateJavascript(js, null);
    }

    private void updateTimeline() {
        if (timelineSeekBar == null) return;
        if (player == null || youtubeWebView == null && playerView == null || youtubeWebView.getVisibility() == View.VISIBLE || !player.isCurrentMediaItemSeekable()) {
            timelineSeekBar.setEnabled(false);
            timelineSeekBar.setProgress(0);
            return;
        }
        long duration = player.getDuration();
        long position = player.getCurrentPosition();
        if (duration > 0 && duration != androidx.media3.common.C.TIME_UNSET) {
            timelineSeekBar.setEnabled(true);
            timelineSeekBar.setProgress((int)Math.max(0, Math.min(1000, (position * 1000L) / duration)));
        } else {
            timelineSeekBar.setEnabled(false);
            timelineSeekBar.setProgress(0);
        }
    }

    private void adjustVolume(float d) { if (player == null) return; int p=(int)(player.getVolume()*100); setVolumePercent(Math.max(0, Math.min(100, p + Math.round(d*100)))); showControlsTemporarily(); }
    private void setVolumePercent(int percent) {
        lastVolume = Math.max(1, percent);
        if (youtubeWebView != null && youtubeWebView.getVisibility() == View.VISIBLE) sendYouTubeCommand("setVolume", "[" + percent + "]");
        else if (player != null) player.setVolume(Math.max(0, Math.min(1, percent / 100f)));
    }
    private void toggleMute() {
        if (youtubeWebView != null && youtubeWebView.getVisibility() == View.VISIBLE) {
            if (lastVolume > 0) { sendYouTubeCommand("setVolume", "[0]"); lastVolume = 0; }
            else { lastVolume = 100; sendYouTubeCommand("setVolume", "[100]"); }
        } else if (player != null) {
            if (player.getVolume() > 0) { lastVolume = Math.max(1, (int)(player.getVolume()*100)); setVolumePercent(0); }
            else setVolumePercent(lastVolume > 0 ? lastVolume : 100);
        }
        showControlsTemporarily();
    }

    private void showVolumePopup(View anchor) {
        if (volumePopup != null && volumePopup.isShowing()) { volumePopup.dismiss(); return; }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setPadding(dp(12), dp(8), dp(12), dp(8));
        box.setBackground(round(darkMode ? Color.rgb(28,34,42) : Color.WHITE, 14));
        SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        int initial = player != null ? Math.round(player.getVolume()*100) : lastVolume;
        bar.setProgress(initial);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { if (fromUser) setVolumePercent(progress); }
            public void onStartTrackingTouch(SeekBar seekBar) { handler.removeCallbacks(hideControls); }
            public void onStopTrackingTouch(SeekBar seekBar) { showControlsTemporarily(); }
        });
        box.addView(bar, new LinearLayout.LayoutParams(dp(180), dp(42)));
        volumePopup = new PopupWindow(box, dp(210), dp(58), true);
        volumePopup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        volumePopup.setOutsideTouchable(true);
        volumePopup.setElevation(dp(8));
        volumePopup.showAsDropDown(anchor, -dp(175), -dp(65));
        showControlsTemporarily();
    }
    private void showQualityMenu(View anchor) {
        PopupWindow popup = new PopupWindow(this); LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(8,8,8,8); box.setBackgroundColor(Color.rgb(35,40,48));
        for (String q : new String[]{"Auto","1080p","720p","480p","360p"}) {
            Button b = controlButton(q);
            b.setOnClickListener(v -> {
                if (youtubeWebView != null && youtubeWebView.getVisibility() == View.VISIBLE) sendYouTubeCommand("setPlaybackQuality", "[\"" + q + "\"]");
                Toast.makeText(this, "Quality: " + q, Toast.LENGTH_SHORT).show(); popup.dismiss(); showControlsTemporarily();
            });
            box.addView(b, new LinearLayout.LayoutParams(dp(180), dp(48)));
        }
        popup.setContentView(box); popup.setWidth(220); popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT); popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.rgb(35,40,48))); popup.setOutsideTouchable(true); popup.setFocusable(true); popup.showAsDropDown(anchor); showControlsTemporarily();
    }
    private void toggleFullscreen() {
        if (videoFrame == null) return;
        isFullscreen = !isFullscreen;
        ViewGroup decor = (ViewGroup) getWindow().getDecorView();
        if (isFullscreen) {
            videoFrameOriginalParent = (ViewGroup) videoFrame.getParent();
            videoFrameOriginalIndex = videoFrameOriginalParent != null ? videoFrameOriginalParent.indexOfChild(videoFrame) : 0;
            if (videoFrameOriginalParent != null) videoFrameOriginalParent.removeView(videoFrame);
            decor.addView(videoFrame, new ViewGroup.LayoutParams(-1, -1));
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            if (adSection != null) adSection.setVisibility(View.GONE);
            if (footerView != null) footerView.setVisibility(View.GONE);
            if (sportsAttributionView != null) sportsAttributionView.setVisibility(View.GONE);
            showControlsTemporarily();
        } else {
            decor.removeView(videoFrame);
            if (videoFrameOriginalParent != null) {
                videoFrameOriginalParent.addView(videoFrame, Math.min(videoFrameOriginalIndex, videoFrameOriginalParent.getChildCount()), new LinearLayout.LayoutParams(-1, normalPlayerHeight));
            }
            getWindow().getDecorView().setSystemUiVisibility(darkMode ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            if (adSection != null) adSection.setVisibility(View.VISIBLE);
            if (footerView != null) footerView.setVisibility(View.VISIBLE);
            if (sportsAttributionView != null) sportsAttributionView.setVisibility(currentCategory.startsWith("SPORT:") || "Cricket Live".equals(currentCategory) ? View.VISIBLE : View.GONE);
            showControlsTemporarily();
        }
    }

    private int themeBackground() { return darkMode ? Color.rgb(7,16,29) : Color.rgb(247,249,252); }
    private int themePrimaryText() { return darkMode ? Color.WHITE : Color.rgb(25,30,36); }
    private int themeSecondaryText() { return darkMode ? Color.LTGRAY : Color.rgb(92,99,108); }
    private int themeCard() { return darkMode ? Color.rgb(17,31,48) : Color.WHITE; }
    private int themePill() { return darkMode ? Color.rgb(27,42,58) : Color.rgb(232,236,241); }

    private void applySystemTheme() {
        getWindow().setStatusBarColor(darkMode ? Color.rgb(8,12,18) : Color.rgb(247,249,252));
        getWindow().setNavigationBarColor(darkMode ? Color.BLACK : Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(darkMode ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }

    private void toggleTheme() {
        darkMode = !darkMode;
        prefs.edit().putBoolean("dark_mode", darkMode).apply();
        String keepCategory = currentCategory;
        int keepIndex = currentIndex;
        boolean wasPlaying = player != null && player.isPlaying();
        buildUi();
        if (keepIndex >= 0 && keepIndex < channels.size() && wasPlaying && !keepCategory.startsWith("SPORT:") && !"Cricket Live".equals(keepCategory)) { playChannel(keepIndex); }
        loadBackendContent();
        currentCategory = keepCategory;
        showCategory(keepCategory);
        applySystemTheme();
    }

    private void applyThemeToViewTree(View view, boolean inPlayer) {
        boolean playerArea = inPlayer || view == videoFrame || view == playerControls || view == playerView || view == youtubeWebView;
        if (!playerArea) {
            if (view instanceof TextView) {
                TextView tv = (TextView)view;
                int c = tv.getCurrentTextColor();
                if (c == Color.WHITE || c == Color.LTGRAY || c == Color.GRAY) tv.setTextColor(themePrimaryText());
            }
            if (view instanceof Button && view != themeToggleButton) ((Button) view).setTextColor(themePrimaryText());
        }
        if (view instanceof ViewGroup) {
            ViewGroup group=(ViewGroup)view;
            for(int i=0;i<group.getChildCount();i++) applyThemeToViewTree(group.getChildAt(i), playerArea);
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null); if (volumePopup != null) volumePopup.dismiss(); network.shutdownNow();
        if (player != null) { player.release(); player = null; }
        if (noticeWebView != null) noticeWebView.destroy(); if (youtubeWebView != null) youtubeWebView.destroy();
        if (nativeAd != null) { nativeAd.destroy(); nativeAd = null; }
        if (bottomNativeAd1 != null) { bottomNativeAd1.destroy(); bottomNativeAd1 = null; }
        if (bottomNativeAd2 != null) { bottomNativeAd2.destroy(); bottomNativeAd2 = null; }
        super.onDestroy();
    }

    static class Channel {
        int id, viewerCount; String number, name, country, category, url, sourceType, youtubeVideoId, programName; boolean showViewers, loop;
        Channel(int id, String number, String name, String country, String category, String url, String sourceType, String youtubeVideoId, String programName, int viewerCount, boolean showViewers, boolean loop) { this.id=id;this.number=number;this.name=name;this.country=country;this.category=category;this.url=url;this.sourceType=sourceType;this.youtubeVideoId=youtubeVideoId;this.programName=programName;this.viewerCount=viewerCount;this.showViewers=showViewers;this.loop=loop; }
    }
    static class Notice { String type,title,html,mediaUrl,linkUrl; Notice(String t,String ti,String h,String m,String l){type=t;title=ti;html=h;mediaUrl=m;linkUrl=l;} }
}
