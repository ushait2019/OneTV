CREATE TABLE IF NOT EXISTS ad_platforms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  platform_key TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 0,
  priority INTEGER NOT NULL DEFAULT 100,
  fallback_priority INTEGER NOT NULL DEFAULT 100,
  maintenance_mode INTEGER NOT NULL DEFAULT 0,
  environment TEXT NOT NULL DEFAULT 'test',
  sdk_ready INTEGER NOT NULL DEFAULT 0,
  adapter_type TEXT NOT NULL DEFAULT 'sdk',
  app_id TEXT NOT NULL DEFAULT '',
  account_id TEXT NOT NULL DEFAULT '',
  publisher_id TEXT NOT NULL DEFAULT '',
  api_key TEXT NOT NULL DEFAULT '',
  api_secret TEXT NOT NULL DEFAULT '',
  config_json TEXT NOT NULL DEFAULT '{}',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ad_platform_units (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  platform_id INTEGER NOT NULL,
  app_key TEXT NOT NULL DEFAULT 'onetv',
  format TEXT NOT NULL,
  placement TEXT NOT NULL DEFAULT 'global',
  unit_id TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1,
  priority INTEGER NOT NULL DEFAULT 100,
  country TEXT NOT NULL DEFAULT '*',
  config_json TEXT NOT NULL DEFAULT '{}',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(platform_id, app_key, format, placement, country),
  FOREIGN KEY(platform_id) REFERENCES ad_platforms(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_ad_platforms_enabled_priority ON ad_platforms(enabled, priority);
CREATE INDEX IF NOT EXISTS idx_ad_units_lookup ON ad_platform_units(platform_id, app_key, format, placement, enabled, priority);

INSERT OR IGNORE INTO ad_platforms(platform_key,name,enabled,priority,fallback_priority,maintenance_mode,environment,sdk_ready,adapter_type)
VALUES
('admob','Google AdMob',1,10,10,0,'live',1,'sdk'),
('applovin','AppLovin',0,20,20,0,'test',0,'sdk'),
('unity_levelplay','Unity Ads / LevelPlay',0,30,30,0,'test',0,'sdk'),
('meta_audience','Meta Audience Network',0,40,40,0,'test',0,'sdk'),
('liftoff','Liftoff Monetize',0,50,50,0,'test',0,'sdk'),
('inmobi','InMobi',0,60,60,0,'test',0,'sdk'),
('pangle','Pangle',0,70,70,0,'test',0,'sdk'),
('mintegral','Mintegral',0,80,80,0,'test',0,'sdk'),
('digital_turbine','Digital Turbine / DT Exchange',0,90,90,0,'test',0,'sdk'),
('bigo','BIGO Ads',0,100,100,0,'test',0,'sdk');

INSERT OR IGNORE INTO ad_platform_units(platform_id,app_key,format,placement,unit_id,enabled,priority,country)
SELECT id,'onetv','banner','sports_footer','ca-app-pub-5981864080922785/5178976268',1,10,'*' FROM ad_platforms WHERE platform_key='admob';
INSERT OR IGNORE INTO ad_platform_units(platform_id,app_key,format,placement,unit_id,enabled,priority,country)
SELECT id,'onetv','native','content_list','ca-app-pub-5981864080922785/1737269754',1,10,'*' FROM ad_platforms WHERE platform_key='admob';
INSERT OR IGNORE INTO ad_platform_units(platform_id,app_key,format,placement,unit_id,enabled,priority,country)
SELECT id,'onetv','interstitial','navigation','ca-app-pub-5981864080922785/7592231664',1,10,'*' FROM ad_platforms WHERE platform_key='admob';
