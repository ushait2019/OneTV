CREATE TABLE IF NOT EXISTS channels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_number TEXT NOT NULL,
  name TEXT NOT NULL,
  country TEXT NOT NULL DEFAULT 'International',
  category TEXT NOT NULL DEFAULT 'TV',
  logo_url TEXT NOT NULL DEFAULT '',
  stream_url TEXT NOT NULL DEFAULT '',
  source_type TEXT NOT NULL DEFAULT 'link',
  source_value TEXT NOT NULL DEFAULT '',
  api_key TEXT NOT NULL DEFAULT '',
  program_name TEXT NOT NULL DEFAULT '',
  program_api_url TEXT NOT NULL DEFAULT '',
  show_viewers INTEGER NOT NULL DEFAULT 0,
  loop_playback INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_channels_active_sort ON channels(active, sort_order, id);

CREATE TABLE IF NOT EXISTS notices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL DEFAULT 'text',
  title TEXT NOT NULL DEFAULT '',
  html_content TEXT NOT NULL DEFAULT '',
  media_url TEXT NOT NULL DEFAULT '',
  link_url TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notices_active_sort ON notices(active, sort_order, id);


CREATE TABLE IF NOT EXISTS viewer_sessions (
  viewer_id TEXT PRIMARY KEY,
  channel_id INTEGER NOT NULL,
  last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_viewer_sessions_channel_seen ON viewer_sessions(channel_id, last_seen);

CREATE TABLE IF NOT EXISTS channel_views (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_id INTEGER NOT NULL,
  viewer_id TEXT NOT NULL,
  started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_channel_views_channel ON channel_views(channel_id);
CREATE INDEX IF NOT EXISTS idx_channel_views_started ON channel_views(started_at);

-- Remote ad platform registry. Native SDK execution still depends on the SDKs bundled in the Android binary.
CREATE TABLE IF NOT EXISTS ad_platforms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  platform_key TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 0,
  priority INTEGER NOT NULL DEFAULT 100,
  fallback_priority INTEGER NOT NULL DEFAULT 100,
  maintenance_mode INTEGER NOT NULL DEFAULT 0,
  environment TEXT NOT NULL DEFAULT 'test',
  sdk_ready INTEGER NOT NULL DEFAULT 0,
  adapter_type TEXT NOT NULL DEFAULT 'sdk',
  app_id TEXT NOT NULL DEFAULT '',
  account_id TEXT NOT NULL DEFAULT '',
  publisher_id TEXT NOT NULL DEFAULT '',
  api_key TEXT NOT NULL DEFAULT '',
  api_secret TEXT NOT NULL DEFAULT '',
  config_json TEXT NOT NULL DEFAULT '{}',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ad_platform_units (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  platform_id INTEGER NOT NULL,
  app_key TEXT NOT NULL DEFAULT 'onetv',
  format TEXT NOT NULL,
  placement TEXT NOT NULL DEFAULT 'global',
  unit_id TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1,
  priority INTEGER NOT NULL DEFAULT 100,
  country TEXT NOT NULL DEFAULT '*',
  config_json TEXT NOT NULL DEFAULT '{}',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(platform_id, app_key, format, placement, country),
  FOREIGN KEY(platform_id) REFERENCES ad_platforms(id) ON DELETE CASCADE
);

INSERT OR IGNORE INTO ad_platforms(platform_key,name,enabled,priority,fallback_priority,sdk_ready,adapter_type) VALUES
('admob','Google AdMob',1,10,10,1,'sdk'),
('applovin','AppLovin',0,20,20,0,'sdk'),
('unity_levelplay','Unity Ads / LevelPlay',0,30,30,0,'sdk'),
('meta_audience','Meta Audience Network',0,40,40,0,'sdk'),
('liftoff','Liftoff Monetize',0,50,50,0,'sdk'),
('inmobi','InMobi',0,60,60,0,'sdk'),
('pangle','Pangle',0,70,70,0,'sdk'),
('mintegral','Mintegral',0,80,80,0,'sdk'),
('digital_turbine','Digital Turbine / DT Exchange',0,90,90,0,'sdk'),
('bigo','BIGO Ads',0,100,100,0,'sdk');
