ONE TV MASTER SOURCE - CURRENT BASELINE
Prepared: 2026-11-04

This package consolidates the latest available One TV v2.5.6 source snapshot,
the two project specification PDFs, and the supplied USHA IT brand assets.

IMPORTANT IMPLEMENTATION STATUS
- Existing Google Mobile Ads SDK dependency and Banner AdView integration are present.
- Backend currently seeds/configures 10 ad platform records and exposes /ads and admin controls.
- The current Android app only actively renders the AdMob banner integration.
- Native SDK adapters for AppLovin, Unity LevelPlay, Meta Audience Network, Liftoff,
  InMobi, Pangle, Mintegral, DT Exchange and BIGO are NOT integrated/verified in this snapshot.
- Additional ad formats (native, interstitial, rewarded, app-open, etc.) are NOT fully
  implemented as executable Android placements in this snapshot.
- Therefore this archive is a consolidated current source baseline, NOT a completed
  production-final build and NOT proof that all ad platforms/formats are operational.

Before production finalization, each SDK integration requires dependency/version and
Android compatibility checks, applicable account/app IDs and ad-unit configuration,
manifest/ProGuard review, consent/privacy compliance, test-device validation, and
provider-side approval. Backend switches cannot install a missing native SDK.

The supplied project PDFs remain the controlling project specifications. Preserve
existing UI, global bottom ad placements, provider logic and other locked requirements.
