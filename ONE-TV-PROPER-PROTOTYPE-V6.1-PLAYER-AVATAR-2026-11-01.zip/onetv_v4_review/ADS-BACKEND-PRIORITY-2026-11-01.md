# ONE TV Ads Backend Priority

The backend now stores 10 ad platforms: AdMob, AppLovin, Unity LevelPlay, Meta Audience Network, Liftoff Monetize, InMobi, Pangle, Mintegral, DT Exchange, and BIGO Ads.

Use the Admin > Ad Platforms tab to set Active and Priority. Keep 2-3 platforms active. The public `/ads` endpoint returns the top 3 active platforms in priority order.

Current executable ad integration in this prototype is AdMob Banner. Other platforms are configuration-ready only; they must have their native SDK/adapter bundled before the app can serve them. A backend toggle does not install an SDK.
