# One TV — Final Architecture

## Product
**One TV** by **USHA IT**

Android package: `com.ushait.onetv`

### Main menu
1. **TV** — video/live-stream based
2. **Movie & Drama** — video based
3. **Cricket Live** — score/API based only; no video player

## TV
Channel records live in Cloudflare D1. The Android app fetches active channels from the Worker. Adding/editing/removing a channel does not require an APK rebuild.

Supported source modes:
- Direct Link: authorized HLS/DASH/MP4/etc.
- API: Worker resolves an authorized API response to a playable URL.
- YouTube: Worker validates the video with YouTube Data API v3; Android uses the official YouTube embedded player.

Player controls are inside the video and auto-hide after a short period. Channel name and Now Playing are shown below the player. Viewer count is optional per channel.

## Movie & Drama
Uses the same backend content system. Direct authorized media can loop. YouTube content uses the official embedded player, not extracted/re-hosted YouTube media URLs.

## Cricket Live
Cricket Live is deliberately separate from video playback.

Screens:
- Live
- Upcoming
- Results / historical matches
- Match detail / scorecard

The app receives normalized cricket data from the Cloudflare Worker. The provider key stays server-side. Live data refreshes every 20 seconds while the Cricket Live screen is open.

Public Worker endpoints:
- `GET /cricket/live`
- `GET /cricket/upcoming`
- `GET /cricket/results`
- `GET /cricket/match/<MATCH_ID>`
- `GET /cricket/health`

The sports adapter uses SportScore as the primary provider, with OpenCricket as the cricket-only fallback. SportScore currently documents its public API as free forever, with no API key required, across cricket, football, basketball and tennis. The app keeps the required visible “Powered by SportScore” attribution.

## Backend
Cloudflare Worker + D1.

Required secrets:
- `ADMIN_TOKEN`
- `YOUTUBE_API_KEY` for YouTube sources

Optional variable:

## PC Admin Panel
`desktop-panel/` is a Windows Electron admin application. It connects directly to the Worker and manages channels, notices/personal ads, and viewer analytics.

Dashboard includes:
- live viewers per channel
- total views
- last-24-hour views
- unique viewer IDs

Build:
```bash
cd desktop-panel
npm install
npm run build
```

## Android build
The included GitHub Actions workflow builds Debug APK, Release APK and AAB. No Android Studio is required.

Set `BACKEND_URL` in:
`app/src/main/java/com/ushait/onetv/MainActivity.java`

Then push to GitHub and run the workflow.

## Important
Only use TV streams, movies, drama, and other media you are authorized to use or redistribute. The backend/API architecture does not grant distribution rights.
