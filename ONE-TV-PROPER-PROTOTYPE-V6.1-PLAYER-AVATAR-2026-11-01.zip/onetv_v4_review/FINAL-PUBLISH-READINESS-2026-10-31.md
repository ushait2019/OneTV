# One TV Final Publish Readiness

Date: 2026-10-31

## Final source pass completed
- Package: `com.ushait.onetv`
- Version: `1.6` / versionCode `7`
- Sports UI keeps the top application header fixed and the bottom attribution/ads/footer fixed.
- Sports middle content is the scrollable region.
- Two-finger pinch zoom is enabled for Sports content (0.85x–1.35x) without scaling the fixed top/bottom chrome.
- `Powered by SportScore` is plain, non-clickable text and appears immediately above the fixed ad area only on Sports screens.
- SportsScore attribution no longer opens an external browser.
- Bottom ad area is a dedicated two-card layout (`AD CARD 01` / `AD CARD 02`) with AdMob Native Advanced rendering when available.
- USHA IT is not printed inside the ad cards.
- Copyright remains `© 2026 USHA IT. All Rights Reserved.`
- Fullscreen video hides attribution, ads and footer and returns to the normal layout on exit.

## Sports data integrity fixes
- Added canonical provider-aware match IDs.
- Provider match IDs are preserved separately from canonical ONE TV match IDs.
- Duplicate matches are removed deterministically.
- Upstream sport mismatch is rejected instead of being relabeled as the requested sport.
- Fixed a match-detail fallback bug caused by undefined `homeName` / `awayName` references.
- SportScore detail requests unwrap the canonical ID before calling the provider.
- OpenCricket fallback IDs are also canonicalized and can be resolved back to the provider ID.
- Primary and fallback providers remain isolated. Their payloads are never merged into one hybrid match.

## Validation completed in this environment
- Cloudflare Worker JavaScript syntax: PASS (`node --check`)
- Uploaded release APK signature verification: PASS
- Uploaded release AAB signature verification: PASS
- Source ZIP extraction/integrity: PASS
- No real Cloudflare/API secrets added to the source package.

## Binary build limitation
The uploaded `OneTV-release.apk` and `OneTV-release.aab` are the original binaries supplied with this task. The source has now been advanced to version 1.6/versionCode 7, so those original binaries are intentionally not represented as the 1.6 build.

This environment does not contain the Android SDK/Gradle toolchain and has no network access for downloading it. Therefore a newly compiled 1.6 APK/AAB cannot be truthfully claimed as built here. The source is prepared for the final release build, but the binary must be compiled once in an Android build environment before publishing.
