# ONE TV UI Prototype V2

This package updates the Android prototype to follow the supplied four-screen visual direction.

- Home: no hero photo; sports + entertainment tiles and live-now content.
- Sports front pages: dynamic Cricket / Football / Basketball / Tennis labels and sport-specific match-center content.
- Match pages: full middle area is used for match content; the persistent sport selector is removed from the match detail view.
- Match details vary by sport: cricket scorecard/squads/commentary, football timeline/stats/lineups, basketball quarters/stats, tennis sets/stats.
- Entertainment front pages: dynamic TV / Movies / News / Kids sections with featured content and in-app player flow.
- ONE TV logo + All in One remain in the global header on every normal page.
- Android Back returns to the previous screen state. Fullscreen player returns to the previous player layout.
- Selection toasts were removed.
- Ads remain in a dedicated bottom area and never cover match/player content.
- Backend data is used when available; a deterministic demo feed keeps the prototype usable when an endpoint is unavailable.

Reference research: Cricbuzz and CREX were used for information architecture such as live/upcoming/results, competitions, match center, scorecards, commentary and player/team detail. The visual system remains ONE TV-specific rather than copying their interface.
