# ONE TV V6 Proper Prototype Fixes

Date: 2026-11-01

## UI / navigation
- Removed the top-right theme shortcut.
- Header now uses: menu, responsive ONE TV logo, All in One, Search, Notifications.
- Removed all page-local search boxes. Search is available only from the header.
- Menu now contains Sports, Entertainment, Notifications, Settings and About.
- Theme switching is inside Settings and toggles Normal / Dark without opening another theme page.
- Increased bottom safe-area padding so the footer does not collide with Android gesture/navigation indicators.
- Header and cards use responsive weights and compact dimensions for narrow devices.

## Sports Match Centre
- Removed the Home/Away placeholder wording from the match UI. Provider team names are used; missing names show `TBD` only.
- LIVE / UPCOMING / RESULTS now maintain their selected mode and do not reset to LIVE.
- Match detail loads the selected match from the backend provider endpoint before showing sport-specific detail data.
- Cricket, Football, Basketball and Tennis use separate provider-driven renderers.
- Sport-specific sections only display fields supplied by the provider. Missing fields show `Data unavailable` instead of fabricated values.
- The Android source no longer contains the previous demo-match helper/data.
- SportsScore attribution remains visible and non-clickable.

## Entertainment player
- The player is removed from the Entertainment landing page.
- A player opens only after the user opens a connected channel.
- Backend channels with no playable source show `COMING SOON` instead of a blank/broken player.
- The player no longer shows the old `10` / `10` buttons.
- Double-tap left/right seeks previous/next 10 seconds.
- Volume icon behavior: first tap opens a volume slider; when the slider is open, tapping the icon mutes; tapping the muted icon unmutes.
- The explanatory text line below the player was removed.
- Fullscreen remains available.

## Backend-driven data
- Active channels are returned even when their source is not connected, with a `connected` flag.
- `/search` searches backend channel data and provider live matches. No hard-coded search result catalog is published.
- `/notifications` returns backend notices and provider-driven sports state changes.
- Sports match detail keeps `rawProviderData` so the Android match centre can render fields supplied by the provider without inventing values.
- Added `sports_event_state` D1 table for centralized provider event-state tracking.

## Database migration
For an existing One TV D1 database, run:

`wrangler d1 execute one-tv-db --remote --file=migration-sports-events.sql`

Then deploy the updated Worker.
