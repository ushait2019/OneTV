# One TV Sports API Final Configuration

- Primary provider: SportScore
- Primary authentication: none
- Primary quota: approximately 10,000 requests / 24h / IP under the current attribution tier.
- Cricket fallback provider: OpenCricket API
- Fallback secret: `OPENCRICKET_API_KEY` (Cloudflare Worker Secret only)
- Fallback base URL: Worker variable `OPENCRICKET_BASE_URL` (default `https://opencricketapi.com`)
- Fallback is called only when SportScore fails, times out, returns invalid data, or returns an empty result.
- OpenCricket is cricket-only, so football/basketball/tennis do not use it as a cross-sport fallback.
- SportScore is always attempted first.
- Sports responses are edge-cached by the Worker to reduce upstream calls.
- Android never contains either sports API key.
- Android talks only to the One TV Worker.

## Important quota note
The current OpenCricket Starter documentation lists 5,000 authenticated requests **per month**, not per day. The Worker is therefore designed to use it only as a cricket fallback, never in parallel with SportScore.

## Future control
The app reads `/config` from the Worker for sports refresh timing. Provider credentials and the OpenCricket base URL remain backend-side, so they can be changed without rebuilding the Android app.
