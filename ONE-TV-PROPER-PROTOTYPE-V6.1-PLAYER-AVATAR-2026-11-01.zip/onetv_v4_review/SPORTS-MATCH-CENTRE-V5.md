# ONE TV International Sports Match Centre — V5

Date: 2026-11-01

## Goal

Turn the ONE TV sports match detail into a professional international-style match centre while preserving the existing ONE TV shell, ads, navigation and backend architecture.

## Shared shell

- Fixed match hero with competition, status, venue and match metadata.
- Horizontal sport-specific tabs with no text wrapping.
- Only the selected feature content scrolls.
- Android Back returns to the previous screen.
- SportsScore attribution is plain, non-clickable text.

## Cricket

Overview, Live, Scorecard, Squads, Overs, Commentary, Highlights, Series.

Core fields represented in the prototype: innings, score/wickets/overs, target, required runs, current run rate, required run rate, current batters, batting figures, bowling figures, partnerships, fall of wickets, extras, toss, day/session, venue and officials.

## Football

Overview, Live, Stats, Lineups, Timeline, Standings, H2H.

Core fields represented: score, match clock, possession, shots, shots on target, corners, fouls, offsides, passes, pass accuracy, tackles, saves, goals, cards, substitutions, VAR, formations and lineups.

## Basketball

Overview, Live, Box Score, Play-by-play, Lineups, Team Stats, Standings.

Core fields represented: quarter score, game clock, possession, team fouls, timeouts, player MIN/PTS/REB/AST/STL/BLK/TOV, FG%, 3PT%, FT%, team rebounds, offensive rebounds, assists, turnovers, steals, blocks and fouls.

## Tennis

Overview, Live, Scoreboard, Point-by-point, Stats, H2H, Draw.

Core fields represented: set/game/point score, server, break-point state, tiebreak state, aces, double faults, first-serve percentage, first/second serve points won, break points, winners, unforced errors, net points, rally length and serve speed when supplied.

## Data rule

The UI is sport-specific, but live values must ultimately come from the canonical normalized SportsScore payload. Demo values in this prototype are placeholders and must not be treated as live provider facts. Fields that may not be supplied by a provider are presented as provider-dependent.
