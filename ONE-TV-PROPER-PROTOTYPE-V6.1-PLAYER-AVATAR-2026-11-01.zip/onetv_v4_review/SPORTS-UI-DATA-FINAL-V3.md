# One TV Sports UI/Data Final V3 - 2026-10-31

## Purpose
Professional sports presentation with provider-backed data only. No demo sports cards, fabricated scores, fabricated player data, or hardcoded competition/standings content.

## Cricket
- Live / Upcoming / Results match cards use backend data.
- Match Center presents scorecard sections, innings, batting, bowling, ball-by-ball/commentary when supplied by the provider, and match information.
- If ball-by-ball is not supplied by the provider, the UI explicitly says it is unavailable instead of inventing deliveries.
- Team names are responsive to long names and can be tapped.
- Team tap opens a provider-backed Team Summary page with recent/upcoming fixtures when available.

## Other Sports
- Football, Basketball and Tennis use the same professional Match Center pattern.
- Team names/logos are responsive and can open provider-backed team summaries.

## Provider policy
- SportScore is always requested first.
- Cricket list/detail fallback remains OpenCricket only after SportScore failure/invalid/empty data.
- Team summaries use SportScore's documented team endpoint. If unavailable, the app shows an unavailable state rather than fabricated data.
- OpenCricket API keys remain server-side.

## Demo data
The Android app no longer seeds Demo TV / Demo Movie channels when the backend is not configured. It asks the user to connect the One TV backend instead.
