# ONE TV UI V4 Enhancements — 2026-11-01

## Navigation
- Bottom navigation removed.
- SPORTS and ENTERTAINMENT selectors are present only on Home.
- Child pages use Android Back to return to the previous screen.
- Global header search removed.
- Section-header search removed.
- Page-local search entry points remain.

## Notifications
- Header notification icon is now a bell with unread badge.
- Notification center prototype includes live-match and reminder cards.

## Sports
- Larger LIVE / UPCOMING / RESULTS buttons.
- Match detail scoreboard is fixed above the feature tabs.
- Feature tabs are horizontally scrollable and do not wrap.
- Each feature renders a separate prototype page/body.
- Additional sport directory pages are available.

## Search
The in-app prototype searches demo and backend-loaded concepts across:
- matches
- teams
- channels
- videos
- programs
- entertainment titles

## Player
The Media3 player uses its native timeline/controller and an additional touch-visible control layer:
- play/pause
- ±10 seconds
- mute
- playback speed
- quality selector prototype
- fullscreen
- auto-hide after approximately 3.5 seconds

## Build
- `versionCode = 10`
- `versionName = 1.9`
- Existing backend and AdMob configuration retained.
