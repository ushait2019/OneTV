plugins { id("com.android.application") }

android {
    buildFeatures {
        buildConfig = true
    }

    namespace = "com.ushait.onetv"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ushait.onetv"
        minSdk = 24
        targetSdk = 35
        versionCode = 12
        versionName = "2.1"

        val backendUrl = (project.findProperty("backendUrl") as String?)
            ?.trim()
            ?.trimEnd('/')
            ?.ifBlank { "https://one-tv-backend.ushait2019.workers.dev" }
            ?: "https://one-tv-backend.ushait2019.workers.dev"
        buildConfigField("String", "BACKEND_URL", "\"${backendUrl.replace("\"", "\\\"")}\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.2.0")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("com.google.android.gms:play-services-ads:25.5.0")
}
