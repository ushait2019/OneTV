# One TV Backend Sports V2

Date: 2026-10-31

## Provider order
1. **SportScore** is always attempted first.
2. **OpenCricket** is called only for cricket and only after SportScore fails, times out, returns invalid data, returns no matches, or cannot resolve cricket match detail.
3. The providers are never called in parallel.

## SportScore
- Public REST API, no API key required.
- Documented v1 fixtures endpoint: `/api/v1/fixtures/` with `sport`, `date`, `status`, and `limit`.
- Supports football, basketball, cricket and tennis.
- Worker keeps the required visible `Powered by SportScore` attribution in the Android sports UI.
- Worker edge cache reduces duplicate upstream calls.

## OpenCricket
- Cricket-only fallback.
- Worker secret: `OPENCRICKET_API_KEY`.
- Base URL variable: `OPENCRICKET_BASE_URL`.
- Current Starter quota is 5,000 requests/month.
- Key is never returned by `/config` and is never shipped in the Android APK.

## Match details
SportScore match detail is attempted first. If it fails for cricket, the Worker then attempts OpenCricket. OpenCricket-native `match_*` IDs are resolved directly; SportScore slugs are resolved against the current OpenCricket match catalog when possible.

## Public endpoints
- `GET /sports/{sport}/{live|upcoming|results}`
- `GET /sports/{sport}/match/{id}`
- `GET /cricket/live`
- `GET /cricket/upcoming`
- `GET /cricket/results`
- `GET /cricket/match/{id}`
- `GET /cricket/health`
- `GET /config`

Every sports response includes `primaryProvider`, the cricket `fallbackProvider`, and the actual `provider` used for that response.
