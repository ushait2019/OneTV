# One TV Dynamic Backend

Cloudflare Worker + D1 backend for One TV. The Android app reads `/channels` and `/notice`; `/notices` is also supported as a public alias. Admins manage channels and notices from `/admin`.

## What this solves
- Channel data is NOT hard-coded in the APK.
- Add/edit/disable/delete channels from the backend.
- All app users see active channels after the app refreshes its channel list.
- No APK rebuild is needed when a channel is added or its source changes.
- Each channel can use either a direct **Link** source or an **API** source.
- The admin form uses one dropdown: `Source: Link` or `Source: API`. The matching input appears automatically.
- API sources are resolved server-side, so API URLs and optional API keys are not exposed to the Android app.
- Stream URLs should only be for sources you are authorized to use/redistribute.

## Notice / Personal Ad section
The app has an optional responsive section between the player and AdMob area.

- If no notice is published, the section is hidden and takes **zero height**, so there is no blank gap.
- If a notice is published, it can be:
  - **Text**: rich HTML text with font family, size, bold, italic, underline, strike, alignment, lists, colors, highlights, links, and an Advanced HTML editor.
  - **Banner**: responsive image URL, with an optional click URL.
  - **Video**: responsive MP4/WebM URL with player controls.
- The admin panel supports publish/hide, edit, delete, and sort order.
- The app checks notices together with the channel refresh, about every 60 seconds while open.
- The public app receives only the published notice. Admin operations require `ADMIN_TOKEN`.

## Player controls
The channel name is no longer displayed above the controls. Player controls are compact and live **inside the bottom of the video**, similar to a modern video player:
- Previous
- Volume up
- Mute
- Quality menu
- Next
- Fullscreen

Controls appear when the user taps the player and auto-hide after a few seconds. Tapping again hides them.

## Source options
### Source: Link
Enter the direct playable stream URL, such as an authorized HLS, DASH, or MP4 URL.

### Source: API
Enter an API URL that returns the playable stream URL. An optional API key can be supplied. The Worker sends the key as both `Authorization: Bearer <key>` and `X-API-Key: <key>`.

The API response can be a direct URL or JSON containing one of these common fields:
`streamUrl`, `stream_url`, `stream`, `url`, `playUrl`, `play_url`, `sourceUrl`, `source_url`, including inside `data`, `result`, `source`, `channel`, or `response`.

Example API response:
`{"streamUrl":"https://example.com/live.m3u8"}`

## Deploy a new database
1. Install Node.js and Wrangler: `npm install -g wrangler`
2. Login: `wrangler login`
3. Create a D1 database: `wrangler d1 create one-tv-db`
4. Put the returned database ID into `wrangler.toml`.
5. Apply schema: `wrangler d1 execute one-tv-db --remote --file=schema.sql`
6. Set an admin secret: `wrangler secret put ADMIN_TOKEN`
7. Deploy: `wrangler deploy`
8. Open `https://YOUR-WORKER-DOMAIN/admin` in a browser and enter the same ADMIN_TOKEN.

## Existing database migration
If your D1 database was already created from the previous One TV schema, run:
`wrangler d1 execute one-tv-db --remote --file=migration-source.sql`

For this version, also create the notices table:
`wrangler d1 execute one-tv-db --remote --file=migration-notice.sql`

Then deploy the updated Worker.

## App endpoint
After deployment, set the GitHub Actions secret `ONETV_BACKEND_URL` to the Worker base URL. The Android build injects it through `BuildConfig.BACKEND_URL`; no source edit is required. For example:
`https://one-tv-backend.YOUR-SUBDOMAIN.workers.dev`

Then rebuild the APK once. After that, channel additions/edits, source changes, and notice/banner/video publishing do not require another APK rebuild. The app falls back to a placeholder URL only when the GitHub secret is not set.

## Movies, now-playing, and viewer count
- The channel category list includes TV, Movies, Sports, News, and Kids.
- Movies use the same source system and automatically repeat when the app plays them. Use a direct playable MP4/HLS/DASH URL. A normal YouTube webpage URL is not itself a direct Media3 stream URL.
- `program_name` can be used as the displayed current program/movie title. `program_api_url` may point to an authorized API that returns a title such as `programName`, `nowPlaying`, `program`, `showName`, or `title`; the Worker resolves it automatically.
- For direct streams, a current-program name can only be auto-detected when the source exposes usable metadata or an authorized EPG/program API. The backend cannot infer a TV program from an arbitrary video URL.
- Viewer counts are collected automatically with app heartbeat pings. Enable `show_viewers` for a channel when you want the count displayed. Sessions older than 90 seconds are not counted.
- `/viewer/ping` accepts `{ "viewerId": "...", "channelId": 123 }` and is called by the app automatically.

## PC Admin Panel and viewer analytics

The `desktop-panel` folder contains a Windows Electron admin app. It connects to the Worker using the same admin token, so you can manage channels and notices without opening Cloudflare.

The dashboard shows:
- Real-time active viewers per channel (5-second refresh in the desktop app)
- Total channel views
- Last 24-hour views
- Total unique viewer IDs seen by the backend

For an existing D1 database, run once:

`wrangler d1 execute one-tv-db --remote --file=migration-view-stats.sql`

The Android app's `/viewer/ping` heartbeat records a new view when a viewer starts a channel or switches channels. A heartbeat is not counted as a new view every 30 seconds.


### YouTube
For YouTube sources, set the Worker secret `YOUTUBE_API_KEY` to a Google API key with YouTube Data API v3 enabled. In the Channels form choose `YouTube` and paste the normal video URL. The server resolves metadata; the Android app uses the official embedded player.

## Sports Live score API

The One TV app has a dedicated **Sports** section for Cricket, Football, Basketball and Tennis. It does not contain a video player. The Worker proxies normalized score data to the Android app.

Provider: **SportScore** (`https://sportscore.com/`). The current provider documentation states that the public API is free forever, requires no API key, supports these four sports, and offers approximately 10,000 requests per 24 hours per IP on the free tier. A visible **Powered by SportScore** attribution is required.

Public endpoints used by the Android app:

- `GET /sports/{sport}/live`
- `GET /sports/{sport}/upcoming`
- `GET /sports/{sport}/results`
- `GET /sports/{sport}/match/<MATCH_ID>`
- `GET /cricket/live`
- `GET /cricket/upcoming`
- `GET /cricket/results`
- `GET /cricket/match/<MATCH_ID>`
- `GET /cricket/health`

The app refreshes the active sports list every 20 seconds while a sports screen is open. No sports API key is stored in the APK, Worker secrets, or GitHub repository.

## Provider-driven notifications and search
- `GET /search?q=...` returns backend channel matches plus SportScore live/upcoming/finished matches. The Android app does not ship a demo search catalog.
- `GET /notifications` returns published backend notices plus provider-driven sports state changes.
- `sports_event_state` stores centralized provider states. First detection of a live match can create a Match Started event; provider status transitions can create status/innings-break events; a previously-live match appearing in provider results can create a Result event.
- For an existing D1 database, apply `migration-sports-events.sql` once before deploying this Worker.
