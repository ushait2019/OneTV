CREATE TABLE IF NOT EXISTS sports_event_state (
  event_key TEXT PRIMARY KEY,
  sport TEXT NOT NULL,
  match_id TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_sports_event_state_sport ON sports_event_state(sport);
