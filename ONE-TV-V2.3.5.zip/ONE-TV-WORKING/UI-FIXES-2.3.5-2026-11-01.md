# ONE TV UI Fixes 2.3.5

Baseline: V2.3.4 `ONE-TV-WORKING.zip` with the latest deployed backend source.

- Team logos are normalized by cropping transparent bounds and fitting to a consistent compact visual canvas.
- Team identity display is reduced in match cards and Match Centre hero.
- Flag fallback is compact and visually balanced.
- Cricket / Football / Basketball / Tennis home tiles are reduced in height, icon size, text size, and spacing.
- Backend source is unchanged from V2.3.4.
