const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,PATCH,DELETE,OPTIONS",
    "access-control-allow-headers": "Content-Type, Authorization"
  }
});

const text = (data, status = 200) => new Response(data, {
  status,
  headers: { "content-type": "text/plain; charset=utf-8" }
});

function adminOk(request, env) {
  const auth = request.headers.get("Authorization") || "";
  return auth === `Bearer ${env.ADMIN_TOKEN}` && !!env.ADMIN_TOKEN;
}

function findStreamUrl(value) {
  if (!value) return "";
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (/^https?:\/\//i.test(trimmed)) return trimmed;
    try { value = JSON.parse(trimmed); } catch (_) { return ""; }
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = findStreamUrl(item);
      if (found) return found;
    }
    return "";
  }
  if (typeof value !== "object") return "";
  const directKeys = ["streamUrl", "stream_url", "stream", "url", "playUrl", "play_url", "sourceUrl", "source_url"];
  for (const key of directKeys) {
    const found = findStreamUrl(value[key]);
    if (found) return found;
  }
  for (const key of ["data", "result", "source", "channel", "response"]) {
    const found = findStreamUrl(value[key]);
    if (found) return found;
  }
  return "";
}

function extractYouTubeVideoId(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  if (/^[A-Za-z0-9_-]{11}$/.test(raw)) return raw;
  try {
    const u = new URL(raw);
    const host = u.hostname.toLowerCase().replace(/^www\./, '');
    if (host === 'youtu.be') return (u.pathname.split('/').filter(Boolean)[0] || '').slice(0, 11);
    if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'music.youtube.com') {
      const v = u.searchParams.get('v');
      if (v) return v.slice(0, 11);
      const parts = u.pathname.split('/').filter(Boolean);
      if (parts[0] === 'shorts' || parts[0] === 'embed' || parts[0] === 'live') return (parts[1] || '').slice(0, 11);
    }
  } catch (_) {}
  const m = raw.match(/(?:v=|youtu\.be\/|\/shorts\/|\/embed\/|\/live\/)([A-Za-z0-9_-]{11})/i);
  return m ? m[1] : '';
}

async function resolveYouTube(videoId, env) {
  if (!videoId || !env.YOUTUBE_API_KEY) return null;
  try {
    const api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet&id=' + encodeURIComponent(videoId) + '&key=' + encodeURIComponent(env.YOUTUBE_API_KEY);
    const r = await fetch(api, { signal: AbortSignal.timeout(8000) });
    if (!r.ok) return null;
    const data = await r.json();
    const item = data.items && data.items[0];
    if (!item) return null;
    const sn = item.snippet || {};
    const thumbs = sn.thumbnails || {};
    const thumb = (thumbs.maxres || thumbs.standard || thumbs.high || thumbs.medium || thumbs.default || {}).url || '';
    return { videoId, title: String(sn.title || ''), description: String(sn.description || ''), channelTitle: String(sn.channelTitle || ''), thumbnailUrl: thumb };
  } catch (_) { return null; }
}

async function resolveSource(channel, env) {
  const type = String(channel.source_type || "link").toLowerCase();
  const fallbackProgram = String(channel.program_name || "");
  if (type === "youtube") {
    const videoId = extractYouTubeVideoId(channel.source_value || channel.stream_url || '');
    const meta = await resolveYouTube(videoId, env);
    return { youtubeVideoId: videoId, youtubeTitle: meta?.title || fallbackProgram, youtubeThumbnail: meta?.thumbnailUrl || '', programName: meta?.title || fallbackProgram, url: '' };
  }
  if (type !== "api") return { url: channel.source_value || channel.stream_url || "", programName: fallbackProgram };
  const apiUrl = channel.source_value || "";
  if (!apiUrl) return { url: "", programName: fallbackProgram };
  try {
    const headers = { "Accept": "application/json, text/plain;q=0.9, */*;q=0.8" };
    if (channel.api_key) { headers["Authorization"] = `Bearer ${channel.api_key}`; headers["X-API-Key"] = channel.api_key; }
    const response = await fetch(apiUrl, { method: "GET", headers, signal: AbortSignal.timeout(8000) });
    if (!response.ok) return { url: "", programName: fallbackProgram };
    const raw = await response.text();
    let parsed = null;
    try { parsed = JSON.parse(raw); } catch (_) {}
    const program = findProgramName(parsed) || fallbackProgram;
    const url = findStreamUrl(parsed ?? raw);
    return { url, programName: program };
  } catch (_) { return { url: "", programName: fallbackProgram }; }
}

function findProgramName(value) {
  if (!value) return "";
  if (typeof value === "string") return "";
  if (Array.isArray(value)) {
    for (const item of value) { const found = findProgramName(item); if (found) return found; }
    return "";
  }
  if (typeof value !== "object") return "";
  for (const key of ["programName","program_name","nowPlaying","now_playing","program","showName","show_name","title"]) {
    if (typeof value[key] === "string" && value[key].trim()) return value[key].trim();
  }
  for (const key of ["data","result","source","channel","response"]) { const found = findProgramName(value[key]); if (found) return found; }
  return "";
}

async function cleanupViewers(env) {
  await env.DB.prepare("DELETE FROM viewer_sessions WHERE last_seen < datetime('now','-90 seconds')").run();
}

async function viewerCount(env, channelId) {
  const r = await env.DB.prepare("SELECT COUNT(*) AS count FROM viewer_sessions WHERE channel_id=? AND last_seen >= datetime('now','-90 seconds')").bind(channelId).first();
  return Number(r?.count || 0);
}

async function listChannels(env) {
  await cleanupViewers(env);
  const { results } = await env.DB.prepare(`
    SELECT id, channel_number, name, country, category, logo_url, stream_url,
           source_type, source_value, api_key, program_name, program_api_url,
           show_viewers, loop_playback, active, sort_order
    FROM channels WHERE active = 1 ORDER BY sort_order ASC, id ASC
  `).all();
  const resolved = await Promise.all(results.map(async c => {
    const src = await resolveSource(c, env);
    let programName = src.programName || c.program_name || "";
    if (c.program_api_url) {
      try {
        const r = await fetch(c.program_api_url, {headers:{"Accept":"application/json,text/plain;q=0.9,*/*;q=0.8"}, signal: AbortSignal.timeout(6000)});
        if (r.ok) programName = findProgramName(JSON.parse(await r.text())) || programName;
      } catch (_) {}
    }
    const viewers = c.show_viewers ? await viewerCount(env, c.id) : 0;
    const connected = !!src.url;
    return { id:c.id, number:c.channel_number, name:c.name, country:c.country, category:c.category, logoUrl:c.logo_url, streamUrl:src.url || '', url:src.url || '', sourceType:String(c.source_type || 'link').toLowerCase(), youtubeVideoId:src.youtubeVideoId || '', youtubeTitle:src.youtubeTitle || '', youtubeThumbnail:src.youtubeThumbnail || '', programName, viewerCount:viewers, showViewerCount:!!c.show_viewers, loop:!!c.loop_playback, active:!!c.active, connected, sortOrder:c.sort_order };
  }));
  return resolved;
}

async function adminListChannels(env) {
  const { results } = await env.DB.prepare(`
    SELECT id, channel_number, name, country, category, logo_url, stream_url,
           source_type, source_value, api_key, program_name, program_api_url, show_viewers, loop_playback, active, sort_order
    FROM channels ORDER BY sort_order ASC, id ASC
  `).all();
  return results;
}

async function getActiveNotice(env) {
  const { results } = await env.DB.prepare(`
    SELECT id, type, title, html_content, media_url, link_url, active, sort_order
    FROM notices WHERE active = 1 ORDER BY sort_order ASC, id ASC LIMIT 1
  `).all();
  const n = results[0];
  if (!n) return null;
  return {
    id: n.id, type: n.type, title: n.title,
    html: n.html_content, mediaUrl: n.media_url, linkUrl: n.link_url,
    active: !!n.active, sortOrder: n.sort_order
  };
}

async function adminListNotices(env) {
  const { results } = await env.DB.prepare(`
    SELECT id, type, title, html_content, media_url, link_url, active, sort_order
    FROM notices ORDER BY sort_order ASC, id ASC
  `).all();
  return results;
}

function cleanHtml(html) {
  let s = String(html || "");
  s = s.replace(/<script[\\s\\S]*?<\/script>/gi, "");
  s = s.replace(/<iframe[\\s\\S]*?<\/iframe>/gi, "");
  s = s.replace(/\\son[a-z]+\\s*=\\s*(?:\"[^\"]*\"|'[^']*')/gi, "");
  s = s.replace(/javascript:/gi, "");
  return s;
}

function escAttr(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;");
}


const SPORTS = ["football", "basketball", "cricket", "tennis", "baseball"];
const SPORT_CACHE_TTL = 45;

function sportScoreUrl(path, params = {}) {
  const u = new URL("https://sportscore.com" + path);
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && String(v) !== "") u.searchParams.set(k, String(v));
  });
  u.searchParams.set("src", "onetv");
  return u.toString();
}

async function fetchJson(url, headers = {}, timeout = 10000) {
  const response = await fetch(url, {
    headers: { "Accept": "application/json", ...headers },
    signal: AbortSignal.timeout(timeout)
  });
  const body = await response.text();
  if (!response.ok) throw new Error(`Upstream ${response.status}: ${body.slice(0, 200)}`);
  try { return JSON.parse(body); } catch (_) { throw new Error("Upstream returned invalid JSON"); }
}

async function cachedJson(url, headers = {}, timeout = 10000) {
  const cache = caches.default;
  const cacheKey = new Request(url, { method: "GET" });
  const hit = await cache.match(cacheKey);
  if (hit) return await hit.json();
  const data = await fetchJson(url, headers, timeout);
  const response = new Response(JSON.stringify(data), {
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": `public, max-age=${SPORT_CACHE_TTL}` }
  });
  await cache.put(cacheKey, response.clone());
  return data;
}

function extractMatchArray(raw) {
  if (Array.isArray(raw?.matches)) return raw.matches;
  if (Array.isArray(raw?.data?.matches)) return raw.data.matches;
  if (Array.isArray(raw?.data)) return raw.data;
  if (Array.isArray(raw?.results)) return raw.results;
  if (Array.isArray(raw)) return raw;
  return [];
}

function pick(obj, keys, fallback = "") {
  for (const key of keys) {
    const v = obj?.[key];
    if (v !== undefined && v !== null && String(v).trim() !== "") return v;
  }
  return fallback;
}

function teamObject(value, fallbackName = "Team", extra = {}) {
  if (value && typeof value === "object") {
    return {
      name: String(pick(value, ["name", "short_name", "team_name"], fallbackName)),
      slug: String(pick(value, ["slug", "team_slug", "teamSlug"], extra.slug || "")),
      id: String(pick(value, ["id", "team_id", "teamId"], extra.id || "")),
      logo: String(pick(value, ["logo", "logo_url", "image", "badge", "crest", "team_logo", "teamLogo"], extra.logo || "")),
      flag: String(pick(value, ["flag", "country_flag", "countryCode", "country_code", "countryCode2", "country_iso", "countryIso", "iso2", "nationality_code"], extra.flag || "")),
      score: normalizedTeamScore(value, extra.score ?? ""),
      overs: String(pick(value, ["overs", "over", "overs_text", "oversText", "over_text", "overText"], extra.overs ?? "")),
      wickets: String(pick(value, ["wickets", "wicket"], extra.wickets ?? ""))
    };
  }
  return {
    name: String(value || fallbackName),
    slug: String(extra.slug || ""),
    id: String(extra.id || ""),
    logo: String(extra.logo || ""),
    flag: String(extra.flag || ""),
    score: extra.score ?? "",
    overs: String(extra.overs || ""),
    wickets: String(extra.wickets || "")
  };
}

function normalizedTeamScore(value, fallback = "") {
  const direct = pick(value, ["score_text", "scoreText", "display_score", "displayScore", "score"], "");
  if (direct && typeof direct === "object") {
    const runs = pick(direct, ["runs", "run", "total", "points"], "");
    const wickets = pick(direct, ["wickets", "wicket"], "");
    if (runs !== "" && wickets !== "") return `${runs}-${wickets}`;
    if (runs !== "") return String(runs);
  }
  if (String(direct).trim() !== "") return String(direct);
  const runs = pick(value, ["runs", "run", "total", "points"], "");
  const wickets = pick(value, ["wickets", "wicket"], "");
  if (runs !== "" && wickets !== "") return `${runs}-${wickets}`;
  return String(runs !== "" ? runs : (fallback ?? ""));
}

function canonicalMatchTitle(home, away, rawName = "") {
  const h = String(home?.name || "").trim();
  const a = String(away?.name || "").trim();
  if (h && a && h !== "Home" && a !== "Away" && h !== "TBD" && a !== "TBD") return `${h} vs ${a}`;
  const raw = String(rawName || "").trim();
  return raw || "Match";
}

function slugifyTeamName(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function canonicalMatchId(provider, sport, rawId, home, away, startTime) {
  const direct = String(rawId || '').trim();
  if (direct) return `${provider.toLowerCase()}:${sport}:${direct}`;
  const fallback = slugifyMatchName(`${home} vs ${away}`);
  const time = String(startTime || '').trim().toLowerCase();
  return `${provider.toLowerCase()}:${sport}:${fallback}:${time || 'undated'}`;
}

function unwrapProviderMatchId(id, provider, sport) {
  const prefix = `${provider.toLowerCase()}:${sport}:`;
  const value = String(id || '');
  return value.startsWith(prefix) ? value.slice(prefix.length) : value;
}

function sportScoreMatches(raw, sport) {
  const list = extractMatchArray(raw);
  const seen = new Set();
  return list.map((m, i) => {
    const declaredSport = String(pick(m, ['sport', 'sport_type', 'sportType'], sport)).toLowerCase();
    if (declaredSport && declaredSport !== sport.toLowerCase()) return null;
    const home = teamObject(pick(m, ['home_team', 'homeTeam', 'home'], null), 'Home', {
      logo: pick(m, ['home_logo', 'homeLogo'], ''),
      flag: pick(m, ['home_flag', 'homeFlag', 'home_country_code', 'homeCountryCode'], ''),
      score: pick(m, ['home_score', 'homeScore'], ''),
      overs: pick(m, ['home_overs', 'homeOvers', 'home_over', 'homeOver'], ''),
      wickets: pick(m, ['home_wickets', 'homeWickets', 'home_wicket', 'homeWicket'], ''),
      slug: pick(m, ['home_slug', 'homeSlug'], ''),
      id: pick(m, ['home_id', 'homeId'], '')
    });
    const away = teamObject(pick(m, ['away_team', 'awayTeam', 'away'], null), 'Away', {
      logo: pick(m, ['away_logo', 'awayLogo'], ''),
      flag: pick(m, ['away_flag', 'awayFlag', 'away_country_code', 'awayCountryCode'], ''),
      score: pick(m, ['away_score', 'awayScore'], ''),
      overs: pick(m, ['away_overs', 'awayOvers', 'away_over', 'awayOver'], ''),
      wickets: pick(m, ['away_wickets', 'awayWickets', 'away_wicket', 'awayWicket'], ''),
      slug: pick(m, ['away_slug', 'awaySlug'], ''),
      id: pick(m, ['away_id', 'awayId'], '')
    });
    if (!home.slug) home.slug = home.id || slugifyTeamName(home.name);
    if (!away.slug) away.slug = away.id || slugifyTeamName(away.name);
    const rawId = pick(m, ['slug', 'match_slug', 'id', 'match_id'], '');
    const time = String(pick(m, ['time', 'start_time', 'starts_at', 'date', 'datetime'], ''));
    const id = canonicalMatchId('sportscore', sport, rawId, home.name, away.name, time);
    if (seen.has(id)) return null;
    seen.add(id);
    return {
      id,
      providerMatchId: String(rawId || id),
      provider: 'SportScore',
      sport,
      name: canonicalMatchTitle(home, away, pick(m, ['name', 'title'], '')),
      status: String(pick(m, ['status', 'state', 'match_status'], '')),
      statusText: String(pick(m, ['status_text', 'statusText', 'status', 'state'], '')),
      time,
      home,
      away,
      competition: String(pick(m, ['competition', 'league', 'tournament', 'competition_name'], '')),
      competitionLogo: String(pick(m, ['competition_logo', 'competitionLogo', 'competition_logo_url', 'competitionLogoUrl', 'league_logo', 'leagueLogo', 'league_logo_url', 'leagueLogoUrl', 'tournament_logo', 'tournamentLogo', 'tournament_logo_url', 'tournamentLogoUrl'], '')),
      round: String(pick(m, ['round', 'round_name', 'roundName', 'stage', 'stage_name', 'stageName', 'match_number', 'matchNumber'], '')),
      format: String(pick(m, ['format', 'match_format', 'matchFormat', 'type', 'competition_format', 'competitionFormat'], '')),
      matchTitle: String(pick(m, ['match_title', 'matchTitle', 'match_name', 'matchName', 'fixture_title', 'fixtureTitle'], '')),
      venue: String(pick(m, ['venue', 'venue_name', 'stadium'], '')),
      result: String(pick(m, ['result', 'result_text', 'status_text'], ''))
    };
  }).filter(Boolean);
}

async function sportScoreList(sport, status, dateOverride = "") {
  if (!SPORTS.includes(sport)) throw new Error("Unsupported sport");
  // Use the documented v1 fixtures endpoint for all three states. It accepts
  // sport + UTC date + status and keeps the provider contract consistent.
  const date = dateOverride || new Date().toISOString().slice(0, 10);
  const raw = await cachedJson(
    sportScoreUrl("/api/v1/fixtures/", { sport, date, status, limit: 200 }),
    {},
    10000
  );
  return sportScoreMatches(raw, sport);
}

function normalizeOpenCricketMatch(m, i = 0) {
  const home = teamObject(pick(m, ["home_team", "homeTeam", "team1", "home"], null), "TBD");
  const away = teamObject(pick(m, ["away_team", "awayTeam", "team2", "away"], null), "TBD");
  const rawId = String(pick(m, ["id", "match_id", "matchId"], `opencricket-${i}`));
  const status = String(pick(m, ["status", "state", "match_status"], ""));
  const time = String(pick(m, ["start_time", "starts_at", "date", "datetime", "time"], ""));
  const id = canonicalMatchId("opencricket", "cricket", rawId, home.name, away.name, time);
  return {
    id,
    providerMatchId: rawId,
    name: canonicalMatchTitle(home, away, pick(m, ["name", "title"], "")),
    status,
    statusText: String(pick(m, ["status_text", "statusText", "status", "state"], status)),
    time,
    home,
    away,
    competition: String(pick(m, ["competition", "league", "tournament", "competition_name"], "")),
    competitionLogo: String(pick(m, ["competition_logo", "competitionLogo", "competition_logo_url", "competitionLogoUrl", "league_logo", "leagueLogo", "league_logo_url", "leagueLogoUrl", "tournament_logo", "tournamentLogo", "tournament_logo_url", "tournamentLogoUrl"], "")),
    round: String(pick(m, ["round", "round_name", "roundName", "stage", "stage_name", "stageName", "match_number", "matchNumber"], "")),
    format: String(pick(m, ["format", "match_format", "matchFormat", "type", "competition_format", "competitionFormat"], "")),
    matchTitle: String(pick(m, ["match_title", "matchTitle", "match_name", "matchName", "fixture_title", "fixtureTitle"], "")),
    venue: String(pick(m, ["venue", "venue_name", "venueName", "stadium", "ground", "ground_name", "groundName"], "")),
    result: String(pick(m, ["result", "result_text"], ""))
  };
}

function openCricketHeaders(env) {
  const key = String(env.OPENCRICKET_API_KEY || "").trim();
  if (!key) throw new Error("OPENCRICKET_API_KEY is not configured");
  return { Authorization: `Bearer ${key}` };
}

async function openCricketList(status, env) {
  const today = new Date().toISOString().slice(0, 10);
  const raw = await cachedJson(
    (() => {
      const u = new URL(String(env.OPENCRICKET_BASE_URL || "https://opencricketapi.com").replace(/\/$/, "") + "/v1/matches");
      u.searchParams.set("date", today);
      u.searchParams.set("limit", "200");
      return u.toString();
    })(),
    openCricketHeaders(env),
    10000
  );
  const all = extractMatchArray(raw).map((m, i) => normalizeOpenCricketMatch(m, i));
  const lower = all.map(m => ({...m, _status: m.status.toLowerCase(), _time: m.time}));
  if (status === "live") return lower.filter(m => /live|in.?play|playing|started/.test(m._status));
  if (status === "finished") return lower.filter(m => /finished|complete|result|final|ended/.test(m._status));
  return lower.filter(m => /upcoming|scheduled|not.?started|fixture/.test(m._status));
}

async function withSportFallback(sport, status, env) {
  try {
    const primary = await sportScoreList(sport, status);
    if (primary.length > 0) return { provider: "SportScore", matches: primary };
    throw new Error("SportScore returned no matches");
  } catch (primaryError) {
    if (sport !== "cricket") throw primaryError;
    const fallback = await openCricketList(status, env);
    if (!fallback.length) throw new Error(`SportScore failed and OpenCricket returned no ${status} cricket matches`);
    return { provider: "OpenCricket", matches: fallback };
  }
}

function slugifyMatchName(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function openCricketMatchKey(m) {
  const home = String(m?.home?.name || "");
  const away = String(m?.away?.name || "");
  return slugifyMatchName(home + " vs " + away);
}

async function openCricketMatchDetailFallback(id, env) {
  if (!env.OPENCRICKET_API_KEY) throw new Error("OPENCRICKET_API_KEY is not configured");
  const base = String(env.OPENCRICKET_BASE_URL || "https://opencricketapi.com").replace(/\/$/, "");
  const providerId = unwrapProviderMatchId(id, "opencricket", "cricket");

  // If the app selected an OpenCricket-native ID, use the documented detail endpoint.
  if (String(providerId).startsWith("match_")) {
    const raw = await cachedJson(base + "/v1/matches/" + encodeURIComponent(providerId), openCricketHeaders(env), 10000);
    return normalizeOpenCricketDetail(raw, "cricket", providerId);
  }

  // Otherwise resolve the SportScore slug against today's OpenCricket catalog.
  // This is intentionally performed only after SportScore detail fails.
  const today = new Date().toISOString().slice(0, 10);
  const raw = await cachedJson(base + "/v1/matches?date=" + encodeURIComponent(today) + "&limit=200", openCricketHeaders(env), 10000);
  const candidates = extractMatchArray(raw).map((m, i) => normalizeOpenCricketMatch(m, i));
  const wanted = String(providerId).toLowerCase();
  const found = candidates.find(m => {
    const nativeId = String(m.providerMatchId || "").toLowerCase();
    const key = openCricketMatchKey(m).toLowerCase();
    return nativeId === wanted || key === wanted || key.includes(wanted) || wanted.includes(key);
  });
  if (!found) throw new Error("OpenCricket could not resolve the selected cricket match");
  const detailRaw = await cachedJson(base + "/v1/matches/" + encodeURIComponent(found.providerMatchId || found.id), openCricketHeaders(env), 10000);
  return normalizeOpenCricketDetail(detailRaw, "cricket", found.providerMatchId || found.id);
}

async function sportScoreMatchDetail(sport, id, env) {
  let primaryError = null;
  const providerId = unwrapProviderMatchId(id, "sportscore", sport);
  // SportScore is always attempted first. OpenCricket is never called in parallel.
  for (const path of ["/api/v1/match/", "/api/widget/match/"]) {
    try {
      const raw = await cachedJson(sportScoreUrl(path, { sport, slug: providerId }), {}, 10000);
      const detail = normalizeSportScoreDetail(raw, sport);
      if (detail.id || detail.name) return { provider: "SportScore", match: detail };
    } catch (e) { primaryError = e; }
  }
  if (sport === "cricket") {
    try {
      const detail = await openCricketMatchDetailFallback(id, env);
      return { provider: "OpenCricket", match: detail };
    } catch (fallbackError) {
      throw new Error(`SportScore detail failed; OpenCricket fallback failed: ${fallbackError.message || fallbackError}`);
    }
  }
  throw primaryError || new Error("Match detail unavailable");
}

function normalizeOpenCricketDetail(raw, sport, id) {
  const m = raw?.data?.match || raw?.match || raw?.data || raw;
  const home = teamObject(pick(m, ["home_team", "homeTeam", "team1", "home"], null), "TBD");
  const away = teamObject(pick(m, ["away_team", "awayTeam", "team2", "away"], null), "TBD");
  const innings = Array.isArray(m?.innings) ? m.innings.map((x, i) => ({ team: String(pick(x, ["team", "team_name"], `Innings ${i+1}`)), score: String(pick(x, ["score", "runs", "total"], "")) })) : [];
  return {
    id: String(pick(m, ["id", "match_id"], id)),
    sport,
    name: canonicalMatchTitle(home, away, pick(m, ["name", "title"], "")),
    status: String(pick(m, ["status", "state", "result"], "")),
    competition: String(pick(m, ["competition", "league", "tournament"], "")),
    venue: String(pick(m, ["venue", "venue_name", "venueName", "stadium", "ground", "ground_name", "groundName"], "")),
    teams: [home, away],
    innings,
    timeline: Array.isArray(m?.timeline) ? m.timeline : [],
    lineups: Array.isArray(m?.lineups) ? m.lineups : [],
    home, away, rawProviderData: m
  };
}

async function cricketList(kind, env) {
  const status = kind === "live" ? "live" : kind === "upcoming" ? "upcoming" : "finished";
  const result = await withSportFallback("cricket", status, env);
  return result.matches.map(m => ({
    id:m.id,
    name:m.name,
    status:m.statusText || m.status,
    state:m.status,
    competition:m.competition,
    competitionLogo:String(m.competitionLogo || ""),
    round:String(m.round || ""),
    format:String(m.format || ""),
    matchTitle:String(m.matchTitle || ""),
    venue:m.venue,
    result:m.result,
    startsAt:m.time,
    score:m.home?.score || m.away?.score || "",
    teams:[m.home,m.away].map(t => ({name:t.name,slug:String(t.slug || ""),id:String(t.id || ""),score:String(t.score ?? ""),logo:String(t.logo || ""),flag:String(t.flag || ""),overs:String(t.overs || ""),wickets:String(t.wickets || "")}))
  }));
}

function normalizeSportScoreDetail(raw, sport) {
  const m = raw?.match || raw?.data?.match || raw?.data || raw;
  const homeRaw = pick(m, ["home_team", "homeTeam", "home"], "TBD");
  const awayRaw = pick(m, ["away_team", "awayTeam", "away"], "TBD");
  const home = teamObject(homeRaw, "TBD", { logo: pick(m, ["home_logo", "homeLogo"], ""), score: pick(m, ["home_score", "homeScore"], ""), slug: pick(m, ["home_slug", "homeSlug"], ""), id: pick(m, ["home_id", "homeId"], "") });
  const away = teamObject(awayRaw, "TBD", { logo: pick(m, ["away_logo", "awayLogo"], ""), score: pick(m, ["away_score", "awayScore"], ""), slug: pick(m, ["away_slug", "awaySlug"], ""), id: pick(m, ["away_id", "awayId"], "") });
  if (!home.slug) home.slug = slugifyTeamName(home.name);
  if (!away.slug) away.slug = slugifyTeamName(away.name);
  const rawId = String(pick(m, ["slug", "match_slug", "id", "match_id"], ""));
  const startTime = String(pick(m, ["time", "start_time", "starts_at", "date", "datetime"], ""));
  return {
    id: canonicalMatchId("sportscore", sport, rawId, home.name, away.name, startTime),
    providerMatchId: rawId,
    provider: "SportScore",
    sport,
    name: canonicalMatchTitle(home, away, pick(m, ["name", "title"], "")),
    status: String(pick(m, ["status_text", "status", "state"], "")),
    competition: String(pick(m, ["competition", "league", "tournament"], "")),
    venue: String(pick(m, ["venue", "venue_name", "venueName", "stadium", "ground", "ground_name", "groundName"], "")),
    teams: [home, away],
    innings: Array.isArray(m?.innings) ? m.innings : [],
    timeline: Array.isArray(m?.timeline) ? m.timeline : [],
    lineups: Array.isArray(m?.lineups) ? m.lineups : [],
    home, away, rawProviderData: m
  };
}

async function sportScoreTeam(sport, slug, env) {
  let lastError = null;
  for (const path of ["/api/v1/team/", "/api/widget/team/"]) {
    try {
      const raw = await cachedJson(sportScoreUrl(path, { sport, slug, limit: 30 }), {}, 10000);
      const root = raw?.team || raw?.data?.team || raw?.data || raw;
      const teamName = String(pick(root, ["name", "team_name", "title"], slug.replace(/-/g, " ")));
      const teamLogo = String(pick(root, ["logo", "logo_url", "image", "badge"], ""));
      const list = sportScoreMatches(raw, sport);
      if (list.length || teamName) {
        const finished = list.filter(m => /finished|complete|result|final|ended|stumps/.test(String(m.statusText || m.status).toLowerCase()));
        const upcoming = list.filter(m => !finished.includes(m));
        return { provider: "SportScore", team: { name: teamName, slug, logo: teamLogo }, matches: list, recent: finished, upcoming };
      }
    } catch (e) { lastError = e; }
  }
  throw lastError || new Error("SportScore team summary unavailable");
}

async function cricketTeam(slug, env) {
  // Team summaries are supported by SportScore. OpenCricket has no documented
  // equivalent team-schedule endpoint, so never fabricate a summary when SportScore fails.
  return sportScoreTeam("cricket", slug, env);
}

async function cricketMatch(id, env) {
  return sportScoreMatchDetail("cricket", id, env);
}

async function sportsList(sport, status, env) {
  if (!SPORTS.includes(sport)) throw new Error("Unsupported sport");
  return withSportFallback(sport, status, env);
}


function publicStatusLabel(value){
  const k=String(value||'').toLowerCase().replace(/[_-]+/g,' ').replace(/\s+/g,' ').trim();
  if(['live','in play','inplay','playing','ongoing','started'].includes(k)) return 'LIVE';
  if(['upcoming','scheduled','not started','fixture','pre match'].includes(k)) return 'UPCOMING';
  if(['finished','complete','completed','ended','end of day','final','result'].includes(k)) return 'FINISHED';
  if(k==='postponed') return 'POSTPONED';
  if(['cancelled','canceled'].includes(k)) return 'CANCELLED';
  if(k==='abandoned') return 'ABANDONED';
  return '';
}

function shiftIsoDate(days){
  const d=new Date();
  d.setUTCDate(d.getUTCDate()+Number(days||0));
  return d.toISOString().slice(0,10);
}

async function publicSearch(q, env) {
  const query = String(q || "").trim().toLowerCase();
  if (!query) return [];
  const items = [];
  const channels = await listChannels(env);
  for (const c of channels) {
    const hay = `${c.name} ${c.category} ${c.country} ${c.programName}`.toLowerCase();
    if (hay.includes(query)) {
      items.push({
        kind:'channel', icon:'📺', id:c.id, title:c.name,
        subtitle:c.connected ? (c.programName || c.category || 'Live TV') : 'Coming soon',
        url:c.url||'', program:c.programName||'', category:c.category,
        country:c.country, connected:!!c.connected
      });
    }
  }

  // Search the same canonical live/upcoming/result feeds used by the app.
  // Keep this bounded so a single search never fans out into a large provider burst.
  const requests=[];
  for(const sport of SPORTS){
    requests.push({sport, promise:sportsList(sport,'live',env)});
    requests.push({sport, promise:sportsList(sport,'upcoming',env)});
    requests.push({sport, promise:sportsList(sport,'finished',env)});
  }
  const batches=await Promise.all(requests.map(r=>r.promise.catch(()=>({matches:[]}))));
  const seen=new Set();
  for(let i=0;i<batches.length;i++){
    const result=batches[i];
    const sport=requests[i].sport;
    for(const m of (result?.matches || [])){
      const hay = `${m.name} ${m.home?.name||''} ${m.away?.name||''} ${m.competition||''} ${m.venue||''}`.toLowerCase();
      if(!hay.includes(query) || seen.has(m.id)) continue;
      seen.add(m.id);
      const status=publicStatusLabel(m.statusText||m.status);
      items.push({
        kind:'match', icon:'🏆', id:m.id, providerMatchId:m.providerMatchId||'',
        sport, title:canonicalMatchTitle(m.home,m.away,m.name),
        subtitle:`${m.competition||sport}${status ? ' • '+status : ''}`,
        home:m.home, away:m.away, competition:m.competition, venue:m.venue,
        status:status || '', time:m.time
      });
    }
  }
  return items.slice(0,50);
}

async function notificationFeed(env) {
  const items=[];
  const {results: notices=[]}=await env.DB.prepare(`SELECT id,type,title,html_content,media_url,link_url,created_at FROM notices WHERE active=1 ORDER BY sort_order ASC,id DESC LIMIT 20`).all();
  for(const n of notices) items.push({id:`notice-${n.id}`,icon:'ℹ',title:n.title||'ONE TV',body:n.type==='text'?String(n.html_content||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim():`New ${n.type} published`,type:'notice',createdAt:n.created_at});
  // Provider-driven live state. State transitions are persisted centrally so the app never invents match events.
  for(const sport of SPORTS){
    try{
      const result=await sportsList(sport,'live',env);
      for(const m of result.matches){
        const key=`${sport}:${m.id}`;
        const state=String(m.statusText||m.status||'LIVE');
        const prev=await env.DB.prepare(`SELECT state FROM sports_event_state WHERE event_key=?`).bind(key).first();
        if(!prev){
          // Establish the initial provider state silently. A fresh install should
          // not manufacture a notification simply because a live match exists.
          await env.DB.prepare(`INSERT OR REPLACE INTO sports_event_state(event_key,sport,match_id,state,updated_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)`).bind(key,sport,m.id,state).run();
        } else if(String(prev.state)!==state){
          await env.DB.prepare(`UPDATE sports_event_state SET state=?,updated_at=CURRENT_TIMESTAMP WHERE event_key=?`).bind(state,key).run();
          const eventTitle=/innings|break/i.test(state)?'Innings break':/finished|complete|final|ended/i.test(state)?'Result':'Match update';
          const eventIcon=eventTitle==='Innings break'?'🏏':eventTitle==='Result'?'🏁':'🔴';
          items.unshift({id:`auto-${key}-${Date.now()}`,icon:eventIcon,title:`${m.name} • ${eventTitle}`,body:'The match status has changed.',type:'sport',sport,matchId:m.id});
        }
      }
    }catch(_){ }
  }
  // Detect completed matches for previously live matches. This is provider data, not a fabricated result.
  try {
    const liveStates = await env.DB.prepare(`SELECT event_key,sport,match_id,state FROM sports_event_state WHERE state LIKE '%live%' OR state LIKE '%in play%' OR state LIKE '%playing%' OR state LIKE '%started%'`).all();
    for (const sport of SPORTS) {
      const relevant=(liveStates.results||[]).filter(x=>x.sport===sport);
      if(!relevant.length) continue;
      try {
        const result=await sportsList(sport,'finished',env);
        for(const m of result.matches){
          const hit=relevant.find(x=>String(x.match_id)===String(m.id));
          if(!hit) continue;
          await env.DB.prepare(`UPDATE sports_event_state SET state=?,updated_at=CURRENT_TIMESTAMP WHERE event_key=?`).bind(String(m.statusText||m.status||'FINISHED'),hit.event_key).run();
          items.unshift({id:`auto-${hit.event_key}-result`,icon:'🏁',title:`${m.name} • Result`,body:'The match has finished.',type:'sport',sport,matchId:m.id});
        }
      } catch (_) {}
    }
  } catch (_) {}
  return {items:items.slice(0,50),unreadCount:items.length,updatedAt:new Date().toISOString()};
}

async function adminPage(env) {
  const channels = [];
  const notices = [];
  const channelJson = JSON.stringify(channels).replace(/</g, "\\u003c");
  const noticeJson = JSON.stringify(notices).replace(/</g, "\\u003c");

  return new Response(`<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>One TV Admin</title>
<style>
body{font-family:Arial,sans-serif;max-width:1180px;margin:24px auto;padding:0 16px;background:#0b0f14;color:#fff}
input,select,button,textarea{padding:10px;margin:4px;border-radius:6px;border:1px solid #333;background:#151b22;color:#fff;box-sizing:border-box}
button{cursor:pointer}.card{border:1px solid #29313b;border-radius:10px;padding:14px;margin:12px 0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:8px}
small{color:#9aa4af}.on{color:#69db7c}.off{color:#ff8787}.danger{background:#7f1d1d}.source-fields{margin-top:8px}.tabs{display:flex;gap:8px;position:sticky;top:0;background:#0b0f14;padding:10px 0;z-index:5}.tabs button.active{background:#2563eb}
.editor{min-height:160px;border:1px solid #333;border-radius:8px;background:#fff;color:#111;padding:12px;margin:4px;overflow:auto}.toolbar{display:flex;flex-wrap:wrap;align-items:center;gap:2px;background:#151b22;padding:6px;border-radius:8px;margin:4px}.toolbar button{padding:7px 9px;margin:0}.toolbar input{width:42px;padding:6px;margin:0}.html-source{min-height:160px;width:100%;font-family:monospace}.hidden{display:none!important}.preview{border:1px solid #29313b;background:#0b0f14;padding:10px;margin-top:8px}.notice-item{display:flex;justify-content:space-between;gap:10px;align-items:center}.badge{display:inline-block;padding:3px 7px;border-radius:20px;background:#263241;font-size:12px}
</style></head><body>
<h1>One TV Admin</h1>
<p><small>Manage channels and optional notices/personal ads. Changes become available to app users after the next refresh.</small></p>
<div class="card"><b>Admin token</b><br><input id="token" type="password" placeholder="Paste ADMIN_TOKEN" style="width:100%;max-width:600px"><button onclick="connectAdmin()">Connect</button> <span id="connStatus"><small>Not connected</small></span></div>
<div class="tabs"><button id="tabChannels" class="active" onclick="showTab('channels')">Channels</button><button id="tabNotices" onclick="showTab('notices')">Notices / Personal Ads</button><button id="tabAds" onclick="showTab('ads')">Ad Platforms</button></div>

<section id="channelsTab">
<div class="card"><h3>Add / Edit channel</h3><input id="cid" type="hidden">
<div class="grid">
<input id="number" placeholder="Channel number"><input id="name" placeholder="Channel name"><input id="country" placeholder="Country" value="International">
<select id="category"><option value="TV">TV</option><option value="Movies">Movies</option><option value="Sports">Sports</option><option value="News">News</option><option value="Kids">Kids</option></select>
<input id="logoUrl" placeholder="Logo URL"><input id="programName" placeholder="Program / movie title (optional)"><input id="programApiUrl" placeholder="Program API URL (optional)"><input id="sortOrder" type="number" placeholder="Sort order" value="0">
<select id="sourceType" onchange="updateSourceFields()"><option value="link">Source: Direct Link</option><option value="api">Source: API</option><option value="youtube">Source: YouTube</option></select>
</div>
<div id="linkFields" class="source-fields"><input id="streamUrl" placeholder="Stream link (HLS / DASH / MP4)" style="width:100%"></div>
<div id="youtubeFields" class="source-fields hidden"><input id="youtubeUrl" placeholder="YouTube watch / shorts / live URL or Video ID" style="width:100%"><small>YouTube Data API resolves title/thumbnail on the server. Playback uses the official embedded YouTube player.</small></div>
<div id="apiFields" class="source-fields hidden"><input id="sourceValue" placeholder="API URL that returns the stream URL" style="width:100%"><input id="apiKey" type="password" placeholder="API key (optional)" style="width:100%"></div>
<label><input id="showViewers" type="checkbox"> Show viewer count</label> <label><input id="loopPlayback" type="checkbox"> Loop playback (Movies)</label><br><label><input id="active" type="checkbox" checked> Active</label><br><button onclick="saveChannel()">Save channel</button><button onclick="clearChannelForm()">Clear</button></div>
<div id="channelList"></div>
</section>

<section id="adsTab" class="hidden">
<div class="card"><h3>Ad Platform Priority</h3><small>Keep only 2-3 platforms active. Priority 1 is preferred; the app may fall back to the next active supported network. New SDKs still require a new APK/AAB.</small><div id="adList"></div><button onclick="saveAds()">Save Ad Configuration</button></div>
</section>

<section id="noticesTab" class="hidden">
<div class="card"><h3>Publish notice / personal ad</h3><input id="nid" type="hidden">
<div class="grid"><input id="noticeTitle" placeholder="Internal title / label"><select id="noticeType" onchange="updateNoticeFields()"><option value="text">Text</option><option value="banner">Banner image</option><option value="video">Video</option></select><input id="noticeSort" type="number" value="0" placeholder="Sort order"></div>
<div id="textNoticeFields">
<div class="toolbar">
<select onchange="cmd('fontName',this.value)"><option value="Arial">Arial</option><option value="Verdana">Verdana</option><option value="Georgia">Georgia</option><option value="Times New Roman">Times New Roman</option><option value="Courier New">Courier New</option><option value="Trebuchet MS">Trebuchet MS</option><option value="Impact">Impact</option></select>
<select onchange="cmd('fontSize',this.value)"><option value="2">Small</option><option value="3" selected>Normal</option><option value="4">Large</option><option value="5">XL</option><option value="6">XXL</option></select>
<button type="button" onclick="cmd('bold')"><b>B</b></button><button type="button" onclick="cmd('italic')"><i>I</i></button><button type="button" onclick="cmd('underline')"><u>U</u></button><button type="button" onclick="cmd('strikeThrough')"><s>S</s></button>
<button type="button" onclick="cmd('justifyLeft')">Left</button><button type="button" onclick="cmd('justifyCenter')">Center</button><button type="button" onclick="cmd('justifyRight')">Right</button>
<button type="button" onclick="cmd('insertUnorderedList')">• List</button><button type="button" onclick="cmd('insertOrderedList')">1. List</button>
<label>Text <input type="color" value="#ffffff" onchange="cmd('foreColor',this.value)"></label><label>BG <input type="color" value="#111827" onchange="cmd('hiliteColor',this.value)"></label>
<button type="button" onclick="addLink()">Link</button><button type="button" onclick="toggleSource()">HTML</button>
</div>
<div id="noticeEditor" class="editor" contenteditable="true"><div style="font-family:Arial;font-size:18px;text-align:center">Write your notice here...</div></div>
<textarea id="noticeHtml" class="html-source hidden" placeholder="Advanced HTML/CSS"></textarea>
</div>
<div id="mediaNoticeFields" class="hidden"><input id="mediaUrl" placeholder="Image / video URL" style="width:100%"><input id="linkUrl" placeholder="Optional click URL" style="width:100%"><small>Banner: use a direct image URL. Video: use a direct MP4/WebM URL.</small></div>
<label><input id="noticeActive" type="checkbox" checked> Publish now</label><br><button onclick="saveNotice()">Publish / Save notice</button><button onclick="clearNoticeForm()">Clear</button></div>
<div class="card"><h3>Notice preview</h3><div id="noticePreview" class="preview">Nothing published.</div></div>
<div id="noticeList"></div>
</section>

<script>
const initialChannels=${channelJson}; const initialNotices=${noticeJson}; let channels=initialChannels, notices=initialNotices, adPlatforms=[];
const $=id=>document.getElementById(id); function token(){return $('token').value}
async function api(path,opts={}){opts.headers={...(opts.headers||{}),'Authorization':'Bearer '+token(),'Content-Type':'application/json'};const r=await fetch(path,opts);let d={};try{d=await r.json()}catch(_){d={error:'Invalid server response'}}if(!r.ok)throw new Error(d.error||'Request failed');return d}
async function connectAdmin(){try{channels=await api('/admin/channels');notices=await api('/admin/notices');adPlatforms=await api('/admin/ads');renderChannels();renderNotices();renderAds();$('connStatus').innerHTML='<span class=on>Connected</span>'}catch(e){$('connStatus').innerHTML='<span class=off>'+esc(e.message)+'</span>'}}
function showTab(tab){$('channelsTab').classList.toggle('hidden',tab!=='channels');$('noticesTab').classList.toggle('hidden',tab!=='notices');$('adsTab').classList.toggle('hidden',tab!=='ads');$('tabChannels').classList.toggle('active',tab==='channels');$('tabNotices').classList.toggle('active',tab==='notices');$('tabAds').classList.toggle('active',tab==='ads')}
function updateSourceFields(){const t=$('sourceType').value; const a=t==='api'; const y=t==='youtube'; $('linkFields').classList.toggle('hidden',a||y); $('apiFields').classList.toggle('hidden',!a); $('youtubeFields').classList.toggle('hidden',!y)}
function renderAds(){ $('adList').innerHTML=adPlatforms.map((a,i)=>'<div class="card"><b>'+esc(a.name)+'</b> <span class="'+(a.active?'on':'off')+'">'+(a.active?'ACTIVE':'OFF')+'</span><div class="grid"><label>Active <input data-ad="active" data-i="'+i+'" type="checkbox" '+(a.active?'checked':'')+'></label><label>Priority <input data-ad="priority" data-i="'+i+'" type="number" value="'+esc(a.priority)+'"></label><input data-ad="app_id" data-i="'+i+'" placeholder="App ID" value="'+esc(a.app_id||'')+'"><input data-ad="banner_unit_id" data-i="'+i+'" placeholder="Banner Ad Unit ID" value="'+esc(a.banner_unit_id||'')+'"></div></div>').join('') }
function saveAds(){try{document.querySelectorAll('[data-ad]').forEach(el=>{const i=Number(el.dataset.i),k=el.dataset.ad;if(el.type==='checkbox')adPlatforms[i][k]=el.checked;else adPlatforms[i][k]=el.value});api('/admin/ads',{method:'PATCH',body:JSON.stringify({platforms:adPlatforms})}).then(x=>{adPlatforms=x;renderAds();alert('Ad configuration saved')}).catch(e=>alert(e.message))}catch(e){alert(e.message)}}
function renderChannels(){ $('channelList').innerHTML=channels.map(c=>'<div class="card"><b>'+esc(c.name)+'</b> <span class="'+(c.active?'on':'off')+'">'+(c.active?'ACTIVE':'DISABLED')+'</span><br><small>'+esc(c.country)+' • '+esc(c.category)+' • '+esc(c.source_type)+'</small><br><small>'+esc(c.source_type==='api'?c.source_value:c.stream_url)+'</small><br><button onclick="editChannel('+c.id+')">Edit</button><button class="danger" onclick="deleteChannel('+c.id+')">Delete</button></div>').join('') }
function renderNotices(){ $('noticeList').innerHTML=notices.map(n=>'<div class="card notice-item"><div><b>'+esc(n.title||'(Untitled)')+'</b> <span class="badge">'+esc(n.type)+'</span> <span class="'+(n.active?'on':'off')+'">'+(n.active?'PUBLISHED':'HIDDEN')+'</span><br><small>'+esc(n.type==='text'?'Rich text notice':n.media_url)+'</small></div><div><button onclick="editNotice('+n.id+')">Edit</button><button class="danger" onclick="deleteNotice('+n.id+')">Delete</button></div></div>').join('')||'<div class="card"><small>No notices yet.</small></div>' }
function esc(s){return String(s??'').replace(/[&<>\"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]))}
function clearChannelForm(){['cid','number','name','country','logoUrl','programName','programApiUrl','streamUrl','sourceValue','apiKey','youtubeUrl'].forEach(x=>$(x).value='');$('country').value='International';$('category').value='TV';$('sortOrder').value='0';$('showViewers').checked=false;$('loopPlayback').checked=false;$('sourceType').value='link';$('youtubeUrl').value='';$('active').checked=true;updateSourceFields()}
function editChannel(id){const c=channels.find(x=>x.id===id);$('cid').value=c.id;$('number').value=c.channel_number;$('name').value=c.name;$('country').value=c.country;$('category').value=c.category;$('logoUrl').value=c.logo_url;$('programName').value=c.program_name||'';$('programApiUrl').value=c.program_api_url||'';$('sortOrder').value=c.sort_order;$('showViewers').checked=!!c.show_viewers;$('loopPlayback').checked=!!c.loop_playback;$('sourceType').value=c.source_type||'link';$('streamUrl').value=c.source_type==='api'||c.source_type==='youtube'?'':(c.source_value||c.stream_url||'');$('sourceValue').value=c.source_type==='api'?(c.source_value||''):'';$('youtubeUrl').value=c.source_type==='youtube'?(c.source_value||''):'';$('apiKey').value=c.api_key||'';$('active').checked=!!c.active;updateSourceFields();showTab('channels');scrollTo(0,0)}
async function saveChannel(){try{const type=$('sourceType').value;const sourceValue=type==='api'?$('sourceValue').value:(type==='youtube'?$('youtubeUrl').value:$('streamUrl').value); const body={channel_number:$('number').value,name:$('name').value,country:$('country').value,category:$('category').value,logo_url:$('logoUrl').value,stream_url:type==='link'?$('streamUrl').value:'',source_type:type,source_value:sourceValue,api_key:type==='api'?$('apiKey').value:'',program_name:$('programName').value,program_api_url:$('programApiUrl').value,show_viewers:$('showViewers').checked,loop_playback:$('loopPlayback').checked,sort_order:Number($('sortOrder').value||0),active:$('active').checked};if(!body.name)throw new Error('Channel name is required');if(type==='link'&&!body.stream_url)throw new Error('Stream link is required');if(type==='api'&&!body.source_value)throw new Error('API URL is required');if(type==='youtube'&&!body.source_value)throw new Error('YouTube URL is required');const id=$('cid').value;await api(id?'/admin/channels/'+id:'/admin/channels',{method:id?'PATCH':'POST',body:JSON.stringify(body)});clearChannelForm();channels=await api('/admin/channels');renderChannels();alert('Saved')}catch(e){alert(e.message)}}
async function deleteChannel(id){if(!confirm('Delete this channel?'))return;try{await api('/admin/channels/'+id,{method:'DELETE'});channels=await api('/admin/channels');renderChannels()}catch(e){alert(e.message)}}
function cmd(name,value){document.execCommand(name,false,value||null);$('noticeEditor').focus();updatePreview()}
function addLink(){const u=prompt('Enter https:// link');if(u)cmd('createLink',u)}
function toggleSource(){const source=$('noticeHtml'), editor=$('noticeEditor');if(source.classList.contains('hidden')){source.value=editor.innerHTML;source.classList.remove('hidden');editor.classList.add('hidden')}else{editor.innerHTML=source.value;source.classList.add('hidden');editor.classList.remove('hidden')}updatePreview()}
function getNoticeHtml(){return $('noticeHtml').classList.contains('hidden')?$('noticeEditor').innerHTML:$('noticeHtml').value}
function updateNoticeFields(){const type=$('noticeType').value;const text=type==='text';$('textNoticeFields').classList.toggle('hidden',!text);$('mediaNoticeFields').classList.toggle('hidden',text);updatePreview()}
function updatePreview(){const type=$('noticeType').value;let html='';if(type==='text')html=getNoticeHtml();else if(type==='banner')html='<img src="'+esc($('mediaUrl').value)+'" style="max-width:100%;display:block;margin:auto">';else html='<video src="'+esc($('mediaUrl').value)+'" controls muted style="max-width:100%;width:100%"></video>';$('noticePreview').innerHTML=html||'Nothing to preview.'}
function clearNoticeForm(){$('nid').value='';$('noticeTitle').value='';$('noticeType').value='text';$('noticeSort').value='0';$('noticeEditor').innerHTML='<div style="font-family:Arial;font-size:18px;text-align:center">Write your notice here...</div>';$('noticeHtml').value='';$('noticeHtml').classList.add('hidden');$('noticeEditor').classList.remove('hidden');$('mediaUrl').value='';$('linkUrl').value='';$('noticeActive').checked=true;updateNoticeFields();updatePreview()}
function editNotice(id){const n=notices.find(x=>x.id===id);$('nid').value=n.id;$('noticeTitle').value=n.title||'';$('noticeType').value=n.type||'text';$('noticeSort').value=n.sort_order||0;$('noticeEditor').innerHTML=n.html_content||'';$('noticeHtml').value=n.html_content||'';$('noticeHtml').classList.add('hidden');$('noticeEditor').classList.remove('hidden');$('mediaUrl').value=n.media_url||'';$('linkUrl').value=n.link_url||'';$('noticeActive').checked=!!n.active;updateNoticeFields();updatePreview();showTab('notices');scrollTo(0,0)}
async function saveNotice(){try{const type=$('noticeType').value;const body={title:$('noticeTitle').value,type,html_content:type==='text'?getNoticeHtml():'',media_url:type==='text'?'':$('mediaUrl').value,link_url:type==='text'?'':$('linkUrl').value,sort_order:Number($('noticeSort').value||0),active:$('noticeActive').checked};if(type==='text'&&!body.html_content.trim())throw new Error('Notice text is required');if(type!=='text'&&!body.media_url.trim())throw new Error('Media URL is required');const id=$('nid').value;await api(id?'/admin/notices/'+id:'/admin/notices',{method:id?'PATCH':'POST',body:JSON.stringify(body)});clearNoticeForm();notices=await api('/admin/notices');renderNotices();alert('Notice saved')}catch(e){alert(e.message)}}
async function deleteNotice(id){if(!confirm('Delete this notice?'))return;try{await api('/admin/notices/'+id,{method:'DELETE'});notices=await api('/admin/notices');renderNotices()}catch(e){alert(e.message)}}
$('noticeEditor').addEventListener('input',updatePreview);$('mediaUrl').addEventListener('input',updatePreview);updateSourceFields();updateNoticeFields();renderChannels();renderNotices();if(token())connectAdmin();
</script></body></html>`, {headers:{"content-type":"text/html; charset=utf-8"}});
}

async function ensureAdPlatforms(env) {
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS ad_platforms (id INTEGER PRIMARY KEY AUTOINCREMENT, platform_key TEXT NOT NULL UNIQUE, name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 0, priority INTEGER NOT NULL DEFAULT 99, banner_enabled INTEGER NOT NULL DEFAULT 1, interstitial_enabled INTEGER NOT NULL DEFAULT 0, rewarded_enabled INTEGER NOT NULL DEFAULT 0, app_id TEXT NOT NULL DEFAULT '', banner_unit_id TEXT NOT NULL DEFAULT '', interstitial_unit_id TEXT NOT NULL DEFAULT '', rewarded_unit_id TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  const rows = await env.DB.prepare('SELECT COUNT(*) AS n FROM ad_platforms').first();
  if (!Number(rows?.n || 0)) {
    const seed=[['admob','AdMob'],['applovin','AppLovin'],['unity_levelplay','Unity LevelPlay'],['meta','Meta Audience Network'],['liftoff','Liftoff Monetize'],['inmobi','InMobi'],['pangle','Pangle'],['mintegral','Mintegral'],['dt_exchange','DT Exchange'],['bigo','BIGO Ads']];
    for (let i=0;i<seed.length;i++) await env.DB.prepare('INSERT INTO ad_platforms(platform_key,name,priority) VALUES(?,?,?)').bind(seed[i][0],seed[i][1],i+1).run();
  }
}
async function listAdPlatforms(env) { await ensureAdPlatforms(env); const r=await env.DB.prepare('SELECT * FROM ad_platforms ORDER BY active DESC, priority ASC, id ASC').all(); return r.results||[]; }

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, {status: 204, headers: {"access-control-allow-origin":"*","access-control-allow-methods":"GET,POST,PATCH,DELETE,OPTIONS","access-control-allow-headers":"Content-Type, Authorization"}});
    const url = new URL(request.url);
    try {
      if (url.pathname === "/health" && request.method === "GET") {
        let dbOk = false;
        try { await env.DB.prepare("SELECT 1 AS ok").first(); dbOk = true; } catch (_) {}
        return json({ok: dbOk, app: env.APP_NAME || "One TV", database: dbOk ? "connected" : "unavailable"});
      }
      if (url.pathname === "/config" && request.method === "GET") return json({
        app: env.APP_NAME || "One TV",
        backendVersion: "2026-11-01-onetv-v6-provider-driven",
        sports: { primary: "SportScore", cricketFallback: "OpenCricket", refreshMs: 20000 },
        openCricketKeyConfigured: !!env.OPENCRICKET_API_KEY,
        openCricketBaseUrl: String(env.OPENCRICKET_BASE_URL || "https://opencricketapi.com")
      });
      if (url.pathname === "/ads" && request.method === "GET") {
        const platforms=await listAdPlatforms(env);
        const active=platforms.filter(x=>Number(x.active)===1).sort((a,b)=>Number(a.priority)-Number(b.priority)).slice(0,3);
        return json({updatedAt:new Date().toISOString(),activePlatforms:active,availablePlatforms:platforms.map(x=>({platform_key:x.platform_key,name:x.name,active:!!x.active,priority:x.priority}))});
      }
      if (url.pathname === "/channels" && request.method === "GET") return json({version: Date.now(), channels: await listChannels(env)});
      if ((url.pathname === "/notice" || url.pathname === "/notices") && request.method === "GET") {
        const notice = await getActiveNotice(env);
        return json(notice ? {enabled:true, ...notice} : {enabled:false});
      }
      if (url.pathname === "/notifications" && request.method === "GET") return json(await notificationFeed(env));
      if (url.pathname === "/search" && request.method === "GET") return json({query:url.searchParams.get("q")||"",items:await publicSearch(url.searchParams.get("q")||"",env)});
      if (url.pathname === "/cricket/live" && request.method === "GET") {
        const result = await withSportFallback("cricket", "live", env);
        return json({updatedAt:new Date().toISOString(),matches:result.matches.map(m=>({id:m.id,providerMatchId:m.providerMatchId||"",name:m.name,status:m.statusText||m.status,state:m.status,competition:m.competition,round:m.round||"",format:m.format||"",venue:m.venue,result:m.result,startsAt:m.time,score:m.home?.score||m.away?.score||"",teams:[m.home,m.away].map(t=>({name:t.name,slug:String(t.slug||""),id:String(t.id||""),score:String(t.score??""),overs:String(t.overs??""),wickets:String(t.wickets??""),logo:String(t.logo||""),flag:String(t.flag||"")}))})),primaryProvider:"SportScore",fallbackProvider:"OpenCricket",provider:result.provider});
      }
      if (url.pathname === "/cricket/upcoming" && request.method === "GET") {
        const result = await withSportFallback("cricket", "upcoming", env);
        return json({updatedAt:new Date().toISOString(),matches:result.matches.map(m=>({id:m.id,providerMatchId:m.providerMatchId||"",name:m.name,status:m.statusText||m.status,state:m.status,competition:m.competition,round:m.round||"",format:m.format||"",venue:m.venue,result:m.result,startsAt:m.time,score:m.home?.score||m.away?.score||"",teams:[m.home,m.away].map(t=>({name:t.name,slug:String(t.slug||""),id:String(t.id||""),score:String(t.score??""),overs:String(t.overs??""),wickets:String(t.wickets??""),logo:String(t.logo||""),flag:String(t.flag||"")}))})),primaryProvider:"SportScore",fallbackProvider:"OpenCricket",provider:result.provider});
      }
      if (url.pathname === "/cricket/results" && request.method === "GET") {
        const result = await withSportFallback("cricket", "finished", env);
        return json({updatedAt:new Date().toISOString(),matches:result.matches.map(m=>({id:m.id,providerMatchId:m.providerMatchId||"",name:m.name,status:m.statusText||m.status,state:m.status,competition:m.competition,round:m.round||"",format:m.format||"",venue:m.venue,result:m.result,startsAt:m.time,score:m.home?.score||m.away?.score||"",teams:[m.home,m.away].map(t=>({name:t.name,slug:String(t.slug||""),id:String(t.id||""),score:String(t.score??""),overs:String(t.overs??""),wickets:String(t.wickets??""),logo:String(t.logo||""),flag:String(t.flag||"")}))})),primaryProvider:"SportScore",fallbackProvider:"OpenCricket",provider:result.provider});
      }
      const cricketMatchPath = url.pathname.match(/^\/cricket\/match\/(.+)$/);
      if (cricketMatchPath && request.method === "GET") {
        const result = await cricketMatch(decodeURIComponent(cricketMatchPath[1]), env);
        return json({match:result.match,primaryProvider:"SportScore",fallbackProvider:"OpenCricket",provider:result.provider});
      }
      const cricketTeamPath = url.pathname.match(/^\/cricket\/team\/(.+)$/);
      if (cricketTeamPath && request.method === "GET") {
        const result = await cricketTeam(decodeURIComponent(cricketTeamPath[1]), env);
        return json({sport:"cricket", team:result.team, recent:result.recent, upcoming:result.upcoming, matches:result.matches, provider:result.provider, primaryProvider:"SportScore", fallbackProvider:"OpenCricket"});
      }
      if (url.pathname === "/cricket/health" && request.method === "GET") {
        try { const result = await withSportFallback("cricket", "live", env); return json({ok:true,primaryProvider:"SportScore",fallbackProvider:"OpenCricket",provider:result.provider,openCricketKeyConfigured:!!env.OPENCRICKET_API_KEY,liveMatches:result.matches.length}); }
        catch (e) { return json({ok:false,primaryProvider:"SportScore",fallbackProvider:"OpenCricket",openCricketKeyConfigured:!!env.OPENCRICKET_API_KEY,error:String(e.message||e)},502); }
      }
      const sportPath = url.pathname.match(/^\/sports\/(football|basketball|cricket|tennis|baseball)\/(live|upcoming|results)$/);
      if (sportPath && request.method === "GET") {
        const sport = sportPath[1], mode = sportPath[2];
        const status = mode === "results" ? "finished" : mode;
        const result = await sportsList(sport,status,env);
        return json({updatedAt:new Date().toISOString(), sport, mode, matches:result.matches, primaryProvider:"SportScore", fallbackProvider:sport === "cricket" ? "OpenCricket" : null, provider:result.provider});
      }
      const sportTeamPath = url.pathname.match(/^\/sports\/(football|basketball|cricket|tennis|baseball)\/team\/(.+)$/);
      if (sportTeamPath && request.method === "GET") {
        const sport=sportTeamPath[1], slug=decodeURIComponent(sportTeamPath[2]);
        const result = await sportScoreTeam(sport, slug, env);
        return json({sport, team:result.team, recent:result.recent, upcoming:result.upcoming, matches:result.matches, provider:result.provider, primaryProvider:"SportScore", fallbackProvider:sport === "cricket" ? "OpenCricket" : null});
      }
      const sportMatchPath = url.pathname.match(/^\/sports\/(football|basketball|cricket|tennis|baseball)\/match\/(.+)$/);
      if (sportMatchPath && request.method === "GET") {
        const sport=sportMatchPath[1], id=decodeURIComponent(sportMatchPath[2]);
        const result = await sportScoreMatchDetail(sport,id,env);
        return json({sport, match:result.match, primaryProvider:"SportScore", fallbackProvider:sport === "cricket" ? "OpenCricket" : null, provider:result.provider});
      }
      if (url.pathname === "/viewer/ping" && request.method === "POST") {
        const b = await request.json();
        const viewerId = String(b.viewerId || "").trim();
        const channelId = Number(b.channelId || 0);
        if (!viewerId || !channelId) return json({error:"viewerId and channelId are required"},400);
        const existing = await env.DB.prepare("SELECT channel_id FROM viewer_sessions WHERE viewer_id=?").bind(viewerId).first();
        if (!existing || Number(existing.channel_id) !== channelId) {
          await env.DB.prepare("INSERT INTO channel_views(channel_id,viewer_id,started_at) VALUES(?,?,CURRENT_TIMESTAMP)").bind(channelId,viewerId).run();
        }
        await env.DB.prepare("INSERT INTO viewer_sessions(viewer_id,channel_id,last_seen) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(viewer_id) DO UPDATE SET channel_id=excluded.channel_id,last_seen=CURRENT_TIMESTAMP").bind(viewerId,channelId).run();
        return json({ok:true});
      }
      if (url.pathname === "/viewer/ping" && request.method === "OPTIONS") return new Response(null,{status:204});

      if (url.pathname === "/admin" && request.method === "GET") return adminPage(env);
      if (!url.pathname.startsWith("/admin/")) return text("Not found", 404);
      if (!adminOk(request, env)) return json({error:"Unauthorized"}, 401);

      if (url.pathname === "/admin/stats" && request.method === "GET") {
        await cleanupViewers(env);
        const rows = await env.DB.prepare(`SELECT c.id,c.name,c.category,c.active,
          (SELECT COUNT(*) FROM viewer_sessions v WHERE v.channel_id=c.id AND v.last_seen >= datetime('now','-90 seconds')) AS viewers,
          (SELECT COUNT(*) FROM channel_views cv WHERE cv.channel_id=c.id) AS total_views,
          (SELECT COUNT(*) FROM channel_views cv WHERE cv.channel_id=c.id AND cv.started_at >= datetime('now','-24 hours')) AS views_24h
          FROM channels c ORDER BY c.sort_order ASC,c.id ASC`).all();
        const totals = await env.DB.prepare(`SELECT COUNT(*) AS total_views, COUNT(DISTINCT viewer_id) AS unique_viewers FROM channel_views`).first();
        return json({channels: rows.results || [], totals: totals || {total_views:0,unique_viewers:0}});
      }
      if (url.pathname === "/admin/ads" && request.method === "GET") return json(await listAdPlatforms(env));
      if (url.pathname === "/admin/ads" && request.method === "PATCH") {
        const b=await request.json(); await ensureAdPlatforms(env);
        if (Array.isArray(b.platforms)) {
          for (const x of b.platforms) {
            const key=String(x.platform_key||'').trim(); if(!key) continue;
            await env.DB.prepare(`UPDATE ad_platforms SET active=?,priority=?,banner_enabled=?,interstitial_enabled=?,rewarded_enabled=?,app_id=?,banner_unit_id=?,interstitial_unit_id=?,rewarded_unit_id=?,updated_at=CURRENT_TIMESTAMP WHERE platform_key=?`).bind(x.active?1:0,Number(x.priority||99),x.banner_enabled===false?0:1,x.interstitial_enabled?1:0,x.rewarded_enabled?1:0,String(x.app_id||''),String(x.banner_unit_id||''),String(x.interstitial_unit_id||''),String(x.rewarded_unit_id||''),key).run();
          }
        }
        return json(await listAdPlatforms(env));
      }
      if (url.pathname === "/admin/channels" && request.method === "GET") return json(await adminListChannels(env));
      if (url.pathname === "/admin/channels" && request.method === "POST") {
        const b = await request.json();
        const requestedType = String(b.source_type || "link").toLowerCase();
        const sourceType = ["link","api","youtube"].includes(requestedType) ? requestedType : "link";
        const sourceValue = String(b.source_value || (sourceType === "link" ? b.stream_url || "" : ""));
        if (!b.name) return json({error:"Channel name is required"},400);
        if (!sourceValue) return json({error: sourceType === "api" ? "API URL is required" : sourceType === "youtube" ? "YouTube URL is required" : "Stream link is required"},400);
        await env.DB.prepare(`INSERT INTO channels(channel_number,name,country,category,logo_url,stream_url,source_type,source_value,api_key,program_name,program_api_url,show_viewers,loop_playback,active,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
          .bind(String(b.channel_number||""),String(b.name),String(b.country||"International"),String(b.category||"TV"),String(b.logo_url||""),String(b.stream_url||""),sourceType,sourceValue,String(b.api_key||""),String(b.program_name||""),String(b.program_api_url||""),b.show_viewers?1:0,b.loop_playback?1:0,b.active===false?0:1,Number(b.sort_order||0)).run();
        return json({ok:true},201);
      }

      if (url.pathname === "/admin/notices" && request.method === "GET") return json(await adminListNotices(env));
      if (url.pathname === "/admin/notices" && request.method === "POST") {
        const b = await request.json();
        const type = ["text","banner","video"].includes(String(b.type||"text")) ? String(b.type||"text") : "text";
        const html = cleanHtml(b.html_content || "");
        const media = String(b.media_url || "");
        if (type === "text" && !html.trim()) return json({error:"Notice text is required"},400);
        if (type !== "text" && !media.trim()) return json({error:"Media URL is required"},400);
        await env.DB.prepare(`INSERT INTO notices(type,title,html_content,media_url,link_url,active,sort_order) VALUES(?,?,?,?,?,?,?)`)
          .bind(type,String(b.title||""),html,media,String(b.link_url||""),b.active===false?0:1,Number(b.sort_order||0)).run();
        return json({ok:true},201);
      }

      let m = url.pathname.match(/^\/admin\/channels\/(\d+)$/);
      if (m) {
        const id = Number(m[1]);
        if (request.method === "DELETE") { await env.DB.prepare("DELETE FROM channels WHERE id=?").bind(id).run(); return json({ok:true}); }
        if (request.method === "PATCH") {
          const b = await request.json();
          const requestedType = String(b.source_type || "link").toLowerCase();
          const sourceType = ["link","api","youtube"].includes(requestedType) ? requestedType : "link";
          const sourceValue = String(b.source_value || (sourceType === "link" ? b.stream_url || "" : ""));
          if (!b.name) return json({error:"Channel name is required"},400);
          if (!sourceValue) return json({error: sourceType === "api" ? "API URL is required" : sourceType === "youtube" ? "YouTube URL is required" : "Stream link is required"},400);
          await env.DB.prepare(`UPDATE channels SET channel_number=?,name=?,country=?,category=?,logo_url=?,stream_url=?,source_type=?,source_value=?,api_key=?,program_name=?,program_api_url=?,show_viewers=?,loop_playback=?,active=?,sort_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
            .bind(String(b.channel_number||""),String(b.name),String(b.country||"International"),String(b.category||"TV"),String(b.logo_url||""),String(b.stream_url||""),sourceType,sourceValue,String(b.api_key||""),String(b.program_name||""),String(b.program_api_url||""),b.show_viewers?1:0,b.loop_playback?1:0,b.active===false?0:1,Number(b.sort_order||0),id).run();
          return json({ok:true});
        }
      }

      m = url.pathname.match(/^\/admin\/notices\/(\d+)$/);
      if (m) {
        const id = Number(m[1]);
        if (request.method === "DELETE") { await env.DB.prepare("DELETE FROM notices WHERE id=?").bind(id).run(); return json({ok:true}); }
        if (request.method === "PATCH") {
          const b = await request.json();
          const type = ["text","banner","video"].includes(String(b.type||"text")) ? String(b.type||"text") : "text";
          const html = cleanHtml(b.html_content || "");
          const media = String(b.media_url || "");
          if (type === "text" && !html.trim()) return json({error:"Notice text is required"},400);
          if (type !== "text" && !media.trim()) return json({error:"Media URL is required"},400);
          await env.DB.prepare(`UPDATE notices SET type=?,title=?,html_content=?,media_url=?,link_url=?,active=?,sort_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
            .bind(type,String(b.title||""),html,media,String(b.link_url||""),b.active===false?0:1,Number(b.sort_order||0),id).run();
          return json({ok:true});
        }
      }

      return text("Not found",404);
    } catch (e) {
      return json({error: e?.message || "Server error"},500);
    }
  }
};
