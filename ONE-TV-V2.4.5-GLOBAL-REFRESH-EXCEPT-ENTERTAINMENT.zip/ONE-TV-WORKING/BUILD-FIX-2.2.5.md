# ONE TV 2.2.5 Build Fix

Fixed the release compilation error caused by a literal `\n` sequence in MainActivity.java imports.

Correct Java imports are now:
- import android.widget.SeekBar;
- import android.widget.Space;

Version: 2.2.5
versionCode: 20
