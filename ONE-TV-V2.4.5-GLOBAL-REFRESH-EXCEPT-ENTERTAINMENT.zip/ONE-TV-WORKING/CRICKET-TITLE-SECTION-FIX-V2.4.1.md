# ONE TV v2.4.1 - Cricket Match Title Section

This release fixes only the cricket match title block.

Required structure for every cricket listing:
1. Tournament logo or monogram + tournament title.
2. Match title on the next line, always italic. Example: `5th T20I • Hamilton, Seddon Park`.
3. Time/date/schedule on the next line, same text size as the match title and not italic.

Tournament title is bold and slightly larger than the other two lines. The title block is independent from the team/score area below.

No football, basketball, or tennis listing layout was changed.
