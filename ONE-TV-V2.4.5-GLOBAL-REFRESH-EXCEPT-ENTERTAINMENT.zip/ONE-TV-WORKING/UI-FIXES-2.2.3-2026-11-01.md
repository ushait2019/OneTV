# ONE TV UI Fix 2.2.3

- Fixed Normal-theme header contrast: menu, search, notification and All in One now use theme-aware contrast.
- Replaced emoji-style header search/bell/menu glyphs with clean vector icons.
- Moved “All in One” below the ONE TV logo and rebalanced header spacing/alignment.
- Added light/dark system-bar icon handling for Normal theme.
- Made the ad area content-driven: no visible ad means the ad row is GONE and the middle content expands into that space.
- Loaded ads reveal the existing dedicated bottom ad area without changing the content behavior.
- Removed decorative ad-card shapes when no ad is present.
- Version: 2.2.3 / versionCode 18.
