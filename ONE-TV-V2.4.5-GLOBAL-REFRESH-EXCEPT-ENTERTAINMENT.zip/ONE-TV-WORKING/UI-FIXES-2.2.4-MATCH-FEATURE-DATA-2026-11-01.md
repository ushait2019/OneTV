# ONE TV UI Fix 2.2.4 - Match Feature Data

## Fixed
- Match detail feature tabs now search provider payloads through nested provider containers instead of only direct top-level keys.
- Cricket Live now accepts commentary, ball-by-ball, timeline and event payloads.
- Cricket Squads now accepts squads, squad, players, lineups and playing-XI variants.
- Cricket Overs now accepts overs, over-by-over, balls and innings payloads.
- Cricket Commentary now accepts commentary, ball-by-ball, timeline and events.
- Cricket Highlights now accepts highlights, key events, timeline and events.
- Cricket Series now surfaces series information without the previous placeholder sublabel.
- Cricket Scorecard now preserves team scores from both normalized team objects and provider score fields, and surfaces innings summaries before detailed scorecard sections.
- Generic tables and provider event renderers now support nested data containers.
- Nested provider objects are flattened to readable fields while URLs and empty/null values are omitted.
- No fabricated scores, players, commentary or statistics are added.

## Version
- versionName: 2.2.4
- versionCode: 19
