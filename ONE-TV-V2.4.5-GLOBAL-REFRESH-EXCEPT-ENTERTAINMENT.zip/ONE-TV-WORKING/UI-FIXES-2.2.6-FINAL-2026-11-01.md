# ONE TV UI / Search / Notification Final Fixes — 2.2.6

Date: 2026-11-01

## Fixed

- Reworked the top shell spacing using system insets and a smaller responsive header.
- Replaced the oversized search button treatment with a compact circular search control and cleaned search vector.
- Rebuilt the in-app Search screen with a compact search field and keyboard search action.
- Search now calls the ONE TV `/search` backend endpoint and renders provider-backed match results plus configured entertainment channels.
- Backend search now checks the current live feed and a small upcoming/recently-finished provider date window.
- Removed user-facing `Provider match metadata` fallback text.
- Removed raw/unknown provider status presentation such as `Abnormal`.
- Match-state details are rendered only when the provider actually supplies those fields.
- Notification page no longer shows backend/provider explanatory filler text.
- Fresh notification state is clean. Initial live-state discovery is recorded silently instead of manufacturing a notification.
- Notification cards without a match target are non-clickable, preventing invalid notification navigation.
- Added a compact, intentional `No notifications` empty state.
- Theme control is now an explicit dropdown with only `Normal` and `Dark`; touching the settings row does not toggle the theme.
- Theme dropdown styling was rebuilt as a compact popup with selected-state highlighting.
- Theme/background/footer/header colors remain synchronized.
- Sports auto-refresh remains 30 seconds, stops while paused, and resumes when the activity returns.
- Pull-to-refresh remains enabled for Sports pages.
- Removed `Backend-controlled` wording from the user-facing Entertainment UI. User-facing copy now uses `Live channels`, `Entertainment`, and `Coming soon`.
- Removed provider-source filler labels from cricket scorecard sections.
- Player avatars are shown only when the provider supplies a real player image. No generated/fake player portraits are used.
- Version bumped to `2.2.6` / `versionCode 21`.

## Validation

- Java brace/parenthesis/bracket balance checked.
- All Android XML resources parse successfully.
- Cloudflare Worker JavaScript passes `node --check`.
- Source remains configured for the existing ONE TV backend and existing SportScore/OpenCricket architecture.
