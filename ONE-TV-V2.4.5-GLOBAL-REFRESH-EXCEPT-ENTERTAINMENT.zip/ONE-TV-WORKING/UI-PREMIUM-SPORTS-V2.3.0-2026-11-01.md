# ONE TV Premium Sports UI V2.3.0

## Design basis
Reviewed current patterns from SofaScore, Flashscore and FotMob. The goal is not to copy any product, but to combine strong patterns into a distinct ONE TV visual system.

Reference patterns reviewed:
- SofaScore: deep match data, ratings, heatmaps, momentum and visual analytics.
- Flashscore: fast multi-sport score scanning, alerts and dense match navigation.
- FotMob: clean matchday hierarchy, lineups, ratings, xG/shot-map style data presentation.

## ONE TV changes
- Premium match cards with stronger competition/status hierarchy.
- Team identity layer restored: provider logo first, flag second, monogram fallback.
- Team scores remain visible and prominent.
- Match hero redesigned around team identity, score, status and metadata.
- Player rows always retain a visual identity: real provider avatar when available, initials monogram when not.
- Provider metric grids use cleaner 3-column presentation and no raw "Provider" labels.
- Sport section icons are cleaner and sport-specific instead of a generic trophy.
- Existing data fields and provider payloads are preserved; no fabricated scores/statistics added.
- Search, notifications, backend and unrelated entertainment behavior were not intentionally rewritten in this step.

## Version
- versionName: 2.3.0
- versionCode: 22

## Validation
- Java delimiter counts balanced.
- Cloudflare Worker passed `node --check`.
- Full Android APK build was not run locally because Gradle is not installed in the runtime. Use the existing GitHub Actions workflow for the APK/AAB build.
