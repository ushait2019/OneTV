# ONE TV V2.4.7

## Cricket match title provider-data fix

- Provider-supplied explicit match name/title is now authoritative for the Cricket listing title.
- Example values such as `5th`, `T20I`, `Hamilton`, or `Seddon Park` are not hard-coded.
- If the provider supplies a match title, that exact title is shown.
- If the provider also supplies a venue, the venue is appended as ` - Venue`.
- If no complete provider match title exists, provider round/format fields are used only as a data-backed fallback.
- No venue is invented when provider venue data is absent.
- Previous V2.4.6 cumulative fixes remain the baseline.
