# One TV Backend-Driven Architecture V1

Supported runtime controls: sports data/status, live score/commentary payloads already supported by the client, provider fallback, refresh intervals, status labels, notifications refresh, channel sources, ads configuration, and notices.

New native SDKs, permissions, manifest changes, screens/components not already built, or new native capabilities still require a new APK/AAB.

Remote configuration: GET `/config`; admin GET/PATCH `/admin/config`.
API credentials remain server-side.
