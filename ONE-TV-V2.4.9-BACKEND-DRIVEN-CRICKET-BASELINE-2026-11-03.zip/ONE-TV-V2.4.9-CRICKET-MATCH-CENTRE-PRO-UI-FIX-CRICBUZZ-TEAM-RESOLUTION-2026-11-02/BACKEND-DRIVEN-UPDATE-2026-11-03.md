# One TV Backend-Driven Update - 2026-11-03

This is the cumulative baseline built on the previous Cricket Live Scoreboard/Status/Commentary fix.

## Purpose
Reduce the need for APK rebuilds after the first stable store release.

## Included
- Remote `/config` endpoint consumed by the Android client.
- D1 `app_config` table with safe defaults and self-initialization.
- Admin Panel > App Config tab.
- Backend-controlled supported refresh intervals.
- Backend-controlled Live Now / Upcoming / Finished labels.
- Backend-controlled LIVE NOW badge label.
- Backend-controlled live-score auto-refresh toggle.
- Backend-controlled remote-data enable/disable toggle.
- Existing provider/fallback, score, commentary, channel and ad controls remain intact.
- Existing UI layout/design is preserved.

## No rebuild required for supported backend changes
Once this build is installed, supported changes delivered through the existing backend contract can be made server-side.

## Rebuild still required
A new native SDK, new Android permission, new manifest requirement, a new screen/component not already present, or a new native capability still requires an APK/AAB update.

## Deployment
Run `backend/migration-app-config.sql` on D1. The backend also creates/defaults the table automatically when `/config` or the admin config endpoint is used.
