# Cricket Live Scoreboard + Match Status Fix - 2026-11-03

Applied on top of the previous BUILD-FIX baseline.

## Match listing status
- Home/live listings: `Live Now`
- Sports front/list pages: `Live Now`, `Upcoming`, `Finished` where applicable
- Results page: status badge intentionally omitted
- Status badge is aligned to the right of the competition/title row with responsive sizing.
- `VS` remains in the center of team matchups. `LIVE` is no longer rendered in place of `VS`.

## Match detail hero
- Live status badge is more prominent and premium, using a slightly larger pill.
- Live badge remains at the top-right of the match hero.

## Cricket Live tab
- Added a dedicated live scoreboard layout.
- Current team scores, overs, target, required runs, CRR and RRR are displayed when supplied by the provider.
- Current batters and current bowler are shown when supplied.
- Over-by-over data is shown when supplied.
- Ball-by-ball commentary is rendered with over/ball, commentary text and event badges for 4, 6 and wicket when provider data exposes them.
- Provider result text is shown for completed matches when available.

## Automatic live updates
- Match detail refreshes automatically about every 20 seconds while the match screen is open.
- Backend detail caching is reduced to about 10 seconds for live-detail provider calls so the client refresh can receive new score/commentary data.
- Polling stops when the match is finished, cancelled or abandoned.
- Transient provider/network errors schedule another refresh attempt.

## Provider enrichment
- Cricbuzz detail enrichment now also requests commentary data when available.
- Cricbuzz miniscore data is mapped into current batters/current bowler/current score/over/target/required/CRR/RRR fields when available.
- SportScore detail normalization accepts additional current-bowler/current-batter field names.

## Build/testing status
- Backend JavaScript syntax checked with `node --check` successfully.
- Android Release APK/AAB was not compiled in this environment because the Android SDK/Gradle toolchain is not installed here. GitHub Actions should be used for the actual Release build.
- No live Cloudflare, SportScore or Cricbuzz credentials were tested from this environment.
