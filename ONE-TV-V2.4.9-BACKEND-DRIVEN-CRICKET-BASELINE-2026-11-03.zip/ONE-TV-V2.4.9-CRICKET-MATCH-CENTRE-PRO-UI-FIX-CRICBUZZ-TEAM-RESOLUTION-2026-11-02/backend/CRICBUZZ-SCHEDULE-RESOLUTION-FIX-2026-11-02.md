# Cricbuzz Schedule Resolution Fix - 2026-11-02

Cumulative backend fix for cricket Match Centre detail resolution.

## Resolution order

1. SportScore detail
2. Cricbuzz live/upcoming/recent match feeds
3. Cricbuzz schedule feeds (`international`, `league`, `domestic`, `women`)
4. OpenCricket fallback

## Schedule matching

The backend resolves a SportScore match reference using the SportScore team slugs and start time, then scores Cricbuzz candidates by exact/reverse team pair and time proximity. The Cricbuzz schedule endpoint is paged using `lastTime` variants around the requested start timestamp so matches that are not present in the first live/upcoming/recent page can still be resolved.

The Cricbuzz RapidAPI documentation identifies `/schedule/v1/{type}?lastTime` as the schedule endpoint and documents the four schedule types used here.

No Android UI changes were made. All previously implemented provider fallbacks remain cumulative.
