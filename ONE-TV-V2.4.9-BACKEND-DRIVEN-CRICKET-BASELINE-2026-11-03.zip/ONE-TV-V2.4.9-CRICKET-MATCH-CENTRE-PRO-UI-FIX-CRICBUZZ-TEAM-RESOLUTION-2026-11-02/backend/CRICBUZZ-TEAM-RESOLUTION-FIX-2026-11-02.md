# Cricbuzz Team Schedule/Results Resolution Fix - 2026-11-02

This cumulative fix preserves all previous One TV backend/provider changes and adds a stronger Cricbuzz match-ID resolution path.

## Problem observed

SportScore match-detail requests can return a provider match reference whose Cricbuzz equivalent is not present in the generic live/upcoming/recent lists or in the schedule pages searched by timestamp. The previous fallback therefore ended with:

`Cricbuzz could not resolve the selected cricket match by teams and start time`

## New resolution order

For a SportScore cricket match reference, the backend now tries Cricbuzz team-based resolution before the existing generic lists and schedule fallback:

1. Cricbuzz team lists for league/domestic/international/women.
2. Resolve the selected home/away teams by normalized team name.
3. Query the resolved team's `/teams/v1/{teamId}/schedule` and `/teams/v1/{teamId}/results` endpoints.
4. Match the returned fixtures by team pair and start-time proximity.
5. If unresolved, continue with the existing Cricbuzz live/upcoming/recent and schedule resolution.
6. If Cricbuzz still cannot resolve the match, continue to OpenCricket as the existing final fallback.

This path is designed to handle stale or shifted SportScore timestamps while retaining team identity as the primary match key.

## UI impact

No Android UI changes were made.
