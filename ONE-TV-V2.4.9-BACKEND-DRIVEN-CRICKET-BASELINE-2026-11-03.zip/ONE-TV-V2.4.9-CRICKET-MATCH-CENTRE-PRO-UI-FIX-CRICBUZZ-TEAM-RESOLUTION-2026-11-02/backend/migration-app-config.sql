-- ONE TV remote app configuration
CREATE TABLE IF NOT EXISTS app_config (config_key TEXT PRIMARY KEY, config_value TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
INSERT OR IGNORE INTO app_config(config_key,config_value) VALUES ('sports_refresh_ms','30000'),('cricket_detail_refresh_ms','20000'),('notifications_refresh_ms','30000'),('status_live','Live Now'),('status_upcoming','Upcoming'),('status_finished','Finished'),('status_live_badge','LIVE NOW'),('live_score_refresh_enabled','true'),('remote_data_enabled','true');
