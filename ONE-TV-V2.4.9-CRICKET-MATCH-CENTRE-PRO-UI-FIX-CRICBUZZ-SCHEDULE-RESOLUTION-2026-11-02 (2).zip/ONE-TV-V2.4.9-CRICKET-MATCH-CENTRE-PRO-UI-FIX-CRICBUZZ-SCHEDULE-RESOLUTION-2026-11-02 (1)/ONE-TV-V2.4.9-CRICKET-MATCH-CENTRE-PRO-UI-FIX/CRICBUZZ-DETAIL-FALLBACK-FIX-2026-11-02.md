# Cricbuzz Detail Fallback Fix — 2026-11-02

## Purpose

The SportScore cricket Match Centre can fail when a SportScore-specific match detail ID is not accepted by the primary provider. The previous fallback then attempted OpenCricket resolution, which could fail because provider IDs and coverage are not interchangeable.

## Fix

When SportScore cricket match detail fails, the backend now tries Cricbuzz first:

1. Parse the SportScore match reference into home team, away team, and start time.
2. Query Cricbuzz live, upcoming, and recent match lists.
3. Resolve the Cricbuzz-native match ID using team-pair matching plus start-time proximity.
4. Fetch the Cricbuzz match info and scorecard with the native Cricbuzz ID.
5. Return Cricbuzz as the detail provider if resolved successfully.
6. Keep the existing OpenCricket fallback as the final fallback.

No Android UI changes were made.
