# ONE TV V2.4.8 - Cricket Match Centre Data Fix

- Based on V2.4.7.
- SportScore remains the primary provider; OpenCricket remains cricket fallback.
- Match-detail lookup now resolves fixture IDs to the provider slug across nearby UTC dates before retrying the match endpoint.
- Cricket detail normalization now preserves provider-supplied commentary, over-by-over, highlights, squads, innings, batting, bowling, fall of wickets, partnerships, extras, current batters, scorecard and series data.
- Android match centre reads the normalized match payload first instead of preferring an isolated raw-provider container.
- Cricket feature tabs no longer use innings as a fallback for the Over-by-over tab, or timeline as a fallback for Highlights, preventing cross-section data mismatches.
- Summary-level team score/logo/flag/overs/wickets and match metadata are merged into detail only when the detail response is missing those fields.
- No demo or fabricated sports values are added. Provider fields that are genuinely unavailable remain absent.

Version: 2.4.8
Version code: 40
