# ONE TV v2.4.9 - Cricket Match Centre Data & UI Fix

Baseline: v2.4.8

## Scope
This release fixes the Cricket Match Centre information architecture and feature-level data rendering without changing unrelated Sports or Entertainment behavior.

## Fixed information architecture
- Overview: match summary, score/state, basic match information only.
- Live: live score state, current batters, current bowler and live-specific state.
- Scorecard: batting, bowling, extras, fall of wickets, partnerships, innings-wise.
- Squads: squad / playing XI.
- Overs: over-by-over data only.
- Commentary: commentary / ball-by-ball data only.
- Highlights: provider highlights / key events only.
- Series: series metadata and series matches when supplied.

## Data handling
- Provider payload is preserved alongside normalized fields so provider-specific nested data is not lost.
- Cricket scorecard sections are collected from direct provider fields, scorecard containers, and innings containers.
- No section uses another feature's data as a substitute.
- No fabricated player, score, partnership, FOW, extras or commentary data is generated.
- Missing provider fields remain absent rather than being filled with unrelated data.
- Player provider images remain first priority, with deterministic gender-correct fallback avatars when gender is explicitly supplied.

## UI
- Batting rows expose player, dismissal/status, R, B, 4s, 6s and SR when supplied.
- Bowling rows expose player, O, M, R, W and ECO when supplied.
- Fall of Wickets uses wicket number, batter, score and over.
- Partnerships use both batters and partnership runs/balls when supplied.
- Extras are shown as a dedicated section.
- Current batters are shown on Live, not Overview.
- Overs, Commentary and Highlights no longer fall back to unrelated arrays.
- Layout uses responsive cards and compact stat columns intended for mobile screens.

## Version
- versionCode: 41
- versionName: 2.4.9
