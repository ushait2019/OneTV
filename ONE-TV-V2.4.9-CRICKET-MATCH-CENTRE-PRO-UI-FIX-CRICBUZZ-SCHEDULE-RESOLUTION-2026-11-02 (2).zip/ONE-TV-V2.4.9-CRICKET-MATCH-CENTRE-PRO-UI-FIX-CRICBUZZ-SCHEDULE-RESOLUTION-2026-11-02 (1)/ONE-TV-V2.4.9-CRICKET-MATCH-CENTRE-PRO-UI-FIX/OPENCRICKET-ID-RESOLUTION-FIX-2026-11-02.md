# OpenCricket Match-ID Resolution Fix — 2026-11-02

## Problem confirmed
When SportScore match-detail lookup fails, the previous OpenCricket fallback could pass a SportScore-specific canonical ID directly into OpenCricket. A SportScore ID such as:

`montreal-warriors-vs-brampton-blazers:2026-11-01t23:00:00+00:00`

is not an OpenCricket-native match ID, so OpenCricket could return HTTP 400.

## Fix
- Parse the SportScore cricket reference into home-team slug, away-team slug, and start time.
- Query the OpenCricket match catalog for the requested date and nearby dates (±1 and ±2 days).
- Resolve the corresponding OpenCricket match using team-pair matching first and start-time proximity as an additional discriminator.
- Only after resolving the provider-native OpenCricket ID is the detail endpoint called.
- Existing OpenCricket-native `match_*` IDs continue to use the direct detail endpoint.
- No Android UI changes.
- No changes to SportScore primary behavior, CricketData enrichment, Cricbuzz enrichment, or OpenCricket list fallback behavior.
