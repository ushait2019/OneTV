# Cricbuzz Schedule Resolution Fix — 2026-11-02

## Purpose

The previous cumulative fallback searched only Cricbuzz `live`, `upcoming`, and
`recent` match feeds when resolving a SportScore match ID.

Some league matches may not appear on those first-page feeds. This fix keeps
the existing fallback order and adds Cricbuzz schedule feeds:

- `/schedule/v1/league`
- `/schedule/v1/domestic`
- `/schedule/v1/international`
- `/schedule/v1/women`

The resolver still requires a strong team-pair match and uses start-time
proximity before calling the native Cricbuzz match-detail endpoint.

## Fallback order

1. SportScore detail
2. Cricbuzz native match-detail resolution
   - live
   - upcoming
   - recent
   - schedule feeds
3. OpenCricket detail fallback

No Android UI changes were made.
