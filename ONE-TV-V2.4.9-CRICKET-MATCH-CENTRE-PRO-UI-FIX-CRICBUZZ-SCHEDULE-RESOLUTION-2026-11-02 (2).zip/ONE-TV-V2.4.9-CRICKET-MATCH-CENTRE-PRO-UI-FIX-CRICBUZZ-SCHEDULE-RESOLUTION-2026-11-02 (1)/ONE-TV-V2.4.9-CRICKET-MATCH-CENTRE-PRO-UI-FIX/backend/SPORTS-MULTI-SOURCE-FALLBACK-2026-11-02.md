# One TV Sports Multi-Source / Field-Level Fallback

Date: 2026-11-02

## Baseline
v2.4.9 Cricket Match Centre. Existing SportScore primary + OpenCricket full-provider fallback is preserved.

## New layer
Cricket now supports optional field-level enrichment without replacing the SportScore match object:

1. SportScore remains the primary source.
2. CricketData can enrich missing live score / overs / venue fields from `/v1/currentMatches` when `CRICKETDATA_API_KEY` is configured.
3. Cricbuzz via RapidAPI can enrich missing Cricket Match Centre detail fields when `CRICBUZZ_RAPIDAPI_KEY` is configured.
4. OpenCricket remains the full-provider fallback only when SportScore itself fails.

The Android app never calls these providers directly. All keys remain server-side.

## Cricbuzz detail sources
The Worker uses the documented RapidAPI Cricbuzz endpoints:
- `/matches/v1/live`
- `/matches/v1/recent`
- `/matches/v1/upcoming`
- `/mcenter/v1/{matchId}`
- `/mcenter/v1/{matchId}/scard`

The provider match is resolved by team identity before enrichment. A Cricbuzz record is not merged merely because its ID or name is similar.

## Merge rule
Only missing fields are filled. Existing SportScore values are never overwritten by Cricbuzz or CricketData.

Empty arrays/objects are considered missing and may be populated. Non-empty provider data remains authoritative for the primary source.

## Configuration
Set these as Cloudflare Worker secrets when available:
- `CRICBUZZ_RAPIDAPI_KEY`
- `CRICKETDATA_API_KEY`

Optional Worker variable:
- `CRICBUZZ_RAPIDAPI_HOST` (default `cricbuzz-cricket.p.rapidapi.com`)

Existing secrets remain unchanged:
- `OPENCRICKET_API_KEY`
- `ADMIN_TOKEN`
- `YOUTUBE_API_KEY`

## Quota strategy
The enrichment providers are optional and cached. They are not called from Android per user. The Worker cache is used to reduce upstream requests.

This is not a quota bypass mechanism. Each provider is used under its own published plan and terms.
