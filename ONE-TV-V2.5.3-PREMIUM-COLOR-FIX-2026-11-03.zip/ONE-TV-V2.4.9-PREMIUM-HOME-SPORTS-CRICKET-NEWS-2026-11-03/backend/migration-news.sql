CREATE TABLE IF NOT EXISTS news_articles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_name TEXT NOT NULL,
  source_url TEXT NOT NULL,
  source_published_at TEXT NOT NULL DEFAULT '',
  fingerprint TEXT NOT NULL UNIQUE,
  headline TEXT NOT NULL,
  summary TEXT NOT NULL,
  body TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'Other',
  tags_json TEXT NOT NULL DEFAULT '[]',
  source_score REAL NOT NULL DEFAULT 0,
  published_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_news_active_published ON news_articles(active,published_at DESC);
CREATE INDEX IF NOT EXISTS idx_news_category_published ON news_articles(category,published_at DESC);
