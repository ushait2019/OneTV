ONE TV MASTER SOURCE - CURRENT BASELINE
Prepared: 2026-11-04

This package consolidates the latest available One TV v2.5.6 source snapshot,
the two project specification PDFs, and the supplied USHA IT brand assets.

IMPORTANT IMPLEMENTATION STATUS
- Existing Google Mobile Ads SDK dependency and Banner AdView integration are present.
- Backend currently seeds/configures 10 ad platform records and exposes /ads and admin controls.
- The current Android app only actively renders the AdMob banner integration.
- Native SDK adapters for AppLovin, Unity LevelPlay, Meta Audience Network, Liftoff,
  InMobi, Pangle, Mintegral, DT Exchange and BIGO are NOT integrated/verified in this snapshot.
- Additional ad formats (native, interstitial, rewarded, app-open, etc.) are NOT fully
  implemented as executable Android placements in this snapshot.
- Therefore this archive is a consolidated current source baseline, NOT a completed
  production-final build and NOT proof that all ad platforms/formats are operational.

Before production finalization, each SDK integration requires dependency/version and
Android compatibility checks, applicable account/app IDs and ad-unit configuration,
manifest/ProGuard review, consent/privacy compliance, test-device validation, and
provider-side approval. Backend switches cannot install a missing native SDK.

The supplied project PDFs remain the controlling project specifications. Preserve
existing UI, global bottom ad placements, provider logic and other locked requirements.


ONE TV 2.5.7 IMPLEMENTATION UPDATE (2026-11-04)
- Added a 1.2-second animated OneTV startup identity sequence.
- Consumer Live TV/video discovery routes are disabled; the home/drawer entry now opens Photo Stories.
- Photo Stories and news cards use only HTTPS image URLs supplied by the configured licensed news provider.
- Player/team photo fallbacks use neutral initials/monograms rather than a different athlete's photo or a generated gender avatar.
- News image_url is persisted and returned by the backend; news scheduler candidate fetch now receives its Worker environment.
- Version is 2.5.7 / versionCode 47.

IMPORTANT RELEASE STATUS
This is an updated source archive, not a certified production release. Android SDK/Gradle are not available in the build environment, so no APK/AAB or device-level full-route QA was produced. The complete 72-page route inventory is not yet fully implemented in this source snapshot. Real news/photo content requires a licensed provider API and server-side credentials. Sports images require the configured sports provider to return images attached to the exact player/team entities. The approved single footer ad slot remains unchanged; no additional ad containers were added.


Latest source update: OneTV v2.5.8 / versionCode 48 (2026-11-04). Added rights-gated media registry and minute polling; Photo Stories now uses the approved photo feed. Video API feed is exposed but consumer video playback UI is not yet integrated. Provider API credentials and explicit rights metadata are required. This remains a source ZIP, not a verified APK/AAB; full 72-page PDF UI acceptance is not complete.
