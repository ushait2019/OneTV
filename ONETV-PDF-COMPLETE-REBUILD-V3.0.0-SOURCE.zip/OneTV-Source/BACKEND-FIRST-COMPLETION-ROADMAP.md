# OneTV Backend-First Completion Baseline
Prepared: 2026-11-04
Baseline carried forward: v2.5.8 source archive (Android versionCode 48)

## Purpose
This archive is the controlled working baseline for completing OneTV in staged increments.
It is NOT a Play Store release and does not claim that the complete 72-page design is implemented.
Keep all existing source files and prior fixes. Every subsequent change must be applied on top
of this archive, recorded in the change log, and tested before creating the next cumulative ZIP.

## Locked product rules
1. The 72-page Visual Design PDF and 52-page Developer Build Instructions PDF are the controlling specifications.
2. No fabricated/demo content, fake photos, unrelated imagery, invented scores, or placeholder media URLs.
3. Publish media only when the provider/source and the applicable rights are explicitly verified.
   API availability alone is not proof of copyright permission.
4. Keep provider credentials and privileged tokens server-side. Never put them in the APK or public responses.
5. Keep the single approved global footer ad slot. Do not add floating, overlay, or extra ad containers.
6. New content may replace old content only when it matches the same entity/content key and passes
   rights, freshness, quality, and priority checks. Keep an audit trail and expiry/takedown handling.
7. Polling is near-real-time, not instantaneous. Use provider webhooks/push only when actually supported.
8. Do not add new consumer screens, player controls, Android permissions, or native SDKs by backend-only
   configuration. Those require a client/APK increment first.
9. No APK/AAB is considered release-ready until CI build, device QA, provider tests, privacy/consent,
   rights checks, and Play Console requirements pass.

## Existing v2.5.8 work carried forward
- Rights-gated media registry and public photo/video feed endpoints.
- Admin media refresh endpoint and minute polling scheduler.
- Photo Stories client feed connection.
- Short-video API contract (15–180 seconds), but no consumer video player UI is implemented.
- Existing sports and news provider integrations/configuration.
- Existing single footer ad placement and current native AdMob banner integration.
See MEDIA-AUTOMATION-2026-11-04.md and FULL-APP-IMPLEMENTATION-UPDATE-2026-11-04.md.

## Staged completion plan

### Stage 0 — Baseline and environment verification
- Confirm this archive is the only working baseline; retain an untouched copy.
- Confirm repository, Cloudflare Worker/D1 bindings, secrets, migrations, Android SDK/JDK/Gradle,
  GitHub Actions, and test-device availability.
- Run ZIP integrity, Node syntax, database migration, API smoke, Android CI build.
- Record failures as blockers; do not claim unrun tests passed.

### Stage 1 — Backend foundation and data contracts
- Audit all providers, schemas, migrations, secrets, timeouts, retry/backoff, rate limits and cache.
- Normalize IDs, timestamps/timezones, status enums, source attribution, freshness and entity keys.
- Implement provider health, per-field source priority, fallback, deduplication, stale-data policy,
  expiry, takedown, audit logs and admin diagnostics.
- Ensure missing provider fields never get silently fabricated.

### Stage 2 — Rights and media automation
- Build source-specific rights allowlists/contracts. Require explicit permission scope, territory,
  commercial use, embed/stream/download permissions, attribution, expiry and evidence URL/reference.
- Default-deny ambiguous or missing rights. Add manual review/override with actor and audit history.
- Validate MIME type, file size, duration, URL, redirects, host allowlist and malware/security policy.
- Add webhook ingestion where supported; otherwise use configurable polling with backoff and rate limits.
- Replace content only for the same stable content/entity key; do not let unrelated new content displace it.
- Add expiry, rights revocation and takedown propagation.

### Stage 3 — Backend content operations
- Cricket first: live/upcoming/results, match details, scorecard, commentary, squads, stats, teams,
  players, venues, series and standings, with provider fallback and canonical ID resolution.
- Then implement other sports and editorial/entertainment/news feeds as independent modules.
- Add approved photos and short videos; keep video feed hidden from users until the Android player exists.
- Add notification/reminder scheduling only after end-to-end device delivery is tested.

### Stage 4 — Ads and revenue operations
- Preserve the one global footer ad slot.
- Verify sequential banner/video rotation and non-interruption behavior.
- Keep backend platform configuration separate from native SDK availability.
- Integrate each additional native SDK only with an APK build, app IDs, consent, manifest and test ads.
- Add impression/fill/eCPM/revenue reporting only from verified network callbacks/reports.
- Never label a platform operational merely because its backend configuration record exists.

### Stage 5 — Full Android client against the PDF
- Audit every page/route/state in the 72-page design against the current app.
- Implement missing navigation, child screens, loading/empty/offline/stale/error/unauthorized states,
  accessibility, responsive layouts, and interaction states.
- Implement the authorized short-video player and required controls in the Android client.
- Connect all screens to the normalized backend contracts. Keep visual design aligned to the PDF.
- Rebuild APK whenever native code, SDK, permissions, or client UI changes.

### Stage 6 — Integration, QA and release candidate
- Test every route and state on supported Android versions and screen sizes.
- Test no-data, provider-down, expired-rights, revoked-rights, stale-data, offline and rate-limit cases.
- Verify that no unlicensed asset can enter a public feed and takedowns remove it.
- Test ad placement, rotation, frequency, consent and playback continuity.
- Run CI release build, signing, Play integrity/policy checks, privacy disclosures and final regression.
- Produce signed release APK/AAB only after all gates pass.

## Backend-only vs APK boundary
Backend-only: provider credentials/configuration, source priority, data normalization, content refresh,
rights validation rules, approved asset catalog, expiry/takedown, feed ordering, cache, admin controls,
and reporting from available provider data.
APK/client required: new screens/routes, visual components, video player, native ad SDKs, Android
permissions, device notifications, and any client-side interaction not already shipped.

## Working change log
For each next increment append: date, version/commit, exact files changed, reason, migration steps,
tests run and results, known limitations, rollback method. Do not remove earlier entries.

## Release status
Current archive is a staged source baseline only. It is not a completed implementation of all PDF pages,
not a verified Android APK/AAB, and not approved for Play Store publication.
