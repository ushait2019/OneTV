# Change log — 3.0.0 (2026-11-04)
- Created PdfFirstActivity as the new Android launcher.
- Moved legacy MainActivity out of launcher role; kept it in source for provider/player code reference and regression recovery.
- Added new shell/navigation and route map aligned to the PDF's route hierarchy.
- Rebuilt initial Home/Sports/Entertainment/News discovery layouts and backend feed loading with truthful empty/error states.
- Consolidated the new launcher to one footer ad container.
- Preserved existing backend, provider adapters, D1 migrations, ad SDK/configuration, desktop panel and USHA IT brand assets.
- Android versionCode 50, versionName 3.0.0.
