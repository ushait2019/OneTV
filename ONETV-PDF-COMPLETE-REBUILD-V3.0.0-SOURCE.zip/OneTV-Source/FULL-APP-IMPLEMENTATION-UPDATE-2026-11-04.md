# OneTV Full-App Implementation Update — 2026-11-04

## Applied in this source snapshot
- Added a lifecycle-safe 1.2 second animated OneTV identity splash. Remote app-config bootstrap starts before the splash and runs independently; the splash does not wait for slow network requests.
- Removed the consumer-facing Live TV and Entertainment video-category entry points from the home/drawer navigation. The corresponding entry now opens Photo Stories. Channel playback/search actions now show a truthful disabled state instead of opening a video player.
- Kept sports match/player/team identity visuals. Player/team images continue to be sourced from the corresponding provider entity payload; generated initials/monograms remain the neutral fallback rather than substituting another athlete's photograph.
- Added provider-sourced editorial photo cards. A card is only created when the licensed news provider supplies an HTTPS image URL. The app validates the response content type before rendering it.
- Added news image URL persistence to the news pipeline and public `/news` response.
- Fixed the news scheduler's candidate-fetch invocation so it passes the Worker environment to `fetchNewsCandidates(env)`.
- Incremented Android version to 2.5.7 / versionCode 47.

## Deliberately not changed
- The approved global footer ad slot remains the only in-app ad container. Video pages were not converted into new ad placements because the design/developer PDFs prohibit adding a second/floating ad container or moving the canonical footer slot.
- Sports match detail, scorecard, commentary, squads and stats remain available. Video playback is disabled in the consumer app in accordance with the latest instruction, even though the earlier visual specification included a Live Player screen.
- No fake images, synthetic match photos, fabricated viewer counts, placeholder video URLs or invented provider data were added.

## Required external configuration
- Photo Stories and news article images require a licensed news/content API that returns image URLs with commercial display rights. Configure `NEWS_PROVIDER_API_URL` and `NEWS_PROVIDER_API_KEY` server-side.
- Automatic rewritten news publishing additionally requires `OPENAI_API_KEY` server-side.
- Sports/player/team imagery depends on the configured sports provider returning images attached to the exact canonical team/player entities. If the provider does not supply a verified image, the UI uses a neutral identity fallback and does not substitute another player's photograph.
- Authorized playable streams and live provider data still require valid backend source configuration and provider credentials.

## QA performed for this archive
- `node --check backend/src/index.js`
- Java source syntax pass attempted with `javac`; Android/AndroidX/Media3/Google Ads SDK classes are not installed in this build environment, so a complete Android compile cannot be certified here.
- ZIP integrity check (`unzip -t`).

## Release limitation
This is a source ZIP, not a verified APK/AAB. The current environment has no Android SDK/Gradle installation and cannot perform device-level visual, playback, splash lifecycle, provider, or full route acceptance testing. Those checks must pass in the supplied GitHub Actions/Android device environment before Play Store release.


## Rights-gated media automation update — 2026-11-04 (v2.5.8)
- Added a backend media registry for photo and short-video assets. It rejects records without explicit allowed rights, HTTPS media/source URLs, and a verifiable HTTPS rights reference.
- Short video duration is restricted to 15–180 seconds.
- Added `GET /media?type=photo|video` and admin-only `POST /admin/media/refresh`.
- Added scheduled provider polling every minute. This is near-real-time polling; instantaneous updates depend on provider push/webhook support, which is not configured in this source package.
- Approved records are ranked by provider priority and publication time. The latest/highest-priority approved item replaces the previous active item for the same content key.
- Android Photo Stories now consumes the rights-gated `/media?type=photo` feed rather than using unverified news image URLs.
- Video feed API is available, but a dedicated consumer video playback UI is not yet implemented in this increment. Do not represent video playback as complete.
- Provider API credentials and the provider's rights metadata contract must be configured server-side before any media can be published. With no provider configured, the endpoint returns an empty feed rather than fabricated content.
