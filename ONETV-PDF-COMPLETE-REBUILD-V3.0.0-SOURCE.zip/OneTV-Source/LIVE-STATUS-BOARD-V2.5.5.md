# ONE TV v2.5.5 — Cricket Live Status Board

## Scope locked
Only the requested changes are included on top of v2.5.4:
- Replace the match-detail LIVE-only strip with a thicker live status board for live Cricket matches.
- Use the latest provider-supplied ball-by-ball commentary/event text.
- Recognize provider event signals such as wicket, four, six, no-ball, wide, leg-bye, player entering, break, and 1/2/3 runs when the provider payload supplies them.
- Keep the live status text white on a green premium status surface.
- Refresh the selected match detail through the existing backend-driven auto-refresh path.
- Deepen the Default theme moderately for a richer premium charcoal presentation without changing Dark mode.

No other UI, data, source, menu, or backend behavior was intentionally changed.
