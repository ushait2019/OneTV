# One TV v2.5.6 — Live/Upcoming/Results + Live Scoring Board Fix

- Live, Upcoming and Results lists now enforce their requested provider status bucket.
- Live listing badge is green with white text.
- Upcoming badge keeps the existing treatment.
- Finished/Results listing badge is red with white text.
- Removed the separate green "Live status is updating" strip from match detail.
- The existing in-hero LIVE board is now the cricket live scoring board.
- Live board updates from provider commentary/ball-by-ball data on the existing detail refresh cycle.
- Loading state: "Updating live score • Please wait…"
- Specific cricket events are surfaced when supplied: FOUR, SIX, BOWLED, LBW, CAUGHT, RUN OUT, STUMPED, WICKET, NO BALL, WIDE, LEG BYE, PLAYER IN, BREAK, and runs.
- When a match is finished, the provider result/winner status is shown as the final state and detail refresh stops.
- Existing UI/configuration and backend architecture are preserved outside these requested changes.
