# OneTV Media Automation — Rights-gated source update (2026-11-04)

## Locked behavior
- Only media with explicit, verifiable publication/display rights may enter the public media feed.
- Photos require display/publish/in-app/editorial usage permission.
- Videos require embed/stream/display/in-app permission and duration from 15 to 180 seconds.
- Missing rights metadata, missing rights reference, non-HTTPS media/source URL, unsupported duration, or ambiguous permission means reject. No fallback to stock, generated, fixed, unrelated, or fake media.
- Highest-priority/newest approved asset replaces the previous active asset for the same media type and content key.
- The Worker polls the configured provider every minute. This is near-real-time polling, not instant push delivery. Provider webhooks are not configured.
- The provider must expose a stable asset ID and rights metadata contract. API key is server-side only.

## API
- `GET /media?type=photo&limit=40`
- `GET /media?type=video&limit=40`
- `POST /admin/media/refresh` with `Authorization: Bearer ADMIN_TOKEN`

## Required server configuration
- `MEDIA_PROVIDER_NAME`
- `MEDIA_PROVIDER_API_URL`
- `MEDIA_PROVIDER_API_KEY`

## Provider record contract
`id`, `media_type`, `content_key`, `title`, `description`, `media_url`, `thumbnail_url`, `source_url`, `source_name`, `category`, `related_entity_id`, `related_entity_name`, `duration_seconds`, `rights_status`, `rights_reference`, `allowed_usage`, `priority`, `published_at`.

Allowed `rights_status`: `authorized`, `licensed`, `owned`, `public_domain`, `cc0`, `cc-by`. `rights_reference` must be an HTTPS license/permission URL. `allowed_usage` must explicitly include a compatible usage token.

## Important implementation boundary
This update wires the Android Photo Stories screen to the rights-gated photo feed and exposes the video feed API. It does **not** yet implement the full consumer video player UI, nor does it complete the entire 72-page Visual Design PDF route inventory. Existing sports/team/player image payloads still depend on provider-specific image provenance and must be audited separately for rights metadata before claiming that every image in the app is rights-gated. No provider credentials or license agreement were supplied in this task, so the feed remains empty until a compatible licensed provider is configured.
