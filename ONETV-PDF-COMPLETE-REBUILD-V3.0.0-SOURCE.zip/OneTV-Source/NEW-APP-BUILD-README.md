# OneTV 2.6.0 — PDF-led New App Build

This source package starts a new UI implementation from the supplied 72-page visual specification.
It carries forward the existing OneTV provider/backend and advertising integration code, but the
main shell, primary navigation and Home discovery screen have been rebuilt rather than retaining
the previous Home layout.

## Carried forward from the previous OneTV source
- Cloudflare Worker backend URL/configuration and public API contracts.
- Cricket, football, basketball and tennis provider adapters and match-detail parsing.
- News and rights-gated media endpoints.
- Existing Android Media3 playback dependency and player implementation code.
- Existing AdMob SDK, app ad unit configuration, remote ad config fetch, and backend ad management routes.
- USHA IT / OneTV brand assets and Android package identity.

## New UI work in this increment
- Rebuilt compact OneTV app bar.
- Added PDF-aligned top-level bottom navigation: Home, Sports, Entertainment, News.
- Rebuilt Home discovery screen with a featured sports entry, category tiles, live/upcoming/results
  sections, latest news preview, and existing real-provider data loading.
- Consolidated the app's Android AdMob rendering into the single approved footer placement.
- Bumped Android version to 2.6.0 / versionCode 49.

## Specification coverage note
The supplied PDF remains the acceptance source. This is the first new UI foundation increment,
not a declaration that every one of the 72-page routes and visual states has been fully implemented.
Existing sports/match/news/settings routes are retained and will be audited and completed in later
increments. Entertainment is currently wired to the existing rights-gated Photo Stories path; other
entertainment child routes and the short-video player still require implementation/QA.

## Build and release
- Source ZIP only. No signed APK/AAB is included.
- Build requires Android SDK 35, JDK 17, Gradle dependencies and configured backend.
- Provider API keys must remain in Cloudflare secrets, not in the Android app.
- Use test ad IDs for debug builds and verify production AdMob app/ad unit IDs before release.
- Verify the backend ad configuration and rights allowlist before enabling content.
