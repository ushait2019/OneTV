# One TV News Automation

## Editorial flow
1. A licensed news provider/API supplies current article metadata.
2. Backend ranks candidates by source weight, recency/topic signals and popularity keywords.
3. Duplicate stories are suppressed by a normalized headline fingerprint.
4. The backend sends only the licensed provider metadata to the configured LLM.
5. The LLM must create an original headline, summary and short body without inventing facts or copying source sentences.
6. The published item stores the source name and original URL for attribution.
7. Cloudflare Cron runs every 30 minutes and publishes at most one new article per run.

## Required production secrets/config
- `NEWS_PROVIDER_API_URL`
- `NEWS_PROVIDER_API_KEY`
- `OPENAI_API_KEY`
- optional `OPENAI_MODEL`

The selected news provider must explicitly permit the intended commercial use, storage, summarization/rewrite and redistribution. Do not use a public RSS feed merely because it is technically accessible.

## No fake content
If the provider or LLM is unavailable, the backend publishes nothing. The app shows an empty/availability state rather than fabricated news.

## APK impact
The News UI is compiled into version 2.5.0, but new news stories and editorial configuration are backend-driven. After this UI capability is installed, routine article generation does not require APK rebuilds.
