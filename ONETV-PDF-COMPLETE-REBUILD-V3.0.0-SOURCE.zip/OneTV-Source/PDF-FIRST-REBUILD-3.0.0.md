# OneTV PDF-First Rebuild — 3.0.0

## What changed in this source increment
- The launcher now opens `PdfFirstActivity`, a newly authored UI shell; legacy `MainActivity` remains in the source tree but is no longer the launcher.
- New premium dark app shell, compact OneTV header, top-level Home/Sports/Entertainment/News navigation and a single footer ad container.
- New splash, home discovery structure, sport/category route registry covering the navigation families in the 72-page visual PDF.
- Existing backend/provider modules, provider secrets handling, D1 migrations, desktop control panel, brand assets and AdMob dependency/configuration are retained from the previous OneTV source.
- Home and sport feeds request live backend endpoints and show truthful empty/error states when no provider data is returned.
- Android version: 3.0.0 / versionCode 50.

## Important implementation status
This is a genuine new launcher UI foundation and route scaffold, not yet a completed visual clone of every PDF screen. The route registry exists, but several detail screens currently render explicit data-unavailable/integration states pending their specific normalized backend contracts and detailed screen layouts. The PDF's embedded reference screenshots are retained in `Project-References` and are not used as fake production UI images.
- Short-video player, movie/series detail UI, all article/detail states, offline cache states and full notification/reminder persistence still need implementation and QA.
- Provider data for entertainment depends on configured provider endpoints; no fake content is inserted.
- One footer ad container is used. Existing AdMob ID is retained; verify account ownership, consent and live ad behavior before production.
- Rights-gated video/photo publishing must remain default-deny unless permission scope is evidenced.
- No APK/AAB is included. Build requires JDK 17, Android SDK 35 and Gradle dependency access. This environment did not have an Android SDK/Gradle wrapper, so an Android compile/device test could not be run.

## Next work
1. Compile and resolve Android errors in CI.
2. Compare each screen against the exact PDF page image and implement remaining per-screen layouts.
3. Complete normalized backend contracts for every child route.
4. Add authorized video playback, quality selection and source failover.
5. Complete all QA matrix cases and release signing.
