# PDF Route Tracker — 72-page OneTV specification

This tracker is intentionally conservative. `Present (legacy)` means a prior screen/handler exists,
not that the final PDF visual acceptance has passed. `New in 2.6.0` identifies the new shell/home.

| PDF pages | Required area | Current package status |
|---|---|---|
| 1–3 | Design system, shell, global navigation | New app bar + bottom navigation in 2.6.0; full design tokens/accessibility regression still pending |
| 4–5 | Splash and onboarding | Animated splash retained; onboarding route pending |
| 6 | Home | Rebuilt in 2.6.0 with provider-backed sports/news loading |
| 7–9, 23–36 | Sports, cricket and sport-specific match routes | Existing provider-backed handlers retained; visual/route completeness audit pending |
| 10, 37–39 | Watch/player/info/failover/quality | Legacy player code/dependency retained; authorization and short-video player acceptance pending |
| 11–13, 40–46 | Entertainment, movies, series, episodes, music, celebrity, trending, events | Photo Stories path exists; remaining content routes pending |
| 14–15, 47–49 | News, category, source and article modes | Existing news aggregation/article path retained; PDF visual audit pending |
| 16 | Search | Existing search route retained |
| 17–21, 50–51, 64–65 | Notifications, reminders, favorites, downloads, history, account | Existing subset retained; route-by-route QA and missing flows pending |
| 20–22, 59–66 | Settings, privacy, terms, licenses, about | Existing settings/legal handlers retained; full PDF parity pending |
| 52–55, 68 | Offline, stale, provider error, maintenance and system states | Backend/cache/error support varies; full explicit state coverage pending |
| 56–58, 71–72 | Single footer ad slot and remote ad control | One Android footer slot retained; remote controls/provider fallback/diagnostics require end-to-end validation |
| 67–69 | Component library, interaction and final acceptance | Implementation and device QA pending |

No route is marked complete solely because a placeholder handler or backend endpoint exists.
