# ONE TV Premium 3-Line Menu Update — 2026-11-03

- versionCode: 43
- versionName: 2.5.1
- Functional premium navigation drawer based on the supplied reference.
- Underlying screen remains intact while the drawer is open.
- Close button, scrim tap and Android back close the drawer and restore navigation state.
- Functional routes: Home, Live TV, Sports, Entertainment, News, Schedule, Favorites, Notifications, Settings, Help & Support, About One TV.
- Schedule uses provider-driven upcoming cricket data.
- Favorites persist real provider match objects locally and can be toggled from real match cards.
- No fake match/news/channel data was added.
