# Premium Home / Sports / Cricket UI Update

- Home follows the supplied three-screen visual direction while using real provider data only.
- Removed the standalone TV quick button from the Home mode row.
- Home mode row is now Sports / Entertainment / News.
- Entertainment continues to contain TV, Movies and other entertainment sections.
- News is a dedicated backend-driven section.
- Home uses a dynamic featured match hero, Live Now, Upcoming Matches and Recent Results.
- Sports front page uses sport selector, live/upcoming/results navigation and priority-ranked real match cards.
- Cricket front page gets a real provider-driven featured match and dedicated live/upcoming/results actions.
- Existing Cricket Match Centre, scoreboard, commentary and provider fallback code remains in the baseline.
- Responsive sizing continues to use density-based dp sizing and weighted layouts.
- No fake teams, players, scores, tournaments, news or highlight assets were added.
