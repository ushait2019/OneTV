# ONE TV v2.5.2 Theme Refinement

- Default theme now uses a premium charcoal content palette with #2B2B2B as the main background.
- Dark theme keeps the existing cool dark palette with lighter content surfaces.
- Theme selector labels are now `Default` and `Dark`.
- New installs default to `Default`; existing saved Dark preference remains respected.
- Premium navigation drawer now adapts its background to the active palette instead of forcing a dark drawer with dark text in Default mode.
- No fake/demo data or provider logic was changed.
