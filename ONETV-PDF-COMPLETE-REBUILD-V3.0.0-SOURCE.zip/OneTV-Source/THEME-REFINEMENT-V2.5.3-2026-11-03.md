# One TV v2.5.3 Theme Refinement

- Fixed Default theme contrast across the premium Home and shared player surfaces.
- Default background remains #2B2B2B with richer charcoal cards and surfaces.
- Reworked the Home featured-match hero in Default mode to a dark premium gradient so white typography remains readable.
- Made the match-detail tab strip and volume popup theme-aware instead of hard-coded to the Dark palette.
- Kept the existing Dark palette behavior intact.
- Kept the Theme selector labels as `Default` and `Dark`.
- Preserved all prior v2.5.2 functionality, backend integration, 3-line menu, Sports, Entertainment, News, Favorites, Schedule and notification features.
- No fake/provider data was added.

Important: this is a native UI color fix. It requires one APK/AAB rebuild to appear in an already-installed app. After this native fix is installed, subsequent backend-driven changes can continue without rebuilding unless a future change again requires native code.
