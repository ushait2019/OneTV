# One TV v2.5.4 Theme Refinement

- Deepened the Default theme slightly for a richer premium charcoal presentation without making the UI harsh or overly dark.
- Default background: #262626.
- Default panel: #2B2B2E.
- Default card: #323236.
- Default elevated card: #3B3B40.
- Refined Default Home featured-match gradient to a deeper, more readable charcoal/plum blend.
- Refined Default navigation drawer gradient to match the deeper charcoal palette.
- Preserved the existing Dark theme palette.
- Preserved all previous functionality and backend/provider-driven data.
- Theme selector remains Default / Dark.
- This is a native UI refinement and therefore requires one APK/AAB rebuild to appear in the installed app. After installation, continue backend-first changes without rebuilding unless native code is required.
