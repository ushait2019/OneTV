package com.ushait.onetv;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.Intent;
import android.net.Uri;
import android.util.TypedValue;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdSize;

/**
 * PDF-led OneTV application shell.
 * The legacy MainActivity is retained as a source reference only; this is the launcher UI.
 * All content shown here is provider/backend-derived. Missing provider data is never fabricated.
 */
public class PdfFirstActivity extends Activity {
    private static final int BG=0xFF07111F, PANEL=0xFF101E30, CARD=0xFF14263B,
            TEXT=0xFFF3F6FB, MUTED=0xFF9BAFC5, BLUE=0xFF1687F8,
            LINE=0xFF263B52, GREEN=0xFF16A88A;
    private LinearLayout root, content, footer;
    private String route="home", sport="cricket", mode="live";
    private final ExecutorService io=Executors.newFixedThreadPool(3);
    private final Map<String,String> routes=new LinkedHashMap<>();
    private final Map<String,String> endpoints=new HashMap<>();
    private AdView adView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF050C16);
        getWindow().setNavigationBarColor(0xFF050C16);
        registerRoutes();
        splashThenHome();
    }
    private void splashThenHome() {
        FrameLayout splash=new FrameLayout(this); splash.setBackgroundColor(BG);
        LinearLayout center=new LinearLayout(this); center.setOrientation(1); center.setGravity(Gravity.CENTER);
        TextView logo=text("OneTV",34,Color.WHITE,true); TextView by=text("ALL IN ONE  •  USHA IT",10,0xFF76B8FF,true);
        center.addView(logo); center.addView(by); splash.addView(center,new FrameLayout.LayoutParams(-1,-1));
        setContentView(splash);
        splash.postDelayed(()->show("home"),1200);
    }
    private void registerRoutes() {
        routes.put("home","Home"); routes.put("sports","Sports"); routes.put("cricket","Cricket");
        routes.put("football","Football"); routes.put("basketball","Basketball"); routes.put("tennis","Tennis");
        routes.put("match","Match Center"); routes.put("scorecard","Scorecard"); routes.put("commentary","Commentary");
        routes.put("lineups","Squads / Lineups"); routes.put("stats","Statistics"); routes.put("teams","Teams");
        routes.put("players","Players"); routes.put("venues","Venues"); routes.put("series","Competitions / Series");
        routes.put("standings","Standings"); routes.put("watch","Watch"); routes.put("watch-info","Player Info");
        routes.put("watch-notice","Notice"); routes.put("watch-related","Related"); routes.put("watch-quality","Quality");
        routes.put("watch-failover","Source Failover");
        routes.put("entertainment","Entertainment"); routes.put("movies","Movies"); routes.put("movie-detail","Movie Detail");
        routes.put("series-tv","TV & Series"); routes.put("series-detail","Series Detail"); routes.put("seasons","Seasons");
        routes.put("episodes","Episodes"); routes.put("music","Music"); routes.put("celebrity","Celebrity");
        routes.put("trending","Trending"); routes.put("events","Live Events");
        routes.put("news","News"); routes.put("breaking","Breaking"); routes.put("bangladesh","Bangladesh");
        routes.put("world","World"); routes.put("business","Business"); routes.put("technology","Technology");
        routes.put("sports-news","Sports News"); routes.put("ent-news","Entertainment News");
        routes.put("category","News Category"); routes.put("article","Article"); routes.put("source","News Source");
        routes.put("search","Search"); routes.put("notifications","Notifications"); routes.put("reminders","Reminders");
        routes.put("favorites","Favorites"); routes.put("downloads","Downloads"); routes.put("offline","Offline");
        routes.put("history","History"); routes.put("account","Account"); routes.put("settings","Settings");
        routes.put("playback","Playback"); routes.put("data-saver","Data Saver"); routes.put("notification-settings","Notification Settings");
        routes.put("language","Language"); routes.put("appearance","Appearance"); routes.put("privacy","Privacy");
        routes.put("terms","Terms"); routes.put("licenses","Licenses"); routes.put("about","About USHA IT");
        routes.put("system-stale","Stale Data"); routes.put("system-error","Provider Error"); routes.put("maintenance","Maintenance");
        endpoints.put("cricket","/sports/cricket/"); endpoints.put("football","/sports/football/");
        endpoints.put("basketball","/sports/basketball/"); endpoints.put("tennis","/sports/tennis/");
    }
    private void show(String key) {
        route=routes.containsKey(key)?key:"home";
        root=new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(BG);
        root.addView(buildHeader(),new LinearLayout.LayoutParams(-1,dp(60)));
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        content=new LinearLayout(this); content.setOrientation(1); content.setPadding(dp(16),dp(12),dp(16),dp(22));
        scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(buildBottomNav(),new LinearLayout.LayoutParams(-1,dp(58)));
        footer=new LinearLayout(this); footer.setOrientation(1); footer.setGravity(Gravity.CENTER);
        footer.setBackgroundColor(0xFF050C16);
        adView=new AdView(this); adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId(BuildConfig.DEBUG?"ca-app-pub-3940256099942544/6300978111":"ca-app-pub-5981864080922785/5178976268");
        footer.addView(adView,new LinearLayout.LayoutParams(-1,dp(50)));
        TextView copy=text("© 2026 USHA IT. All Rights Reserved.",10,MUTED,false);
        copy.setGravity(Gravity.CENTER); footer.addView(copy,new LinearLayout.LayoutParams(-1,dp(24)));
        root.addView(footer,new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);
        try { adView.loadAd(new AdRequest.Builder().build()); } catch(Exception ignored){}
        renderRoute();
    }
    private View buildHeader() {
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14),0,dp(12),0); bar.setBackgroundColor(0xFF050C16);
        TextView brand=text("OneTV",21,Color.WHITE,true); bar.addView(brand);
        TextView sub=text("  USHA IT",9,0xFF75B9FF,true); bar.addView(sub);
        bar.addView(new Space(this),new LinearLayout.LayoutParams(0,1,1));
        TextView search=text("⌕",27,TEXT,true); search.setGravity(Gravity.CENTER); search.setOnClickListener(v->show("search"));
        bar.addView(search,new LinearLayout.LayoutParams(dp(42),-1));
        TextView bell=text("♧",22,TEXT,true); bell.setGravity(Gravity.CENTER); bell.setOnClickListener(v->show("notifications"));
        bar.addView(bell,new LinearLayout.LayoutParams(dp(42),-1));
        TextView menu=text("☰",23,TEXT,true); menu.setGravity(Gravity.CENTER); menu.setOnClickListener(v->show("settings"));
        bar.addView(menu,new LinearLayout.LayoutParams(dp(42),-1));
        return bar;
    }
    private View buildBottomNav() {
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(0xFF050C16);
        String[][] items={{"⌂","Home","home"},{"◉","Sports","sports"},{"▣","Entertainment","entertainment"},{"▤","News","news"}};
        for(String[] it:items) {
            LinearLayout cell=new LinearLayout(this); cell.setGravity(Gravity.CENTER); cell.setOrientation(1);
            int c=route.equals(it[2])?BLUE:MUTED;
            TextView ico=text(it[0],20,c,true); ico.setGravity(Gravity.CENTER);
            TextView label=text(it[1],9,c,true); label.setGravity(Gravity.CENTER);
            cell.addView(ico); cell.addView(label);
            cell.setOnClickListener(v->show(it[2]));
            nav.addView(cell,new LinearLayout.LayoutParams(0,-1,1));
        }
        return nav;
    }
    private void renderRoute() {
        String title=routes.get(route);
        if(route.equals("home")) { renderHome(); return; }
        heading(title,subtitleFor(route));
        if(route.equals("sports")) {
            tileGrid(new String[]{"Cricket","Football","Basketball","Tennis"},new String[]{"cricket","football","basketball","tennis"});
            section("Live across sports"); loadSportsOverview();
        } else if(endpoints.containsKey(route)) {
            sport=route; mode="live"; tabs(new String[]{"LIVE","UPCOMING","RESULTS"},new String[]{"live","upcoming","results"});
            section(title+" matches"); loadSportMatches(mode);
            if(route.equals("cricket")) tileGrid(new String[]{"Series","Teams","Players","Venues","Standings"},new String[]{"series","teams","players","venues","standings"});
        } else if(route.equals("entertainment")) {
            tileGrid(new String[]{"Movies","TV & Series","Music","Celebrity","Trending","Live Events"},new String[]{"movies","series-tv","music","celebrity","trending","events"});
            section("Popular on OneTV"); loadGeneric("/entertainment/trending");
        } else if(route.equals("news")) {
            tileGrid(new String[]{"Breaking","Bangladesh","World","Business","Technology","Sports","Entertainment"},new String[]{"breaking","bangladesh","world","business","technology","sports-news","ent-news"});
            section("Latest stories"); loadGeneric("/news?limit=30");
        } else if(route.equals("search")) {
            EditText q=new EditText(this); q.setSingleLine(true); q.setHint("Search sports, entertainment and news");
            q.setTextColor(TEXT); q.setHintTextColor(MUTED); content.addView(q);
            action("Search",()->loadGeneric("/search?q="+Uri.encode(q.getText().toString())));
        } else if(route.startsWith("system-")||route.equals("offline")||route.equals("maintenance")) {
            empty("Content status","The app will show the last valid cached content or a truthful service status when backend state is available.");
        } else if(route.equals("settings")) {
            tileGrid(new String[]{"Playback","Data Saver","Notifications","Language","Appearance","Privacy","Terms","Licenses","About"},new String[]{"playback","data-saver","notification-settings","language","appearance","privacy","terms","licenses","about"});
        } else if(route.equals("account")) {
            empty("Guest mode","Browsing remains available without signing in. Account sync can be enabled when configured.");
        } else if(route.equals("watch")||route.startsWith("watch-")) {
            empty("Authorized media only","A playable source will appear only when backend rights validation confirms an authorized in-app stream.");
        } else if(route.equals("match")) {
            tabs(new String[]{"Overview","Scorecard","Commentary","Squads","Stats"},new String[]{"match","scorecard","commentary","lineups","stats"});
            empty("Match details","Open a canonical provider match to load verified score, teams, venue and match events.");
        } else if(route.equals("notifications")||route.equals("reminders")||route.equals("favorites")||route.equals("downloads")||route.equals("history")) {
            empty(title,"No items are available yet. This section will populate from real user actions and backend events.");
        } else if(route.equals("movies")||route.equals("series-tv")||route.equals("music")||route.equals("celebrity")||route.equals("trending")||route.equals("events")) {
            loadGeneric("/entertainment/"+route);
        } else if(route.equals("breaking")||route.equals("bangladesh")||route.equals("world")||route.equals("business")||route.equals("technology")||route.equals("sports-news")||route.equals("ent-news")) {
            loadGeneric("/news?category="+Uri.encode(title.toLowerCase(Locale.US)));
        } else if(route.equals("about")) {
            empty("USHA IT","OneTV is developed and maintained by USHA IT. © 2026 USHA IT. All Rights Reserved.");
        } else {
            empty(title,"This route is part of the approved OneTV navigation map. It will display provider-backed records when its data contract is connected.");
        }
    }
    private void renderHome() {
        heading("Discover OneTV","Sports, Entertainment and News in one place");
        LinearLayout hero=card();
        hero.addView(text("FEATURED",9,0xFF76B9FF,true));
        TextView h=text("Your world. One screen.",22,TEXT,true); h.setPadding(0,dp(8),0,dp(5)); hero.addView(h);
        hero.addView(text("Live scores, entertainment and verified stories.",11,MUTED,false));
        actionInto(hero,"Explore Sports",()->show("sports")); content.addView(hero);
        tileGrid(new String[]{"Sports","Entertainment","News"},new String[]{"sports","entertainment","news"});
        section("Live & Upcoming"); loadSportsOverview();
        section("Latest News"); loadGeneric("/news?limit=5");
    }
    private void loadSportsOverview() {
        for(String sp:new String[]{"cricket","football","basketball","tennis"}) {
            final String path="/sports/"+sp+"/live";
            fetch(path,data->{
                JSONArray a=data.optJSONArray("matches");
                if(a!=null) for(int i=0;i<a.length()&&i<3;i++) matchCard(a.optJSONObject(i),sp);
            });
        }
    }
    private void loadSportMatches(String m) {
        String path="/sports/"+sport+"/"+m;
        if(sport.equals("cricket")&&m.equals("results")) path="/cricket/results";
        fetch(path,data->{
            JSONArray a=data.optJSONArray("matches");
            if(a==null||a.length()==0){empty("No "+m+" matches","No verified "+m+" fixtures are currently available from the connected provider.");return;}
            for(int i=0;i<a.length();i++) matchCard(a.optJSONObject(i),sport);
        });
    }
    private void loadGeneric(String path) {
        fetch(path,data->{
            JSONArray a=data.optJSONArray("items");
            if(a==null) a=data.optJSONArray("articles");
            if(a==null) a=data.optJSONArray("results");
            if(a==null||a.length()==0){empty("No published content","No verified items are currently available from the configured provider.");return;}
            for(int i=0;i<a.length();i++) {
                JSONObject o=a.optJSONObject(i); if(o==null) continue;
                String t=o.optString("title",o.optString("name","")).trim();
                if(t.isEmpty()) continue;
                LinearLayout c=card(); c.addView(text(t,14,TEXT,true));
                String source=o.optString("source_name",o.optString("source",""));
                if(!source.isEmpty()) c.addView(text(source+"  •  "+o.optString("published_at",""),9,MUTED,false));
                content.addView(c);
            }
        });
    }
    private interface Result { void accept(JSONObject data); }
    private void fetch(String path,Result cb) {
        String base=BuildConfig.BACKEND_URL;
        if(base==null||base.trim().isEmpty()) { empty("Backend not configured","Connect the OneTV backend to load verified live content."); return; }
        io.execute(()->{
            try {
                URL u=new URL(base+path); HttpURLConnection c=(HttpURLConnection)u.openConnection();
                c.setConnectTimeout(8000); c.setReadTimeout(10000); c.setRequestProperty("Accept","application/json");
                InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream();
                byte[] b=new byte[4096]; int n; while((n=in.read(b))!=-1)out.write(b,0,n);
                JSONObject data=new JSONObject(out.toString("UTF-8")); c.disconnect();
                runOnUiThread(()->cb.accept(data));
            } catch(Exception e) { runOnUiThread(()->empty("Provider temporarily unavailable","The app could not retrieve current verified data. Please try again later.")); }
        });
    }
    private void matchCard(JSONObject m,String sp) {
        if(m==null)return;
        String comp=m.optString("competition",m.optString("series",""));
        String home=m.optString("homeTeam",m.optString("team1",m.optString("teamA","")));
        String away=m.optString("awayTeam",m.optString("team2",m.optString("teamB","")));
        String status=m.optString("status",m.optString("state",""));
        String score=m.optString("score","");
        if(home.isEmpty()&&away.isEmpty())return;
        LinearLayout c=card();
        c.addView(text(comp.isEmpty()?sp.toUpperCase(Locale.US):comp,10,0xFF75B9FF,true));
        TextView teams=text(home+"   VS   "+away,16,TEXT,true); teams.setPadding(0,dp(8),0,dp(5)); c.addView(teams);
        c.addView(text(status+(score.isEmpty()?"":"  •  "+score),10,MUTED,false));
        c.setOnClickListener(v->show("match")); content.addView(c);
    }
    private void heading(String h,String sub) {
        TextView t=text(h,25,TEXT,true); t.setPadding(0,dp(5),0,dp(3)); content.addView(t);
        TextView s=text(sub,11,MUTED,false); s.setPadding(0,0,0,dp(14)); content.addView(s);
    }
    private String subtitleFor(String k) {
        if(k.equals("sports"))return "Explore live sports and competitions";
        if(k.equals("cricket"))return "Live • Upcoming • Results • Series";
        if(k.equals("entertainment"))return "Movies, series, music and more";
        if(k.equals("news"))return "Source-attributed news and updates";
        return "OneTV • USHA IT";
    }
    private void section(String s) { TextView t=text(s,17,TEXT,true); t.setPadding(0,dp(16),0,dp(9)); content.addView(t); }
    private void tileGrid(String[] labels,String[] keys) {
        for(int i=0;i<labels.length;i+=2) {
            LinearLayout row=new LinearLayout(this); row.setOrientation(0);
            for(int j=i;j<Math.min(i+2,labels.length);j++) {
                final String key=keys[j]; LinearLayout c=card();
                TextView t=text(labels[j],14,TEXT,true); c.addView(t);
                c.setOnClickListener(v->show(key));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(76),1); lp.setMargins(dp(3),dp(3),dp(3),dp(3)); row.addView(c,lp);
            }
            content.addView(row);
        }
    }
    private void tabs(String[] labels,String[] keys) {
        HorizontalScrollView hsv=new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row=new LinearLayout(this);
        for(int i=0;i<labels.length;i++) { final String key=keys[i]; TextView b=text(labels[i],10,TEXT,true); b.setGravity(Gravity.CENTER); b.setPadding(dp(14),dp(11),dp(14),dp(11)); b.setBackground(bg(CARD,24)); b.setOnClickListener(v->{if(key.equals("live")||key.equals("upcoming")||key.equals("results")){mode=key;content.removeViews(2,Math.max(0,content.getChildCount()-2));section(routes.get(sport)+" "+key);loadSportMatches(key);}else show(key);}); row.addView(b); }
        hsv.addView(row); content.addView(hsv);
    }
    private LinearLayout card() {
        LinearLayout c=new LinearLayout(this); c.setOrientation(1); c.setPadding(dp(14),dp(13),dp(14),dp(13));
        c.setBackground(bg(CARD,17)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(5),0,dp(7)); c.setLayoutParams(lp); return c;
    }
    private void empty(String title,String desc) {
        LinearLayout c=card(); c.setGravity(Gravity.CENTER_VERTICAL);
        c.addView(text(title,14,TEXT,true)); TextView d=text(desc,10,MUTED,false); d.setPadding(0,dp(5),0,0); c.addView(d); content.addView(c);
    }
    private void action(String label,Runnable r) { TextView b=text(label,12,Color.WHITE,true); b.setGravity(Gravity.CENTER); b.setPadding(dp(14),dp(12),dp(14),dp(12)); b.setBackground(bg(BLUE,12)); b.setOnClickListener(v->r.run()); content.addView(b); }
    private void actionInto(LinearLayout parent,String label,Runnable r) { TextView b=text(label,11,Color.WHITE,true); b.setGravity(Gravity.CENTER); b.setPadding(dp(12),dp(10),dp(12),dp(10)); b.setBackground(bg(BLUE,12)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2); lp.topMargin=dp(12); parent.addView(b,lp); b.setOnClickListener(v->r.run()); }
    private TextView text(String s,float size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(TypedValue.COMPLEX_UNIT_SP,size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private GradientDrawable bg(int color,int radius) { GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private int dp(int v) { return (int)(v*getResources().getDisplayMetrics().density+.5f); }
    @Override public void onBackPressed() { if(!route.equals("home"))show("home"); else super.onBackPressed(); }
    @Override protected void onDestroy() { if(adView!=null)adView.destroy(); io.shutdownNow(); super.onDestroy(); }
}
