# One TV Cricket Home Feed: Live + Upcoming + Recent Finished Priority

## Change
The backend home feed now includes all three useful listing states without requiring an APK rebuild:

1. Top live matches first, up to 3.
2. Highest-priority/popularity upcoming matches next, up to 5.
3. Recent finished matches after those, up to 3 and marked highlight-eligible.
4. Remaining live/upcoming matches follow the primary blocks.

## Ranking
- Provider-supplied popularity/audience/viewer/rank fields are used when present.
- If the provider does not supply a popularity metric, a deterministic fallback score uses competition tier, match format, and international-team interest.
- This fallback is a ranking heuristic, not a claim of measured audience size.
- Upcoming ties are ordered by earliest start time.
- Finished ties are ordered by most recent completion time.

## Status
The existing canonical status classifier remains authoritative:
LIVE, UPCOMING, FINISHED.

## Results page
The `/cricket/results` endpoint remains separate and is not changed by this feed ordering.

## Deployment
Backend-only change. Existing APK can consume the updated `/cricket/live` response after the Worker is deployed. No Android rebuild is required.
