# One TV Backend: Start Here

This folder is the production-ready Cloudflare Worker + D1 backend package for One TV.

## What is already prepared
- Dynamic TV/movie channel database and admin CRUD
- Published Notice Board data for the TV page only
- Viewer heartbeat + per-channel view analytics
- YouTube Data API metadata resolution with official embedded playback in the Android app
- Sports score proxy for cricket, football, basketball and tennis
- SportScore public API for sports data, no API key required, using the documented v1 fixtures/match contract
- SportScore edge-cached responses to reduce upstream usage
- CORS for the Android client
- Windows Electron admin panel
- PowerShell deployment helper

## What cannot be pre-filled
Cloudflare D1 `database_id`, Worker URL, `ADMIN_TOKEN` and YouTube API key belong to your accounts and are intentionally not stored in this ZIP. SportScore requires no API key.

## First deployment
1. Install Node.js and Wrangler: `npm install -g wrangler`
2. Run `wrangler login`.
3. Run `wrangler d1 create one-tv-db`.
4. Copy the returned `database_id` into `wrangler.toml`.
5. Run `./deploy.ps1` on Windows PowerShell.
6. Wrangler will ask for the two required secrets.
7. Copy the deployed Worker URL.
8. Add that URL as the GitHub Actions secret `ONETV_BACKEND_URL`.
9. Re-run the Android workflow.

## Verification
- `GET /health` should report `database: connected`.
- `GET /cricket/health` should report SportScore as the provider. No cricket API key is required.
- Open `/admin`, enter the `ADMIN_TOKEN`, and press **Connect**.

## Sports score provider
SportScore is the primary sports-data provider. For cricket only, the Worker falls back to OpenCricket when SportScore fails, times out, returns invalid data, or returns an empty result. Its current public documentation states that the API requires no API key, supports cricket, football, basketball and tennis, and provides approximately 10,000 requests per 24 hours per IP on the free tier. A visible “Powered by SportScore” attribution is required. The Worker uses the documented `/api/v1/fixtures/` endpoint for live/upcoming/results and `/api/v1/match/` for details.

The Android app refreshes the active sports list every 20 seconds and also provides a manual refresh button on sports screens. The Worker returns the actual provider used for each response so the admin panel can verify fallback behavior.

## Important
Do not put Cloudflare, YouTube, or cricket API secrets in the Android APK, GitHub source, or desktop JavaScript.

## Sports multi-source enrichment (2026-11-02)
SportScore remains the primary provider. Optional CricketData and Cricbuzz credentials enable field-level enrichment for missing cricket fields. OpenCricket remains the cricket-only full-provider fallback.

Secrets:
- `CRICKETDATA_API_KEY`
- `CRICBUZZ_RAPIDAPI_KEY`
Optional variable:
- `CRICBUZZ_RAPIDAPI_HOST=cricbuzz-cricket.p.rapidapi.com`


## Rights-gated automatic photos and short videos (2026-11-04)
- `GET /media?type=photo` returns only photo records with explicit publication/display permission.
- `GET /media?type=video` returns only short video records (15–180 seconds) with explicit embed/stream/display permission.
- `POST /admin/media/refresh` triggers a manual refresh (Bearer `ADMIN_TOKEN`).
- Worker cron now polls the configured media provider once per minute. This is near-real-time polling, not a guarantee of instantaneous provider push delivery.
- Configure `MEDIA_PROVIDER_NAME`, `MEDIA_PROVIDER_API_URL`, and `MEDIA_PROVIDER_API_KEY` as Worker secrets/vars. Credentials remain server-side.
- Provider response must contain an `items`, `results`, `data` array or be an array. Each item must include a stable `id`, `media_type`, HTTPS `media_url`, HTTPS `source_url`, explicit `rights_status` (`authorized`, `licensed`, `owned`, `public_domain`, `cc0`, or `cc-by`), an HTTPS `rights_reference`, and `allowed_usage` matching the requested media type. Video duration must be 15–180 seconds. Unverified/ambiguous records are rejected by default.
- Provider item fields: `id`, `media_type`, `content_key`, `title`, `description`, `media_url`, `thumbnail_url`, `source_url`, `source_name`, `category`, `related_entity_id`, `related_entity_name`, `duration_seconds`, `rights_status`, `rights_reference`, `allowed_usage`, `priority`, `published_at`.
- For each `media_type + content_key`, the backend keeps the highest-priority newest approved item active and deactivates the older item. Missing items in a partial provider response are not treated as deletions.
- Run `backend/migration-media-rights.sql` on D1 during deployment; the Worker also creates the table lazily.
- The Android Photo Stories screen now reads `/media?type=photo`. The `/media?type=video` feed is exposed by the backend; a consumer video playback screen still requires UI integration and must use the provider's permitted playback method. This ZIP does not claim that the video screen/player is complete.
