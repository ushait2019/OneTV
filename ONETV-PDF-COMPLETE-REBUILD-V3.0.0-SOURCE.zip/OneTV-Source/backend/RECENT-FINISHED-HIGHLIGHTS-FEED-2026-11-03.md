# Recent Finished Match Highlight Feed

- `/cricket/live` remains the backend endpoint consumed by the existing app listing.
- The backend now places up to 3 currently live cricket matches first.
- Up to 3 most recently finished matches follow those live matches.
- Finished matches are ordered newest-finished first, so older finished matches move downward as new matches finish.
- Remaining live matches follow the recent-finished block, preserving access to the full live set.
- Recent finished items are marked `section=recent_finished` and `highlightEligible=true`.
- `/cricket/results` remains the dedicated Results feed and is unchanged.
- No Android UI/code change is required for this feed behavior.
