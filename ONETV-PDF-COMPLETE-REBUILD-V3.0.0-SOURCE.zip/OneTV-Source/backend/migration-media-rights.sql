-- OneTV rights-gated automated media feed (photos + short videos)
CREATE TABLE IF NOT EXISTS media_assets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  provider_key TEXT NOT NULL,
  provider_asset_id TEXT NOT NULL,
  media_type TEXT NOT NULL CHECK(media_type IN ('photo','video')),
  content_key TEXT NOT NULL,
  title TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  media_url TEXT NOT NULL,
  thumbnail_url TEXT NOT NULL DEFAULT '',
  source_url TEXT NOT NULL DEFAULT '',
  source_name TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT 'general',
  related_entity_id TEXT NOT NULL DEFAULT '',
  related_entity_name TEXT NOT NULL DEFAULT '',
  duration_seconds INTEGER NOT NULL DEFAULT 0,
  rights_status TEXT NOT NULL,
  rights_reference TEXT NOT NULL DEFAULT '',
  allowed_usage TEXT NOT NULL DEFAULT '',
  priority REAL NOT NULL DEFAULT 0,
  source_published_at TEXT NOT NULL DEFAULT '',
  first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  active INTEGER NOT NULL DEFAULT 1,
  UNIQUE(provider_key, provider_asset_id)
);
CREATE INDEX IF NOT EXISTS idx_media_active_type_priority ON media_assets(active,media_type,priority DESC,last_seen_at DESC);
CREATE INDEX IF NOT EXISTS idx_media_content_key ON media_assets(content_key,active);
