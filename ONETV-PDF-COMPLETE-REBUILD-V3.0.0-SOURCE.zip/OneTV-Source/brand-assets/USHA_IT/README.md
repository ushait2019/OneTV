# USHA IT brand assets

Original assets supplied by the OneTV owner. Keep original proportions and transparency.

- 01 full transparent logo: light surfaces / general brand use.
- 02 transparent icon: compact brand mark.
- 03 monochrome navy icon: light surfaces where a single-colour mark is needed.
- 04 full white reversed logo: dark surfaces (used on the About screen).
- 05 white reversed icon: dark surfaces / compact brand use.

OneTV is the consumer app brand. USHA IT is its developer and owner.
