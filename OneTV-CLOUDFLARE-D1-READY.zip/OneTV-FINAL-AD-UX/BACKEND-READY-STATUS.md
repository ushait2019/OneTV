# One TV Backend Ready Status

Date: 2026-10-31

## Ready in this package
- Cloudflare Worker + D1 backend source
- D1 schema
- Channel CRUD and source resolver
- Direct Link / API / YouTube source support
- YouTube Data API metadata resolver
- Official YouTube embedded playback path in Android
- Notice Board API and admin editor
- Viewer heartbeat and analytics
- Cricket Live proxy
- Short-lived Cricket API cache
- Admin web page and Windows desktop panel
- PowerShell and shell deployment helpers
- Android Worker URL injection through `ONETV_BACKEND_URL`
- AdMob production IDs already integrated

## Account-specific steps still required
These cannot be fabricated safely:
1. Create the Cloudflare D1 database and put its real ID in `backend/wrangler.toml`.
2. Deploy the Worker from the user's Cloudflare account.
3. Set `ADMIN_TOKEN`, `YOUTUBE_API_KEY`, and `CRICKET_API_KEY` as Worker secrets.
4. Put the resulting Worker URL in GitHub Actions secret `ONETV_BACKEND_URL`.
5. Run the GitHub Actions Android build.

The ZIP intentionally contains no real Cloudflare or third-party API secrets.
