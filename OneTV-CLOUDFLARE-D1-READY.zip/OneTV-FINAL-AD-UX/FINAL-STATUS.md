# One TV Final Status

Date: 2026-10-31

## Product
- Brand: One TV
- Slogan: All in One
- Package: `com.ushait.onetv`
- Developer: USHA IT
- Copyright: `© 2026 USHA IT. All Rights Reserved.`
- Navigation: `TV • MOVIES • CRICKET`

## Ads
- App ID: `ca-app-pub-5981864080922785~4472399258`
- Banner: `ca-app-pub-5981864080922785/5178976268`
- Interstitial: `ca-app-pub-5981864080922785/7592231664`
- Native Advanced: `ca-app-pub-5981864080922785/1737269754`
- Interstitial app-side cooldown: 120 seconds
- No launch, exit, back-button, score-reading, or video-playback interstitials

## Backend
- Cloudflare Worker + D1 source included
- Dynamic channel CRUD
- Direct Link / API / YouTube source modes
- YouTube Data API metadata resolver
- Notice Board only on TV/Home
- Viewer heartbeat and analytics
- Cricket Live proxy
- Cricket response cache
- Web admin + Windows admin panel
- GitHub Actions `ONETV_BACKEND_URL` injection

## Verified in this environment
- Worker JavaScript syntax check passed
- Deployment shell script syntax check passed
- D1 schema SQLite smoke test passed
- GitHub Actions YAML parse passed
- Required AdMob IDs are present
- Previous undefined `purgeViewerSessions` reference removed
- `/admin` is a public shell; admin data/API operations remain token-protected
- `/notice` and `/notices` are supported

## Not claimed as locally compiled
The execution environment does not contain the Android SDK/Gradle installation required to run the Android build locally. Final Android compilation must be verified by the included GitHub Actions workflow.

## Account-specific setup still required
- Real Cloudflare D1 database ID
- Worker deployment URL
- `ADMIN_TOKEN`
- `YOUTUBE_API_KEY`
- `CRICKET_API_KEY`
- GitHub Actions secret `ONETV_BACKEND_URL`

No real third-party secrets are stored in this ZIP.
