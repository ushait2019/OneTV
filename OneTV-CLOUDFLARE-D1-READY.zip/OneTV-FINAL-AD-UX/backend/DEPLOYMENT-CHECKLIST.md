# One TV Backend Deployment Checklist

## 0. What is already done
- Cloudflare Worker source is included in `src/index.js`.
- D1 schema is included in `schema.sql`.
- Channel CRUD, notices, viewer analytics, YouTube metadata resolution, and Cricket Live proxy are included.
- Cricket responses use short server-side caching to reduce upstream API calls.
- Android reads the Worker URL from the GitHub Actions secret `ONETV_BACKEND_URL` through `BuildConfig.BACKEND_URL`.

## 1. Install and log in
On Windows PowerShell:

```powershell
npm install -g wrangler
wrangler login
wrangler whoami
```

## 2. Create the D1 database

```powershell
cd backend
wrangler d1 create one-tv-db
```

Copy the returned `database_id` into `backend/wrangler.toml`:

```toml
database_id = "YOUR_REAL_D1_DATABASE_ID"
```

Do not commit the database ID if your repository policy treats it as sensitive.

## 3. Deploy the database schema

```powershell
wrangler d1 execute one-tv-db --remote --file=schema.sql
```

## 4. Add Worker secrets

```powershell
wrangler secret put ADMIN_TOKEN
wrangler secret put YOUTUBE_API_KEY
wrangler secret put CRICKET_API_KEY
```

- `ADMIN_TOKEN`: long random value used by the web/desktop admin tools.
- `YOUTUBE_API_KEY`: Google API key with YouTube Data API v3 enabled.
- `CRICKET_API_KEY`: OpenCricket API key, or the key for another provider if you later adapt `cricketFetch()`.

Never put these values in the Android source or GitHub repository.

## 5. Deploy the Worker

```powershell
wrangler deploy
```

Wrangler prints the Worker URL, for example:

```text
https://one-tv-backend.YOUR-SUBDOMAIN.workers.dev
```

## 6. Verify the backend

```powershell
curl.exe https://YOUR-WORKER-URL/health
curl.exe https://YOUR-WORKER-URL/cricket/health
```

`/health` should report `database: connected`.

Open:

```text
https://YOUR-WORKER-URL/admin
```

Enter the same `ADMIN_TOKEN` and click **Connect**.

## 7. Connect Android builds

In GitHub repository settings, add this Actions secret:

```text
Name: ONETV_BACKEND_URL
Value: https://YOUR-WORKER-URL
```

Then run the GitHub Actions workflow again. The workflow passes the URL into Gradle and the app receives it as `BuildConfig.BACKEND_URL`.

## 8. Existing D1 database
Do not blindly run old migrations twice. If this is an existing One TV database, inspect its schema first and apply only the missing migration. The supplied migration files are kept for that purpose.

## 9. Windows deployment shortcut

You can also run:

```powershell
.\deploy.ps1
```

It checks for Wrangler and the D1 database ID, applies `schema.sql`, asks for the three secrets, and deploys the Worker.
