# One TV Backend: Start Here

This folder is the production-ready Cloudflare Worker + D1 backend package for One TV.

## What is already prepared
- Dynamic TV/movie channel database and admin CRUD
- Published Notice Board data for the TV page only
- Viewer heartbeat + per-channel view analytics
- YouTube Data API metadata resolution with official embedded playback in the Android app
- Cricket Live proxy with live/upcoming/results/match endpoints
- Server-side API keys only
- Cricket response caching to reduce upstream API usage
- CORS for the Android client
- Windows Electron admin panel
- PowerShell deployment helper

## What cannot be pre-filled
Cloudflare D1 `database_id`, Worker URL, `ADMIN_TOKEN`, YouTube API key, and cricket API key belong to your accounts and are intentionally not stored in this ZIP.

## First deployment
1. Install Node.js and Wrangler: `npm install -g wrangler`
2. Run `wrangler login`.
3. Run `wrangler d1 create one-tv-db`.
4. Copy the returned `database_id` into `wrangler.toml`.
5. Run `./deploy.ps1` on Windows PowerShell.
6. Wrangler will ask for the three secrets.
7. Copy the deployed Worker URL.
8. Add that URL as the GitHub Actions secret `ONETV_BACKEND_URL`.
9. Re-run the Android workflow.

## Verification
- `GET /health` should report `database: connected`.
- `GET /cricket/health` should report the configured provider once `CRICKET_API_KEY` is set.
- Open `/admin`, enter the `ADMIN_TOKEN`, and press **Connect**.

## Cricket provider
The default provider is OpenCricket API at `https://opencricketapi.com`. It currently advertises live scores and upcoming fixtures and a free Starter tier with 5,000 authenticated requests/month. The Worker caches live responses for about 18 seconds, so many app users do not each trigger a separate upstream request every 20 seconds.

## Important
Do not put Cloudflare, YouTube, or cricket API secrets in the Android APK, GitHub source, or desktop JavaScript.
