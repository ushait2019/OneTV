#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v wrangler >/dev/null || { echo "Install Wrangler first: npm install -g wrangler"; exit 1; }
wrangler whoami
if grep -q 'REPLACE_WITH_YOUR_D1_DATABASE_ID' wrangler.toml; then
  echo "Create the D1 database first: wrangler d1 create one-tv-db"
  echo "Then put the returned database_id into wrangler.toml and run again."
  exit 1
fi
wrangler d1 execute one-tv-db --remote --file=schema.sql
wrangler secret put ADMIN_TOKEN
wrangler secret put YOUTUBE_API_KEY
wrangler secret put CRICKET_API_KEY
wrangler deploy
