# One TV - Dynamic Backend + Player + Notices

This version keeps One TV channel data outside the APK and adds an optional backend-controlled notice/personal-ad section.

## App
- Brand: One TV
- Developer: USHA IT
- Package: `com.ushait.onetv`
- Top menu: **TV | Movie & Drama | Cricket Live**
- Channel numbers are not shown in the app UI.
- Channel name is not displayed as a separate player title.
- Player controls are compact, inside the bottom of the video, and tap-to-show / auto-hide.
- Optional notice section sits between player and AdMob. When no notice is published, it has zero height.
- Notice types: rich text, responsive banner, responsive video.
- AdMob banner and USHA IT copyright remain at the bottom.

## Backend
Cloudflare Worker + D1.

- `/channels` returns active playable channels.
- `/notice` returns the currently published notice, or `{ "enabled": false }`.
- `/admin` provides channel management and notice/personal-ad publishing.
- Channel source dropdown: Link or API.
- Notice text has a rich editor plus Advanced HTML mode.

See `backend/README.md` for deployment and migration commands.

Only use streams and media you are authorized to use or redistribute.


## Final UI / backend architecture
- Top menu: **TV | Movie & Drama | Cricket Live**.
- TV and Movie & Drama are video-based. Cricket Live is score-only and has no video player.
- Player controls stay inside the video and auto-hide/show on tap. Channel name and current-program line appear below the player. Viewer count is optional per channel and is collected through viewer heartbeats.
- Notice/personal-ad area remains optional and collapses to zero height when nothing is published.
- Channel list is placed below the AdMob section, so there is no channel-list block between the player and ads.
- Movies use direct playable video URLs and repeat automatically. Normal YouTube webpage URLs are not treated as direct Media3 stream URLs.
- Current program names can be supplied by an authorized source/API. Arbitrary streams do not reliably expose EPG/now-playing metadata.


## YouTube Data API + Official Embedded Player
- Admin channel source now supports `YouTube`. Paste a normal YouTube watch/shorts/live URL or 11-character video ID.
- Cloudflare Worker uses the official YouTube Data API `videos.list` to validate the video and fetch title/thumbnail metadata.
- Store the API key only as a Worker secret: `wrangler secret put YOUTUBE_API_KEY`. Never put the key in the Android app.
- Android plays YouTube videos through the official `youtube.com/embed/{VIDEO_ID}` player in a WebView. It does not extract or re-host YouTube media URLs.
- Direct HLS/MP4/DASH streams continue to use Media3/ExoPlayer.


## Cricket Live

Cricket Live is a **score-only** section. It has no TV/movie video player. The app loads live scores, upcoming matches, results/history and match details from the Cloudflare Worker. The Worker keeps the cricket provider key server-side.

The current implementation is wired for OpenCricket API by default. It provides live scores and an historical archive, so old match data is also API-driven and does not need to be bundled into the APK. The UI is a custom One TV score-card design, not a copy of Cricbuzz.

Required Worker secret:

```bash
wrangler secret put CRICKET_API_KEY
```

Optional variable:

```text
CRICKET_API_BASE_URL=https://opencricketapi.com
```

Public Worker routes used by the app:

- `/cricket/live`
- `/cricket/upcoming`
- `/cricket/results`
- `/cricket/match/<MATCH_ID>`
- `/cricket/health`

Live scores refresh every 20 seconds while Cricket Live is open.
