package com.ushait.onetv;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final String ADMOB_LIVE_BANNER_ID = "ca-app-pub-5981864080922785/5178976268";
    private static final String ADMOB_TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111";
    private static final String BACKEND_URL = "https://REPLACE-WITH-YOUR-WORKER.workers.dev";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final List<Channel> channels = new ArrayList<>();
    private final String viewerId = UUID.randomUUID().toString();

    private ExoPlayer player;
    private PlayerView playerView;
    private WebView youtubeWebView;
    private LinearLayout playerContainer;
    private LinearLayout playerControls;
    private FrameLayout noticeContainer;
    private WebView noticeWebView;
    private LinearLayout channelList;
    private LinearLayout categoryList;
    private LinearLayout cricketContainer;
    private LinearLayout cricketList;
    private TextView cricketHeader;
    private TextView cricketUpdated;
    private TextView nowPlayingName;
    private TextView nowPlayingProgram;
    private TextView viewerCountView;

    private int currentIndex = 0;
    private boolean controlsVisible = false;
    private String currentCategory = "TV";
    private String cricketMode = "live";
    private boolean cricketDetail = false;

    private final Runnable refreshContent = new Runnable() {
        @Override public void run() {
            loadBackendContent();
            handler.postDelayed(this, 60000);
        }
    };
    private final Runnable cricketRefresh = new Runnable() {
        @Override public void run() {
            if ("Cricket Live".equals(currentCategory) && !cricketDetail) loadCricket(cricketMode);
            handler.postDelayed(this, 20000);
        }
    };
    private final Runnable viewerHeartbeat = new Runnable() {
        @Override public void run() {
            pingViewer();
            handler.postDelayed(this, 30000);
        }
    };
    private final Runnable hideControls = new Runnable() {
        @Override public void run() { setControlsVisible(false); }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 12, 18));
        getWindow().setNavigationBarColor(Color.BLACK);
        MobileAds.initialize(this, status -> {});
        buildUi();
        loadBackendContent();
        handler.postDelayed(refreshContent, 60000);
        handler.postDelayed(cricketRefresh, 20000);
        handler.postDelayed(viewerHeartbeat, 30000);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(8, 12, 18));
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(0, bars.top, 0, bars.bottom);
            return insets;
        });

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.onetv_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setAdjustViewBounds(true);
        logo.setPadding(16, 6, 16, 6);
        root.addView(logo, new LinearLayout.LayoutParams(-1, 70));

        HorizontalScrollView catsScroll = new HorizontalScrollView(this);
        catsScroll.setHorizontalScrollBarEnabled(false);
        categoryList = new LinearLayout(this);
        categoryList.setGravity(Gravity.CENTER_VERTICAL);
        categoryList.setPadding(8, 0, 8, 8);
        catsScroll.addView(categoryList);
        root.addView(catsScroll, new LinearLayout.LayoutParams(-1, -2));

        playerContainer = new LinearLayout(this);
        playerContainer.setOrientation(LinearLayout.VERTICAL);
        buildPlayerArea();
        root.addView(playerContainer, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nowPlaying = new LinearLayout(this);
        nowPlaying.setOrientation(LinearLayout.VERTICAL);
        nowPlaying.setPadding(16, 8, 16, 8);
        nowPlayingName = text("", 17, Color.WHITE, true);
        nowPlayingProgram = text("", 13, Color.LTGRAY, false);
        viewerCountView = text("", 12, Color.GRAY, false);
        nowPlaying.addView(nowPlayingName);
        nowPlaying.addView(nowPlayingProgram);
        nowPlaying.addView(viewerCountView);
        playerContainer.addView(nowPlaying);

        noticeContainer = new FrameLayout(this);
        noticeWebView = new WebView(this);
        WebSettings ws = noticeWebView.getSettings();
        ws.setJavaScriptEnabled(false);
        ws.setDomStorageEnabled(false);
        ws.setAllowFileAccess(false);
        noticeWebView.setBackgroundColor(Color.TRANSPARENT);
        noticeWebView.setWebViewClient(new WebViewClient());
        noticeContainer.addView(noticeWebView, new FrameLayout.LayoutParams(-1, -1));
        playerContainer.addView(noticeContainer, new LinearLayout.LayoutParams(-1, 0));

        buildAdSection(playerContainer);

        TextView channelsTitle = text("Channels", 18, Color.WHITE, true);
        channelsTitle.setPadding(18, 12, 18, 8);
        playerContainer.addView(channelsTitle);

        ScrollView scroll = new ScrollView(this);
        channelList = new LinearLayout(this);
        channelList.setOrientation(LinearLayout.VERTICAL);
        channelList.setPadding(12, 0, 12, 8);
        scroll.addView(channelList);
        playerContainer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        cricketContainer = buildCricketArea();
        root.addView(cricketContainer, new LinearLayout.LayoutParams(-1, 0, 1));
        cricketContainer.setVisibility(View.GONE);

        TextView footer = text("© 2026 USHA IT. All Rights Reserved.", 12, Color.GRAY, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(8, 10, 8, 12);
        root.addView(footer);

        setContentView(root);
        rebuildCategories();
        showCategory("TV");
        hideNotice();
    }

    private void buildPlayerArea() {
        FrameLayout videoFrame = new FrameLayout(this);
        videoFrame.setBackgroundColor(Color.BLACK);
        int playerHeight = Math.max(300, (int) (getResources().getDisplayMetrics().widthPixels * 0.62f));

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        videoFrame.addView(playerView, new FrameLayout.LayoutParams(-1, playerHeight));

        youtubeWebView = new WebView(this);
        WebSettings yws = youtubeWebView.getSettings();
        yws.setJavaScriptEnabled(true);
        yws.setDomStorageEnabled(true);
        yws.setMediaPlaybackRequiresUserGesture(false);
        yws.setAllowFileAccess(false);
        youtubeWebView.setWebViewClient(new WebViewClient());
        youtubeWebView.setBackgroundColor(Color.BLACK);
        videoFrame.addView(youtubeWebView, new FrameLayout.LayoutParams(-1, playerHeight));
        youtubeWebView.setVisibility(View.GONE);

        playerControls = new LinearLayout(this);
        playerControls.setOrientation(LinearLayout.HORIZONTAL);
        playerControls.setGravity(Gravity.CENTER_VERTICAL);
        playerControls.setPadding(6, 2, 6, 2);
        playerControls.setBackgroundColor(Color.argb(205, 0, 0, 0));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, 52, Gravity.BOTTOM);
        videoFrame.addView(playerControls, cp);

        Button prev = playerControlButton("‹");
        Button volume = playerControlButton("🔊");
        Button mute = playerControlButton("🔇");
        Button quality = playerControlButton("⚙");
        Button next = playerControlButton("›");
        Button fullscreen = playerControlButton("⛶");
        prev.setOnClickListener(v -> playChannel(currentIndex - 1));
        volume.setOnClickListener(v -> adjustVolume(0.10f));
        mute.setOnClickListener(v -> toggleMute());
        quality.setOnClickListener(v -> showQualityMenu(quality));
        next.setOnClickListener(v -> playChannel(currentIndex + 1));
        fullscreen.setOnClickListener(v -> toggleFullscreen());
        playerControls.addView(prev, controlWeight());
        playerControls.addView(volume, controlWeight());
        playerControls.addView(mute, controlWeight());
        playerControls.addView(quality, controlWeight());
        playerControls.addView(next, controlWeight());
        playerControls.addView(fullscreen, controlWeight());

        playerView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) toggleControls();
            return true;
        });
        youtubeWebView.setOnTouchListener((v, event) -> false);

        playerContainer.addView(videoFrame, 0, new LinearLayout.LayoutParams(-1, playerHeight));
        playerControls.setVisibility(View.GONE);
    }

    private LinearLayout buildAdSection(ViewGroup parent) {
        LinearLayout adSection = new LinearLayout(this);
        adSection.setOrientation(LinearLayout.VERTICAL);
        adSection.setGravity(Gravity.CENTER);
        adSection.setBackgroundColor(Color.rgb(22, 27, 34));
        adSection.setPadding(8, 6, 8, 6);
        TextView label = text("ADVERTISEMENT", 10, Color.GRAY, false);
        label.setGravity(Gravity.CENTER);
        adSection.addView(label, new LinearLayout.LayoutParams(-1, 20));
        AdView adView = new AdView(this);
        int widthPx = getResources().getDisplayMetrics().widthPixels;
        float density = getResources().getDisplayMetrics().density;
        int adWidth = Math.max(1, (int) (widthPx / density));
        adView.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth));
        boolean debug = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        adView.setAdUnitId(debug ? ADMOB_TEST_BANNER_ID : ADMOB_LIVE_BANNER_ID);
        adView.loadAd(new AdRequest.Builder().build());
        adSection.addView(adView, new LinearLayout.LayoutParams(-1, -2));
        parent.addView(adSection);
        return adSection;
    }

    private LinearLayout buildCricketArea() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundColor(Color.rgb(8, 12, 18));

        LinearLayout header = new LinearLayout(this);
        header.setPadding(16, 12, 16, 6);
        header.setGravity(Gravity.CENTER_VERTICAL);
        cricketHeader = text("Cricket Live", 22, Color.WHITE, true);
        header.addView(cricketHeader, new LinearLayout.LayoutParams(0, -2, 1));
        cricketUpdated = text("", 11, Color.GRAY, false);
        header.addView(cricketUpdated);
        outer.addView(header);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setPadding(12, 0, 12, 8);
        String[] modes = {"Live", "Upcoming", "Results"};
        for (String mode : modes) {
            Button b = scoreTabButton(mode);
            b.setOnClickListener(v -> {
                cricketDetail = false;
                cricketMode = mode.equals("Live") ? "live" : mode.equals("Upcoming") ? "upcoming" : "results";
                loadCricket(cricketMode);
            });
            tabs.addView(b, new LinearLayout.LayoutParams(0, 48, 1));
        }
        outer.addView(tabs);

        ScrollView scroll = new ScrollView(this);
        cricketList = new LinearLayout(this);
        cricketList.setOrientation(LinearLayout.VERTICAL);
        cricketList.setPadding(12, 4, 12, 18);
        scroll.addView(cricketList);
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        return outer;
    }

    private Button scoreTabButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setBackground(round(Color.rgb(27, 35, 45), 18));
        return b;
    }

    private void rebuildCategories() {
        if (categoryList == null) return;
        categoryList.removeAllViews();
        String[] cats = {"TV", "Movie & Drama", "Cricket Live"};
        for (String cat : cats) {
            Button b = new Button(this);
            b.setText(cat);
            b.setAllCaps(false);
            b.setTextColor(Color.WHITE);
            b.setTextSize(13);
            b.setBackground(round(Color.rgb(27, 35, 45), 18));
            b.setOnClickListener(v -> showCategory(cat));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, 50);
            p.setMargins(4, 0, 4, 0);
            categoryList.addView(b, p);
        }
    }

    private void showCategory(String cat) {
        currentCategory = cat;
        boolean cricket = "Cricket Live".equals(cat);
        playerContainer.setVisibility(cricket ? View.GONE : View.VISIBLE);
        cricketContainer.setVisibility(cricket ? View.VISIBLE : View.GONE);
        if (cricket) {
            cricketDetail = false;
            loadCricket(cricketMode);
            return;
        }
        if (channelList == null) return;
        channelList.removeAllViews();
        for (int i = 0; i < channels.size(); i++) {
            Channel c = channels.get(i);
            boolean match = "TV".equals(cat) ? "TV".equalsIgnoreCase(c.category) :
                    ("Movies".equalsIgnoreCase(c.category) || "Movie & Drama".equalsIgnoreCase(c.category));
            if (!match) continue;
            Button b = new Button(this);
            b.setText(c.name);
            b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            b.setAllCaps(false);
            b.setTextColor(Color.WHITE);
            b.setBackground(round(Color.rgb(19, 26, 34), 12));
            final int idx = i;
            b.setOnClickListener(v -> playChannel(idx));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 58);
            p.setMargins(0, 4, 0, 4);
            channelList.addView(b, p);
        }
    }

    private void loadBackendContent() {
        if (BACKEND_URL.contains("REPLACE-WITH-YOUR-WORKER")) {
            seedDemoChannels();
            showCategory("TV");
            hideNotice();
            return;
        }
        network.execute(() -> {
            List<Channel> loaded = new ArrayList<>();
            Notice loadedNotice = null;
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/channels"));
                JSONArray arr = root.optJSONArray("channels");
                if (arr != null) for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    loaded.add(new Channel(o.optInt("id"), o.optString("number"), o.optString("name"), o.optString("country"), o.optString("category", "TV"), o.optString("streamUrl"), o.optString("sourceType", "link"), o.optString("youtubeVideoId"), o.optString("programName"), o.optInt("viewerCount"), o.optBoolean("showViewerCount"), o.optBoolean("loop")));
                }
            } catch (Exception ignored) { loaded = null; }
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/notice"));
                if (root.optBoolean("enabled")) loadedNotice = new Notice(root.optString("type"), root.optString("title"), root.optString("html"), root.optString("mediaUrl"), root.optString("linkUrl"));
            } catch (Exception ignored) {}
            final List<Channel> result = loaded;
            final Notice notice = loadedNotice;
            runOnUiThread(() -> {
                if (result != null) {
                    channels.clear(); channels.addAll(result);
                    if (!"Cricket Live".equals(currentCategory)) showCategory(currentCategory);
                    if (player == null && !channels.isEmpty()) {
                        int first = firstIndexForCategory("TV");
                        if (first >= 0) playChannel(first);
                    }
                }
                if (notice != null) renderNotice(notice); else hideNotice();
            });
        });
    }

    private void seedDemoChannels() {
        channels.clear();
        channels.add(new Channel(1, "", "Demo TV", "International", "TV", "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", "link", "", "Demo Program", 0, false, false));
        channels.add(new Channel(2, "", "Demo Movie", "International", "Movies", "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4", "link", "", "Demo Movie", 0, false, true));
    }

    private int firstIndexForCategory(String cat) {
        for (int i = 0; i < channels.size(); i++) {
            Channel c = channels.get(i);
            if ("TV".equals(cat) && "TV".equalsIgnoreCase(c.category)) return i;
            if ("Movie & Drama".equals(cat) && ("Movies".equalsIgnoreCase(c.category) || "Movie & Drama".equalsIgnoreCase(c.category))) return i;
        }
        return channels.isEmpty() ? -1 : 0;
    }

    private void playChannel(int index) {
        if (channels.isEmpty()) return;
        currentIndex = (index + channels.size()) % channels.size();
        Channel c = channels.get(currentIndex);
        if (player == null) {
            player = new ExoPlayer.Builder(this).build();
            playerView.setPlayer(player);
            player.addListener(new Player.Listener() {
                @Override public void onPlayerError(PlaybackException error) { Toast.makeText(MainActivity.this, "Unable to play this stream", Toast.LENGTH_SHORT).show(); }
            });
        }
        if ("youtube".equalsIgnoreCase(c.sourceType) && c.youtubeVideoId != null && !c.youtubeVideoId.isEmpty()) {
            player.pause();
            playerView.setVisibility(View.GONE);
            youtubeWebView.setVisibility(View.VISIBLE);
            loadYouTubeVideo(c.youtubeVideoId, c.loop || "Movies".equalsIgnoreCase(c.category));
        } else {
            youtubeWebView.setVisibility(View.GONE);
            playerView.setVisibility(View.VISIBLE);
            if (c.url == null || c.url.trim().isEmpty()) {
                Toast.makeText(this, "No playable stream configured", Toast.LENGTH_SHORT).show();
                return;
            }
            player.setMediaItem(MediaItem.fromUri(Uri.parse(c.url)));
            player.setRepeatMode(c.loop || "Movies".equalsIgnoreCase(c.category) ? Player.REPEAT_MODE_ONE : Player.REPEAT_MODE_OFF);
            player.prepare(); player.play();
        }
        updateNowPlaying(c);
        pingViewer();
        showControlsTemporarily();
    }

    private void loadYouTubeVideo(String id, boolean loop) {
        String safe = id.replaceAll("[^A-Za-z0-9_-]", "");
        if (safe.length() != 11) return;
        String loopParam = loop ? "&loop=1&playlist=" + safe : "";
        String html = "<html><body style='margin:0;background:#000;overflow:hidden'><iframe width='100%' height='100%' src='https://www.youtube.com/embed/" + safe + "?autoplay=1&playsinline=1&rel=0&modestbranding=1" + loopParam + "' frameborder='0' allow='autoplay; encrypted-media; picture-in-picture; fullscreen' allowfullscreen></iframe></body></html>";
        youtubeWebView.loadDataWithBaseURL("https://www.youtube.com/", html, "text/html", "UTF-8", null);
    }

    private void loadCricket(String mode) {
        if (cricketList == null || BACKEND_URL.contains("REPLACE-WITH-YOUR-WORKER")) {
            showCricketMessage("Connect the One TV Worker to load live cricket scores.");
            return;
        }
        cricketList.removeAllViews();
        showCricketMessage("Loading " + mode + " matches…");
        network.execute(() -> {
            try {
                String body = getUrl(BACKEND_URL + "/cricket/" + mode);
                JSONObject root = new JSONObject(body);
                JSONArray matches = root.optJSONArray("matches");
                runOnUiThread(() -> renderCricketMatches(matches, mode));
            } catch (Exception e) {
                runOnUiThread(() -> showCricketMessage("Cricket data is temporarily unavailable."));
            }
        });
    }

    private void renderCricketMatches(JSONArray matches, String mode) {
        cricketList.removeAllViews();
        cricketUpdated.setText("Updated just now");
        if (matches == null || matches.length() == 0) {
            showCricketMessage(mode.equals("live") ? "No live matches right now." : "No matches found.");
            return;
        }
        for (int i = 0; i < matches.length(); i++) {
            try { cricketList.addView(matchCard(matches.getJSONObject(i))); }
            catch (Exception ignored) {}
        }
    }

    private View matchCard(JSONObject m) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(16, 14, 16, 14);
        card.setBackground(round(Color.rgb(18, 25, 33), 16));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, 10);
        card.setLayoutParams(cp);

        LinearLayout top = new LinearLayout(this);
        TextView comp = text(m.optString("competition", "Cricket"), 11, Color.LTGRAY, false);
        top.addView(comp, new LinearLayout.LayoutParams(0, -2, 1));
        TextView status = text(m.optString("status", m.optString("state", "")), 11, Color.WHITE, true);
        status.setGravity(Gravity.RIGHT);
        top.addView(status);
        card.addView(top);

        TextView name = text(m.optString("name", m.optString("teams", "Match")), 16, Color.WHITE, true);
        name.setPadding(0, 7, 0, 8);
        card.addView(name);

        JSONArray teams = m.optJSONArray("teams");
        if (teams != null && teams.length() > 0) {
            for (int t = 0; t < teams.length(); t++) {
                JSONObject team = teams.optJSONObject(t);
                if (team == null) continue;
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                TextView tn = text(team.optString("name", "Team"), 15, Color.WHITE, false);
                TextView ts = text(team.optString("score", ""), 18, Color.WHITE, true);
                ts.setGravity(Gravity.RIGHT);
                row.addView(tn, new LinearLayout.LayoutParams(0, 44, 1));
                row.addView(ts, new LinearLayout.LayoutParams(-2, 44));
                card.addView(row);
            }
        } else {
            TextView score = text(m.optString("score", ""), 18, Color.WHITE, true);
            card.addView(score);
        }

        String footer = m.optString("venue", "");
        if (!footer.isEmpty()) card.addView(text(footer, 11, Color.GRAY, false));
        String result = m.optString("result", m.optString("status", ""));
        if ("results".equals(cricketMode) && !result.isEmpty()) {
            TextView r = text(result, 12, Color.rgb(124, 211, 145), true);
            r.setPadding(0, 7, 0, 0);
            card.addView(r);
        }
        card.setOnClickListener(v -> loadCricketDetail(m.optString("id", m.optString("match", ""))));
        return card;
    }

    private void loadCricketDetail(String matchId) {
        if (matchId == null || matchId.isEmpty()) return;
        cricketDetail = true;
        cricketList.removeAllViews();
        showCricketMessage("Loading scorecard…");
        network.execute(() -> {
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/cricket/match/" + Uri.encode(matchId)));
                runOnUiThread(() -> renderCricketDetail(root));
            } catch (Exception e) {
                runOnUiThread(() -> showCricketMessage("Scorecard is temporarily unavailable."));
            }
        });
    }

    private void renderCricketDetail(JSONObject root) {
        cricketList.removeAllViews();
        Button back = scoreTabButton("‹ Back to matches");
        back.setOnClickListener(v -> { cricketDetail = false; loadCricket(cricketMode); });
        cricketList.addView(back, new LinearLayout.LayoutParams(-1, 48));
        JSONObject m = root.optJSONObject("match");
        if (m == null) m = root;
        TextView title = text(m.optString("name", m.optString("teams", "Match")), 21, Color.WHITE, true);
        title.setPadding(4, 16, 4, 8);
        cricketList.addView(title);
        cricketList.addView(text(m.optString("competition", ""), 12, Color.GRAY, false));
        cricketList.addView(text(m.optString("venue", ""), 12, Color.GRAY, false));
        JSONArray teams = m.optJSONArray("teams");
        if (teams != null) for (int i = 0; i < teams.length(); i++) {
            JSONObject t = teams.optJSONObject(i);
            if (t == null) continue;
            cricketList.addView(scoreLine(t.optString("name", "Team"), t.optString("score", "")));
        }
        String status = m.optString("status", m.optString("result", ""));
        if (!status.isEmpty()) cricketList.addView(text(status, 14, Color.rgb(124, 211, 145), true));

        JSONArray innings = m.optJSONArray("innings");
        if (innings != null && innings.length() > 0) {
            TextView h = text("Scorecard", 18, Color.WHITE, true);
            h.setPadding(0, 18, 0, 8);
            cricketList.addView(h);
            for (int i = 0; i < innings.length(); i++) {
                JSONObject in = innings.optJSONObject(i);
                if (in == null) continue;
                cricketList.addView(scoreLine(in.optString("team", "Innings " + (i + 1)), in.optString("score", in.optString("runs", ""))));
            }
        }
        cricketUpdated.setText("Match details");
    }

    private View scoreLine(String left, String right) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(14, 8, 14, 8);
        row.setBackground(round(Color.rgb(18, 25, 33), 10));
        TextView l = text(left, 15, Color.WHITE, false);
        TextView r = text(right, 17, Color.WHITE, true);
        r.setGravity(Gravity.RIGHT);
        row.addView(l, new LinearLayout.LayoutParams(0, 48, 1));
        row.addView(r, new LinearLayout.LayoutParams(-2, 48));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 3, 0, 3);
        row.setLayoutParams(p);
        return row;
    }

    private void showCricketMessage(String message) {
        cricketList.removeAllViews();
        TextView t = text(message, 14, Color.LTGRAY, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(20, 60, 20, 60);
        cricketList.addView(t);
    }

    private String getUrl(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(15000); c.setRequestMethod("GET");
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()))) {
            StringBuilder b = new StringBuilder(); String line;
            while ((line = r.readLine()) != null) b.append(line);
            return b.toString();
        } finally { c.disconnect(); }
    }

    private void pingViewer() {
        if (BACKEND_URL.contains("REPLACE-WITH-YOUR-WORKER") || channels.isEmpty()) return;
        if (currentIndex < 0 || currentIndex >= channels.size()) return;
        int id = channels.get(currentIndex).id;
        if (id <= 0) return;
        network.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(BACKEND_URL + "/viewer/ping").openConnection();
                c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json");
                byte[] body = new JSONObject().put("viewerId", viewerId).put("channelId", id).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
                try (OutputStream out = c.getOutputStream()) { out.write(body); }
                c.getResponseCode();
            } catch (Exception ignored) {} finally { if (c != null) c.disconnect(); }
        });
    }

    private void updateNowPlaying(Channel c) {
        nowPlayingName.setText(c.name);
        nowPlayingProgram.setText("Now Playing: " + (c.programName == null || c.programName.trim().isEmpty() ? "—" : c.programName));
        if (c.showViewers && c.viewerCount > 0) {
            viewerCountView.setVisibility(View.VISIBLE);
            viewerCountView.setText("👁 " + c.viewerCount + " viewers");
        } else viewerCountView.setVisibility(View.GONE);
    }

    private void renderNotice(Notice n) {
        if (n == null) { hideNotice(); return; }
        String type = n.type == null ? "text" : n.type.toLowerCase();
        String html; int heightDp;
        if ("banner".equals(type)) {
            html = "<html><body style='margin:0;background:#0b0f14'><img src='" + esc(n.mediaUrl) + "' style='width:100%;display:block'></body></html>"; heightDp = 100;
        } else if ("video".equals(type)) {
            html = "<html><body style='margin:0;background:#000'><video src='" + esc(n.mediaUrl) + "' controls autoplay muted playsinline loop style='width:100%;height:100%;object-fit:cover'></video></body></html>"; heightDp = 170;
        } else {
            html = "<html><body style='margin:0;background:#0b0f14;color:#fff'><div style='padding:10px 14px'>" + n.html + "</div></body></html>"; heightDp = 100;
        }
        noticeWebView.loadDataWithBaseURL("https://onetv.local/", html, "text/html", "UTF-8", null);
        noticeContainer.setVisibility(View.VISIBLE);
        ViewGroup.LayoutParams lp = noticeContainer.getLayoutParams(); lp.height = (int)(heightDp * getResources().getDisplayMetrics().density); noticeContainer.setLayoutParams(lp);
    }

    private void hideNotice() {
        if (noticeContainer == null) return;
        noticeContainer.setVisibility(View.GONE);
        ViewGroup.LayoutParams lp = noticeContainer.getLayoutParams(); lp.height = 0; noticeContainer.setLayoutParams(lp);
    }

    private String esc(String s) { return s == null ? "" : s.replace("&", "&amp;").replace("\"", "&quot;").replace("'", "&#39;").replace("<", "&lt;").replace(">", "&gt;"); }

    private LinearLayout.LayoutParams controlWeight() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, 46, 1f); p.setMargins(1,0,1,0); return p; }
    private Button playerControlButton(String label) { Button b = new Button(this); b.setText(label); b.setTextSize(15); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setMinHeight(0); b.setMinWidth(0); b.setPadding(0,0,0,0); b.setBackgroundColor(Color.TRANSPARENT); return b; }
    private Button controlButton(String label) { Button b = new Button(this); b.setText(label); b.setTextSize(12); b.setAllCaps(false); return b; }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(null, Typeface.BOLD); return t; }
    private GradientDrawable round(int color, float radius) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }

    private void setControlsVisible(boolean visible) { controlsVisible = visible; playerControls.setVisibility(visible ? View.VISIBLE : View.GONE); }
    private void toggleControls() { if (controlsVisible) { setControlsVisible(false); handler.removeCallbacks(hideControls); } else showControlsTemporarily(); }
    private void showControlsTemporarily() { setControlsVisible(true); handler.removeCallbacks(hideControls); handler.postDelayed(hideControls, 3500); }
    private void adjustVolume(float d) { if (player == null) return; player.setVolume(Math.max(0, Math.min(1, player.getVolume() + d))); showControlsTemporarily(); }
    private void toggleMute() { if (player == null) return; player.setVolume(player.getVolume() > 0 ? 0 : 1); showControlsTemporarily(); }
    private void showQualityMenu(View anchor) {
        PopupWindow popup = new PopupWindow(this); LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(8,8,8,8); box.setBackgroundColor(Color.rgb(35,40,48));
        for (String q : new String[]{"Auto","1080p","720p","480p","360p"}) { Button b = controlButton(q); b.setOnClickListener(v -> { Toast.makeText(this, "Quality: " + q, Toast.LENGTH_SHORT).show(); popup.dismiss(); showControlsTemporarily(); }); box.addView(b, new LinearLayout.LayoutParams(180,48)); }
        popup.setContentView(box); popup.setWidth(220); popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT); popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.rgb(35,40,48))); popup.setOutsideTouchable(true); popup.setFocusable(true); popup.showAsDropDown(anchor); showControlsTemporarily();
    }
    private void toggleFullscreen() { int flags = getWindow().getDecorView().getSystemUiVisibility(); boolean full = (flags & View.SYSTEM_UI_FLAG_FULLSCREEN) != 0; getWindow().getDecorView().setSystemUiVisibility(full ? View.SYSTEM_UI_FLAG_LAYOUT_STABLE : View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE); showControlsTemporarily(); }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null); network.shutdownNow();
        if (player != null) { player.release(); player = null; }
        if (noticeWebView != null) noticeWebView.destroy(); if (youtubeWebView != null) youtubeWebView.destroy();
        super.onDestroy();
    }

    static class Channel {
        int id, viewerCount; String number, name, country, category, url, sourceType, youtubeVideoId, programName; boolean showViewers, loop;
        Channel(int id, String number, String name, String country, String category, String url, String sourceType, String youtubeVideoId, String programName, int viewerCount, boolean showViewers, boolean loop) { this.id=id;this.number=number;this.name=name;this.country=country;this.category=category;this.url=url;this.sourceType=sourceType;this.youtubeVideoId=youtubeVideoId;this.programName=programName;this.viewerCount=viewerCount;this.showViewers=showViewers;this.loop=loop; }
    }
    static class Notice { String type,title,html,mediaUrl,linkUrl; Notice(String t,String ti,String h,String m,String l){type=t;title=ti;html=h;mediaUrl=m;linkUrl=l;} }
}
