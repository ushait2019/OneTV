# One TV backend deployment checklist

## New D1 database
```bash
npm install -g wrangler
wrangler login
wrangler d1 create one-tv-db
```

Put the returned database ID in `wrangler.toml`, then:

```bash
wrangler d1 execute one-tv-db --remote --file=schema.sql
wrangler secret put ADMIN_TOKEN
wrangler secret put YOUTUBE_API_KEY
wrangler secret put CRICKET_API_KEY
wrangler deploy
```

If you want a custom cricket provider base URL:

```bash
wrangler deploy --var CRICKET_API_BASE_URL:https://YOUR-PROVIDER.example
```

Or set it in the Worker configuration before deployment.

## Existing One TV D1 database
Apply only migrations that your current database still needs. Do not blindly run an ALTER TABLE migration twice.

Typical sequence for an older database:
```bash
wrangler d1 execute one-tv-db --remote --file=migration-source.sql
wrangler d1 execute one-tv-db --remote --file=migration-notice.sql
wrangler d1 execute one-tv-db --remote --file=migration-view-stats.sql
```

`migration-youtube.sql` is informational only and does not add columns.

## Verify
```bash
curl https://YOUR-WORKER-DOMAIN/health
curl https://YOUR-WORKER-DOMAIN/cricket/health
```

Then open:
`https://YOUR-WORKER-DOMAIN/admin`

Use the same `ADMIN_TOKEN` for the admin panel.

## Android
Set the Worker base URL in `MainActivity.java` and rebuild once. After that, channel/content changes are backend-driven.
