# One TV - Dynamic Backend Edition

Android live-TV client by USHA IT. The APK does **not** hard-code the channel catalog. It reads active channels from the One TV backend.

## What you get
- Backend-controlled channel list.
- Add/edit/disable/delete channels without rebuilding the APK.
- All users receive the latest active channel list automatically when the app opens and via a background refresh every 60 seconds while the app is running.
- Backend-controlled channel number, name, country, category, logo URL, stream URL, active status and sort order.
- Dynamic category buttons based on the channels currently returned by the backend.
- Media3/ExoPlayer playback.
- Previous/Next channel, volume/mute, fullscreen and quality UI hooks.
- Existing One TV AdMob banner support retained.
- Android Studio is not required; GitHub Actions builds the APK/AAB.

## Important
The backend does not grant rights to any TV stream. Only add stream URLs that you are authorized to use and redistribute.

## Setup order
1. Deploy `backend/` to Cloudflare Workers + D1. Follow `backend/README.md`.
2. Copy your Worker base URL into `BACKEND_URL` in `app/src/main/java/com/ushait/onetv/MainActivity.java`.
3. Commit/push to GitHub and build with the included GitHub Actions workflow.
4. After that first APK build, channel additions and stream URL changes happen from the backend. No APK rebuild is required for channel changes.

## Backend API
- Public app endpoint: `GET /channels`
- Health check: `GET /health`
- Admin UI: `GET /admin`
- Admin CRUD: `/admin/channels`

The Android app only needs the public `GET /channels` endpoint. The admin token never goes into the APK.
