plugins { id("com.android.application") }

android {
    namespace = "com.ushait.onetv"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ushait.onetv"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("com.google.android.gms:play-services-ads:25.5.0")
}
