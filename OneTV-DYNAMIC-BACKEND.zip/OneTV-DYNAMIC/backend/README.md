# One TV Dynamic Backend

Cloudflare Worker + D1 backend for One TV. The Android app reads `/channels`; admins manage channels from `/admin`.

## What this solves
- Channel data is NOT hard-coded in the APK.
- Add/edit/disable/delete channels from the backend.
- All app users see active channels after the app refreshes its channel list.
- No APK rebuild is needed when a channel is added or its stream URL changes.
- Stream URLs should only be for sources you are authorized to use/redistribute.

## Deploy
1. Install Node.js and Wrangler: `npm install -g wrangler`
2. Login: `wrangler login`
3. Create a D1 database: `wrangler d1 create one-tv-db`
4. Put the returned database ID into `wrangler.toml`.
5. Apply schema: `wrangler d1 execute one-tv-db --remote --file=schema.sql`
6. Set an admin secret: `wrangler secret put ADMIN_TOKEN`
7. Deploy: `wrangler deploy`
8. Open `https://YOUR-WORKER-DOMAIN/admin` in a browser and enter the same ADMIN_TOKEN.

## App endpoint
After deployment, set `BACKEND_URL` in `MainActivity.java` to the Worker base URL, for example:
`https://one-tv-backend.YOUR-SUBDOMAIN.workers.dev`

Then rebuild the APK once. After that, channel additions/edits do not require another APK build.
