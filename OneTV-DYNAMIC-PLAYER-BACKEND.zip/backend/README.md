# One TV Dynamic Backend

Cloudflare Worker + D1 backend for One TV. The Android app reads `/channels`; admins manage channels from `/admin`.

## What this solves
- Channel data is NOT hard-coded in the APK.
- Add/edit/disable/delete channels from the backend.
- All app users see active channels after the app refreshes its channel list.
- No APK rebuild is needed when a channel is added or its source changes.
- Each channel can use either a direct **Link** source or an **API** source.
- The admin form uses one dropdown: `Source: Link` or `Source: API`. The matching input appears automatically.
- API sources are resolved server-side, so API URLs and optional API keys are not exposed to the Android app.
- Stream URLs should only be for sources you are authorized to use/redistribute.

## Source options

### Source: Link
Enter the direct playable stream URL, such as an authorized HLS, DASH, or MP4 URL.

### Source: API
Enter an API URL that returns the playable stream URL. An optional API key can be supplied. The Worker sends the key as both `Authorization: Bearer <key>` and `X-API-Key: <key>`.

The API response can be a direct URL or JSON containing one of these common fields:
`streamUrl`, `stream_url`, `stream`, `url`, `playUrl`, `play_url`, `sourceUrl`, `source_url`, including inside `data`, `result`, `source`, `channel`, or `response`.

Example API response:
`{"streamUrl":"https://example.com/live.m3u8"}`

## Deploy a new database
1. Install Node.js and Wrangler: `npm install -g wrangler`
2. Login: `wrangler login`
3. Create a D1 database: `wrangler d1 create one-tv-db`
4. Put the returned database ID into `wrangler.toml`.
5. Apply schema: `wrangler d1 execute one-tv-db --remote --file=schema.sql`
6. Set an admin secret: `wrangler secret put ADMIN_TOKEN`
7. Deploy: `wrangler deploy`
8. Open `https://YOUR-WORKER-DOMAIN/admin` in a browser and enter the same ADMIN_TOKEN.

## Existing database migration
If your D1 database was already created from the previous One TV schema, run:
`wrangler d1 execute one-tv-db --remote --file=migration-source.sql`
Then deploy the updated Worker.

## App endpoint
After deployment, set `BACKEND_URL` in `MainActivity.java` to the Worker base URL, for example:
`https://one-tv-backend.YOUR-SUBDOMAIN.workers.dev`

Then rebuild the APK once. After that, channel additions/edits and source changes do not require another APK rebuild.
