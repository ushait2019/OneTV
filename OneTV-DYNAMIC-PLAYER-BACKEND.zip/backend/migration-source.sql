-- Run this only if your existing D1 database was created from the older One TV schema.
ALTER TABLE channels ADD COLUMN source_type TEXT NOT NULL DEFAULT 'link';
ALTER TABLE channels ADD COLUMN source_value TEXT NOT NULL DEFAULT '';
ALTER TABLE channels ADD COLUMN api_key TEXT NOT NULL DEFAULT '';

UPDATE channels
SET source_value = stream_url
WHERE source_value = '';
