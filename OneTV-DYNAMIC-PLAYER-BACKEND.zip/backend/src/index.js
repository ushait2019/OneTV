const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,PATCH,DELETE,OPTIONS",
    "access-control-allow-headers": "Content-Type, Authorization"
  }
});

const text = (data, status = 200) => new Response(data, {
  status,
  headers: { "content-type": "text/plain; charset=utf-8" }
});

function adminOk(request, env) {
  const auth = request.headers.get("Authorization") || "";
  return auth === `Bearer ${env.ADMIN_TOKEN}` && !!env.ADMIN_TOKEN;
}

function findStreamUrl(value) {
  if (!value) return "";
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (/^https?:\/\//i.test(trimmed)) return trimmed;
    try { value = JSON.parse(trimmed); } catch (_) { return ""; }
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = findStreamUrl(item);
      if (found) return found;
    }
    return "";
  }
  if (typeof value !== "object") return "";

  const directKeys = ["streamUrl", "stream_url", "stream", "url", "playUrl", "play_url", "sourceUrl", "source_url"];
  for (const key of directKeys) {
    const found = findStreamUrl(value[key]);
    if (found) return found;
  }
  for (const key of ["data", "result", "source", "channel", "response"]) {
    const found = findStreamUrl(value[key]);
    if (found) return found;
  }
  return "";
}

async function resolveSource(channel) {
  const type = String(channel.source_type || "link").toLowerCase();
  if (type !== "api") return channel.source_value || channel.stream_url || "";

  const apiUrl = channel.source_value || "";
  if (!apiUrl) return "";

  try {
    const headers = { "Accept": "application/json, text/plain;q=0.9, */*;q=0.8" };
    if (channel.api_key) {
      headers["Authorization"] = `Bearer ${channel.api_key}`;
      headers["X-API-Key"] = channel.api_key;
    }
    const response = await fetch(apiUrl, {
      method: "GET",
      headers,
      signal: AbortSignal.timeout(8000)
    });
    if (!response.ok) return "";
    const contentType = response.headers.get("content-type") || "";
    const body = await response.text();
    if (contentType.includes("application/json") || body.trim().startsWith("{") || body.trim().startsWith("[")) {
      return findStreamUrl(body);
    }
    return findStreamUrl(body);
  } catch (_) {
    return "";
  }
}

async function listChannels(env) {
  const { results } = await env.DB.prepare(`
    SELECT id, channel_number, name, country, category, logo_url, stream_url,
           source_type, source_value, api_key, active, sort_order
    FROM channels
    WHERE active = 1
    ORDER BY sort_order ASC, id ASC
  `).all();

  const resolved = await Promise.all(results.map(async c => ({
    id: c.id,
    number: c.channel_number,
    name: c.name,
    country: c.country,
    category: c.category,
    logoUrl: c.logo_url,
    streamUrl: await resolveSource(c),
    active: !!c.active,
    sortOrder: c.sort_order
  })));

  return resolved.filter(c => c.streamUrl);
}

async function adminList(env) {
  const { results } = await env.DB.prepare(`
    SELECT id, channel_number, name, country, category, logo_url, stream_url,
           source_type, source_value, api_key, active, sort_order
    FROM channels ORDER BY sort_order ASC, id ASC
  `).all();
  return results;
}

async function adminPage(env) {
  const rows = await adminList(env);
  const safe = JSON.stringify(rows).replace(/</g, "\\u003c");
  return new Response(`<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>One TV Admin</title>
<style>
body{font-family:Arial,sans-serif;max-width:1100px;margin:30px auto;padding:0 16px;background:#0b0f14;color:#fff}
input,select,button{padding:10px;margin:4px;border-radius:6px;border:1px solid #333;background:#151b22;color:#fff}
button{cursor:pointer}.card{border:1px solid #29313b;border-radius:10px;padding:14px;margin:12px 0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:8px}
small{color:#9aa4af}.on{color:#69db7c}.off{color:#ff8787}.danger{background:#7f1d1d}.source-fields{margin-top:8px}
</style></head><body>
<h1>One TV Admin</h1><p><small>Manage channels. Changes are immediately available to all app users after their next refresh.</small></p>
<div class="card"><h3>Admin token</h3><input id="token" type="password" placeholder="Paste ADMIN_TOKEN" style="width:70%"></div>
<div class="card"><h3>Add / Edit channel</h3><input id="id" type="hidden">
<div class="grid">
<input id="number" placeholder="Channel number"><input id="name" placeholder="Channel name"><input id="country" placeholder="Country" value="International">
<select id="category"><option value="TV">TV</option><option value="Sports">Sports</option><option value="News">News</option><option value="Kids">Kids</option></select>
<input id="logoUrl" placeholder="Logo URL"><input id="sortOrder" type="number" placeholder="Sort order" value="0">
<select id="sourceType" onchange="updateSourceFields()"><option value="link">Source: Link</option><option value="api">Source: API</option></select>
</div>
<div id="linkFields" class="source-fields"><input id="streamUrl" placeholder="Stream link (HLS / DASH / MP4)" style="width:100%;box-sizing:border-box"></div>
<div id="apiFields" class="source-fields" style="display:none"><input id="sourceValue" placeholder="API URL that returns the stream URL" style="width:100%;box-sizing:border-box"><input id="apiKey" type="password" placeholder="API key (optional)" style="width:100%;box-sizing:border-box"></div>
<label><input id="active" type="checkbox" checked> Active</label><br><button onclick="save()">Save channel</button><button onclick="clearForm()">Clear</button></div>
<div id="list"></div>
<script>
const initial=${safe}; let rows=initial;
const $=id=>document.getElementById(id);
function token(){return $('token').value}
function updateSourceFields(){const api=$('sourceType').value==='api';$('linkFields').style.display=api?'none':'block';$('apiFields').style.display=api?'block':'none'}
async function api(path,opts={}){opts.headers={...(opts.headers||{}),'Authorization':'Bearer '+token(),'Content-Type':'application/json'};const r=await fetch(path,opts);const d=await r.json();if(!r.ok)throw new Error(d.error||'Request failed');return d}
function render(){ $('list').innerHTML=rows.map(c=>'<div class="card"><b>'+esc(c.name)+'</b> <span class="'+(c.active?'on':'off')+'">'+(c.active?'ACTIVE':'DISABLED')+'</span><br><small>'+esc(c.country)+' • '+esc(c.category)+' • '+esc(c.source_type)+'</small><br><small>'+esc(c.source_type==='api'?c.source_value:c.stream_url)+'</small><br><button onclick="edit('+c.id+')">Edit</button><button class="danger" onclick="del('+c.id+')">Delete</button></div>').join('') }
function esc(s){return String(s??'').replace(/[&<>\"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]))}
function clearForm(){['id','number','name','country','logoUrl','streamUrl','sourceValue','apiKey'].forEach(x=>$(x).value='');$('country').value='International';$('category').value='TV';$('sortOrder').value='0';$('sourceType').value='link';$('active').checked=true;updateSourceFields()}
function edit(id){const c=rows.find(x=>x.id===id);$('id').value=c.id;$('number').value=c.channel_number;$('name').value=c.name;$('country').value=c.country;$('category').value=c.category;$('logoUrl').value=c.logo_url;$('sortOrder').value=c.sort_order;$('sourceType').value=c.source_type||'link';$('streamUrl').value=c.source_type==='api'?'':(c.source_value||c.stream_url||'');$('sourceValue').value=c.source_type==='api'?(c.source_value||''):'';$('apiKey').value=c.api_key||'';$('active').checked=!!c.active;updateSourceFields();scrollTo(0,0)}
async function refresh(){rows=await api('/admin/channels');render()}
async function save(){try{const type=$('sourceType').value;const body={channel_number:$('number').value,name:$('name').value,country:$('country').value,category:$('category').value,logo_url:$('logoUrl').value,stream_url:type==='link'?$('streamUrl').value:'',source_type:type,source_value:type==='api'?$('sourceValue').value:$('streamUrl').value,api_key:type==='api'?$('apiKey').value:'',sort_order:Number($('sortOrder').value||0),active:$('active').checked};if(!body.name)throw new Error('Channel name is required');if(type==='link'&&!body.stream_url)throw new Error('Stream link is required');if(type==='api'&&!body.source_value)throw new Error('API URL is required');const idv=$('id').value;await api(idv?'/admin/channels/'+idv:'/admin/channels',{method:idv?'PATCH':'POST',body:JSON.stringify(body)});clearForm();await refresh();alert('Saved')}catch(e){alert(e.message)}}
async function del(id){if(!confirm('Delete this channel?'))return;try{await api('/admin/channels/'+id,{method:'DELETE'});await refresh()}catch(e){alert(e.message)}}
updateSourceFields();render();
</script></body></html>`, {headers:{"content-type":"text/html; charset=utf-8"}});
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, {status: 204, headers: {"access-control-allow-origin":"*","access-control-allow-methods":"GET,POST,PATCH,DELETE,OPTIONS","access-control-allow-headers":"Content-Type, Authorization"}});
    const url = new URL(request.url);
    try {
      if (url.pathname === "/health" && request.method === "GET") return json({ok:true, app: env.APP_NAME || "One TV"});
      if (url.pathname === "/channels" && request.method === "GET") return json({version: Date.now(), channels: await listChannels(env)});
      if (url.pathname === "/admin" && request.method === "GET") return adminPage(env);
      if (!url.pathname.startsWith("/admin/")) return text("Not found", 404);
      if (!adminOk(request, env)) return json({error:"Unauthorized"}, 401);
      if (url.pathname === "/admin/channels" && request.method === "GET") return json(await adminList(env));
      if (url.pathname === "/admin/channels" && request.method === "POST") {
        const b = await request.json();
        const sourceType = String(b.source_type || "link").toLowerCase() === "api" ? "api" : "link";
        const sourceValue = String(b.source_value || (sourceType === "link" ? b.stream_url || "" : ""));
        if (!b.name) return json({error:"Channel name is required"},400);
        if (!sourceValue) return json({error: sourceType === "api" ? "API URL is required" : "Stream link is required"},400);
        await env.DB.prepare(`INSERT INTO channels(channel_number,name,country,category,logo_url,stream_url,source_type,source_value,api_key,active,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?,?)`)
          .bind(String(b.channel_number||""),String(b.name),String(b.country||"International"),String(b.category||"TV"),String(b.logo_url||""),String(b.stream_url||""),sourceType,sourceValue,String(b.api_key||""),b.active===false?0:1,Number(b.sort_order||0)).run();
        return json({ok:true},201);
      }
      const m = url.pathname.match(/^\/admin\/channels\/(\d+)$/);
      if (m) {
        const id = Number(m[1]);
        if (request.method === "DELETE") { await env.DB.prepare("DELETE FROM channels WHERE id=?").bind(id).run(); return json({ok:true}); }
        if (request.method === "PATCH") {
          const b = await request.json();
          const sourceType = String(b.source_type || "link").toLowerCase() === "api" ? "api" : "link";
          const sourceValue = String(b.source_value || (sourceType === "link" ? b.stream_url || "" : ""));
          if (!b.name) return json({error:"Channel name is required"},400);
          if (!sourceValue) return json({error: sourceType === "api" ? "API URL is required" : "Stream link is required"},400);
          await env.DB.prepare(`UPDATE channels SET channel_number=?,name=?,country=?,category=?,logo_url=?,stream_url=?,source_type=?,source_value=?,api_key=?,active=?,sort_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
            .bind(String(b.channel_number||""),String(b.name),String(b.country||"International"),String(b.category||"TV"),String(b.logo_url||""),String(b.stream_url||""),sourceType,sourceValue,String(b.api_key||""),b.active===false?0:1,Number(b.sort_order||0),id).run();
          return json({ok:true});
        }
      }
      return text("Not found",404);
    } catch (e) {
      return json({error: e?.message || "Server error"},500);
    }
  }
};
