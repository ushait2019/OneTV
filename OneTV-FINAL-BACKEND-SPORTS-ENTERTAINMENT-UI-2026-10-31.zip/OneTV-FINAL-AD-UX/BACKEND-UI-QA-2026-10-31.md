# One TV Backend + UI QA

## Backend
- SportScore is the primary sports provider for football, basketball, cricket and tennis.
- OpenCricket is the cricket fallback when SportScore fails.
- OpenCricket credentials are server-side Worker secrets only.
- Added generic sports routes: `/sports/{sport}/{live|upcoming|results}`.
- Added sports match detail routes.
- Existing channel, notice and viewer-session APIs remain intact.
- Worker source passes `node --check` syntax validation.

## Header / navigation
- One TV logo is centered.
- `All in One` is directly below the logo.
- Small side ad placeholders are constrained and do not participate in the brand center layout.
- Top-level navigation is `SPORTS` and `ENTERTAINMENT` dropdowns.
- Sports: Cricket, Football, Basketball, Tennis.
- Entertainment: TV, Movies, Drama, Songs.

## Layout / overlap rules
- Major content areas use parent containers and explicit padding instead of positional offsets.
- Dropdowns use bounded PopupWindow width and item heights.
- Player controls are inside the player frame.
- Fullscreen hides ad/footer/navigation/category UI.
- No Next/Previous video controls.

## Video controls
- Play/Pause.
- Volume slider.
- Quality menu.
- Fullscreen.
- Controls auto-hide after inactivity.
- YouTube playback uses the official embedded player and command API; direct streams use Media3.

## Build note
The repository does not contain a Gradle wrapper and this execution environment does not have a system Gradle installation, so a local Gradle release compile could not be executed here. The GitHub Actions workflow remains the authoritative Android build path.
