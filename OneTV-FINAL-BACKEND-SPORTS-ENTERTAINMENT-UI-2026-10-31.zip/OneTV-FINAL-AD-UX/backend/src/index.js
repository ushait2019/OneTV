const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,PATCH,DELETE,OPTIONS",
    "access-control-allow-headers": "Content-Type, Authorization"
  }
});

const text = (data, status = 200) => new Response(data, {
  status,
  headers: { "content-type": "text/plain; charset=utf-8" }
});

function adminOk(request, env) {
  const auth = request.headers.get("Authorization") || "";
  return auth === `Bearer ${env.ADMIN_TOKEN}` && !!env.ADMIN_TOKEN;
}

function findStreamUrl(value) {
  if (!value) return "";
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (/^https?:\/\//i.test(trimmed)) return trimmed;
    try { value = JSON.parse(trimmed); } catch (_) { return ""; }
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = findStreamUrl(item);
      if (found) return found;
    }
    return "";
  }
  if (typeof value !== "object") return "";
  const directKeys = ["streamUrl", "stream_url", "stream", "url", "playUrl", "play_url", "sourceUrl", "source_url"];
  for (const key of directKeys) {
    const found = findStreamUrl(value[key]);
    if (found) return found;
  }
  for (const key of ["data", "result", "source", "channel", "response"]) {
    const found = findStreamUrl(value[key]);
    if (found) return found;
  }
  return "";
}

function extractYouTubeVideoId(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  if (/^[A-Za-z0-9_-]{11}$/.test(raw)) return raw;
  try {
    const u = new URL(raw);
    const host = u.hostname.toLowerCase().replace(/^www\./, '');
    if (host === 'youtu.be') return (u.pathname.split('/').filter(Boolean)[0] || '').slice(0, 11);
    if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'music.youtube.com') {
      const v = u.searchParams.get('v');
      if (v) return v.slice(0, 11);
      const parts = u.pathname.split('/').filter(Boolean);
      if (parts[0] === 'shorts' || parts[0] === 'embed' || parts[0] === 'live') return (parts[1] || '').slice(0, 11);
    }
  } catch (_) {}
  const m = raw.match(/(?:v=|youtu\.be\/|\/shorts\/|\/embed\/|\/live\/)([A-Za-z0-9_-]{11})/i);
  return m ? m[1] : '';
}

async function resolveYouTube(videoId, env) {
  if (!videoId || !env.YOUTUBE_API_KEY) return null;
  try {
    const api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet&id=' + encodeURIComponent(videoId) + '&key=' + encodeURIComponent(env.YOUTUBE_API_KEY);
    const r = await fetch(api, { signal: AbortSignal.timeout(8000) });
    if (!r.ok) return null;
    const data = await r.json();
    const item = data.items && data.items[0];
    if (!item) return null;
    const sn = item.snippet || {};
    const thumbs = sn.thumbnails || {};
    const thumb = (thumbs.maxres || thumbs.standard || thumbs.high || thumbs.medium || thumbs.default || {}).url || '';
    return { videoId, title: String(sn.title || ''), description: String(sn.description || ''), channelTitle: String(sn.channelTitle || ''), thumbnailUrl: thumb };
  } catch (_) { return null; }
}

async function resolveSource(channel, env) {
  const type = String(channel.source_type || "link").toLowerCase();
  const fallbackProgram = String(channel.program_name || "");
  if (type === "youtube") {
    const videoId = extractYouTubeVideoId(channel.source_value || channel.stream_url || '');
    const meta = await resolveYouTube(videoId, env);
    return { youtubeVideoId: videoId, youtubeTitle: meta?.title || fallbackProgram, youtubeThumbnail: meta?.thumbnailUrl || '', programName: meta?.title || fallbackProgram, url: '' };
  }
  if (type !== "api") return { url: channel.source_value || channel.stream_url || "", programName: fallbackProgram };
  const apiUrl = channel.source_value || "";
  if (!apiUrl) return { url: "", programName: fallbackProgram };
  try {
    const headers = { "Accept": "application/json, text/plain;q=0.9, */*;q=0.8" };
    if (channel.api_key) { headers["Authorization"] = `Bearer ${channel.api_key}`; headers["X-API-Key"] = channel.api_key; }
    const response = await fetch(apiUrl, { method: "GET", headers, signal: AbortSignal.timeout(8000) });
    if (!response.ok) return { url: "", programName: fallbackProgram };
    const raw = await response.text();
    let parsed = null;
    try { parsed = JSON.parse(raw); } catch (_) {}
    const program = findProgramName(parsed) || fallbackProgram;
    const url = findStreamUrl(parsed ?? raw);
    return { url, programName: program };
  } catch (_) { return { url: "", programName: fallbackProgram }; }
}

function findProgramName(value) {
  if (!value) return "";
  if (typeof value === "string") return "";
  if (Array.isArray(value)) {
    for (const item of value) { const found = findProgramName(item); if (found) return found; }
    return "";
  }
  if (typeof value !== "object") return "";
  for (const key of ["programName","program_name","nowPlaying","now_playing","program","showName","show_name","title"]) {
    if (typeof value[key] === "string" && value[key].trim()) return value[key].trim();
  }
  for (const key of ["data","result","source","channel","response"]) { const found = findProgramName(value[key]); if (found) return found; }
  return "";
}

async function cleanupViewers(env) {
  await env.DB.prepare("DELETE FROM viewer_sessions WHERE last_seen < datetime('now','-90 seconds')").run();
}

async function viewerCount(env, channelId) {
  const r = await env.DB.prepare("SELECT COUNT(*) AS count FROM viewer_sessions WHERE channel_id=? AND last_seen >= datetime('now','-90 seconds')").bind(channelId).first();
  return Number(r?.count || 0);
}

async function listChannels(env) {
  await cleanupViewers(env);
  const { results } = await env.DB.prepare(`
    SELECT id, channel_number, name, country, category, logo_url, stream_url,
           source_type, source_value, api_key, program_name, program_api_url,
           show_viewers, loop_playback, active, sort_order
    FROM channels WHERE active = 1 ORDER BY sort_order ASC, id ASC
  `).all();
  const resolved = await Promise.all(results.map(async c => {
    const src = await resolveSource(c, env);
    let programName = src.programName || c.program_name || "";
    if (c.program_api_url) {
      try {
        const r = await fetch(c.program_api_url, {headers:{"Accept":"application/json,text/plain;q=0.9,*/*;q=0.8"}, signal: AbortSignal.timeout(6000)});
        if (r.ok) programName = findProgramName(JSON.parse(await r.text())) || programName;
      } catch (_) {}
    }
    const viewers = c.show_viewers ? await viewerCount(env, c.id) : 0;
    return { id:c.id, number:c.channel_number, name:c.name, country:c.country, category:c.category, logoUrl:c.logo_url, streamUrl:src.url || '', sourceType:String(c.source_type || 'link').toLowerCase(), youtubeVideoId:src.youtubeVideoId || '', youtubeTitle:src.youtubeTitle || '', youtubeThumbnail:src.youtubeThumbnail || '', programName, viewerCount:viewers, showViewerCount:!!c.show_viewers, loop:!!c.loop_playback, active:!!c.active, sortOrder:c.sort_order };
  }));
  return resolved.filter(c => c.streamUrl || c.youtubeVideoId);
}

async function adminListChannels(env) {
  const { results } = await env.DB.prepare(`
    SELECT id, channel_number, name, country, category, logo_url, stream_url,
           source_type, source_value, api_key, program_name, program_api_url, show_viewers, loop_playback, active, sort_order
    FROM channels ORDER BY sort_order ASC, id ASC
  `).all();
  return results;
}

async function getActiveNotice(env) {
  const { results } = await env.DB.prepare(`
    SELECT id, type, title, html_content, media_url, link_url, active, sort_order
    FROM notices WHERE active = 1 ORDER BY sort_order ASC, id ASC LIMIT 1
  `).all();
  const n = results[0];
  if (!n) return null;
  return {
    id: n.id, type: n.type, title: n.title,
    html: n.html_content, mediaUrl: n.media_url, linkUrl: n.link_url,
    active: !!n.active, sortOrder: n.sort_order
  };
}

async function adminListNotices(env) {
  const { results } = await env.DB.prepare(`
    SELECT id, type, title, html_content, media_url, link_url, active, sort_order
    FROM notices ORDER BY sort_order ASC, id ASC
  `).all();
  return results;
}

function cleanHtml(html) {
  let s = String(html || "");
  s = s.replace(/<script[\\s\\S]*?<\/script>/gi, "");
  s = s.replace(/<iframe[\\s\\S]*?<\/iframe>/gi, "");
  s = s.replace(/\\son[a-z]+\\s*=\\s*(?:\"[^\"]*\"|'[^']*')/gi, "");
  s = s.replace(/javascript:/gi, "");
  return s;
}

function escAttr(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;");
}


const SPORTS = ["football", "basketball", "cricket", "tennis"];

function sportScoreUrl(path, params = {}) {
  const u = new URL("https://sportscore.com" + path);
  Object.entries(params).forEach(([k, v]) => { if (v !== undefined && v !== null && String(v) !== "") u.searchParams.set(k, String(v)); });
  u.searchParams.set("src", "onetv");
  return u.toString();
}

async function fetchJson(url, headers = {}, timeout = 10000) {
  const response = await fetch(url, { headers: { "Accept": "application/json", ...headers }, signal: AbortSignal.timeout(timeout) });
  const body = await response.text();
  if (!response.ok) throw new Error(`Upstream ${response.status}: ${body.slice(0, 200)}`);
  try { return JSON.parse(body); } catch (_) { throw new Error("Upstream returned invalid JSON"); }
}

function sportScoreMatches(raw, sport) {
  const list = Array.isArray(raw?.matches) ? raw.matches : Array.isArray(raw?.data?.matches) ? raw.data.matches : [];
  return list.map((m, i) => ({
    id: String(m.slug || m.id || `${sport}-${i}`),
    sport,
    name: `${m.home || "Home"} vs ${m.away || "Away"}`,
    status: String(m.status || ""),
    statusText: String(m.status_text || m.status || ""),
    time: String(m.time || ""),
    home: { name: String(m.home || "Home"), logo: String(m.home_logo || ""), score: m.home_score ?? "" },
    away: { name: String(m.away || "Away"), logo: String(m.away_logo || ""), score: m.away_score ?? "" },
    competition: String(m.competition || m.league || ""),
    venue: String(m.venue || ""),
    result: String(m.result || "")
  }));
}

async function sportScoreList(sport, status, env) {
  if (!SPORTS.includes(sport)) throw new Error("Unsupported sport");
  const raw = await fetchJson(sportScoreUrl("/api/v1/fixtures/", { sport, date: new Date().toISOString().slice(0, 10), status, limit: 100 }), {}, 10000);
  return sportScoreMatches(raw, sport);
}

function cricketBase(env) {
  return String(env.CRICKET_API_BASE_URL || "https://opencricketapi.com").replace(/\/$/, "");
}

async function openCricketFetch(path, env) {
  const key = String(env.CRICKET_API_KEY || env.OPENCRICKET_API_KEY || "").trim();
  if (!key) throw new Error("OpenCricket key not configured");
  const endpoint = cricketBase(env) + path;
  const response = await fetch(endpoint, {
    headers: { "Authorization": `Bearer ${key}`, "Accept": "application/json" },
    signal: AbortSignal.timeout(10000)
  });
  const body = await response.text();
  if (!response.ok) throw new Error(`OpenCricket ${response.status}: ${body.slice(0, 200)}`);
  try { return JSON.parse(body); } catch (_) { throw new Error("OpenCricket returned invalid JSON"); }
}

function cricketItems(raw) {
  const data = raw?.data ?? raw;
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.results)) return data.results;
  if (Array.isArray(data?.matches)) return data.matches;
  if (Array.isArray(data?.cards)) return data.cards;
  if (Array.isArray(raw?.results)) return raw.results;
  return [];
}

function cricketTeam(raw) {
  if (typeof raw === "string") return { name: raw, score: "" };
  const name = raw?.name || raw?.team || raw?.short_name || raw?.shortName || "Team";
  let score = raw?.score || raw?.score_text || raw?.scoreText || "";
  if (!score && (raw?.runs !== undefined || raw?.wickets !== undefined)) {
    score = `${raw?.runs ?? 0}/${raw?.wickets ?? 0}`;
    if (raw?.overs !== undefined && raw?.overs !== null && String(raw.overs) !== "") score += ` (${raw.overs} ov)`;
  }
  return { name: String(name), score: String(score || "") };
}

function normalizeCricketMatch(raw) {
  const teamsRaw = Array.isArray(raw?.teams) ? raw.teams : [];
  const teams = teamsRaw.map(cricketTeam);
  if (!teams.length && Array.isArray(raw?.team_info)) raw.team_info.forEach(x => teams.push(cricketTeam(x)));
  if (!teams.length && raw?.team1) teams.push(cricketTeam(raw.team1));
  if (!teams.length && raw?.team2) teams.push(cricketTeam(raw.team2));
  if (!teams.length && raw?.teams && typeof raw.teams === "string") String(raw.teams).split(/\s+v(?:s)?\.?\s+/i).forEach(x => teams.push(cricketTeam(x)));
  const id = raw?.match || raw?.id || raw?.key || raw?.match_id || raw?.matchKey || raw?.slug || "";
  const name = raw?.name || raw?.short_name || raw?.title || (teams.length ? teams.map(x => x.name).join(" vs ") : "Cricket Match");
  return { id: String(id), name: String(name), status: String(raw?.status || raw?.state || raw?.match_status || raw?.status_text || ""), state: String(raw?.state || ""), competition: String(raw?.competition || raw?.series || raw?.tournament || raw?.league || ""), venue: String(raw?.venue || raw?.ground || raw?.stadium || ""), result: String(raw?.result || raw?.winner || raw?.result_text || ""), startsAt: String(raw?.starts_at || raw?.start_time || raw?.startTime || raw?.date || raw?.start_date || ""), score: String(raw?.score || ""), teams };
}

function normalizeOpenCricketList(raw) { return cricketItems(raw).map(normalizeCricketMatch).filter(x => x.id || x.name); }

async function cricketList(kind, env) {
  const status = kind === "live" ? "live" : kind === "upcoming" ? "upcoming" : "finished";
  try {
    const primary = await sportScoreList("cricket", status, env);
    return primary.map(m => ({ id:m.id, name:m.name, status:m.statusText || m.status, state:m.status, competition:m.competition, venue:m.venue, result:m.result, startsAt:m.time, score:"", teams:[m.home,m.away].map(t => ({name:t.name, score:String(t.score ?? "")})) }));
  } catch (primaryError) {
    const paths = kind === "live" ? ["/v1/live"] : [kind === "upcoming" ? "/v1/matches?state=upcoming&limit=50" : "/v1/matches?state=finished&limit=50"];
    try { return normalizeOpenCricketList(await openCricketFetch(paths[0], env)); }
    catch (fallbackError) { throw new Error(`SportScore failed; OpenCricket fallback failed: ${fallbackError.message || primaryError.message}`); }
  }
}

async function cricketMatch(id, env) {
  try {
    const raw = await fetchJson(sportScoreUrl("/api/widget/match/", { sport: "cricket", slug: id }), {}, 10000);
    return raw?.match || raw?.data?.match || raw;
  } catch (_) {
    const raw = await openCricketFetch("/v1/matches/" + encodeURIComponent(id), env);
    const data = raw?.data?.match || raw?.data?.card || raw?.match || raw?.card || raw?.data || raw;
    return normalizeCricketDetail(data);
  }
}

function normalizeCricketDetail(raw) {
  const match = normalizeCricketMatch(raw);
  const inningsRaw = Array.isArray(raw?.innings) ? raw.innings : (Array.isArray(raw?.data?.innings) ? raw.data.innings : []);
  const innings = inningsRaw.map((x, i) => ({ team:String(x?.team || x?.name || x?.batting_team || `Innings ${i+1}`), score:x?.score ? String(x.score) : `${x?.runs ?? ""}${x?.wickets !== undefined ? "/" + x.wickets : ""}${x?.overs !== undefined ? " (" + x.overs + " ov)" : ""}` }));
  return { ...match, innings };
}

async function sportsList(sport, status, env) {
  if (!SPORTS.includes(sport)) throw new Error("Unsupported sport");
  if (sport === "cricket") return cricketList(status === "finished" ? "results" : status, env);
  return sportScoreList(sport, status, env);
}

async function adminPage(env) {
  const channels = [];
  const notices = [];
  const channelJson = JSON.stringify(channels).replace(/</g, "\\u003c");
  const noticeJson = JSON.stringify(notices).replace(/</g, "\\u003c");

  return new Response(`<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>One TV Admin</title>
<style>
body{font-family:Arial,sans-serif;max-width:1180px;margin:24px auto;padding:0 16px;background:#0b0f14;color:#fff}
input,select,button,textarea{padding:10px;margin:4px;border-radius:6px;border:1px solid #333;background:#151b22;color:#fff;box-sizing:border-box}
button{cursor:pointer}.card{border:1px solid #29313b;border-radius:10px;padding:14px;margin:12px 0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:8px}
small{color:#9aa4af}.on{color:#69db7c}.off{color:#ff8787}.danger{background:#7f1d1d}.source-fields{margin-top:8px}.tabs{display:flex;gap:8px;position:sticky;top:0;background:#0b0f14;padding:10px 0;z-index:5}.tabs button.active{background:#2563eb}
.editor{min-height:160px;border:1px solid #333;border-radius:8px;background:#fff;color:#111;padding:12px;margin:4px;overflow:auto}.toolbar{display:flex;flex-wrap:wrap;align-items:center;gap:2px;background:#151b22;padding:6px;border-radius:8px;margin:4px}.toolbar button{padding:7px 9px;margin:0}.toolbar input{width:42px;padding:6px;margin:0}.html-source{min-height:160px;width:100%;font-family:monospace}.hidden{display:none!important}.preview{border:1px solid #29313b;background:#0b0f14;padding:10px;margin-top:8px}.notice-item{display:flex;justify-content:space-between;gap:10px;align-items:center}.badge{display:inline-block;padding:3px 7px;border-radius:20px;background:#263241;font-size:12px}
</style></head><body>
<h1>One TV Admin</h1>
<p><small>Manage channels and optional notices/personal ads. Changes become available to app users after the next refresh.</small></p>
<div class="card"><b>Admin token</b><br><input id="token" type="password" placeholder="Paste ADMIN_TOKEN" style="width:100%;max-width:600px"><button onclick="connectAdmin()">Connect</button> <span id="connStatus"><small>Not connected</small></span></div>
<div class="tabs"><button id="tabChannels" class="active" onclick="showTab('channels')">Channels</button><button id="tabNotices" onclick="showTab('notices')">Notices / Personal Ads</button></div>

<section id="channelsTab">
<div class="card"><h3>Add / Edit channel</h3><input id="cid" type="hidden">
<div class="grid">
<input id="number" placeholder="Channel number"><input id="name" placeholder="Channel name"><input id="country" placeholder="Country" value="International">
<select id="category"><option value="TV">TV</option><option value="Movies">Movies</option><option value="Sports">Sports</option><option value="News">News</option><option value="Kids">Kids</option></select>
<input id="logoUrl" placeholder="Logo URL"><input id="programName" placeholder="Program / movie title (optional)"><input id="programApiUrl" placeholder="Program API URL (optional)"><input id="sortOrder" type="number" placeholder="Sort order" value="0">
<select id="sourceType" onchange="updateSourceFields()"><option value="link">Source: Direct Link</option><option value="api">Source: API</option><option value="youtube">Source: YouTube</option></select>
</div>
<div id="linkFields" class="source-fields"><input id="streamUrl" placeholder="Stream link (HLS / DASH / MP4)" style="width:100%"></div>
<div id="youtubeFields" class="source-fields hidden"><input id="youtubeUrl" placeholder="YouTube watch / shorts / live URL or Video ID" style="width:100%"><small>YouTube Data API resolves title/thumbnail on the server. Playback uses the official embedded YouTube player.</small></div>
<div id="apiFields" class="source-fields hidden"><input id="sourceValue" placeholder="API URL that returns the stream URL" style="width:100%"><input id="apiKey" type="password" placeholder="API key (optional)" style="width:100%"></div>
<label><input id="showViewers" type="checkbox"> Show viewer count</label> <label><input id="loopPlayback" type="checkbox"> Loop playback (Movies)</label><br><label><input id="active" type="checkbox" checked> Active</label><br><button onclick="saveChannel()">Save channel</button><button onclick="clearChannelForm()">Clear</button></div>
<div id="channelList"></div>
</section>

<section id="noticesTab" class="hidden">
<div class="card"><h3>Publish notice / personal ad</h3><input id="nid" type="hidden">
<div class="grid"><input id="noticeTitle" placeholder="Internal title / label"><select id="noticeType" onchange="updateNoticeFields()"><option value="text">Text</option><option value="banner">Banner image</option><option value="video">Video</option></select><input id="noticeSort" type="number" value="0" placeholder="Sort order"></div>
<div id="textNoticeFields">
<div class="toolbar">
<select onchange="cmd('fontName',this.value)"><option value="Arial">Arial</option><option value="Verdana">Verdana</option><option value="Georgia">Georgia</option><option value="Times New Roman">Times New Roman</option><option value="Courier New">Courier New</option><option value="Trebuchet MS">Trebuchet MS</option><option value="Impact">Impact</option></select>
<select onchange="cmd('fontSize',this.value)"><option value="2">Small</option><option value="3" selected>Normal</option><option value="4">Large</option><option value="5">XL</option><option value="6">XXL</option></select>
<button type="button" onclick="cmd('bold')"><b>B</b></button><button type="button" onclick="cmd('italic')"><i>I</i></button><button type="button" onclick="cmd('underline')"><u>U</u></button><button type="button" onclick="cmd('strikeThrough')"><s>S</s></button>
<button type="button" onclick="cmd('justifyLeft')">Left</button><button type="button" onclick="cmd('justifyCenter')">Center</button><button type="button" onclick="cmd('justifyRight')">Right</button>
<button type="button" onclick="cmd('insertUnorderedList')">• List</button><button type="button" onclick="cmd('insertOrderedList')">1. List</button>
<label>Text <input type="color" value="#ffffff" onchange="cmd('foreColor',this.value)"></label><label>BG <input type="color" value="#111827" onchange="cmd('hiliteColor',this.value)"></label>
<button type="button" onclick="addLink()">Link</button><button type="button" onclick="toggleSource()">HTML</button>
</div>
<div id="noticeEditor" class="editor" contenteditable="true"><div style="font-family:Arial;font-size:18px;text-align:center">Write your notice here...</div></div>
<textarea id="noticeHtml" class="html-source hidden" placeholder="Advanced HTML/CSS"></textarea>
</div>
<div id="mediaNoticeFields" class="hidden"><input id="mediaUrl" placeholder="Image / video URL" style="width:100%"><input id="linkUrl" placeholder="Optional click URL" style="width:100%"><small>Banner: use a direct image URL. Video: use a direct MP4/WebM URL.</small></div>
<label><input id="noticeActive" type="checkbox" checked> Publish now</label><br><button onclick="saveNotice()">Publish / Save notice</button><button onclick="clearNoticeForm()">Clear</button></div>
<div class="card"><h3>Notice preview</h3><div id="noticePreview" class="preview">Nothing published.</div></div>
<div id="noticeList"></div>
</section>

<script>
const initialChannels=${channelJson}; const initialNotices=${noticeJson}; let channels=initialChannels, notices=initialNotices;
const $=id=>document.getElementById(id); function token(){return $('token').value}
async function api(path,opts={}){opts.headers={...(opts.headers||{}),'Authorization':'Bearer '+token(),'Content-Type':'application/json'};const r=await fetch(path,opts);let d={};try{d=await r.json()}catch(_){d={error:'Invalid server response'}}if(!r.ok)throw new Error(d.error||'Request failed');return d}
async function connectAdmin(){try{channels=await api('/admin/channels');notices=await api('/admin/notices');renderChannels();renderNotices();$('connStatus').innerHTML='<span class=on>Connected</span>'}catch(e){$('connStatus').innerHTML='<span class=off>'+esc(e.message)+'</span>'}}
function showTab(tab){$('channelsTab').classList.toggle('hidden',tab!=='channels');$('noticesTab').classList.toggle('hidden',tab!=='notices');$('tabChannels').classList.toggle('active',tab==='channels');$('tabNotices').classList.toggle('active',tab==='notices')}
function updateSourceFields(){const t=$('sourceType').value; const a=t==='api'; const y=t==='youtube'; $('linkFields').classList.toggle('hidden',a||y); $('apiFields').classList.toggle('hidden',!a); $('youtubeFields').classList.toggle('hidden',!y)}
function renderChannels(){ $('channelList').innerHTML=channels.map(c=>'<div class="card"><b>'+esc(c.name)+'</b> <span class="'+(c.active?'on':'off')+'">'+(c.active?'ACTIVE':'DISABLED')+'</span><br><small>'+esc(c.country)+' • '+esc(c.category)+' • '+esc(c.source_type)+'</small><br><small>'+esc(c.source_type==='api'?c.source_value:c.stream_url)+'</small><br><button onclick="editChannel('+c.id+')">Edit</button><button class="danger" onclick="deleteChannel('+c.id+')">Delete</button></div>').join('') }
function renderNotices(){ $('noticeList').innerHTML=notices.map(n=>'<div class="card notice-item"><div><b>'+esc(n.title||'(Untitled)')+'</b> <span class="badge">'+esc(n.type)+'</span> <span class="'+(n.active?'on':'off')+'">'+(n.active?'PUBLISHED':'HIDDEN')+'</span><br><small>'+esc(n.type==='text'?'Rich text notice':n.media_url)+'</small></div><div><button onclick="editNotice('+n.id+')">Edit</button><button class="danger" onclick="deleteNotice('+n.id+')">Delete</button></div></div>').join('')||'<div class="card"><small>No notices yet.</small></div>' }
function esc(s){return String(s??'').replace(/[&<>\"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]))}
function clearChannelForm(){['cid','number','name','country','logoUrl','programName','programApiUrl','streamUrl','sourceValue','apiKey','youtubeUrl'].forEach(x=>$(x).value='');$('country').value='International';$('category').value='TV';$('sortOrder').value='0';$('showViewers').checked=false;$('loopPlayback').checked=false;$('sourceType').value='link';$('youtubeUrl').value='';$('active').checked=true;updateSourceFields()}
function editChannel(id){const c=channels.find(x=>x.id===id);$('cid').value=c.id;$('number').value=c.channel_number;$('name').value=c.name;$('country').value=c.country;$('category').value=c.category;$('logoUrl').value=c.logo_url;$('programName').value=c.program_name||'';$('programApiUrl').value=c.program_api_url||'';$('sortOrder').value=c.sort_order;$('showViewers').checked=!!c.show_viewers;$('loopPlayback').checked=!!c.loop_playback;$('sourceType').value=c.source_type||'link';$('streamUrl').value=c.source_type==='api'||c.source_type==='youtube'?'':(c.source_value||c.stream_url||'');$('sourceValue').value=c.source_type==='api'?(c.source_value||''):'';$('youtubeUrl').value=c.source_type==='youtube'?(c.source_value||''):'';$('apiKey').value=c.api_key||'';$('active').checked=!!c.active;updateSourceFields();showTab('channels');scrollTo(0,0)}
async function saveChannel(){try{const type=$('sourceType').value;const sourceValue=type==='api'?$('sourceValue').value:(type==='youtube'?$('youtubeUrl').value:$('streamUrl').value); const body={channel_number:$('number').value,name:$('name').value,country:$('country').value,category:$('category').value,logo_url:$('logoUrl').value,stream_url:type==='link'?$('streamUrl').value:'',source_type:type,source_value:sourceValue,api_key:type==='api'?$('apiKey').value:'',program_name:$('programName').value,program_api_url:$('programApiUrl').value,show_viewers:$('showViewers').checked,loop_playback:$('loopPlayback').checked,sort_order:Number($('sortOrder').value||0),active:$('active').checked};if(!body.name)throw new Error('Channel name is required');if(type==='link'&&!body.stream_url)throw new Error('Stream link is required');if(type==='api'&&!body.source_value)throw new Error('API URL is required');if(type==='youtube'&&!body.source_value)throw new Error('YouTube URL is required');const id=$('cid').value;await api(id?'/admin/channels/'+id:'/admin/channels',{method:id?'PATCH':'POST',body:JSON.stringify(body)});clearChannelForm();channels=await api('/admin/channels');renderChannels();alert('Saved')}catch(e){alert(e.message)}}
async function deleteChannel(id){if(!confirm('Delete this channel?'))return;try{await api('/admin/channels/'+id,{method:'DELETE'});channels=await api('/admin/channels');renderChannels()}catch(e){alert(e.message)}}
function cmd(name,value){document.execCommand(name,false,value||null);$('noticeEditor').focus();updatePreview()}
function addLink(){const u=prompt('Enter https:// link');if(u)cmd('createLink',u)}
function toggleSource(){const source=$('noticeHtml'), editor=$('noticeEditor');if(source.classList.contains('hidden')){source.value=editor.innerHTML;source.classList.remove('hidden');editor.classList.add('hidden')}else{editor.innerHTML=source.value;source.classList.add('hidden');editor.classList.remove('hidden')}updatePreview()}
function getNoticeHtml(){return $('noticeHtml').classList.contains('hidden')?$('noticeEditor').innerHTML:$('noticeHtml').value}
function updateNoticeFields(){const type=$('noticeType').value;const text=type==='text';$('textNoticeFields').classList.toggle('hidden',!text);$('mediaNoticeFields').classList.toggle('hidden',text);updatePreview()}
function updatePreview(){const type=$('noticeType').value;let html='';if(type==='text')html=getNoticeHtml();else if(type==='banner')html='<img src="'+esc($('mediaUrl').value)+'" style="max-width:100%;display:block;margin:auto">';else html='<video src="'+esc($('mediaUrl').value)+'" controls muted style="max-width:100%;width:100%"></video>';$('noticePreview').innerHTML=html||'Nothing to preview.'}
function clearNoticeForm(){$('nid').value='';$('noticeTitle').value='';$('noticeType').value='text';$('noticeSort').value='0';$('noticeEditor').innerHTML='<div style="font-family:Arial;font-size:18px;text-align:center">Write your notice here...</div>';$('noticeHtml').value='';$('noticeHtml').classList.add('hidden');$('noticeEditor').classList.remove('hidden');$('mediaUrl').value='';$('linkUrl').value='';$('noticeActive').checked=true;updateNoticeFields();updatePreview()}
function editNotice(id){const n=notices.find(x=>x.id===id);$('nid').value=n.id;$('noticeTitle').value=n.title||'';$('noticeType').value=n.type||'text';$('noticeSort').value=n.sort_order||0;$('noticeEditor').innerHTML=n.html_content||'';$('noticeHtml').value=n.html_content||'';$('noticeHtml').classList.add('hidden');$('noticeEditor').classList.remove('hidden');$('mediaUrl').value=n.media_url||'';$('linkUrl').value=n.link_url||'';$('noticeActive').checked=!!n.active;updateNoticeFields();updatePreview();showTab('notices');scrollTo(0,0)}
async function saveNotice(){try{const type=$('noticeType').value;const body={title:$('noticeTitle').value,type,html_content:type==='text'?getNoticeHtml():'',media_url:type==='text'?'':$('mediaUrl').value,link_url:type==='text'?'':$('linkUrl').value,sort_order:Number($('noticeSort').value||0),active:$('noticeActive').checked};if(type==='text'&&!body.html_content.trim())throw new Error('Notice text is required');if(type!=='text'&&!body.media_url.trim())throw new Error('Media URL is required');const id=$('nid').value;await api(id?'/admin/notices/'+id:'/admin/notices',{method:id?'PATCH':'POST',body:JSON.stringify(body)});clearNoticeForm();notices=await api('/admin/notices');renderNotices();alert('Notice saved')}catch(e){alert(e.message)}}
async function deleteNotice(id){if(!confirm('Delete this notice?'))return;try{await api('/admin/notices/'+id,{method:'DELETE'});notices=await api('/admin/notices');renderNotices()}catch(e){alert(e.message)}}
$('noticeEditor').addEventListener('input',updatePreview);$('mediaUrl').addEventListener('input',updatePreview);updateSourceFields();updateNoticeFields();renderChannels();renderNotices();if(token())connectAdmin();
</script></body></html>`, {headers:{"content-type":"text/html; charset=utf-8"}});
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, {status: 204, headers: {"access-control-allow-origin":"*","access-control-allow-methods":"GET,POST,PATCH,DELETE,OPTIONS","access-control-allow-headers":"Content-Type, Authorization"}});
    const url = new URL(request.url);
    try {
      if (url.pathname === "/health" && request.method === "GET") {
        let dbOk = false;
        try { await env.DB.prepare("SELECT 1 AS ok").first(); dbOk = true; } catch (_) {}
        return json({ok: dbOk, app: env.APP_NAME || "One TV", database: dbOk ? "connected" : "unavailable"});
      }
      if (url.pathname === "/channels" && request.method === "GET") return json({version: Date.now(), channels: await listChannels(env)});
      if ((url.pathname === "/notice" || url.pathname === "/notices") && request.method === "GET") {
        const notice = await getActiveNotice(env);
        return json(notice ? {enabled:true, ...notice} : {enabled:false});
      }
      if (url.pathname === "/cricket/live" && request.method === "GET") return json({updatedAt: new Date().toISOString(), provider:"SportScore", matches: await cricketList("live", env)});
      if (url.pathname === "/cricket/upcoming" && request.method === "GET") return json({updatedAt: new Date().toISOString(), provider:"SportScore", matches: await cricketList("upcoming", env)});
      if (url.pathname === "/cricket/results" && request.method === "GET") return json({updatedAt: new Date().toISOString(), provider:"SportScore", matches: await cricketList("results", env)});
      const cricketMatchPath = url.pathname.match(/^\/cricket\/match\/(.+)$/);
      if (cricketMatchPath && request.method === "GET") return json({match: await cricketMatch(cricketMatchPath[1], env)});
      if (url.pathname === "/cricket/health" && request.method === "GET") {
        try { const sample = await cricketList("live", env); return json({ok:true, primary:"SportScore", fallback:"OpenCricket", liveMatches: sample.length}); }
        catch (e) { return json({ok:false, primary:"SportScore", fallback:"OpenCricket", error:String(e.message || e)}, 502); }
      }
      const sportPath = url.pathname.match(/^\/sports\/(football|basketball|cricket|tennis)\/(live|upcoming|results)$/);
      if (sportPath && request.method === "GET") {
        const sport = sportPath[1], mode = sportPath[2];
        const status = mode === "results" ? "finished" : mode;
        return json({updatedAt:new Date().toISOString(), sport, mode, provider:"SportScore", matches:await sportsList(sport,status,env)});
      }
      const sportMatchPath = url.pathname.match(/^\/sports\/(football|basketball|cricket)\/match\/(.+)$/);
      if (sportMatchPath && request.method === "GET") {
        const sport=sportMatchPath[1], id=decodeURIComponent(sportMatchPath[2]);
        if (sport === "cricket") return json({sport, match:await cricketMatch(id,env)});
        const raw=await fetchJson(sportScoreUrl("/api/widget/match/",{sport,slug:id}),{},10000);
        return json({sport,match:raw?.match || raw?.data?.match || raw});
      }
      if (url.pathname === "/viewer/ping" && request.method === "POST") {
        const b = await request.json();
        const viewerId = String(b.viewerId || "").trim();
        const channelId = Number(b.channelId || 0);
        if (!viewerId || !channelId) return json({error:"viewerId and channelId are required"},400);
        const existing = await env.DB.prepare("SELECT channel_id FROM viewer_sessions WHERE viewer_id=?").bind(viewerId).first();
        if (!existing || Number(existing.channel_id) !== channelId) {
          await env.DB.prepare("INSERT INTO channel_views(channel_id,viewer_id,started_at) VALUES(?,?,CURRENT_TIMESTAMP)").bind(channelId,viewerId).run();
        }
        await env.DB.prepare("INSERT INTO viewer_sessions(viewer_id,channel_id,last_seen) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(viewer_id) DO UPDATE SET channel_id=excluded.channel_id,last_seen=CURRENT_TIMESTAMP").bind(viewerId,channelId).run();
        return json({ok:true});
      }
      if (url.pathname === "/viewer/ping" && request.method === "OPTIONS") return new Response(null,{status:204});

      if (url.pathname === "/admin" && request.method === "GET") return adminPage(env);
      if (!url.pathname.startsWith("/admin/")) return text("Not found", 404);
      if (!adminOk(request, env)) return json({error:"Unauthorized"}, 401);

      if (url.pathname === "/admin/stats" && request.method === "GET") {
        await cleanupViewers(env);
        const rows = await env.DB.prepare(`SELECT c.id,c.name,c.category,c.active,
          (SELECT COUNT(*) FROM viewer_sessions v WHERE v.channel_id=c.id AND v.last_seen >= datetime('now','-90 seconds')) AS viewers,
          (SELECT COUNT(*) FROM channel_views cv WHERE cv.channel_id=c.id) AS total_views,
          (SELECT COUNT(*) FROM channel_views cv WHERE cv.channel_id=c.id AND cv.started_at >= datetime('now','-24 hours')) AS views_24h
          FROM channels c ORDER BY c.sort_order ASC,c.id ASC`).all();
        const totals = await env.DB.prepare(`SELECT COUNT(*) AS total_views, COUNT(DISTINCT viewer_id) AS unique_viewers FROM channel_views`).first();
        return json({channels: rows.results || [], totals: totals || {total_views:0,unique_viewers:0}});
      }
      if (url.pathname === "/admin/channels" && request.method === "GET") return json(await adminListChannels(env));
      if (url.pathname === "/admin/channels" && request.method === "POST") {
        const b = await request.json();
        const requestedType = String(b.source_type || "link").toLowerCase();
        const sourceType = ["link","api","youtube"].includes(requestedType) ? requestedType : "link";
        const sourceValue = String(b.source_value || (sourceType === "link" ? b.stream_url || "" : ""));
        if (!b.name) return json({error:"Channel name is required"},400);
        if (!sourceValue) return json({error: sourceType === "api" ? "API URL is required" : sourceType === "youtube" ? "YouTube URL is required" : "Stream link is required"},400);
        await env.DB.prepare(`INSERT INTO channels(channel_number,name,country,category,logo_url,stream_url,source_type,source_value,api_key,program_name,program_api_url,show_viewers,loop_playback,active,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
          .bind(String(b.channel_number||""),String(b.name),String(b.country||"International"),String(b.category||"TV"),String(b.logo_url||""),String(b.stream_url||""),sourceType,sourceValue,String(b.api_key||""),String(b.program_name||""),String(b.program_api_url||""),b.show_viewers?1:0,b.loop_playback?1:0,b.active===false?0:1,Number(b.sort_order||0)).run();
        return json({ok:true},201);
      }

      if (url.pathname === "/admin/notices" && request.method === "GET") return json(await adminListNotices(env));
      if (url.pathname === "/admin/notices" && request.method === "POST") {
        const b = await request.json();
        const type = ["text","banner","video"].includes(String(b.type||"text")) ? String(b.type||"text") : "text";
        const html = cleanHtml(b.html_content || "");
        const media = String(b.media_url || "");
        if (type === "text" && !html.trim()) return json({error:"Notice text is required"},400);
        if (type !== "text" && !media.trim()) return json({error:"Media URL is required"},400);
        await env.DB.prepare(`INSERT INTO notices(type,title,html_content,media_url,link_url,active,sort_order) VALUES(?,?,?,?,?,?,?)`)
          .bind(type,String(b.title||""),html,media,String(b.link_url||""),b.active===false?0:1,Number(b.sort_order||0)).run();
        return json({ok:true},201);
      }

      let m = url.pathname.match(/^\/admin\/channels\/(\d+)$/);
      if (m) {
        const id = Number(m[1]);
        if (request.method === "DELETE") { await env.DB.prepare("DELETE FROM channels WHERE id=?").bind(id).run(); return json({ok:true}); }
        if (request.method === "PATCH") {
          const b = await request.json();
          const requestedType = String(b.source_type || "link").toLowerCase();
          const sourceType = ["link","api","youtube"].includes(requestedType) ? requestedType : "link";
          const sourceValue = String(b.source_value || (sourceType === "link" ? b.stream_url || "" : ""));
          if (!b.name) return json({error:"Channel name is required"},400);
          if (!sourceValue) return json({error: sourceType === "api" ? "API URL is required" : sourceType === "youtube" ? "YouTube URL is required" : "Stream link is required"},400);
          await env.DB.prepare(`UPDATE channels SET channel_number=?,name=?,country=?,category=?,logo_url=?,stream_url=?,source_type=?,source_value=?,api_key=?,program_name=?,program_api_url=?,show_viewers=?,loop_playback=?,active=?,sort_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
            .bind(String(b.channel_number||""),String(b.name),String(b.country||"International"),String(b.category||"TV"),String(b.logo_url||""),String(b.stream_url||""),sourceType,sourceValue,String(b.api_key||""),String(b.program_name||""),String(b.program_api_url||""),b.show_viewers?1:0,b.loop_playback?1:0,b.active===false?0:1,Number(b.sort_order||0),id).run();
          return json({ok:true});
        }
      }

      m = url.pathname.match(/^\/admin\/notices\/(\d+)$/);
      if (m) {
        const id = Number(m[1]);
        if (request.method === "DELETE") { await env.DB.prepare("DELETE FROM notices WHERE id=?").bind(id).run(); return json({ok:true}); }
        if (request.method === "PATCH") {
          const b = await request.json();
          const type = ["text","banner","video"].includes(String(b.type||"text")) ? String(b.type||"text") : "text";
          const html = cleanHtml(b.html_content || "");
          const media = String(b.media_url || "");
          if (type === "text" && !html.trim()) return json({error:"Notice text is required"},400);
          if (type !== "text" && !media.trim()) return json({error:"Media URL is required"},400);
          await env.DB.prepare(`UPDATE notices SET type=?,title=?,html_content=?,media_url=?,link_url=?,active=?,sort_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
            .bind(type,String(b.title||""),html,media,String(b.link_url||""),b.active===false?0:1,Number(b.sort_order||0),id).run();
          return json({ok:true});
        }
      }

      return text("Not found",404);
    } catch (e) {
      return json({error: e?.message || "Server error"},500);
    }
  }
};
