# One TV Ad Monetization Configuration

## Confirmed AdMob IDs
- App ID: `ca-app-pub-5981864080922785~4472399258`
- Banner: `ca-app-pub-5981864080922785/5178976268`
- Interstitial: `ca-app-pub-5981864080922785/7592231664`
- Native Advanced: `ca-app-pub-5981864080922785/1737269754`

## Placement
1. Adaptive Banner: TV, MOVIES, and CRICKET screens, fixed above the copyright footer.
2. Native Advanced: limited to one clearly labeled content-list placement when content is available.
3. Interstitial: only after repeated category navigation, with a 120-second in-app cooldown.

## UX rules
- No interstitial at app launch.
- No interstitial on back button.
- No interstitial over video playback.
- No interstitial while reading Cricket scores.
- No player-overlay ads.
- No rewarded ads.
- No App Open ads.
- No forced unskippable video ads.
- Fullscreen video hides banner and footer and restores them after exit.

## Debug vs Release
Debug builds use Google's official test ad units. Release builds use the confirmed One TV live IDs above. The code determines debug/release mode from the Android application flag, so no `BuildConfig` dependency is used for ad selection.

## Ad availability
New AdMob units can take some time before live inventory begins serving. A successful ad request does not guarantee that an ad will fill.
