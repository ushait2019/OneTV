# One TV AdMob Configuration

## Live IDs
- App ID: `ca-app-pub-5981864080922785~4472399258`
- Banner: `ca-app-pub-5981864080922785/5178976268`
- Interstitial: `ca-app-pub-5981864080922785/7592231664`
- Native Advanced: `ca-app-pub-5981864080922785/1737269754`

## Test IDs used by debug builds
- Banner: Google official test banner
- Interstitial: Google official test interstitial
- Native Advanced: Google official test native advanced

The app selects test units automatically for debug builds using the Android application's debuggable flag. Release builds use the live One TV AdMob units above.

## Placement rules
- Banner: fixed above the copyright footer on TV, MOVIES, and CRICKET screens.
- Native: one native ad in a content list, after several content items when available. It is clearly labeled ADVERTISEMENT.
- Interstitial: only after repeated category navigation, with a 120-second in-app cooldown. It is never requested at app launch, on back, during video playback, inside the player, or in Cricket score reading.
- Fullscreen video hides the banner, native list content, notice, and footer outside the video surface. Exiting fullscreen restores the normal layout.
- No rewarded ads, app-open ads, or forced unskippable video ads are included.
