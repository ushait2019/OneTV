# One TV Backend + UI QA

## Backend
- SportScore is the primary sports provider for football, basketball, cricket and tennis.
- SportScore is the only sports provider in the updated build.
- No sports API credential is required.
- Added generic sports routes: `/sports/{sport}/{live|upcoming|results}`.
- Added sports match detail routes.
- Existing channel, notice and viewer-session APIs remain intact.
- Worker source passes `node --check` syntax validation.

## Header / navigation
- One TV logo is centered.
- `All in One` is directly below the logo.
- Small side ad placeholders are constrained and do not participate in the brand center layout.
- Top-level navigation is `SPORTS` and `ENTERTAINMENT` dropdowns.
- Sports: Cricket, Football, Basketball, Tennis.
- Entertainment: TV, Movies, Drama, Songs.

## Layout / overlap rules
- Major content areas use parent containers and explicit padding instead of positional offsets.
- Dropdowns use bounded PopupWindow width and item heights.
- Player controls are inside the player frame.
- Fullscreen hides ad/footer/navigation/category UI.
- No Next/Previous video controls.

## Video controls
- Play/Pause.
- Volume slider.
- Quality menu.
- Fullscreen.
- Controls auto-hide after inactivity.
- YouTube playback uses the official embedded player and command API; direct streams use Media3.

## Build note
The repository does not contain a Gradle wrapper and this execution environment does not have a system Gradle installation, so a local Gradle release compile could not be executed here. The GitHub Actions workflow remains the authoritative Android build path.

## Update 2026-10-31 05:xx
- SportScore is now the sole sports provider.
- Removed OpenCricket fallback/key dependency from Worker source and deployment helpers.
- Added `/sports/tennis/match/<MATCH_ID>` support so tennis cards can open details.
- Added normalized SportScore match-detail payloads for all four sports.
- Reduced player control buttons and replaced large emoji controls with vector icons.
- Added a compact sports-only refresh button next to the updated timestamp.
- Refresh control is hidden on video/entertainment pages and match-detail screens.
- Android version bumped to 1.5 / versionCode 6.
