# One TV PC Admin Control

This package now includes a Windows desktop admin panel in `desktop-panel/`.

## What you can control from the PC
- Add, edit, disable, enable, and delete channels.
- Choose Link or API as the channel source.
- Edit logo, country, category, program/movie title, program API, viewer-count visibility and loop playback.
- Publish, hide, edit, and delete text/banner/video notices and personal ads.
- See real-time active viewers for every channel.
- See total views and last-24-hour views per channel.
- See overall unique viewers.

## How it connects
The desktop panel does not store the channel database locally. It connects to the same Cloudflare Worker API used by the Android app. This means a change made on the PC is immediately available to all app users after their next refresh.

## Build the Windows app
Install Node.js 20+ on Windows. Open Command Prompt in `desktop-panel`:

```text
npm install
npm run build
```

The installer and portable EXE will be generated in `desktop-panel/dist/`.

## First database migration
If your D1 database already exists, run:

```text
wrangler d1 execute one-tv-db --remote --file=migration-view-stats.sql
```

If you create the database from the new `schema.sql`, the view-statistics table is included.

## Security
The admin token is used only for admin API requests. Do not put the admin token into the Android APK.
