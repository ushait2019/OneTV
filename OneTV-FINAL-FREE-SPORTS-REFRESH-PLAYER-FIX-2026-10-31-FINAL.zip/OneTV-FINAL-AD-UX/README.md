# One TV - Final Android + Cloudflare Backend Package

## App identity
- Brand: **One TV**
- Slogan: **All in One**
- Developer: **USHA IT**
- Copyright: `© 2026 USHA IT. All Rights Reserved.`
- Package: `com.ushait.onetv`
- Version: `1.3` / versionCode `4`

## Final UI
- Header: One TV logo on the left and **All in One** on the right.
- Menu: **TV • MOVIES • CRICKET**.
- TV and MOVIES are video-based.
- Cricket is score-only and has no video player.
- Channel/program information is shown below the player.
- Player controls stay inside the video and auto-hide after inactivity.
- Previous/Next controls use large touch targets.
- Notice board exists only on TV/Home.
- When no notice is published, the notice area has zero height.
- When a notice is published, its reserved area expands without overlapping the player or ads.
- Adaptive banner advertisement stays above the copyright footer on all normal screens.
- Fullscreen video hides the non-video UI, including notice, ads, and footer, and restores it on exit.

## AdMob
Confirmed live IDs:
- App ID: `ca-app-pub-5981864080922785~4472399258`
- Banner: `ca-app-pub-5981864080922785/5178976268`
- Interstitial: `ca-app-pub-5981864080922785/7592231664`
- Native Advanced: `ca-app-pub-5981864080922785/1737269754`

Debug builds use Google's official test units. Release builds use the live One TV units. The app does not use `BuildConfig` for ad selection, avoiding the previous compile failure.

### Ad UX rules
- Banner: TV, MOVIES, CRICKET, above copyright.
- Native: one clearly labeled native ad in a content list when content is available.
- Interstitial: only after repeated category navigation and only when the 120-second in-app cooldown has expired.
- No interstitial at launch, back navigation, during video playback, inside the player, or while reading Cricket scores.
- No rewarded, App Open, or forced unskippable video ads.

## Backend
Cloudflare Worker + D1 keeps channel, notice, viewer, and cricket data outside the APK.

Public app routes:
- `/channels`
- `/notice`
- `/viewer/ping`
- `/cricket/live`
- `/cricket/upcoming`
- `/cricket/results`
- `/cricket/match/<MATCH_ID>`
- `/cricket/health`

Admin routes are protected by `ADMIN_TOKEN`.

The Android source currently contains a Worker URL placeholder in `MainActivity.java` because no deployed Worker hostname was supplied in this build context. Replace `BACKEND_URL` with the actual deployed Worker base URL before the production build. This value cannot be safely invented.

## TV / Movies
- Direct authorized HLS, DASH, and MP4 streams use Media3/ExoPlayer.
- Movie playback can loop.
- YouTube content uses the official embedded player. YouTube API credentials stay on the Worker.
- The app does not extract or re-host YouTube media URLs.

## Cricket Live
- No video player.
- Live, Upcoming, Results/history, and match details are API-driven.
- Live data refreshes every 20 seconds while the Cricket screen is open.
- Cricket provider credentials stay on the Cloudflare Worker.

## Viewer analytics
- Viewer heartbeat every 30 seconds.
- Sessions older than 90 seconds are excluded from active viewer counts.
- Starting/switching channels records a view without counting every heartbeat as a new view.
- D1 stores viewer/session statistics for the Windows admin panel.

## Build
GitHub Actions uses JDK 17, Gradle 8.13, and Android SDK 35. It builds Debug APK, Release APK, and AAB. Release signing uses the existing `ONETV_KEYSTORE_*` GitHub secrets when configured.

Only use streams, media, and API data that you are authorized to use or redistribute.


## Backend connection

The Android build reads the Cloudflare Worker URL from the GitHub Actions secret `ONETV_BACKEND_URL`. Deploy the `backend/` folder first, then add that secret before the final release build.
