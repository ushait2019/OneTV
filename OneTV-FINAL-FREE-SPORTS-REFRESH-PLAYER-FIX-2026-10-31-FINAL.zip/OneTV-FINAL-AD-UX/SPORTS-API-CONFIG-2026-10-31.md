# One TV Sports API

- Provider: SportScore
- Free forever tier: yes, according to current SportScore developer page
- API key: not required for the public attribution tier
- Rate: approximately 10,000 requests / 24h / IP
- Sports: football, basketball, cricket, tennis
- Attribution: visible Powered by SportScore link
- Live: /api/widget/matches/
- Upcoming/results: /api/v1/fixtures/
- Match detail: /api/v1/match/

OpenCricket is not used by this build.
