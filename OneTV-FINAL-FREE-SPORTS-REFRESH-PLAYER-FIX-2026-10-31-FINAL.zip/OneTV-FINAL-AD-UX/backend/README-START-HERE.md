# One TV Backend: Start Here

This folder is the production-ready Cloudflare Worker + D1 backend package for One TV.

## What is already prepared
- Dynamic TV/movie channel database and admin CRUD
- Published Notice Board data for the TV page only
- Viewer heartbeat + per-channel view analytics
- YouTube Data API metadata resolution with official embedded playback in the Android app
- Sports score proxy for cricket, football, basketball and tennis
- SportScore public API for sports data, no API key required
- SportScore edge-cached responses to reduce upstream usage
- CORS for the Android client
- Windows Electron admin panel
- PowerShell deployment helper

## What cannot be pre-filled
Cloudflare D1 `database_id`, Worker URL, `ADMIN_TOKEN` and YouTube API key belong to your accounts and are intentionally not stored in this ZIP. SportScore requires no API key.

## First deployment
1. Install Node.js and Wrangler: `npm install -g wrangler`
2. Run `wrangler login`.
3. Run `wrangler d1 create one-tv-db`.
4. Copy the returned `database_id` into `wrangler.toml`.
5. Run `./deploy.ps1` on Windows PowerShell.
6. Wrangler will ask for the two required secrets.
7. Copy the deployed Worker URL.
8. Add that URL as the GitHub Actions secret `ONETV_BACKEND_URL`.
9. Re-run the Android workflow.

## Verification
- `GET /health` should report `database: connected`.
- `GET /cricket/health` should report SportScore as the provider. No cricket API key is required.
- Open `/admin`, enter the `ADMIN_TOKEN`, and press **Connect**.

## Sports score provider
SportScore is the primary and only sports-data provider in this build. Its current public documentation states that the API is free forever, requires no API key, supports cricket, football, basketball and tennis, and provides approximately 10,000 requests per 24 hours per IP on the free tier. A visible “Powered by SportScore” attribution is required.

The Android app refreshes the active sports list every 20 seconds and also provides a manual refresh button on sports screens.

## Important
Do not put Cloudflare, YouTube, or cricket API secrets in the Android APK, GitHub source, or desktop JavaScript.
