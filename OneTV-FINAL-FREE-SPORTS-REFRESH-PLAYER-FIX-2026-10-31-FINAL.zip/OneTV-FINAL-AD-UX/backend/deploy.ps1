$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Get-Command wrangler -ErrorAction SilentlyContinue)) {
  Write-Host "Wrangler is not installed. Install with: npm install -g wrangler" -ForegroundColor Yellow
  exit 1
}

Write-Host "One TV backend deployment" -ForegroundColor Cyan
Write-Host "1) Wrangler login will be required if this machine is not already authenticated." -ForegroundColor Gray
wrangler whoami

$cfg = Get-Content .\wrangler.toml -Raw
if ($cfg -match 'REPLACE_WITH_YOUR_D1_DATABASE_ID') {
  Write-Host "D1 database ID is still a placeholder." -ForegroundColor Yellow
  Write-Host "Run: wrangler d1 create one-tv-db" -ForegroundColor Yellow
  Write-Host "Copy the returned database_id into backend\wrangler.toml, then run this script again." -ForegroundColor Yellow
  exit 1
}

Write-Host "Applying D1 schema..." -ForegroundColor Cyan
wrangler d1 execute one-tv-db --remote --file=schema.sql

Write-Host "Set/update required Worker secrets." -ForegroundColor Cyan
Write-Host "You will be prompted by Wrangler for each secret. Do not paste secrets into source files." -ForegroundColor Gray
wrangler secret put ADMIN_TOKEN
wrangler secret put YOUTUBE_API_KEY

Write-Host "Deploying Worker..." -ForegroundColor Cyan
wrangler deploy

Write-Host "Backend deployed. Test /health, /cricket/health and /admin." -ForegroundColor Green
