-- Run this only if your existing D1 database was created from the older One TV schema.
ALTER TABLE channels ADD COLUMN source_type TEXT NOT NULL DEFAULT 'link';
ALTER TABLE channels ADD COLUMN source_value TEXT NOT NULL DEFAULT '';
ALTER TABLE channels ADD COLUMN api_key TEXT NOT NULL DEFAULT '';

UPDATE channels
SET source_value = stream_url
WHERE source_value = '';

ALTER TABLE channels ADD COLUMN program_name TEXT NOT NULL DEFAULT '';
ALTER TABLE channels ADD COLUMN program_api_url TEXT NOT NULL DEFAULT '';
ALTER TABLE channels ADD COLUMN show_viewers INTEGER NOT NULL DEFAULT 0;
ALTER TABLE channels ADD COLUMN loop_playback INTEGER NOT NULL DEFAULT 0;
CREATE TABLE IF NOT EXISTS viewer_sessions (viewer_id TEXT PRIMARY KEY, channel_id INTEGER NOT NULL, last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_viewer_sessions_channel_seen ON viewer_sessions(channel_id, last_seen);
