-- Run this only if you already deployed the previous One TV backend
-- that already has source_type/source_value/api_key and notices.
ALTER TABLE channels ADD COLUMN program_name TEXT NOT NULL DEFAULT '';
ALTER TABLE channels ADD COLUMN program_api_url TEXT NOT NULL DEFAULT '';
ALTER TABLE channels ADD COLUMN show_viewers INTEGER NOT NULL DEFAULT 0;
ALTER TABLE channels ADD COLUMN loop_playback INTEGER NOT NULL DEFAULT 0;
CREATE TABLE IF NOT EXISTS viewer_sessions (
  viewer_id TEXT PRIMARY KEY,
  channel_id INTEGER NOT NULL,
  last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_viewer_sessions_channel_seen ON viewer_sessions(channel_id, last_seen);
