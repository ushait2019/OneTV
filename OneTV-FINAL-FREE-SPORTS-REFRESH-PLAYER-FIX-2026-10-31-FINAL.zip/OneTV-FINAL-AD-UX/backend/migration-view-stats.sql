CREATE TABLE IF NOT EXISTS channel_views (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_id INTEGER NOT NULL,
  viewer_id TEXT NOT NULL,
  started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_channel_views_channel ON channel_views(channel_id);
CREATE INDEX IF NOT EXISTS idx_channel_views_started ON channel_views(started_at);
