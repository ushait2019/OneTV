param(
  [Parameter(Mandatory=$true)][string]$BaseUrl,
  [Parameter(Mandatory=$false)][string]$AdminToken = ""
)
$ErrorActionPreference = "Stop"
$BaseUrl = $BaseUrl.TrimEnd('/')
Write-Host "Testing One TV backend: $BaseUrl" -ForegroundColor Cyan

$health = Invoke-RestMethod -Uri "$BaseUrl/health" -Method Get
$health | ConvertTo-Json -Depth 5

$cricket = Invoke-RestMethod -Uri "$BaseUrl/cricket/health" -Method Get
$cricket | ConvertTo-Json -Depth 5

if ($AdminToken) {
  $headers = @{ Authorization = "Bearer $AdminToken" }
  $channels = Invoke-RestMethod -Uri "$BaseUrl/admin/channels" -Headers $headers -Method Get
  $notices = Invoke-RestMethod -Uri "$BaseUrl/admin/notices" -Headers $headers -Method Get
  Write-Host "Admin API OK. Channels: $($channels.Count); Notices: $($notices.Count)" -ForegroundColor Green
}

Write-Host "Smoke test completed." -ForegroundColor Green
