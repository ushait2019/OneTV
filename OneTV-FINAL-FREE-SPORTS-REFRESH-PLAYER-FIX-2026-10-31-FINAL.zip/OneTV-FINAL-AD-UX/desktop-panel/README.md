# One TV Admin Panel for Windows

A desktop Electron control panel for One TV. It connects directly to the Cloudflare Worker API, so you do not need to open Cloudflare every time.

## What it does
- Dashboard with real-time active viewer count.
- Per-channel live viewers, total views, and last-24-hour views.
- Channel management view.
- Notices / personal ads view.
- Stores Worker URL and admin token locally on the PC.
- Auto-refreshes live statistics every 5 seconds.

## Build
Install Node.js 20+ on Windows, then in this folder:

```bash
npm install
npm run build
```

Electron Builder creates a Windows installer and portable EXE under `dist/`.

## First setup
1. Deploy the One TV Worker and D1 database.
2. Run the new `backend/migration-view-stats.sql` once if the database already exists.
3. Set the Worker URL and admin token in this app.
4. Click Connect.
