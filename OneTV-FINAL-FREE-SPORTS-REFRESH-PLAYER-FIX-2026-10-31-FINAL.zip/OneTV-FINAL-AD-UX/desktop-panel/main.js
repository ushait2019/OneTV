const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
function createWindow(){
  const win = new BrowserWindow({width: 1360,height: 900,minWidth:1100,minHeight:700,webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false}});
  win.loadFile('index.html');
}
app.whenReady().then(()=>{createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow()});});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
ipcMain.handle('open-external',(_,url)=>shell.openExternal(url));
