const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('onetv', { openExternal:(url)=>ipcRenderer.invoke('open-external',url) });
