package com.ushait.onetv;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Stack;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final String BACKEND_URL = BuildConfig.BACKEND_URL;
    private static final int BG = Color.rgb(5, 10, 17);
    private static final int PANEL = Color.rgb(13, 25, 39);
    private static final int CARD = Color.rgb(20, 35, 51);
    private static final int CARD_2 = Color.rgb(24, 42, 61);
    private static final int BLUE = Color.rgb(28, 126, 245);
    private static final int CYAN = Color.rgb(0, 205, 190);
    private static final int PURPLE = Color.rgb(119, 52, 245);
    private static final int TEXT = Color.WHITE;
    private static final int MUTED = Color.rgb(174, 188, 203);
    private static final int GREEN = Color.rgb(0, 194, 142);
    private static final int RED = Color.rgb(244, 63, 81);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final Stack<String> history = new Stack<>();
    private final List<Channel> channels = new ArrayList<>();

    private LinearLayout root;
    private FrameLayout contentHost;
    private LinearLayout topModeRow;
    private TextView pageTitle;
    private TextView pageSubtitle;
    private TextView headerSlogan;
    private ImageView logoView;
    private LinearLayout bottomBar;
    private LinearLayout adRow;
    private TextView footer;
    private TextView statusText;
    private JSONObject adConfig;

    private ExoPlayer player;
    private PlayerView playerView;
    private boolean fullscreen = false;
    private ViewGroup playerOriginalParent;
    private int playerOriginalIndex = 0;

    private String screen = "home";
    private String selectedSport = "cricket";
    private String selectedEntertainment = "TV";
    private String matchMode = "live";
    private JSONObject selectedMatch;
    private String detailTab = "SCORECARD";
    private JSONArray remoteMatches;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(Color.BLACK);
        MobileAds.initialize(this, status -> {});
        buildShell();
        showHome(false);
        loadChannels();
        loadAdConfig();
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        root.addView(buildHeader(), new LinearLayout.LayoutParams(-1, dp(88)));
        contentHost = new FrameLayout(this);
        root.addView(contentHost, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout fixedBottom = new LinearLayout(this);
        fixedBottom.setOrientation(LinearLayout.VERTICAL);
        fixedBottom.setBackgroundColor(BG);
        adRow = buildAds();
        fixedBottom.addView(adRow, new LinearLayout.LayoutParams(-1, dp(92)));
        bottomBar = buildBottomNav();
        fixedBottom.addView(bottomBar, new LinearLayout.LayoutParams(-1, dp(58)));
        footer = tv("© 2026 USHA IT. All Rights Reserved.", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(5), 0, dp(8));
        fixedBottom.addView(footer, new LinearLayout.LayoutParams(-1, dp(30)));
        root.addView(fixedBottom, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }

    private View buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(18), dp(5), dp(14), dp(4));
        header.setBackgroundColor(Color.rgb(4, 9, 15));

        TextView menu = tv("☰", 24, TEXT, false); menu.setGravity(Gravity.CENTER); menu.setContentDescription("Menu"); menu.setOnClickListener(v -> showSimple("Menu", "ONE TV sections and settings"));
        header.addView(menu, new LinearLayout.LayoutParams(dp(38), dp(44)));

        logoView = new ImageView(this);
        logoView.setImageResource(R.drawable.onetv_logo);
        logoView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        header.addView(logoView, new LinearLayout.LayoutParams(dp(116), dp(54)));

        headerSlogan = tv("All in One", 16, TEXT, true);
        headerSlogan.setGravity(Gravity.CENTER_VERTICAL);
        headerSlogan.setPadding(dp(8), 0, 0, 0);
        header.addView(headerSlogan, new LinearLayout.LayoutParams(0, dp(54), 1));

        TextView search = tv("⌕", 27, TEXT, false);
        search.setGravity(Gravity.CENTER);
        search.setContentDescription("Search");
        search.setOnClickListener(v -> showSimple("Search", "Search sports, matches, teams, channels and content"));
        header.addView(search, new LinearLayout.LayoutParams(dp(38), dp(44)));

        TextView bell = tv("♧", 23, TEXT, false);
        bell.setGravity(Gravity.CENTER);
        bell.setContentDescription("Notifications");
        bell.setOnClickListener(v -> showSimple("Notifications", "Match reminders and ONE TV updates"));
        header.addView(bell, new LinearLayout.LayoutParams(dp(38), dp(44)));

        TextView sun = tv("☀", 21, Color.rgb(255, 197, 40), false);
        sun.setGravity(Gravity.CENTER);
        sun.setBackground(round(CARD, 14));
        sun.setOnClickListener(v -> showSimple("Appearance", "Theme settings are ready for remote configuration"));
        header.addView(sun, new LinearLayout.LayoutParams(dp(44), dp(44)));
        return header;
    }

    private LinearLayout buildBottomNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(Color.rgb(7, 15, 24));
        String[] labels = {"⌂\nHome", "♜\nSports", "▣\nLive TV", "▦\nMedia", "♙\nProfile"};
        String[] ids = {"home", "sports", "live", "media", "profile"};
        for (int i = 0; i < labels.length; i++) {
            final String id = ids[i];
            TextView b = tv(labels[i], 10.5f, MUTED, false);
            b.setGravity(Gravity.CENTER);
            b.setLineSpacing(0, .85f);
            b.setOnClickListener(v -> {
                if ("home".equals(id)) showHome(true);
                else if ("sports".equals(id)) showSportsHome(true);
                else if ("live".equals(id)) showEntertainment("TV", true);
                else if ("media".equals(id)) showEntertainment("Movies", true);
                else showSimple("Profile", "Profile and preferences");
            });
            nav.addView(b, new LinearLayout.LayoutParams(0, -1, 1));
        }
        return nav;
    }

    private LinearLayout buildAds() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(12), dp(6), dp(12), dp(6));
        addAdSlot(row, "home_1");
        addAdSlot(row, "home_2");
        return row;
    }

    private void addAdSlot(LinearLayout row, String placement) {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER);
        card.setBackground(round(PANEL, 12));
        AdView ad = new AdView(this);
        ad.setAdSize(AdSize.BANNER);
        String unit = BuildConfig.DEBUG ? "ca-app-pub-3940256099942544/6300978111" : "ca-app-pub-5981864080922785/5178976268";
        ad.setAdUnitId(unit);
        card.addView(ad, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1);
        p.setMargins(dp(3), 0, dp(3), 0);
        row.addView(card, p);
        ad.loadAd(new AdRequest.Builder().build());
    }

    private void showHome(boolean push) {
        if (push) push("home");
        screen = "home";
        clearContent();
        buildHome();
        hideAds(false);
    }

    private void buildHome() {
        LinearLayout page = page();
        topModeRow = modeRow();
        page.addView(topModeRow);
        page.addView(sectionLabel("Sports", "Live, Upcoming, Results & More"));
        LinearLayout sportsGrid = new LinearLayout(this);
        sportsGrid.setPadding(dp(14), dp(3), dp(14), dp(10));
        String[] sports = {"Cricket", "Football", "Basketball", "Tennis"};
        String[] icons = {"🏏", "⚽", "🏀", "🎾"};
        for (int i = 0; i < sports.length; i++) {
            final String sport = sports[i].toLowerCase(Locale.US);
            LinearLayout c = featureTile(icons[i], sports[i], i == 0 ? CYAN : BLUE);
            c.setOnClickListener(v -> showSports(sport, true));
            sportsGrid.addView(c, weighted());
        }
        page.addView(sportsGrid);

        LinearLayout liveHead = new LinearLayout(this);
        liveHead.setGravity(Gravity.CENTER_VERTICAL);
        liveHead.setPadding(dp(18), dp(4), dp(18), dp(4));
        TextView live = tv("Live Now", 17, TEXT, true);
        liveHead.addView(live, new LinearLayout.LayoutParams(0, -2, 1));
        TextView see = tv("See All  ›", 11, MUTED, true);
        liveHead.addView(see);
        page.addView(liveHead);

        page.addView(homeLiveCard());

        page.addView(sectionLabel("Entertainment", "TV, Movies, News, Kids & More"));
        LinearLayout entGrid = new LinearLayout(this);
        entGrid.setPadding(dp(14), dp(3), dp(14), dp(12));
        String[] e = {"TV", "Movies", "News", "Kids"};
        String[] ei = {"▣", "▤", "▥", "◉"};
        for (int i = 0; i < e.length; i++) {
            final String cat = e[i];
            LinearLayout c = featureTile(ei[i], cat, i == 1 ? PURPLE : (i == 2 ? GREEN : BLUE));
            c.setOnClickListener(v -> showEntertainment(cat, true));
            entGrid.addView(c, weighted());
        }
        page.addView(entGrid);
        addScroll(page);
    }

    private View homeLiveCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(11), dp(14), dp(11));
        card.setBackground(round(Color.WHITE, 15));
        TextView top = tv("● LIVE   Test Series  •  3rd Test", 10, RED, true);
        card.addView(top);
        LinearLayout teams = new LinearLayout(this);
        teams.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = scoreTeam("🇿🇦", "RSA", "329 & 387");
        LinearLayout right = scoreTeam("🇦🇺", "AUS", "429 & 111");
        teams.addView(left, weighted());
        TextView vs = tv("VS", 11, BLUE, true);
        vs.setGravity(Gravity.CENTER);
        teams.addView(vs, new LinearLayout.LayoutParams(dp(32), -2));
        teams.addView(right, weighted());
        card.addView(teams);
        TextView lead = tv("AUS Lead by 113 runs  ›", 10, Color.rgb(12, 105, 61), true);
        lead.setGravity(Gravity.CENTER);
        lead.setBackground(round(Color.rgb(215, 249, 224), 9));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(34));
        lp.setMargins(dp(4), dp(7), dp(4), 0);
        card.addView(lead, lp);
        card.setOnClickListener(v -> {
            selectedMatch = demoMatch("cricket", "RSA vs AUS • 3rd Test");
            showMatchDetail(true);
        });
        return card;
    }

    private void showSportsHome(boolean push) {
        if (push) push("sportsHome");
        screen = "sportsHome";
        clearContent();
        LinearLayout page = page();
        page.addView(modeRow());
        page.addView(sectionLabel("Sports", "Choose a sport"));
        LinearLayout grid = new LinearLayout(this);
        grid.setPadding(dp(14), 0, dp(14), dp(10));
        String[] names = {"Cricket", "Football", "Basketball", "Tennis"};
        String[] icons = {"🏏", "⚽", "🏀", "🎾"};
        for (int i=0;i<names.length;i++) {
            final String s=names[i].toLowerCase(Locale.US);
            LinearLayout c=featureTile(icons[i],names[i],BLUE);
            c.setOnClickListener(v->showSports(s,true));
            grid.addView(c, weighted());
        }
        page.addView(grid);
        page.addView(sectionLabel("Live & Upcoming", "Match center"));
        for (String s : names) {
            JSONObject m = demoMatch(s.toLowerCase(Locale.US), s + " Match");
            page.addView(sportsListCard(m, false));
        }
        addScroll(page);
    }

    private void showSports(String sport, boolean push) {
        if (push) push("sport:" + sport);
        screen = "sport";
        selectedSport = sport;
        matchMode = "live";
        clearContent();
        LinearLayout page = page();
        page.addView(selectedSectionBar(sportName(sport), true));
        LinearLayout tabs = new LinearLayout(this);
        tabs.setPadding(dp(12), dp(7), dp(12), dp(7));
        String[] modes={"LIVE","UPCOMING","RESULTS"};
        for(String mode:modes){
            TextView b=tab(mode, mode.equals("LIVE"));
            b.setOnClickListener(v->{matchMode=mode.toLowerCase(Locale.US); renderSportList(page,sport);});
            tabs.addView(b, weighted());
        }
        page.addView(tabs);
        renderSportList(page,sport);
        loadSportsFromBackend(sport, matchMode, page);
        addScroll(page);
    }

    private void renderSportList(LinearLayout page, String sport) {
        while(page.getChildCount()>2) page.removeViewAt(2);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), dp(2), dp(12), dp(18));
        if (remoteMatches != null && remoteMatches.length() > 0) {
            for (int i = 0; i < remoteMatches.length(); i++) {
                JSONObject m = remoteMatches.optJSONObject(i);
                if (m != null) list.addView(sportsListCard(m, i == 0));
            }
        } else {
            String[] titles;
            if ("football".equals(sport)) titles = new String[]{"International San Carlos vs Escorpiones Belen","Real Madrid vs Valencia","Manchester City vs Liverpool"};
            else if ("basketball".equals(sport)) titles = new String[]{"Lakers vs Warriors","Celtics vs Knicks","Nuggets vs Suns"};
            else if ("tennis".equals(sport)) titles = new String[]{"Alcaraz vs Sinner","Djokovic vs Zverev","WTA Finals"};
            else titles = new String[]{"RSA vs AUS • 3rd Test","BAN vs WI • 1st Test","IND vs NZ • 5th T20I"};
            for(int i=0;i<titles.length;i++){
                JSONObject m=demoMatch(sport,titles[i]);
                list.addView(sportsListCard(m, i==0 && "live".equals(matchMode)));
            }
        }
        page.addView(list);
    }

    private void loadSportsFromBackend(String sport, String mode, LinearLayout page) {
        if (BACKEND_URL == null || BACKEND_URL.contains("REPLACE")) return;
        network.execute(() -> {
            try {
                String path = "cricket".equals(sport) ? "/cricket/" + mode : "/sports/" + sport + "/" + mode;
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + path));
                JSONArray arr = root.optJSONArray("matches");
                if (arr == null || arr.length()==0) return;
                runOnUiThread(() -> {
                    if (!"sport".equals(screen) || !selectedSport.equals(sport)) return;
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject item = arr.optJSONObject(i);
                        if (item != null && !item.has("sport")) try { item.put("sport", sport); } catch (Exception ignored) {}
                    }
                    remoteMatches = arr;
                    renderSportList(page, sport);
                });
            } catch(Exception ignored) {}
        });
    }

    private View sportsListCard(JSONObject m, boolean live) {
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(13),dp(11),dp(13),dp(11));
        card.setBackground(round(CARD,15));

        String sport=m.optString("sport",selectedSport);
        TextView comp=tv(m.optString("competition",sportName(sport)+" • Match Center"),10,MUTED,true);
        card.addView(comp);

        LinearLayout titleRow=new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=tv(m.optString("title",""),12,TEXT,true);
        titleRow.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        titleRow.addView(tv(live?"● LIVE":m.optString("status","UPCOMING"),10,live?RED:GREEN,true));
        card.addView(titleRow);

        LinearLayout teams=new LinearLayout(this);
        teams.setGravity(Gravity.CENTER_VERTICAL);
        JSONObject home=team(m,true), away=team(m,false);
        teams.addView(matchTeam(home,true),weighted());
        TextView vs=tv("VS",11,BLUE,true);vs.setGravity(Gravity.CENTER);
        teams.addView(vs,new LinearLayout.LayoutParams(dp(34),-2));
        teams.addView(matchTeam(away,false),weighted());
        card.addView(teams);

        if ("football".equalsIgnoreCase(sport)) {
            card.addView(detailRow("Timeline", live ? "68' • 2 goals • 3 cards" : "Full time • match events"));
        } else if ("basketball".equalsIgnoreCase(sport)) {
            card.addView(detailRow("Quarters", "Q1 24-21  •  Q2 28-26  •  Q3 19-22"));
        } else if ("tennis".equalsIgnoreCase(sport)) {
            card.addView(detailRow("Sets", "6-4  •  3-6  •  4-2  •  Games 3-2"));
        } else {
            card.addView(detailRow("Match center", live ? "Live score • required rate • current over" : "Scorecard • squads • commentary"));
        }

        card.setOnClickListener(v->{selectedMatch=m;showMatchDetail(true);});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,0,0,dp(9));
        card.setLayoutParams(p);
        return card;
    }

    private View matchTeam(JSONObject t, boolean left) {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        TextView logo=tv(t.optString("flag",left?"◉":"◉"),27,TEXT,false);
        logo.setGravity(Gravity.CENTER);
        box.addView(logo,new LinearLayout.LayoutParams(-1,dp(40)));
        TextView name=tv(t.optString("name",left?"Home":"Away"),13,TEXT,true);
        name.setGravity(Gravity.CENTER);
        name.setMaxLines(2);
        box.addView(name);
        String score=t.optString("score","");
        if(!score.isEmpty()) box.addView(tv(score,17,TEXT,true));
        return box;
    }

    private void showMatchDetail(boolean push) {
        if (push) push("match");
        screen="match";
        clearContent();
        LinearLayout page=page();
        if(selectedMatch==null) selectedMatch=demoMatch(selectedSport,"Match Center");
        JSONObject m=selectedMatch;
        String sport=m.optString("sport",selectedSport);
        detailTab = "cricket".equals(sport) ? "SCORECARD" : "OVERVIEW";
        page.addView(matchHero(m));
        LinearLayout tabs=new LinearLayout(this);
        tabs.setPadding(dp(10),dp(7),dp(10),dp(7));
        String[] labels = "cricket".equals(sport) ? new String[]{"Overview","Live","Scorecard","Squads","Overs","Commentary"} : new String[]{"Overview","Live","Stats","Lineups","Timeline"};
        for(String label:labels){
            TextView b=tab(label,label.equalsIgnoreCase(detailTab));
            b.setOnClickListener(v->{detailTab=label.toUpperCase(Locale.US); renderMatchTab(page,m,sport);});
            tabs.addView(b,weighted());
        }
        page.addView(tabs);
        renderMatchTab(page,m,sport);
        addScroll(page);
    }

    private View matchHero(JSONObject m) {
        LinearLayout hero=new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(15),dp(10),dp(15),dp(12));
        hero.setBackground(round(PANEL,17));
        TextView back=tv("‹  Back to matches",11,MUTED,true);
        back.setOnClickListener(v -> onBackPressed());
        hero.addView(back);
        TextView title=tv(m.optString("title",m.optString("competition","Match")),13,TEXT,true);
        hero.addView(title);
        TextView date=tv(m.optString("date","Today • Local time"),10,MUTED,false);
        hero.addView(date);
        LinearLayout teams=new LinearLayout(this);
        teams.setGravity(Gravity.CENTER_VERTICAL);
        teams.addView(matchTeam(team(m,true),true),weighted());
        TextView vs=tv("VS",14,BLUE,true);vs.setGravity(Gravity.CENTER);
        teams.addView(vs,new LinearLayout.LayoutParams(dp(40),-2));
        teams.addView(matchTeam(team(m,false),false),weighted());
        hero.addView(teams);
        TextView status=tv(m.optString("result",m.optString("status","LIVE")),11,GREEN,true);
        status.setGravity(Gravity.CENTER);
        hero.addView(status);
        return hero;
    }

    private void renderMatchTab(LinearLayout page, JSONObject m, String sport) {
        while(page.getChildCount()>3) page.removeViewAt(3);
        LinearLayout body=new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(12),dp(2),dp(12),dp(18));
        String tab=detailTab;
        if("cricket".equals(sport)){
            if(tab.contains("SCORECARD") || tab.contains("OVERVIEW")) renderCricketScore(body,m);
            else if(tab.contains("SQUADS")) renderSquads(body,m);
            else if(tab.contains("COMMENTARY") || tab.contains("LIVE")) renderCommentary(body,m);
            else renderCricketScore(body,m);
        } else if("football".equals(sport)) renderFootball(body,tab,m);
        else if("basketball".equals(sport)) renderBasketball(body,tab,m);
        else renderTennis(body,tab,m);
        page.addView(body);
    }

    private void renderCricketScore(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("RSA 1st Innings", "329-10  (82.3 Ov)"));
        String[][] rows={{"Aiden Markram","78","141","10","1","55.32"},{"M. Ackerman","95","94","12","2","101.06"},{"D. Bedingham","50","80","7","0","62.50"},{"T. Bavuma (c)","0","3","0","0","0.00"}};
        LinearLayout table=tableBox();
        table.addView(tableRow(new String[]{"Batter","R","B","4s","6s","SR"},true));
        for(String[] r:rows)table.addView(tableRow(r,false));
        body.addView(table);
        body.addView(sectionLabel("Bowling • AUS", "Overs, maidens, runs and wickets"));
        body.addView(statCard("Hazlewood","3/42","12.3 overs"));
        body.addView(statCard("Starc","2/51","14 overs"));
        body.addView(statCard("Fall of wickets","1-44, 2-132, 3-218","Partnerships available"));
        body.addView(statCard("Extras","14","Total 343"));
    }

    private void renderSquads(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Squads", "Players and roles"));
        String[][] players={{"🇿🇦","Aiden Markram","All-rounder"},{"🇿🇦","T. Bavuma","Batter"},{"🇿🇦","K. Rabada","Bowler"},{"🇦🇺","M. Starc","Bowler"},{"🇦🇺","P. Cummins","Bowler"}};
        for(String[] p:players){
            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10),dp(8),dp(10),dp(8));
            row.setBackground(round(CARD,12));
            row.addView(tv(p[0],22,TEXT,false),new LinearLayout.LayoutParams(dp(44),dp(44)));
            LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);
            info.addView(tv(p[1],13,TEXT,true));info.addView(tv(p[2],10,MUTED,false));
            row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            body.addView(row, marginBottomParams(5));
        }
    }

    private void renderCommentary(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Commentary", "Over by over • live events"));
        String[] events={"82.3 • Wicket • outside edge to keeper","82.2 • 1 run • worked to square leg","82.1 • FOUR • driven through cover","81.6 • dot ball • good length","81.5 • 2 runs • clipped through midwicket"};
        for(int i=0;i<events.length;i++) body.addView(eventRow(events[i],i+1));
    }

    private void renderFootball(LinearLayout body,String tab,JSONObject m) {
        if(tab.contains("STATS")||tab.contains("OVERVIEW")){
            body.addView(sectionLabel("Match stats","Football match center"));
            body.addView(statCard("Possession","54% — 46%","Home — Away"));
            body.addView(statCard("Shots","12 — 9","On target 6 — 4"));
            body.addView(statCard("Corners","5 — 3","Cards 2 — 1"));
        } else if(tab.contains("LINEUPS")){
            body.addView(sectionLabel("Lineups","Starting XI and substitutions"));
            String[] ps={"Goalkeeper","Right Back","Centre Back","Left Back","Midfielder","Attacking Midfielder","Striker"};
            for(String p:ps)body.addView(eventRow(p+"  •  Player",1));
        } else {
            body.addView(sectionLabel("Match timeline","Goals, cards and substitutions"));
            body.addView(eventRow("78'  GOAL  •  Escorpiones Belen",1));
            body.addView(eventRow("64'  Yellow card  •  International San Carlos",2));
            body.addView(eventRow("51'  Substitution",3));
            body.addView(eventRow("45'  Half time",4));
        }
    }

    private void renderBasketball(LinearLayout body,String tab,JSONObject m) {
        body.addView(sectionLabel("Game center","Quarter-by-quarter"));
        body.addView(statCard("Q1","24 — 21","Q2 28 — 26"));
        body.addView(statCard("Q3","19 — 22","Q4 31 — 27"));
        body.addView(statCard("Top scorer","LeBron James • 31","Assists 8 • Rebounds 10"));
        body.addView(statCard("Team fouls","14 — 17","Timeouts 2 — 3"));
    }

    private void renderTennis(LinearLayout body,String tab,JSONObject m) {
        body.addView(sectionLabel("Tennis match center","Sets, games and player stats"));
        body.addView(statCard("Set 1","6 — 4","Completed"));
        body.addView(statCard("Set 2","3 — 6","Completed"));
        body.addView(statCard("Set 3","4 — 2","Live"));
        body.addView(statCard("Aces","8 — 5","First serve 67% — 61%"));
    }

    private void showEntertainment(String category, boolean push) {
        if(push) push("ent:" + category);
        screen="entertainment";
        selectedEntertainment=category;
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar(category,true));
        if("TV".equals(category)) buildTvFront(page);
        else if("Movies".equals(category)) buildMediaFront(page,"Movies");
        else if("News".equals(category)) buildMediaFront(page,"News");
        else buildMediaFront(page,category);
    }

    private void buildTvFront(LinearLayout page) {
        LinearLayout hero=heroBanner("Featured Channel","Live TV • Sports • News","WATCH LIVE",BLUE);
        hero.setOnClickListener(v->playFirstChannel());
        page.addView(hero);
        page.addView(sectionLabel("TV Channels","Live channels and categories"));
        LinearLayout list=new LinearLayout(this);
        list.setPadding(dp(12),0,dp(12),dp(12));
        String[] demo={"BTV News","Star Sports","Sony Entertainment","ATN News"};
        for(String n:demo){
            LinearLayout c=channelTile(n);
            c.setOnClickListener(v->playFirstChannel());
            list.addView(c,weighted());
        }
        page.addView(list);
        page.addView(sectionLabel("Live TV Player","In-app playback"));
        page.addView(buildPlayerCard());
        addScroll(page);
    }

    private void buildMediaFront(LinearLayout page,String type) {
        page.addView(heroBanner("Featured "+type,"Curated entertainment for ONE TV","WATCH NOW",PURPLE));
        page.addView(sectionLabel(type,"Backend-controlled content"));
        String[] titles={"The Last Mission","Matchday Highlights","Top Headlines","Prime Time","Kids Zone","New Releases"};
        for(String t:titles) page.addView(contentRow(t,type));
        addScroll(page);
    }

    private LinearLayout heroBanner(String title,String sub,String action,int accent) {
        LinearLayout h=new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);
        h.setPadding(dp(16),dp(15),dp(16),dp(15));
        h.setBackground(round(Color.rgb(24,34,55),17));
        TextView a=tv(title,19,TEXT,true);
        TextView b=tv(sub,11,MUTED,false);
        Button c=smallButton(action,accent);
        h.addView(a);h.addView(b);h.addView(c,new LinearLayout.LayoutParams(-2,dp(36)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(12),dp(8),dp(12),dp(10));h.setLayoutParams(p);
        return h;
    }

    private View buildPlayerCard() {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10),dp(10),dp(10),dp(10));
        box.setBackground(round(PANEL,16));
        FrameLayout frame=new FrameLayout(this);
        frame.setBackgroundColor(Color.BLACK);
        PlayerView pv=new PlayerView(this);
        pv.setUseController(true);
        frame.addView(pv,new FrameLayout.LayoutParams(-1,dp(190)));
        box.addView(frame);
        TextView label=tv("LIVE TV • In-app player",11,GREEN,true);
        box.addView(label);
        box.setOnClickListener(v->playFirstChannel());
        return box;
    }

    private void playFirstChannel() {
        if(channels.isEmpty()){
            showSimple("Live TV","No channel is configured yet. Connect the backend to add authorized streams.");
            return;
        }
        Channel c=channels.get(0);
        if(c.url==null||c.url.isEmpty()){
            showSimple(c.name,"The channel source is not configured.");
            return;
        }
        screen="player";
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar(c.name,false));
        FrameLayout frame=new FrameLayout(this);
        frame.setBackgroundColor(Color.BLACK);
        playerView=new PlayerView(this);
        playerView.setUseController(true);
        frame.addView(playerView,new FrameLayout.LayoutParams(-1,dp(220)));
        page.addView(frame);
        TextView full = tv("⛶  FULLSCREEN", 11, TEXT, true);
        full.setGravity(Gravity.CENTER);
        full.setBackground(round(CARD, 12));
        full.setPadding(0, dp(8), 0, dp(8));
        full.setOnClickListener(v -> toggleFullscreen());
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(42));
        fp.setMargins(dp(12), dp(8), dp(12), dp(2));
        page.addView(full, fp);
        page.addView(sectionLabel("Now Playing",c.program));
        page.addView(tv("Playback stays inside ONE TV. Use the player controls for volume, seek and fullscreen.",11,MUTED,false));
        addScroll(page);
        if(player!=null)player.release();
        player=new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        try{player.setMediaItem(MediaItem.fromUri(Uri.parse(c.url)));player.prepare();player.play();}catch(Exception ignored){}
    }

    private void loadChannels() {
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")) return;
        network.execute(()->{
            try{
                JSONObject root=new JSONObject(getUrl(BACKEND_URL+"/channels"));
                JSONArray arr=root.optJSONArray("channels");
                if(arr==null)return;
                List<Channel> temp=new ArrayList<>();
                for(int i=0;i<arr.length();i++){
                    JSONObject o=arr.optJSONObject(i);
                    if(o==null)continue;
                    temp.add(new Channel(o.optString("name","Channel"),o.optString("url",o.optString("sourceUrl","")),o.optString("program","")));
                }
                runOnUiThread(()->{channels.clear();channels.addAll(temp);});
            }catch(Exception ignored){}
        });
    }


    private void loadAdConfig() {
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")) return;
        network.execute(()->{
            try {
                JSONObject cfg=new JSONObject(getUrl(BACKEND_URL+"/ads"));
                adConfig=cfg;
                JSONArray active=cfg.optJSONArray("activePlatforms");
                boolean admobActive=false;
                if(active!=null) for(int i=0;i<active.length();i++){ JSONObject a=active.optJSONObject(i); if(a!=null && "admob".equalsIgnoreCase(a.optString("platform_key"))){ admobActive=true; break; } }
                final boolean enabled=admobActive;
                runOnUiThread(()->{ if(adRow!=null) adRow.setVisibility(enabled?View.VISIBLE:View.GONE); });
            } catch(Exception ignored) {}
        });
    }

    private void showSimple(String title,String subtitle) {
        clearContent();
        screen="simple";
        LinearLayout page=page();
        page.addView(selectedSectionBar(title,false));
        page.addView(sectionLabel(title,subtitle));
        page.addView(statCard("ONE TV","USHA IT","All in One"));
        addScroll(page);
    }

    private void clearContent() {
        if(contentHost!=null)contentHost.removeAllViews();
        if(statusText!=null)statusText=null;
    }

    private LinearLayout page() {
        LinearLayout p=new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundColor(BG);
        return p;
    }

    private void addScroll(LinearLayout page) {
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));
        contentHost.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
    }

    private LinearLayout modeRow() {
        LinearLayout row=new LinearLayout(this);
        row.setPadding(dp(12),dp(8),dp(12),dp(7));
        TextView s=modeButton("SPORTS",BLUE);
        s.setOnClickListener(v->showSportsHome(true));
        TextView e=modeButton("ENTERTAINMENT",PURPLE);
        e.setOnClickListener(v->showEntertainment("TV",true));
        row.addView(s,weighted());
        row.addView(e,weighted());
        return row;
    }

    private View selectedSectionBar(String name,boolean entertainment) {
        LinearLayout bar=new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14),dp(8),dp(14),dp(8));
        TextView icon=tv(entertainment?"▣":"🏆",21,TEXT,false);
        bar.addView(icon,new LinearLayout.LayoutParams(dp(40),dp(48)));
        TextView title=tv(name+"  ▾",18,TEXT,true);
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));
        TextView search=tv("⌕",23,TEXT,false);
        search.setGravity(Gravity.CENTER);
        bar.addView(search,new LinearLayout.LayoutParams(dp(42),dp(48)));
        return bar;
    }

    private View sectionLabel(String title, String sub) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(18), dp(8), dp(18), dp(6));
        TextView t = tv(title, 18, TEXT, true);
        TextView s = tv(sub, 10, MUTED, false);
        wrap.addView(t);
        if (sub != null && !sub.isEmpty()) wrap.addView(s);
        return wrap;
    }

    private TextView modeButton(String label,int accent) {
        TextView b=tv(label,13,TEXT,true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(CARD,15));
        b.setPadding(0,0,0,0);
        return b;
    }

    private LinearLayout featureTile(String icon,String name,int accent) {
        LinearLayout c=new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(3),dp(8),dp(3),dp(8));
        c.setBackground(round(CARD_2,13));
        TextView i=tv(icon,25,TEXT,false);i.setGravity(Gravity.CENTER);
        TextView n=tv(name,11,TEXT,true);n.setGravity(Gravity.CENTER);
        c.addView(i,new LinearLayout.LayoutParams(-1,dp(36)));
        c.addView(n);
        LinearLayout.LayoutParams p=weighted();
        p.setMargins(dp(3),0,dp(3),0);
        c.setLayoutParams(p);
        return c;
    }

    private LinearLayout scoreTeam(String flag,String name,String score) {
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setGravity(Gravity.CENTER);
        b.addView(tv(flag,18,TEXT,false));
        b.addView(tv(name,14,Color.BLACK,true));
        b.addView(tv(score,14,Color.BLACK,true));
        return b;
    }

    private LinearLayout channelTile(String name) {
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);
        c.setPadding(dp(4),dp(8),dp(4),dp(8));c.setBackground(round(Color.WHITE,10));
        TextView icon=tv("▣",22,BLUE,true);icon.setGravity(Gravity.CENTER);
        TextView n=tv(name,9,Color.DKGRAY,true);n.setGravity(Gravity.CENTER);n.setMaxLines(2);
        c.addView(icon,new LinearLayout.LayoutParams(-1,dp(32)));c.addView(n);
        return c;
    }

    private LinearLayout contentRow(String title,String type) {
        LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(12),dp(9),dp(12),dp(9));r.setBackground(round(CARD,12));
        TextView icon=tv(type.equals("News")?"▤":"▶",20,TEXT,false);r.addView(icon,new LinearLayout.LayoutParams(dp(45),dp(45)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.addView(tv(title,13,TEXT,true));info.addView(tv(type+" • ONE TV",10,MUTED,false));
        r.addView(info,new LinearLayout.LayoutParams(0,-2,1));r.addView(tv("›",24,MUTED,false));
        return r;
    }

    private TextView tab(String label,boolean active) {
        TextView b=tv(label,10,active?TEXT:MUTED,true);
        b.setGravity(Gravity.CENTER);b.setBackground(round(active?BLUE:CARD,18));
        b.setPadding(dp(2),0,dp(2),0);
        return b;
    }

    private Button smallButton(String label,int color) {
        Button b=new Button(this);b.setText(label);b.setTextSize(10);b.setTextColor(TEXT);b.setAllCaps(false);b.setMinHeight(0);b.setMinWidth(0);b.setPadding(dp(12),0,dp(12),0);b.setBackground(round(color,18));return b;
    }

    private TextView eventRow(String value,int n) {
        TextView t=tv(value,12,TEXT,false);t.setPadding(dp(12),dp(11),dp(12),dp(11));t.setBackground(round(CARD,12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(6));t.setLayoutParams(p);return t;
    }

    private View statCard(String title,String value,String sub) {
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(13),dp(10),dp(13),dp(10));r.setBackground(round(CARD,12));
        r.addView(tv(title,10,MUTED,true));r.addView(tv(value,16,TEXT,true));r.addView(tv(sub,10,MUTED,false));return r;
    }

    private LinearLayout tableBox() {
        LinearLayout t=new LinearLayout(this);t.setOrientation(LinearLayout.VERTICAL);t.setBackground(round(CARD,12));return t;
    }

    private LinearLayout tableRow(String[] values,boolean header) {
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(6),dp(6),dp(6),dp(6));
        for(int i=0;i<values.length;i++){TextView v=tv(values[i],header?8.5f:9.5f,header?MUTED:TEXT,header);v.setGravity(i==0?Gravity.LEFT:Gravity.CENTER);row.addView(v,new LinearLayout.LayoutParams(0,dp(32),i==0?2.3f:1));}
        row.setBackgroundColor(header?Color.rgb(25,45,59):Color.TRANSPARENT);return row;
    }

    private LinearLayout detailRow(String left,String right) {
        LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(10),dp(8),dp(10),dp(8));r.setBackground(round(CARD,10));r.addView(tv(left,12,TEXT,true),new LinearLayout.LayoutParams(0,-2,1));r.addView(tv(right,12,MUTED,false));return r;
    }

    private LinearLayout.LayoutParams marginBottomParams(int dp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, this.dp(dp));
        return p;
    }

    private LinearLayout.LayoutParams weighted() { return new LinearLayout.LayoutParams(0, -2, 1); }

    private JSONObject demoMatch(String sport,String title) {
        JSONObject m=new JSONObject();
        try{
            m.put("sport",sport);
            m.put("title",title);
            m.put("competition",sportName(sport)+" • Match Center");
            m.put("status","LIVE");
            m.put("result","Live • Updated just now");
            m.put("date","Today • Local time");
            JSONObject h=new JSONObject(),a=new JSONObject();
            if("cricket".equals(sport)){h.put("name","RSA");h.put("flag","🇿🇦");h.put("score","329 & 387");a.put("name","AUS");a.put("flag","🇦🇺");a.put("score","429 & 111");}
            else if("football".equals(sport)){h.put("name","International San Carlos");h.put("flag","◉");h.put("score","2");a.put("name","Escorpiones Belen");a.put("flag","◉");a.put("score","3");m.put("status","finished");}
            else if("basketball".equals(sport)){h.put("name","Lakers");h.put("flag","LAL");h.put("score","102");a.put("name","Warriors");a.put("flag","GSW");a.put("score","98");}
            else {h.put("name","Alcaraz");h.put("flag","ES");h.put("score","2");a.put("name","Sinner");a.put("flag","IT");a.put("score","1");}
            m.put("home",h);m.put("away",a);
        }catch(Exception ignored){}
        return m;
    }

    private JSONObject team(JSONObject m,boolean home) {
        JSONObject t=m.optJSONObject(home?"home":"away");
        return t==null?new JSONObject():t;
    }

    private String sportName(String s) {
        if(s==null)return "Sports";
        if("football".equalsIgnoreCase(s)||"soccer".equalsIgnoreCase(s))return "Football";
        if("basketball".equalsIgnoreCase(s))return "Basketball";
        if("tennis".equalsIgnoreCase(s))return "Tennis";
        return "Cricket";
    }

    private void push(String state) {
        if(screen!=null&&!screen.equals(state))history.push(screen);
    }

    @Override public void onBackPressed() {
        if(fullscreen){exitFullscreen();return;}
        if(!history.empty()){
            String prev=history.pop();
            if("home".equals(prev))showHome(false);
            else if("sportsHome".equals(prev))showSportsHome(false);
            else if(prev.startsWith("sport:"))showSports(prev.substring(6),false);
            else if(prev.startsWith("ent:"))showEntertainment(prev.substring(4),false);
            else if("match".equals(prev)&&selectedMatch!=null)showMatchDetail(false);
            else showHome(false);
        }else super.onBackPressed();
    }

    private void exitFullscreen() {
        fullscreen=false;
        getWindow().getDecorView().setSystemUiVisibility(0);
        if(playerView!=null)playerView.setVisibility(View.VISIBLE);
    }

    private void toggleFullscreen() {
        if (playerView == null) return;
        ViewGroup decor = (ViewGroup) getWindow().getDecorView();
        if (!fullscreen) {
            playerOriginalParent = (ViewGroup) playerView.getParent();
            playerOriginalIndex = playerOriginalParent == null ? 0 : playerOriginalParent.indexOfChild(playerView);
            if (playerOriginalParent != null) playerOriginalParent.removeView(playerView);
            decor.addView(playerView, new ViewGroup.LayoutParams(-1, -1));
            playerView.setVisibility(View.VISIBLE);
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            if (adRow != null) adRow.setVisibility(View.GONE);
            if (bottomBar != null) bottomBar.setVisibility(View.GONE);
            if (footer != null) footer.setVisibility(View.GONE);
            fullscreen = true;
        } else {
            decor.removeView(playerView);
            if (playerOriginalParent != null) {
                playerOriginalParent.addView(playerView, Math.min(playerOriginalIndex, playerOriginalParent.getChildCount()),
                        new FrameLayout.LayoutParams(-1, dp(220)));
            }
            getWindow().getDecorView().setSystemUiVisibility(0);
            if (adRow != null) adRow.setVisibility(View.VISIBLE);
            if (bottomBar != null) bottomBar.setVisibility(View.VISIBLE);
            if (footer != null) footer.setVisibility(View.VISIBLE);
            fullscreen = false;
        }
    }

    private void hideAds(boolean hide){if(adRow!=null)adRow.setVisibility(hide?View.GONE:View.VISIBLE);if(footer!=null)footer.setVisibility(hide?View.GONE:View.VISIBLE);if(bottomBar!=null)bottomBar.setVisibility(hide?View.GONE:View.VISIBLE);}


    private TextView tv(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(android.graphics.Typeface.DEFAULT,bold?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL);t.setIncludeFontPadding(false);return t;}

    private GradientDrawable round(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}

    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}

    private LinearLayout.LayoutParams weightedLp(){return new LinearLayout.LayoutParams(0,-2,1);}

    private JSONObject getJson(String url){try{return new JSONObject(getUrl(url));}catch(Exception e){return new JSONObject();}}

    private String getUrl(String address)throws Exception{
        HttpURLConnection c=null;
        try{
            URL u=new URL(address);c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);c.setRequestMethod("GET");
            int code=c.getResponseCode();
            InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
            if(in==null)throw new Exception("HTTP "+code);
            BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder sb=new StringBuilder();String line;
            while((line=r.readLine())!=null)sb.append(line);
            return sb.toString();
        }finally{if(c!=null)c.disconnect();}
    }

    private static class Channel {
        String name,url,program;
        Channel(String n,String u,String p){name=n;url=u;program=p;}
    }

    @Override protected void onDestroy(){
        handler.removeCallbacksAndMessages(null);
        network.shutdownNow();
        if(player!=null){player.release();player=null;}
        super.onDestroy();
    }
}
