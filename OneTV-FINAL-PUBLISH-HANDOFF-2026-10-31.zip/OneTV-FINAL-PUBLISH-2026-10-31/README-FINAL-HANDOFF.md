# One TV Final Handoff

This package contains the final source pass and the original uploaded release APK/AAB.

Important: the APK/AAB in `original-release-artifacts` are the binaries supplied before the final source fixes. They are retained for reference and signature verification only. They are not the newly modified 1.6 binary.

The final source is in `source/`.
