# One TV Sports Pro UI V3

The sports surface keeps the existing One TV navigation and adds a professional live-score platform layer:

- Live / Upcoming / Results
- professional match cards with team logos and scores
- clickable competition headings for standings
- clickable team names for team pages
- clickable player names for player profiles
- match center with Scorecard, Ball by Ball, Stats and Standings
- cricket innings tables, batter/bowler figures and player photos when supplied by the API
- live batsman and bowler panels when the provider returns those fields
- responsive vertical cards suitable for narrow Android screens
- pull-to-refresh and manual refresh
- complete video fullscreen remains separate from the sports UI
- backend-driven channel/source management remains unchanged

The UI is data-driven: if the provider returns richer player, scorecard, commentary or statistics fields, the pages can render them without another APK architecture change.
