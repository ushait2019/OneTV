# One TV Sports Pro Backend V3

## Sports data flow
- SportScore is always the primary provider.
- Cricket list and match-detail requests fall back to OpenCricket only after SportScore fails or returns unusable data.
- SportScore and OpenCricket are never called in parallel.
- OpenCricket API key remains a Cloudflare Worker secret.

## New sports entity endpoints
- GET `/sports/{sport}/standings/{competition-slug}`
- GET `/sports/{sport}/player/{player-slug}`
- GET `/sports/{sport}/team/{team-slug}`
- GET `/sports/{sport}/topscorers/{competition-slug}?stat=goals`

These endpoints are SportScore-backed and return the provider plus upstream data so the Android app can render richer pages without another APK build.

## Match detail normalization
Match details preserve and normalize:
- teams, logos, scores and slugs
- competition and competition slug
- venue and start time
- innings / scorecard data
- timeline / commentary / ball-by-ball events
- lineups / player photo and profile identifiers
- match statistics
- raw upstream match data for forward-compatible UI fields

## One TV video control
The existing backend channel system remains remote-controlled through the admin panel. Channels can be added, edited, disabled or deleted, and their direct stream, API source or YouTube source can be changed without rebuilding the APK.
