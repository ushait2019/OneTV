package com.ushait.onetv;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;

import androidx.core.graphics.Insets;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final String ADMOB_LIVE_BANNER_ID = "ca-app-pub-5981864080922785/5178976268";
    private static final String ADMOB_TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111";
    private static final String ADMOB_LIVE_INTERSTITIAL_ID = "ca-app-pub-5981864080922785/7592231664";
    private static final String ADMOB_TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712";
    private static final String ADMOB_LIVE_NATIVE_ID = "ca-app-pub-5981864080922785/1737269754";
    private static final String ADMOB_TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110";
    private static final String BACKEND_URL = BuildConfig.BACKEND_URL;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final List<Channel> channels = new ArrayList<>();
    private final String viewerId = UUID.randomUUID().toString();

    private ExoPlayer player;
    private PlayerView playerView;
    private WebView youtubeWebView;
    private LinearLayout playerContainer;
    private LinearLayout playerControls;
    private LinearLayout contentHost;
    private LinearLayout adSection;
    private LinearLayout nowPlayingBlock;
    private TextView channelsTitle;
    private ScrollView channelScroll;
    private FrameLayout videoFrame;
    private int normalPlayerHeight;
    private TextView footerView;
    private FrameLayout noticeContainer;
    private WebView noticeWebView;
    private LinearLayout channelList;
    private LinearLayout categoryList;
    private HorizontalScrollView categoryScroll;
    private ImageButton pauseResumeButton;
    private LinearLayout cricketContainer;
    private LinearLayout cricketList;
    private TextView cricketHeader;
    private TextView cricketUpdated;
    private TextView nowPlayingName;
    private TextView nowPlayingProgram;
    private TextView viewerCountView;
    private Button sportsRefreshButton;
    private Button themeToggleButton;
    private LinearLayout rootLayout;
    private SwipeRefreshLayout sportsSwipeRefresh;
    private SeekBar timelineSeekBar;
    private PopupWindow volumePopup;
    private int lastVolume = 100;
    private final Runnable timelineUpdater = new Runnable() {
        @Override public void run() {
            updateTimeline();
            handler.postDelayed(this, 500);
        }
    };
    private SharedPreferences prefs;
    private boolean darkMode = false;
    private int sportsRefreshMs = 20000;

    private int currentIndex = 0;
    private boolean controlsVisible = false;
    private boolean playbackPaused = false;
    private String currentCategory = "TV";
    private String cricketMode = "live";
    private String currentSport = "cricket";
    private boolean cricketDetail = false;
    private InterstitialAd interstitialAd;
    private int navigationAdCounter = 0;
    private long lastInterstitialShownAt = 0L;
    private static final long INTERSTITIAL_COOLDOWN_MS = 120000L;
    private NativeAd nativeAd;
    private NativeAdView nativeAdView;
    private boolean isFullscreen = false;
    private ViewGroup videoFrameOriginalParent;
    private int videoFrameOriginalIndex = 0;
    private boolean youtubeReady = false;
    private String pendingYoutubeCommand = null;
    private String sportsPage = "matches";
    private String currentMatchId = "";
    private String currentCompetitionSlug = "";
    private String currentPlayerSlug = "";
    private JSONObject currentMatchObject = null;
    private long sportsRequestToken = 0L;
    private Notice activeNotice;

    private final Runnable refreshContent = new Runnable() {
        @Override public void run() {
            loadBackendContent();
            handler.postDelayed(this, 60000);
        }
    };
    private final Runnable cricketRefresh = new Runnable() {
        @Override public void run() {
            if ("Cricket Live".equals(currentCategory) && !cricketDetail) loadCricket(cricketMode);
            else if (currentCategory.startsWith("SPORT:") && !cricketDetail) loadSport(currentSport, cricketMode);
            handler.postDelayed(this, sportsRefreshMs);
        }
    };
    private final Runnable viewerHeartbeat = new Runnable() {
        @Override public void run() {
            pingViewer();
            handler.postDelayed(this, 30000);
        }
    };
    private final Runnable hideControls = new Runnable() {
        @Override public void run() { setControlsVisible(false); }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("onetv_preferences", MODE_PRIVATE);
        darkMode = prefs.getBoolean("dark_mode", false);
        applySystemTheme();
        MobileAds.initialize(this, status -> {});
        buildUi();
        loadInterstitialAd();
        loadNativeAd();
        loadRemoteConfig();
        loadBackendContent();
        handler.postDelayed(refreshContent, 60000);
        handler.postDelayed(cricketRefresh, sportsRefreshMs);
        handler.post(timelineUpdater);
        handler.postDelayed(viewerHeartbeat, 30000);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        rootLayout = root;
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(themeBackground());
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(0, bars.top, 0, bars.bottom);
            return insets;
        });

        FrameLayout brandHeader = new FrameLayout(this);
        brandHeader.setPadding(8, 6, 8, 2);
        brandHeader.setMinimumHeight(92);

        LinearLayout centerBrand = new LinearLayout(this);
        centerBrand.setOrientation(LinearLayout.VERTICAL);
        centerBrand.setGravity(Gravity.CENTER);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.onetv_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setAdjustViewBounds(true);
        centerBrand.addView(logo, new LinearLayout.LayoutParams(dp(150), dp(54)));
        TextView slogan = text("All in One", 13, themeSecondaryText(), true);
        slogan.setGravity(Gravity.CENTER);
        centerBrand.addView(slogan, new LinearLayout.LayoutParams(-1, dp(24)));
        FrameLayout.LayoutParams centerLp = new FrameLayout.LayoutParams(dp(210), -1, Gravity.CENTER);
        brandHeader.addView(centerBrand, centerLp);

        themeToggleButton = new Button(this);
        themeToggleButton.setText(darkMode ? "☀" : "☾");
        themeToggleButton.setTextSize(18);
        themeToggleButton.setAllCaps(false);
        themeToggleButton.setTextColor(themePrimaryText());
        themeToggleButton.setGravity(Gravity.CENTER);
        themeToggleButton.setMinHeight(0);
        themeToggleButton.setMinWidth(0);
        themeToggleButton.setPadding(0, 0, 0, 0);
        themeToggleButton.setBackground(round(themePill(), 14));
        themeToggleButton.setContentDescription(darkMode ? "Switch to light mode" : "Switch to dark mode");
        themeToggleButton.setOnClickListener(v -> toggleTheme());
        FrameLayout.LayoutParams themeLp = new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.END | Gravity.CENTER_VERTICAL);
        themeLp.rightMargin = dp(8);
        brandHeader.addView(themeToggleButton, themeLp);
        root.addView(brandHeader, new LinearLayout.LayoutParams(-1, dp(94)));

        LinearLayout mainNav = new LinearLayout(this);
        mainNav.setGravity(Gravity.CENTER);
        mainNav.setPadding(dp(12), dp(4), dp(12), dp(8));
        Button sportsMenu = pillButton("SPORTS  ▾", 13.5f, dp(46));
        Button entertainmentMenu = pillButton("ENTERTAINMENT  ▾", 13.5f, dp(46));
        sportsMenu.setOnClickListener(v -> showSportsMenu(sportsMenu));
        entertainmentMenu.setOnClickListener(v -> showEntertainmentMenu(entertainmentMenu));
        LinearLayout.LayoutParams navLp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        navLp.setMargins(0, 0, dp(6), 0);
        mainNav.addView(sportsMenu, navLp);
        LinearLayout.LayoutParams navLp2 = new LinearLayout.LayoutParams(0, dp(46), 1f);
        navLp2.setMargins(dp(6), 0, 0, 0);
        mainNav.addView(entertainmentMenu, navLp2);
        root.addView(mainNav, new LinearLayout.LayoutParams(-1, dp(58)));

        categoryScroll = new HorizontalScrollView(this);
        categoryScroll.setHorizontalScrollBarEnabled(false);
        categoryList = new LinearLayout(this);
        categoryList.setGravity(Gravity.CENTER_VERTICAL);
        categoryList.setPadding(dp(12), 0, dp(12), dp(8));
        categoryScroll.addView(categoryList, new ViewGroup.LayoutParams(-2, -2));
        categoryScroll.setVisibility(View.GONE);
        root.addView(categoryScroll, new LinearLayout.LayoutParams(-1, dp(54)));

        // Main content occupies all space between the top menu and the fixed ad/footer.
        FrameLayout contentFrame = new FrameLayout(this);
        root.addView(contentFrame, new LinearLayout.LayoutParams(-1, 0, 1f));

        playerContainer = new LinearLayout(this);
        playerContainer.setOrientation(LinearLayout.VERTICAL);
        buildPlayerArea();
        contentFrame.addView(playerContainer, new FrameLayout.LayoutParams(-1, -1));

        nowPlayingBlock = new LinearLayout(this);
        nowPlayingBlock.setOrientation(LinearLayout.VERTICAL);
        nowPlayingBlock.setPadding(16, 8, 16, 8);
        nowPlayingName = text("", 17, themePrimaryText(), true);
        nowPlayingProgram = text("", 13, themeSecondaryText(), false);
        viewerCountView = text("", 12, themeSecondaryText(), false);
        nowPlayingBlock.addView(nowPlayingName);
        nowPlayingBlock.addView(nowPlayingProgram);
        nowPlayingBlock.addView(viewerCountView);
        playerContainer.addView(nowPlayingBlock);

        noticeContainer = new FrameLayout(this);
        noticeWebView = new WebView(this);
        WebSettings ws = noticeWebView.getSettings();
        ws.setJavaScriptEnabled(false);
        ws.setDomStorageEnabled(false);
        ws.setAllowFileAccess(false);
        noticeWebView.setBackgroundColor(Color.TRANSPARENT);
        noticeWebView.setWebViewClient(new WebViewClient());
        noticeContainer.addView(noticeWebView, new FrameLayout.LayoutParams(-1, -1));
        playerContainer.addView(noticeContainer, new LinearLayout.LayoutParams(-1, 0));

        channelsTitle = text("Channels", 18, themePrimaryText(), true);
        channelsTitle.setPadding(18, 12, 18, 8);
        playerContainer.addView(channelsTitle);

        channelScroll = new ScrollView(this);
        channelList = new LinearLayout(this);
        channelList.setOrientation(LinearLayout.VERTICAL);
        channelList.setPadding(12, 0, 12, 8);
        channelScroll.addView(channelList);
        playerContainer.addView(channelScroll, new LinearLayout.LayoutParams(-1, 0, 1));

        cricketContainer = buildCricketArea();
        contentFrame.addView(cricketContainer, new FrameLayout.LayoutParams(-1, -1));
        cricketContainer.setVisibility(View.GONE);

        // The general ad strip is fixed at the bottom for every non-fullscreen screen,
        // including Cricket Live. It is hidden only during video fullscreen.
        adSection = buildAdSection(root);
        root.addView(adSection, new LinearLayout.LayoutParams(-1, -2));

        footerView = text("© 2026 USHA IT. All Rights Reserved.", 12, Color.GRAY, false);
        footerView.setGravity(Gravity.CENTER);
        footerView.setPadding(8, 8, 8, 10);
        root.addView(footerView, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        if (player != null) playerView.setPlayer(player);
        rebuildCategories();
        showCategory(currentCategory);
        hideNotice();
        applyThemeToViewTree(root, false);
    }

    private void buildPlayerArea() {
        videoFrame = new FrameLayout(this);
        videoFrame.setBackgroundColor(Color.BLACK);
        int playerHeight = Math.max(dp(220), (int) (getResources().getDisplayMetrics().widthPixels * 0.5625f));
        normalPlayerHeight = playerHeight;

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        videoFrame.addView(playerView, new FrameLayout.LayoutParams(-1, playerHeight));

        youtubeWebView = new WebView(this);
        WebSettings yws = youtubeWebView.getSettings();
        yws.setJavaScriptEnabled(true);
        yws.setDomStorageEnabled(true);
        yws.setMediaPlaybackRequiresUserGesture(false);
        yws.setAllowFileAccess(false);
        youtubeWebView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                handler.postDelayed(() -> {
                    youtubeReady = true;
                    if (pendingYoutubeCommand != null) {
                        String cmd = pendingYoutubeCommand; pendingYoutubeCommand = null;
                        sendYouTubeCommand(cmd, "[]");
                    }
                }, 900);
            }
        });
        youtubeWebView.setBackgroundColor(Color.BLACK);
        videoFrame.addView(youtubeWebView, new FrameLayout.LayoutParams(-1, playerHeight));
        youtubeWebView.setVisibility(View.GONE);

        playerControls = new LinearLayout(this);
        playerControls.setOrientation(LinearLayout.HORIZONTAL);
        playerControls.setGravity(Gravity.CENTER_VERTICAL);
        playerControls.setPadding(dp(8), dp(4), dp(8), dp(4));
        playerControls.setBackgroundColor(Color.argb(225, 0, 0, 0));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, dp(50), Gravity.BOTTOM);
        videoFrame.addView(playerControls, cp);

        pauseResumeButton = playerIconButton(R.drawable.ic_play, "Play or pause", v -> togglePlayback());
        playerControls.addView(pauseResumeButton, controlFixed(dp(36)));

        ImageButton volumeIcon = playerIconButton(R.drawable.ic_volume, "Mute or unmute and show volume", v -> { toggleMute(); showVolumePopup(v); });
        playerControls.addView(volumeIcon, controlFixed(dp(36)));

        timelineSeekBar = new SeekBar(this);
        timelineSeekBar.setMax(1000);
        timelineSeekBar.setProgress(0);
        timelineSeekBar.setPadding(0, 0, 0, 0);
        timelineSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || player == null || !player.isCurrentMediaItemSeekable()) return;
                long duration = player.getDuration();
                if (duration > 0) player.seekTo((duration * progress) / 1000L);
            }
            public void onStartTrackingTouch(SeekBar seekBar) { handler.removeCallbacks(hideControls); }
            public void onStopTrackingTouch(SeekBar seekBar) { showControlsTemporarily(); }
        });
        LinearLayout.LayoutParams timelineLp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        timelineLp.setMargins(dp(3), 0, dp(6), 0);
        playerControls.addView(timelineSeekBar, timelineLp);

        ImageButton quality = playerIconButton(R.drawable.ic_settings, "Quality", v -> showQualityMenu(v));
        playerControls.addView(quality, controlFixed(dp(36)));

        ImageButton fullscreen = playerIconButton(R.drawable.ic_fullscreen, "Fullscreen", v -> toggleFullscreen());
        playerControls.addView(fullscreen, controlFixed(dp(36)));

        playerView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) toggleControls();
            return true;
        });
        youtubeWebView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) showControlsTemporarily();
            return false;
        });

        playerContainer.addView(videoFrame, 0, new LinearLayout.LayoutParams(-1, playerHeight));
        playerControls.setVisibility(View.GONE);
    }

    private void loadInterstitialAd() {
        boolean debug = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        String unit = debug ? ADMOB_TEST_INTERSTITIAL_ID : ADMOB_LIVE_INTERSTITIAL_ID;
        AdRequest request = new AdRequest.Builder().build();
        InterstitialAd.load(this, unit, request, new InterstitialAdLoadCallback() {
            @Override public void onAdLoaded(InterstitialAd ad) { interstitialAd = ad; }
            @Override public void onAdFailedToLoad(LoadAdError error) { interstitialAd = null; }
        });
    }

    private void maybeShowInterstitial() {
        if (isFullscreen || interstitialAd == null) return;
        long now = System.currentTimeMillis();
        if (now - lastInterstitialShownAt < INTERSTITIAL_COOLDOWN_MS) return;
        InterstitialAd ad = interstitialAd;
        interstitialAd = null;
        lastInterstitialShownAt = now;
        ad.setFullScreenContentCallback(new com.google.android.gms.ads.FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() { loadInterstitialAd(); }
            @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) { loadInterstitialAd(); }
        });
        ad.show(this);
    }

    private void loadNativeAd() {
        boolean debug = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        String unit = debug ? ADMOB_TEST_NATIVE_ID : ADMOB_LIVE_NATIVE_ID;
        AdLoader loader = new AdLoader.Builder(this, unit)
                .forNativeAd(ad -> {
                    if (nativeAdView != null && nativeAdView.getParent() != null) {
                        ((ViewGroup) nativeAdView.getParent()).removeView(nativeAdView);
                    }
                    if (nativeAd != null) nativeAd.destroy();
                    nativeAd = ad;
                    runOnUiThread(this::insertNativeAdIntoCurrentList);
                })
                .withAdListener(new AdListener() {
                    @Override public void onAdFailedToLoad(LoadAdError error) { nativeAd = null; }
                })
                .build();
        loader.loadAd(new AdRequest.Builder().build());
    }

    private void insertNativeAdIntoCurrentList() {
        if (nativeAd == null || isFullscreen) return;
        if ("Cricket Live".equals(currentCategory)) {
            if (cricketList == null || cricketDetail) return;
            addNativeAdToList(cricketList, 3);
        } else {
            if (channelList == null) return;
            addNativeAdToList(channelList, 5);
        }
    }

    private void addNativeAdToList(LinearLayout list, int preferredIndex) {
        if (nativeAd == null || list == null) return;
        if (nativeAdView != null && nativeAdView.getParent() != null) {
            ((ViewGroup) nativeAdView.getParent()).removeView(nativeAdView);
        }
        nativeAdView = buildNativeAdView(nativeAd);
        int index = Math.min(preferredIndex, list.getChildCount());
        list.addView(nativeAdView, index);
    }

    private NativeAdView buildNativeAdView(NativeAd ad) {
        NativeAdView adView = new NativeAdView(this);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(16, 14, 16, 14);
        card.setBackground(round(themeCard(), 16));

        TextView label = text("ADVERTISEMENT", 9, Color.GRAY, true);
        card.addView(label, new LinearLayout.LayoutParams(-1, 22));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        top.addView(icon, new LinearLayout.LayoutParams(44, 44));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(10, 0, 0, 0);
        TextView headline = text("", 15, Color.WHITE, true);
        TextView advertiser = text("", 11, Color.GRAY, false);
        copy.addView(headline);
        copy.addView(advertiser);
        top.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(top);

        TextView body = text("", 12, Color.LTGRAY, false);
        body.setPadding(0, 8, 0, 8);
        card.addView(body);

        Button cta = pillButton("Learn more", 12, 44);
        cta.setTextColor(Color.WHITE);
        card.addView(cta, new LinearLayout.LayoutParams(-1, 44));

        adView.addView(card, new ViewGroup.LayoutParams(-1, -2));
        adView.setHeadlineView(headline);
        adView.setBodyView(body);
        adView.setIconView(icon);
        adView.setAdvertiserView(advertiser);
        adView.setCallToActionView(cta);

        headline.setText(ad.getHeadline());
        if (ad.getBody() != null && !ad.getBody().trim().isEmpty()) {
            body.setText(ad.getBody());
            body.setVisibility(View.VISIBLE);
        } else body.setVisibility(View.GONE);
        if (ad.getAdvertiser() != null && !ad.getAdvertiser().trim().isEmpty()) advertiser.setText(ad.getAdvertiser());
        else advertiser.setVisibility(View.GONE);
        if (ad.getCallToAction() != null && !ad.getCallToAction().trim().isEmpty()) cta.setText(ad.getCallToAction());
        else cta.setVisibility(View.GONE);
        if (ad.getIcon() != null && ad.getIcon().getDrawable() != null) icon.setImageDrawable(ad.getIcon().getDrawable());
        else icon.setVisibility(View.GONE);
        adView.setNativeAd(ad);
        return adView;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout smallHeaderAdSlot() {
        LinearLayout box = new LinearLayout(this); box.setGravity(Gravity.CENTER); box.setBackground(round(Color.rgb(18,24,31), 10));
        TextView t = text("AD", 9, Color.GRAY, true); t.setGravity(Gravity.CENTER); box.addView(t, new LinearLayout.LayoutParams(-1,-1)); return box;
    }
    private LinearLayout.LayoutParams controlFixed(int w) { LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,dp(36)); p.setMargins(dp(2),0,dp(2),0); return p; }

    private LinearLayout buildAdSection(ViewGroup parent) {
        LinearLayout adSection = new LinearLayout(this);
        adSection.setOrientation(LinearLayout.VERTICAL);
        adSection.setGravity(Gravity.CENTER);
        adSection.setBackgroundColor(Color.rgb(22, 27, 34));
        adSection.setPadding(8, 6, 8, 6);
        TextView label = text("ADVERTISEMENT", 10, Color.GRAY, false);
        label.setGravity(Gravity.CENTER);
        adSection.addView(label, new LinearLayout.LayoutParams(-1, 20));
        AdView adView = new AdView(this);
        int widthPx = getResources().getDisplayMetrics().widthPixels;
        float density = getResources().getDisplayMetrics().density;
        int adWidth = Math.max(1, (int) (widthPx / density));
        adView.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth));
        boolean debug = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        adView.setAdUnitId(debug ? ADMOB_TEST_BANNER_ID : ADMOB_LIVE_BANNER_ID);
        adView.loadAd(new AdRequest.Builder().build());
        adSection.addView(adView, new LinearLayout.LayoutParams(-1, -2));
        return adSection;
    }

    private LinearLayout buildCricketArea() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundColor(themeBackground());

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(10), dp(14), dp(4));
        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.VERTICAL);
        TextView eyebrow = text("ONE TV • SPORTS", 10, Color.rgb(0,137,123), true);
        cricketHeader = text("Cricket", 25, themePrimaryText(), true);
        heading.addView(eyebrow); heading.addView(cricketHeader);
        header.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        sportsRefreshButton = new Button(this);
        sportsRefreshButton.setText("REFRESH NOW"); sportsRefreshButton.setTextSize(11); sportsRefreshButton.setAllCaps(false);
        sportsRefreshButton.setTextColor(Color.WHITE); sportsRefreshButton.setMinHeight(0); sportsRefreshButton.setMinWidth(0);
        sportsRefreshButton.setPadding(0,0,0,0); sportsRefreshButton.setBackground(round(Color.rgb(20,112,196),16));
        sportsRefreshButton.setOnClickListener(v -> refreshCurrentSportsPage());
        header.addView(sportsRefreshButton, new LinearLayout.LayoutParams(dp(112), dp(40)));
        outer.addView(header);

        cricketUpdated = text("Live scores update automatically", 11, themeSecondaryText(), false);
        cricketUpdated.setGravity(Gravity.CENTER_VERTICAL); cricketUpdated.setPadding(dp(14),0,dp(14),dp(5));
        outer.addView(cricketUpdated, new LinearLayout.LayoutParams(-1,dp(28)));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setPadding(dp(10),0,dp(10),dp(6));
        String[] modes={"LIVE","UPCOMING","RESULTS"};
        for(String mode:modes){
            Button b=sportsSegmentButton(mode);
            b.setOnClickListener(v->{
                cricketDetail=false; sportsPage="matches";
                cricketMode=mode.equals("LIVE")?"live":mode.equals("UPCOMING")?"upcoming":"results";
                refreshCurrentSportsPage();
            });
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(42),1); tp.setMargins(dp(3),0,dp(3),0); tabs.addView(b,tp);
        }
        outer.addView(tabs);

        TextView powered=text("Powered by SportScore",10,themeSecondaryText(),false);
        powered.setGravity(Gravity.CENTER); powered.setPadding(0,0,0,dp(5));
        powered.setOnClickListener(v->{try{startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW,Uri.parse("https://sportscore.com/")));}catch(Exception ignored){}});
        outer.addView(powered,new LinearLayout.LayoutParams(-1,dp(22)));

        sportsSwipeRefresh=new SwipeRefreshLayout(this);
        sportsSwipeRefresh.setColorSchemeColors(Color.rgb(20,112,196),Color.rgb(0,137,123));
        sportsSwipeRefresh.setOnRefreshListener(()->{refreshCurrentSportsPage();handler.postDelayed(()->{if(sportsSwipeRefresh!=null)sportsSwipeRefresh.setRefreshing(false);},1000);});
        ScrollView scroll=new ScrollView(this);
        cricketList=new LinearLayout(this); cricketList.setOrientation(LinearLayout.VERTICAL); cricketList.setPadding(dp(10),dp(4),dp(10),dp(24));
        scroll.addView(cricketList); sportsSwipeRefresh.addView(scroll,new ViewGroup.LayoutParams(-1,-1));
        outer.addView(sportsSwipeRefresh,new LinearLayout.LayoutParams(-1,0,1));
        return outer;
    }

    private Button sportsSegmentButton(String label) {
        Button b = pillButton(label, 12.5f, dp(44));
        b.setTextColor(themePrimaryText());
        return b;
    }

    private void rebuildCategories() {
        if (categoryList == null) return;
        categoryList.removeAllViews();
    }

    private void showSportsMenu(View anchor) {
        showMenu(anchor, new String[]{"Cricket", "Football", "Basketball", "Tennis"},
                new String[]{"Cricket Live", "SPORT:football", "SPORT:basketball", "SPORT:tennis"});
    }

    private void showEntertainmentMenu(View anchor) {
        showMenu(anchor, new String[]{"TV", "Movies", "Drama", "Songs"},
                new String[]{"TV", "Movies", "Drama", "Songs"});
    }

    private void showMenu(View anchor, String[] labels, String[] values) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(8), dp(8), dp(8));
        box.setBackground(round(themeCard(), 14));
        for (int i = 0; i < labels.length; i++) {
            final String value = values[i];
            Button item = pillButton(labels[i], 14, dp(50));
            item.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            item.setPadding(dp(16), 0, dp(16), 0);
            item.setOnClickListener(v -> {
                showCategory(value);
                ((PopupWindow) v.getTag()).dismiss();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
            lp.setMargins(0, dp(3), 0, dp(3));
            box.addView(item, lp);
            final PopupWindow[] holder = new PopupWindow[1];
            item.setTag(holder);
        }
        PopupWindow popup = new PopupWindow(box, Math.min(dp(240), getResources().getDisplayMetrics().widthPixels - dp(24)), ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(true);
        popup.setElevation(dp(10));
        for (int i = 0; i < box.getChildCount(); i++) ((View)box.getChildAt(i)).setTag(popup);
        popup.showAsDropDown(anchor, 0, dp(4));
    }

    private void selectSportsCategory(String cat) {
        cricketDetail = false;
        if (cat == null) cat = "Cricket Live";
        currentCategory = cat;
        if (cat.equals("Cricket Live")) {
            currentSport = "cricket";
            cricketMode = cricketMode == null ? "live" : cricketMode;
            if (sportsRefreshButton != null) sportsRefreshButton.setVisibility(View.VISIBLE);
            cricketContainer.setVisibility(View.VISIBLE);
            playerContainer.setVisibility(View.GONE);
            cricketList.removeAllViews();
            loadCricket(cricketMode);
        } else if (cat.startsWith("SPORT:")) {
            currentSport = cat.substring("SPORT:".length()).toLowerCase();
            cricketMode = cricketMode == null ? "live" : cricketMode;
            if (sportsRefreshButton != null) sportsRefreshButton.setVisibility(View.VISIBLE);
            cricketContainer.setVisibility(View.VISIBLE);
            playerContainer.setVisibility(View.GONE);
            cricketList.removeAllViews();
            loadSport(currentSport, cricketMode);
        }
    }

    private void showCategory(String cat) {
        if (!cat.equals(currentCategory)) {
            navigationAdCounter++;
            if (navigationAdCounter >= 3) { navigationAdCounter = 0; maybeShowInterstitial(); }
        }
        currentCategory = cat;
        boolean sports = cat.startsWith("SPORT:") || "Cricket Live".equals(cat);
        boolean home = "TV".equals(cat);
        boolean video = !sports;
        playerContainer.setVisibility(video ? View.VISIBLE : View.GONE);
        if (home) { if (activeNotice != null) renderNotice(activeNotice); else hideNotice(); }
        else hideNotice();
        cricketContainer.setVisibility("Cricket Live".equals(cat) ? View.VISIBLE : View.GONE);
        if (sports) {
            cricketMode = "live";
            selectSportsCategory(cat);
            return;
        }
        if (categoryScroll != null) categoryScroll.setVisibility(View.GONE);
        if (sportsRefreshButton != null) sportsRefreshButton.setVisibility(View.GONE);
        if (channelList == null) return;
        channelList.removeAllViews();
        String wanted = cat;
        for (int i = 0; i < channels.size(); i++) {
            Channel c = channels.get(i);
            boolean match = "TV".equals(wanted) ? "TV".equalsIgnoreCase(c.category) : wanted.equalsIgnoreCase(c.category) || ("Movies".equals(wanted) && "Movie & Drama".equalsIgnoreCase(c.category));
            if (!match) continue;
            Button b = new Button(this);
            b.setText(c.name);
            b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            b.setAllCaps(false); b.setTextColor(themePrimaryText()); b.setIncludeFontPadding(false);
            b.setPadding(dp(16), 0, dp(16), 0);
            b.setBackground(round(themeCard(), 12));
            final int idx = i; b.setOnClickListener(v -> playChannel(idx));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(58)); p.setMargins(0, dp(5), 0, dp(5));
            channelList.addView(b, p);
        }
        insertNativeAdIntoCurrentList();
    }

    private void refreshCurrentSportsPage() {
        if (cricketDetail) return;
        if (sportsRefreshButton != null) sportsRefreshButton.setEnabled(false);
        if ("Cricket Live".equals(currentCategory) || currentCategory.startsWith("SPORT:")) {
            selectSportsCategory(currentCategory);
        }
        handler.postDelayed(() -> { if (sportsRefreshButton != null) sportsRefreshButton.setEnabled(true); if (sportsSwipeRefresh != null) sportsSwipeRefresh.setRefreshing(false); }, 900);
    }

    private String cap(String s) { return s == null || s.isEmpty() ? "Sports" : Character.toUpperCase(s.charAt(0)) + s.substring(1); }

    private void loadRemoteConfig() {
        if (BACKEND_URL.contains("REPLACE-WITH-YOUR-WORKER")) return;
        network.execute(() -> {
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/config"));
                JSONObject sports = root.optJSONObject("sports");
                if (sports != null) sportsRefreshMs = Math.max(10000, sports.optInt("refreshMs", 20000));
            } catch (Exception ignored) {}
        });
    }

    private void loadBackendContent() {
        if (BACKEND_URL.contains("REPLACE-WITH-YOUR-WORKER")) {
            seedDemoChannels();
            showCategory("TV");
            hideNotice();
            return;
        }
        network.execute(() -> {
            List<Channel> loaded = new ArrayList<>();
            Notice loadedNotice = null;
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/channels"));
                JSONArray arr = root.optJSONArray("channels");
                if (arr != null) for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    loaded.add(new Channel(o.optInt("id"), o.optString("number"), o.optString("name"), o.optString("country"), o.optString("category", "TV"), o.optString("streamUrl"), o.optString("sourceType", "link"), o.optString("youtubeVideoId"), o.optString("programName"), o.optInt("viewerCount"), o.optBoolean("showViewerCount"), o.optBoolean("loop")));
                }
            } catch (Exception ignored) { loaded = null; }
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/notice"));
                if (root.optBoolean("enabled")) loadedNotice = new Notice(root.optString("type"), root.optString("title"), root.optString("html"), root.optString("mediaUrl"), root.optString("linkUrl"));
            } catch (Exception ignored) {}
            final List<Channel> result = loaded;
            final Notice notice = loadedNotice;
            runOnUiThread(() -> {
                if (result != null) {
                    channels.clear(); channels.addAll(result);
                    if (!"Cricket Live".equals(currentCategory)) showCategory(currentCategory);
                    if (player == null && !channels.isEmpty()) {
                        int first = firstIndexForCategory("TV");
                        if (first >= 0) playChannel(first);
                    }
                }
                activeNotice = notice;
                if (notice != null && "TV".equals(currentCategory)) renderNotice(notice); else hideNotice();
            });
        });
    }

    private void seedDemoChannels() {
        channels.clear();
        channels.add(new Channel(1, "", "Demo TV", "International", "TV", "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", "link", "", "Demo Program", 0, false, false));
        channels.add(new Channel(2, "", "Demo Movie", "International", "Movies", "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4", "link", "", "Demo Movie", 0, false, true));
    }

    private int firstIndexForCategory(String cat) {
        for (int i = 0; i < channels.size(); i++) {
            Channel c = channels.get(i);
            if ("TV".equals(cat) && "TV".equalsIgnoreCase(c.category)) return i;
            if ("Movie & Drama".equals(cat) && ("Movies".equalsIgnoreCase(c.category) || "Movie & Drama".equalsIgnoreCase(c.category))) return i;
        }
        return channels.isEmpty() ? -1 : 0;
    }

    private void playChannel(int index) {
        if (channels.isEmpty()) return;
        currentIndex = (index + channels.size()) % channels.size();
        Channel c = channels.get(currentIndex);
        if (player == null) {
            player = new ExoPlayer.Builder(this).build();
            playerView.setPlayer(player);
            player.addListener(new Player.Listener() {
                @Override public void onPlayerError(PlaybackException error) { Toast.makeText(MainActivity.this, "Unable to play this stream", Toast.LENGTH_SHORT).show(); }
            });
        }
        if ("youtube".equalsIgnoreCase(c.sourceType) && c.youtubeVideoId != null && !c.youtubeVideoId.isEmpty()) {
            player.pause();
            playerView.setVisibility(View.GONE);
            youtubeWebView.setVisibility(View.VISIBLE);
            loadYouTubeVideo(c.youtubeVideoId, c.loop || "Movies".equalsIgnoreCase(c.category));
            if (pauseResumeButton != null) pauseResumeButton.setImageResource(R.drawable.ic_pause);
            playbackPaused = false;
        } else {
            youtubeWebView.setVisibility(View.GONE);
            playerView.setVisibility(View.VISIBLE);
            if (c.url == null || c.url.trim().isEmpty()) {
                Toast.makeText(this, "No playable stream configured", Toast.LENGTH_SHORT).show();
                return;
            }
            player.setMediaItem(MediaItem.fromUri(Uri.parse(c.url)));
            player.setRepeatMode(c.loop || "Movies".equalsIgnoreCase(c.category) ? Player.REPEAT_MODE_ONE : Player.REPEAT_MODE_OFF);
            player.prepare(); player.play();
            if (pauseResumeButton != null) pauseResumeButton.setImageResource(R.drawable.ic_pause);
            playbackPaused = false;
        }
        updateNowPlaying(c);
        pingViewer();
        showControlsTemporarily();
    }

    private void loadYouTubeVideo(String id, boolean loop) {
        String safe = id.replaceAll("[^A-Za-z0-9_-]", "");
        if (safe.length() != 11) return;
        String loopParam = loop ? "&loop=1&playlist=" + safe : "";
        youtubeReady = false;
        pendingYoutubeCommand = null;
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head><body style='margin:0;background:#000;overflow:hidden'><iframe id='ytplayer' width='100%' height='100%' src='https://www.youtube.com/embed/" + safe + "?autoplay=1&playsinline=1&rel=0&modestbranding=1&controls=0&enablejsapi=1&origin=https%3A%2F%2Fwww.youtube.com" + loopParam + "' frameborder='0' allow='autoplay; encrypted-media; picture-in-picture; fullscreen' allowfullscreen></iframe></body></html>";
        youtubeWebView.loadDataWithBaseURL("https://www.youtube.com/", html, "text/html", "UTF-8", null);
    }

    private void loadCricket(String mode) {
        loadSport("cricket", mode);
    }

    private void loadSport(String sport, String mode) {
        final long requestToken=++sportsRequestToken;
        currentSport=sport; cricketMode=mode; sportsPage="matches"; cricketDetail=false;
        if(cricketHeader!=null) cricketHeader.setText(cap(sport));
        if(cricketList==null || BACKEND_URL.contains("REPLACE-WITH-YOUR-WORKER")){showCricketMessage("Connect the One TV Worker to load live scores.");return;}
        cricketList.removeAllViews(); showCricketMessage("Loading " + mode + " matches…");
        network.execute(()->{
            try{
                JSONObject root=new JSONObject(getUrl(BACKEND_URL+"/sports/"+sport+"/"+mode));
                JSONArray matches=root.optJSONArray("matches");
                runOnUiThread(()->{if(requestToken==sportsRequestToken && currentSport.equals(sport) && currentCategory.startsWith("SPORT:") || requestToken==sportsRequestToken && "Cricket Live".equals(currentCategory)) renderSportsMatches(matches,mode,sport);});
            }catch(Exception e){
                runOnUiThread(()->{if(requestToken==sportsRequestToken)showCricketMessage(cap(sport)+" data is temporarily unavailable. Pull to refresh.");});
            }
        });
    }

    private void renderCricketMatches(JSONArray matches,String mode){renderSportsMatches(matches,mode,"cricket");}

    private void renderSportsMatches(JSONArray matches,String mode,String sport){
        if(sportsRefreshButton!=null)sportsRefreshButton.setVisibility(View.VISIBLE);
        cricketList.removeAllViews();
        cricketUpdated.setText("Live data • refreshed just now");
        if(matches==null || matches.length()==0){showCricketMessage(mode.equals("live")?"No live matches right now.":"No matches found for this section.");return;}
        for(int i=0;i<matches.length();i++){
            try{cricketList.addView(proMatchCard(matches.getJSONObject(i),sport));}catch(Exception ignored){}
        }
        insertNativeAdIntoCurrentList();
    }

    private View proMatchCard(JSONObject m,String sport){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(14),dp(12),dp(14),dp(12));
        card.setBackground(round(themeCard(),20)); card.setElevation(dp(3));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,dp(10));card.setLayoutParams(cp);

        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView comp=text(m.optString("competition","MATCH"),10,themeSecondaryText(),true);comp.setAllCaps(true);
        comp.setOnClickListener(v->openStandingsForMatch(m,sport));
        top.addView(comp,new LinearLayout.LayoutParams(0,-2,1));
        boolean live=isLiveStatus(m.optString("status",m.optString("state","")));
        TextView badge=liveBadge(live?"● LIVE":prettyStatus(m.optString("status",m.optString("state",""))));
        top.addView(badge,new LinearLayout.LayoutParams(-2,dp(30)));card.addView(top);

        LinearLayout matchup=new LinearLayout(this);matchup.setGravity(Gravity.CENTER_VERTICAL);matchup.setPadding(0,dp(10),0,dp(5));
        JSONObject home=teamFromMatch(m,true),away=teamFromMatch(m,false);
        matchup.addView(proTeamBlock(home,true,sport,m),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout center=new LinearLayout(this);center.setOrientation(LinearLayout.VERTICAL);center.setGravity(Gravity.CENTER);
        TextView vs=text("VS",14,Color.rgb(20,112,196),true);vs.setGravity(Gravity.CENTER);center.addView(vs);
        TextView time=text(formatMatchTime(m.optString("startsAt",m.optString("time",""))),9,themeSecondaryText(),false);time.setGravity(Gravity.CENTER);center.addView(time,new LinearLayout.LayoutParams(dp(72),-2));
        matchup.addView(center,new LinearLayout.LayoutParams(dp(72),-2));
        matchup.addView(proTeamBlock(away,false,sport,m),new LinearLayout.LayoutParams(0,-2,1));card.addView(matchup);

        String meta=matchMetaText(m); if(!meta.isEmpty()){TextView mt=text(meta,10,themeSecondaryText(),false);mt.setGravity(Gravity.CENTER);mt.setPadding(0,dp(2),0,dp(9));card.addView(mt);}
        LinearLayout footer=new LinearLayout(this);footer.setGravity(Gravity.CENTER_VERTICAL);footer.setPadding(dp(10),0,dp(10),0);footer.setBackground(round(darkMode?Color.rgb(24,36,49):Color.rgb(238,245,251),14));
        TextView left=text(live?("LIVE • "+sportName(sport)):prettyStatus(m.optString("status","Scheduled")),11,Color.rgb(0,137,123),true);
        TextView right=text(sport.equals("cricket")?"SCORECARD  ›":"MATCH CENTER  ›",11,Color.rgb(20,112,196),true);right.setGravity(Gravity.RIGHT);
        footer.addView(left,new LinearLayout.LayoutParams(0,dp(46),1));footer.addView(right,new LinearLayout.LayoutParams(0,dp(46),1));card.addView(footer);
        String id=m.optString("id",m.optString("match",""));
        if(!id.isEmpty())card.setOnClickListener(v->{if("cricket".equals(sport))loadCricketDetail(id,m);else loadSportDetail(sport,id,m);});
        card.setAlpha(0f);card.setTranslationY(dp(8));card.animate().alpha(1f).translationY(0f).setDuration(260).start();return card;
    }

    private View proTeamBlock(JSONObject t,boolean left,String sport,JSONObject match){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setPadding(dp(2),0,dp(2),0);
        ImageView logo=teamLogoView(t.optString("logo",""),t.optString("name","Team"));box.addView(logo,new LinearLayout.LayoutParams(dp(58),dp(58)));
        TextView name=text(t.optString("name","Team"),13,themePrimaryText(),true);name.setGravity(Gravity.CENTER);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        String slug=t.optString("slug",t.optString("id",""));if(!slug.isEmpty())name.setOnClickListener(v->openTeamPage(sport,slug,name.getText().toString()));
        box.addView(name,new LinearLayout.LayoutParams(-1,-2));
        TextView score=text(t.optString("score","").isEmpty()?"-":t.optString("score"),19,themePrimaryText(),true);score.setGravity(Gravity.CENTER);box.addView(score,new LinearLayout.LayoutParams(-1,-2));
        return box;
    }

    private boolean isLiveStatus(String s){String x=String.valueOf(s).toLowerCase();return x.contains("live")||x.contains("in play")||x.contains("playing")||x.contains("started")||x.equals("1");}
    private String prettyStatus(String s){if(s==null||s.trim().isEmpty())return "SCHEDULED";String x=s.replace('_',' ').trim();return x.length()>18?x.substring(0,18):x.toUpperCase();}
    private TextView liveBadge(String label){TextView t=text(label,10,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(10),0,dp(10),0);t.setBackground(round(label.startsWith("●")?Color.rgb(224,52,76):Color.rgb(20,112,196),18));if(label.startsWith("●"))t.animate().alpha(.72f).setDuration(700).withEndAction(()->t.animate().alpha(1f).setDuration(700).start()).start();return t;}
    private JSONObject teamFromMatch(JSONObject m,boolean home){JSONObject t=m.optJSONObject(home?"home":"away");if(t!=null)return t;JSONArray teams=m.optJSONArray("teams");if(teams!=null&&teams.length()>(home?0:1))return teams.optJSONObject(home?0:1);return new JSONObject();}
    private String matchMetaText(JSONObject m){String venue=m.optString("venue","");String time=m.optString("startsAt",m.optString("time",""));if(!venue.isEmpty()&&!time.isEmpty())return formatMatchTime(time)+"  •  "+venue;if(!venue.isEmpty())return venue;return formatMatchTime(time);}
    private String formatMatchTime(String s){if(s==null||s.trim().isEmpty())return "";return s.replace("T"," ").replace("Z","");}

    private ImageView teamLogoView(String url,String name){ImageView iv=new ImageView(this);iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);iv.setPadding(dp(5),dp(5),dp(5),dp(5));iv.setBackground(round(darkMode?Color.rgb(31,42,54):Color.rgb(239,245,249),28));if(url!=null&&!url.trim().isEmpty())loadRemoteImage(iv,url);else iv.setImageDrawable(initialsDrawable(name));return iv;}
    private String initials(String name){String[] p=String.valueOf(name).trim().split("\\s+");if(p.length==0||p[0].isEmpty())return "TV";if(p.length==1)return p[0].substring(0,Math.min(2,p[0].length())).toUpperCase();return (p[0].substring(0,1)+p[p.length-1].substring(0,1)).toUpperCase();}
    private android.graphics.drawable.Drawable initialsDrawable(String name){TextView d=new TextView(this);d.setText(initials(name));d.setTextSize(13);d.setTextColor(Color.rgb(20,112,196));d.setGravity(Gravity.CENTER);d.setTypeface(null,Typeface.BOLD);d.setBackground(round(darkMode?Color.rgb(31,42,54):Color.rgb(239,245,249),28));d.measure(View.MeasureSpec.makeMeasureSpec(dp(58),View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(dp(58),View.MeasureSpec.EXACTLY));d.layout(0,0,dp(58),dp(58));Bitmap b=Bitmap.createBitmap(dp(58),dp(58),Bitmap.Config.ARGB_8888);d.draw(new android.graphics.Canvas(b));return new android.graphics.drawable.BitmapDrawable(getResources(),b);}

    private void loadSportDetail(String sport,String matchId){loadSportDetail(sport,matchId,null);}
    private void loadSportDetail(String sport,String matchId,JSONObject fallbackMatch){loadMatchDetail(sport,matchId,fallbackMatch);}
    private void loadCricketDetail(String matchId){loadCricketDetail(matchId,null);}
    private void loadCricketDetail(String matchId,JSONObject fallbackMatch){loadMatchDetail("cricket",matchId,fallbackMatch);}

    private void loadMatchDetail(String sport,String matchId,JSONObject fallbackMatch){
        if(matchId==null||matchId.isEmpty())return;final long token=++sportsRequestToken;cricketDetail=true;sportsPage="scorecard";currentMatchId=matchId;
        if(sportsRefreshButton!=null)sportsRefreshButton.setVisibility(View.GONE);cricketList.removeAllViews();showCricketMessage("Loading match center…");
        network.execute(()->{try{JSONObject root=new JSONObject(getUrl(BACKEND_URL+"/sports/"+sport+"/match/"+Uri.encode(matchId)));runOnUiThread(()->{if(token==sportsRequestToken)renderSportsDetail(root,sport);});}
        catch(Exception e){runOnUiThread(()->{if(token==sportsRequestToken){if(fallbackMatch!=null)renderSportsDetail(wrapMatch(fallbackMatch),sport);else showCricketMessage("Match center is temporarily unavailable.");}});}});
    }

    private JSONObject wrapMatch(JSONObject match){JSONObject root=new JSONObject();try{root.put("match",match);}catch(Exception ignored){}return root;}

    private void renderSportsDetail(JSONObject root,String sport){
        if(sportsRefreshButton!=null)sportsRefreshButton.setVisibility(View.GONE);cricketList.removeAllViews();JSONObject m=root.optJSONObject("match");if(m==null)m=root;currentMatchObject=m;
        currentCompetitionSlug=m.optString("competitionSlug",slugifyLocal(m.optString("competition","")));sportsPage="scorecard";
        addBackHeader(sportName(sport)+" • MATCH CENTER",()->{cricketDetail=false;sportsPage="matches";selectSportsCategory("cricket".equals(sport)?"Cricket Live":"SPORT:"+sport);});
        renderMatchHero(m,sport);
        addDetailTabs(m,sport);
        renderMatchPage(m,sport,"scorecard");
        cricketUpdated.setText("Live match center • updated just now");
    }

    private void addBackHeader(String title,Runnable action){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);Button back=pillButton("‹",20,dp(42));back.setOnClickListener(v->action.run());row.addView(back,new LinearLayout.LayoutParams(dp(44),dp(42)));TextView h=text(title,13,Color.rgb(0,137,123),true);h.setGravity(Gravity.CENTER);row.addView(h,new LinearLayout.LayoutParams(0,dp(42),1));cricketList.addView(row);}

    private void renderMatchHero(JSONObject m,String sport){
        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setPadding(dp(14),dp(14),dp(14),dp(14));hero.setBackground(round(themeCard(),22));hero.setElevation(dp(3));
        TextView comp=text(m.optString("competition","Match"),11,themeSecondaryText(),true);comp.setGravity(Gravity.CENTER);comp.setOnClickListener(v->openStandingsForMatch(m,sport));hero.addView(comp);
        LinearLayout teams=new LinearLayout(this);teams.setGravity(Gravity.CENTER_VERTICAL);JSONObject h=teamFromMatch(m,true),a=teamFromMatch(m,false);teams.addView(detailTeamPro(h,true,sport),new LinearLayout.LayoutParams(0,-2,1));TextView vs=text("VS",14,Color.rgb(20,112,196),true);vs.setGravity(Gravity.CENTER);teams.addView(vs,new LinearLayout.LayoutParams(dp(45),-2));teams.addView(detailTeamPro(a,false,sport),new LinearLayout.LayoutParams(0,-2,1));hero.addView(teams);
        TextView status=text(m.optString("statusText",m.optString("status","SCHEDULED")),11,isLiveStatus(m.optString("status",""))?Color.rgb(224,52,76):Color.rgb(0,137,123),true);status.setGravity(Gravity.CENTER);status.setPadding(0,dp(7),0,0);hero.addView(status);
        TextView meta=text(matchMetaText(m),10,themeSecondaryText(),false);meta.setGravity(Gravity.CENTER);hero.addView(meta);cricketList.addView(hero,new LinearLayout.LayoutParams(-1,-2));
    }

    private View detailTeamPro(JSONObject t,boolean left,String sport){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);ImageView logo=teamLogoView(t.optString("logo",""),t.optString("name","Team"));box.addView(logo,new LinearLayout.LayoutParams(dp(66),dp(66)));TextView name=text(t.optString("name","Team"),14,themePrimaryText(),true);name.setGravity(Gravity.CENTER);String slug=t.optString("slug",t.optString("id",""));if(!slug.isEmpty())name.setOnClickListener(v->openTeamPage(sport,slug,name.getText().toString()));box.addView(name,new LinearLayout.LayoutParams(-1,-2));TextView score=text(t.optString("score","").isEmpty()?"-":t.optString("score"),25,themePrimaryText(),true);score.setGravity(Gravity.CENTER);box.addView(score);return box;}

    private void addDetailTabs(JSONObject m,String sport){LinearLayout tabs=new LinearLayout(this);tabs.setPadding(0,dp(8),0,dp(5));String[] labels=sport.equals("cricket")?new String[]{"SCORECARD","BALL BY BALL","STATS","STANDINGS"}:new String[]{"OVERVIEW","TIMELINE","STATS","STANDINGS"};for(String label:labels){Button b=sportsSegmentButton(label);b.setTextSize(9.5f);b.setOnClickListener(v->{String p=label.equals("BALL BY BALL")||label.equals("TIMELINE")?"commentary":label.toLowerCase();if(label.equals("STANDINGS")){openStandingsForMatch(m,sport);return;}sportsPage=p;renderMatchPage(m,sport,p);});tabs.addView(b,new LinearLayout.LayoutParams(0,dp(42),1));}cricketList.addView(tabs);}

    private void renderMatchPage(JSONObject m,String sport,String page){
        removeDetailContent();
        if("scorecard".equals(page)||"overview".equals(page)) { if("cricket".equals(sport)) renderCricketScorecard(m); else renderGenericOverview(m,sport); }
        else if("commentary".equals(page)) renderBallByBall(m,sport);
        else if("stats".equals(page)) renderMatchStats(m,sport);
    }

    private void removeDetailContent(){while(cricketList.getChildCount()>4)cricketList.removeViewAt(4);}

    private void renderCricketScorecard(JSONObject m){
        renderLivePlayers(m);
        addClickableSectionTitle("LIVE SCORE","Current innings, batters and bowler",()->renderLivePlayers(m));
        JSONArray innings=arrayFrom(m,"innings","scorecard","scorecards","innings_data");
        if(innings.length()==0){renderSimpleTeams(m);}
        for(int i=0;i<innings.length();i++)renderInningsCard(innings.optJSONObject(i),i+1);
        renderRecentBalls(m);
        renderLineups(m);
    }

    private void renderSimpleTeams(JSONObject m){JSONArray teams=m.optJSONArray("teams");if(teams!=null)for(int i=0;i<teams.length();i++){JSONObject t=teams.optJSONObject(i);if(t!=null)cricketList.addView(statRow(t.optString("name","Team"),t.optString("score","-"),"SCORE"));}}

    private void renderLivePlayers(JSONObject m){
        JSONArray bats=arrayFrom(m,"current_batsmen","currentBatsmen","batsmen","batters","current_batters");JSONArray bowl=arrayFrom(m,"current_bowlers","currentBowlers","bowlers","current_bowler");
        if(bats.length()==0&&bowl.length()==0)return;
        addClickableSectionTitle("LIVE BATSMEN","Tap a player for full profile",()->{if(bats.length()>0)openPlayerPageFromObject(bats.optJSONObject(0),"cricket");});
        if(bats.length()>0){for(int i=0;i<Math.min(4,bats.length());i++){JSONObject p=bats.optJSONObject(i);if(p!=null)cricketList.addView(playerStatRow(p,"BAT"));}}
        if(bowl.length()>0){addClickableSectionTitle("LIVE BOWLER","Current bowling figures",null);for(int i=0;i<Math.min(3,bowl.length());i++){JSONObject p=bowl.optJSONObject(i);if(p!=null)cricketList.addView(playerStatRow(p,"BOWL"));}}
    }

    private View playerStatRow(JSONObject p,String type){String name=p.optString("name",p.optString("player",p.optString("player_name","Player")));String photo=p.optString("photo",p.optString("photo_url",p.optString("image",p.optString("avatar",""))));LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(10),dp(8),dp(10),dp(8));r.setBackground(round(themeCard(),14));ImageView iv=teamLogoView(photo,name);r.addView(iv,new LinearLayout.LayoutParams(dp(46),dp(46)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);TextView nm=text(name,13,themePrimaryText(),true);nm.setOnClickListener(v->openPlayerPageFromObject(p,"cricket"));tx.addView(nm);String statLine=type.equals("BAT")?battingStatLine(p):bowlingStatLine(p);tx.addView(text(statLine,10,themeSecondaryText(),false));r.addView(tx,new LinearLayout.LayoutParams(0,-2,1));TextView role=text(type,9,Color.rgb(0,137,123),true);r.addView(role,new LinearLayout.LayoutParams(dp(42),dp(36)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(5));r.setLayoutParams(lp);return r;}

    private String battingStatLine(JSONObject p){return "R "+val(p,"runs","r")+"   B "+val(p,"balls","b")+"   4s "+val(p,"fours","4s")+"   6s "+val(p,"sixes","6s")+"   SR "+val(p,"strike_rate","strikeRate","sr");}
    private String bowlingStatLine(JSONObject p){return "O "+val(p,"overs","o")+"   M "+val(p,"maidens","m")+"   R "+val(p,"runs","r")+"   W "+val(p,"wickets","w")+"   ECO "+val(p,"economy","econ");}
    private String val(JSONObject o,String... keys){for(String k:keys){if(o.has(k)&&!o.isNull(k))return o.optString(k,"");}return "-";}

    private void renderInningsCard(JSONObject in,int no){if(in==null)return;String team=in.optString("team",in.optString("team_name","Innings "+no));String total=in.optString("score",in.optString("total",in.optString("runs","-")));addClickableSectionTitle("INNINGS "+no,team+"  •  "+total,null);JSONArray bats=arrayFrom(in,"batsmen","batters","batting","players");if(bats.length()>0){cricketList.addView(tableHeader(new String[]{"BATSMAN","R","B","4s","6s","SR"}));for(int i=0;i<bats.length();i++){JSONObject p=bats.optJSONObject(i);if(p!=null)cricketList.addView(scoreRow(p,true));}}JSONArray bowl=arrayFrom(in,"bowlers","bowling");if(bowl.length()>0){cricketList.addView(tableHeader(new String[]{"BOWLER","O","M","R","W","ECO"}));for(int i=0;i<bowl.length();i++){JSONObject p=bowl.optJSONObject(i);if(p!=null)cricketList.addView(scoreRow(p,false));}}String extras=in.optString("extras","");if(!extras.isEmpty())cricketList.addView(statRow("Extras",extras,"EXTRAS"));}

    private View tableHeader(String[] cols){LinearLayout r=new LinearLayout(this);r.setPadding(dp(10),dp(7),dp(10),dp(7));r.setBackground(round(darkMode?Color.rgb(28,43,57):Color.rgb(228,239,247),10));for(int i=0;i<cols.length;i++){TextView t=text(cols[i],9,themeSecondaryText(),true);t.setGravity(i==0?Gravity.LEFT:Gravity.CENTER);float weight=(i==0&&"#".equals(cols[0]))?0.6f:("TEAM".equals(cols[i])?2.4f:(i==0?2.4f:1f));r.addView(t,new LinearLayout.LayoutParams(0,dp(30),weight));}return r;}
    private View scoreRow(JSONObject p,boolean bat){String name=p.optString("name",p.optString("player",p.optString("player_name","Player")));LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(10),dp(7),dp(10),dp(7));String photo=p.optString("photo",p.optString("photo_url",p.optString("image",p.optString("avatar",""))));ImageView iv=teamLogoView(photo,name);r.addView(iv,new LinearLayout.LayoutParams(dp(34),dp(34)));TextView nm=text(name,11,themePrimaryText(),true);nm.setPadding(dp(7),0,dp(4),0);nm.setOnClickListener(v->openPlayerPageFromObject(p,"cricket"));r.addView(nm,new LinearLayout.LayoutParams(0,dp(40),2.4f));String[] keys=bat?new String[]{"runs","balls","fours","sixes","strike_rate"}:new String[]{"overs","maidens","runs","wickets","economy"};for(String k:keys){TextView t=text(val(p,k),10,themePrimaryText(),false);t.setGravity(Gravity.CENTER);r.addView(t,new LinearLayout.LayoutParams(0,dp(40),1));}return r;}

    private void renderRecentBalls(JSONObject m){JSONArray events=arrayFrom(m,"events","timeline","commentary","comments","ball_by_ball","ballByBall");if(events.length()==0)return;addClickableSectionTitle("RECENT BALLS","Tap to open full ball-by-ball commentary",()->renderBallByBall(m,"cricket"));for(int i=Math.max(0,events.length()-8);i<events.length();i++){JSONObject e=events.optJSONObject(i);cricketList.addView(ballRow(e!=null?e:events.optString(i),i+1));}}

    private View ballRow(Object raw,int index){String over="";String textValue="";String runs="";String wicket="";if(raw instanceof JSONObject){JSONObject o=(JSONObject)raw;over=val(o,"over","over_number","overs");textValue=o.optString("commentary",o.optString("comment",o.optString("description",o.optString("text",o.optString("event",o.toString())))));runs=val(o,"runs","run","total_runs","score");wicket=val(o,"wicket","wickets","is_wicket");}else textValue=String.valueOf(raw);LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(8),dp(7),dp(8),dp(7));r.setBackground(round(themeCard(),12));TextView ov=text(over.isEmpty()?String.valueOf(index):over,9,themeSecondaryText(),true);ov.setGravity(Gravity.CENTER);r.addView(ov,new LinearLayout.LayoutParams(dp(42),dp(34)));TextView tx=text(textValue,10,themePrimaryText(),false);tx.setMaxLines(3);r.addView(tx,new LinearLayout.LayoutParams(0,dp(48),1));String badge=wicket.equals("true")||wicket.equals("1")?"W":runs.isEmpty()?"•":runs;TextView rb=text(badge,11,Color.WHITE,true);rb.setGravity(Gravity.CENTER);rb.setBackground(round((badge.equals("W")?Color.rgb(224,52,76):Color.rgb(20,112,196)),16));r.addView(rb,new LinearLayout.LayoutParams(dp(38),dp(32)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(4));r.setLayoutParams(lp);return r;}

    private void renderBallByBall(JSONObject m,String sport){addClickableSectionTitle("BALL BY BALL","Live delivery-by-delivery commentary",null);JSONArray events=arrayFrom(m,"events","timeline","commentary","comments","ball_by_ball","ballByBall");if(events.length()==0){showInlineMessage("Ball-by-ball data is not available for this match yet.");return;}for(int i=0;i<events.length();i++){JSONObject e=events.optJSONObject(i);cricketList.addView(ballRow(e!=null?e:events.optString(i),i+1));}}

    private void renderMatchStats(JSONObject m,String sport){addClickableSectionTitle("MATCH STATISTICS","Live statistics and performance",null);JSONObject stats=m.optJSONObject("statistics");if(stats==null)stats=m.optJSONObject("stats");if(stats!=null){java.util.Iterator<String> it=stats.keys();while(it.hasNext()){String k=it.next();Object v=stats.opt(k);cricketList.addView(statRow(prettyKey(k),String.valueOf(v),"STAT"));}}else{renderSimpleTeams(m);String status=m.optString("status","");cricketList.addView(statRow("Status",status,"STAT"));cricketList.addView(statRow("Venue",m.optString("venue","-"),"STAT"));cricketList.addView(statRow("Competition",m.optString("competition","-"),"STAT"));}}

    private void renderGenericOverview(JSONObject m,String sport){renderSimpleTeams(m);addClickableSectionTitle("TIMELINE","Live match events",()->renderBallByBall(m,sport));JSONArray events=arrayFrom(m,"events","timeline");for(int i=0;i<Math.min(12,events.length());i++)cricketList.addView(ballRow(events.opt(i),i+1));renderLineups(m);}

    private JSONArray arrayFrom(JSONObject o,String... keys){for(String k:keys){JSONArray a=o.optJSONArray(k);if(a!=null)return a;}return new JSONArray();}
    private String prettyKey(String k){return k.replace('_',' ').replace('-',' ').toUpperCase();}

    private void renderLineups(JSONObject m){JSONArray lineups=arrayFrom(m,"lineups","players","squads","rosters");if(lineups.length()==0)return;addClickableSectionTitle("PLAYERS","Tap any player for complete statistics",null);for(int i=0;i<Math.min(30,lineups.length());i++){JSONObject p=lineups.optJSONObject(i);if(p!=null){String name=p.optString("name",p.optString("player",p.optString("player_name","Player")));String role=p.optString("role",p.optString("position",""));String image=p.optString("photo",p.optString("photo_url",p.optString("image",p.optString("avatar",""))));cricketList.addView(playerRow(name,role,image,p));}}}

    private View playerRow(String name,String role,String imageUrl,JSONObject data){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(10),dp(7),dp(10),dp(7));r.setBackground(round(themeCard(),14));ImageView iv=teamLogoView(imageUrl,name);r.addView(iv,new LinearLayout.LayoutParams(dp(46),dp(46)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(10),0,0,0);TextView nm=text(name,13,themePrimaryText(),true);nm.setOnClickListener(v->openPlayerPageFromObject(data,"cricket"));tx.addView(nm);tx.addView(text(role,10,themeSecondaryText(),false));r.addView(tx,new LinearLayout.LayoutParams(0,dp(52),1));TextView arrow=text("›",22,Color.rgb(20,112,196),true);r.addView(arrow,new LinearLayout.LayoutParams(dp(28),dp(44)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(5));r.setLayoutParams(lp);return r;}

    private void addClickableSectionTitle(String title,String subtitle,Runnable click){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(4),dp(13),dp(4),dp(7));row.setBackground(round(themeBackground(),10));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);TextView h=text(title,14,themePrimaryText(),true);TextView sub=text(subtitle,9,themeSecondaryText(),false);tx.addView(h);tx.addView(sub);row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));if(click!=null){TextView arrow=text("›",22,Color.rgb(20,112,196),true);row.addView(arrow,new LinearLayout.LayoutParams(dp(28),dp(40)));row.setOnClickListener(v->click.run());}cricketList.addView(row);}
    private View statRow(String left,String right,String tag){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(12),dp(8),dp(12),dp(8));r.setBackground(round(darkMode?Color.rgb(24,35,46):Color.rgb(240,246,250),14));TextView l=text(left,11,themePrimaryText(),false);TextView rr=text(right,12,Color.rgb(0,137,123),true);rr.setGravity(Gravity.RIGHT);r.addView(l,new LinearLayout.LayoutParams(0,dp(40),1));r.addView(rr,new LinearLayout.LayoutParams(0,dp(40),1));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(5));r.setLayoutParams(lp);return r;}
    private void showInlineMessage(String msg){TextView t=text(msg,12,themeSecondaryText(),false);t.setGravity(Gravity.CENTER);t.setPadding(dp(18),dp(30),dp(18),dp(30));cricketList.addView(t);}
    private void showCricketMessage(String message){cricketList.removeAllViews();showInlineMessage(message);}

    private void openStandingsForMatch(JSONObject m,String sport){String slug=m.optString("competitionSlug",slugifyLocal(m.optString("competition","")));if(slug.isEmpty()){showInlineMessage("Competition standings are not available for this match.");return;}openStandingsPage(sport,slug,m.optString("competition","Standings"));}
    private void openStandingsPage(String sport,String slug,String title){sportsPage="standings";cricketDetail=true;currentCompetitionSlug=slug;cricketList.removeAllViews();addBackHeader("STANDINGS • "+title,()->{if(currentMatchObject!=null)renderSportsDetail(wrapMatch(currentMatchObject),sport);else selectSportsCategory("cricket".equals(sport)?"Cricket Live":"SPORT:"+sport);});showInlineMessage("Loading standings…");network.execute(()->{try{JSONObject root=new JSONObject(getUrl(BACKEND_URL+"/sports/"+sport+"/standings/"+Uri.encode(slug)));runOnUiThread(()->renderStandingsPage(root,sport,title));}catch(Exception e){runOnUiThread(()->showInlineMessage("Standings are temporarily unavailable."));}});}

    private void renderStandingsPage(JSONObject root,String sport,String title){cricketList.removeViews(1,Math.max(0,cricketList.getChildCount()-1));addClickableSectionTitle("LEAGUE TABLE",title+" • live standings",null);JSONArray rows=findArrayDeep(root,"standings","table","rows","teams");if(rows.length()==0){showInlineMessage("No standings table was returned by the sports provider.");return;}cricketList.addView(tableHeader(new String[]{"#","","TEAM","P","W","L","T","NR","PTS"}));for(int i=0;i<rows.length();i++){JSONObject r=rows.optJSONObject(i);if(r==null)continue;cricketList.addView(standingRow(r,i+1,sport));}}
    private View standingRow(JSONObject r,int rank,String sport){String team=r.optString("team",r.optString("team_name",r.optString("name","Team")));String logo=r.optString("logo",r.optString("logo_url",r.optString("image","")));LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(7),dp(8),dp(7));row.setBackground(round(themeCard(),12));TextView rk=text(String.valueOf(rank),10,themeSecondaryText(),true);rk.setGravity(Gravity.CENTER);row.addView(rk,new LinearLayout.LayoutParams(dp(28),dp(42)));ImageView iv=teamLogoView(logo,team);row.addView(iv,new LinearLayout.LayoutParams(dp(36),dp(36)));TextView nm=text(team,11,themePrimaryText(),true);String slug=r.optString("slug",r.optString("team_slug",slugifyLocal(team)));nm.setOnClickListener(v->openTeamPage(sport,slug,team));row.addView(nm,new LinearLayout.LayoutParams(0,dp(42),2.4f));String[] keys={"played","p","wins","w","losses","l","ties","t","no_result","nr","points","pts"};String[] vals={firstVal(r,"played","p"),firstVal(r,"wins","w"),firstVal(r,"losses","l"),firstVal(r,"ties","t"),firstVal(r,"no_result","nr"),firstVal(r,"points","pts")};for(String v:vals){TextView x=text(v.isEmpty()?"-":v,10,themePrimaryText(),false);x.setGravity(Gravity.CENTER);row.addView(x,new LinearLayout.LayoutParams(0,dp(42),1));}return row;}
    private String firstVal(JSONObject o,String... keys){for(String k:keys){if(o.has(k)&&!o.isNull(k))return o.optString(k,"");}return "";}
    private JSONArray findArrayDeep(JSONObject root,String... keys){for(String k:keys){JSONArray a=root.optJSONArray(k);if(a!=null)return a;JSONObject d=root.optJSONObject("data");if(d!=null){a=d.optJSONArray(k);if(a!=null)return a;}}JSONObject data=root.optJSONObject("data");if(data!=null){for(String k:keys){JSONArray a=data.optJSONArray(k);if(a!=null)return a;}}return new JSONArray();}

    private void openPlayerPageFromObject(JSONObject p,String sport){String slug=p==null?"":p.optString("slug",p.optString("player_slug",p.optString("id","")));String name=p==null?"Player":p.optString("name",p.optString("player",p.optString("player_name","Player")));if(slug.isEmpty())slug=slugifyLocal(name);openPlayerPage(sport,slug,name);}
    private void openPlayerPage(String sport,String slug,String name){sportsPage="player";currentPlayerSlug=slug;cricketList.removeAllViews();addBackHeader("PLAYER • "+name,()->{if(currentMatchObject!=null)renderSportsDetail(wrapMatch(currentMatchObject),sport);else selectSportsCategory("cricket".equals(sport)?"Cricket Live":"SPORT:"+sport);});showInlineMessage("Loading player profile…");network.execute(()->{try{JSONObject root=new JSONObject(getUrl(BACKEND_URL+"/sports/"+sport+"/player/"+Uri.encode(slug)));runOnUiThread(()->renderPlayerPage(root,sport,name));}catch(Exception e){runOnUiThread(()->showInlineMessage("Player data is temporarily unavailable."));}});}

    private void renderPlayerPage(JSONObject root,String sport,String fallbackName){
        JSONObject d=root.optJSONObject("data");if(d==null)d=root;
        JSONObject p=d.optJSONObject("player");if(p==null)p=d;
        String name=p.optString("name",p.optString("full_name",fallbackName));
        String photo=p.optString("photo",p.optString("photo_url",p.optString("image",p.optString("avatar",p.optString("image_url","")))));
        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setGravity(Gravity.CENTER);hero.setPadding(dp(14),dp(16),dp(14),dp(16));hero.setBackground(round(themeCard(),20));
        ImageView iv=teamLogoView(photo,name);hero.addView(iv,new LinearLayout.LayoutParams(dp(104),dp(104)));
        TextView nm=text(name,21,themePrimaryText(),true);nm.setGravity(Gravity.CENTER);hero.addView(nm);
        String role=p.optString("role",p.optString("position",p.optString("type","")));if(!role.isEmpty())hero.addView(text(role,11,themeSecondaryText(),false));
        String team=p.optString("team",p.optString("team_name",p.optString("club","")));if(!team.isEmpty()){
            TextView tm=text(team,11,Color.rgb(0,137,123),true);tm.setGravity(Gravity.CENTER);String teamSlug=p.optString("team_slug",p.optString("teamSlug",slugifyLocal(team)));if(!teamSlug.isEmpty())tm.setOnClickListener(v->openTeamPage(sport,teamSlug,team));hero.addView(tm);
        }
        cricketList.addView(hero);
        addClickableSectionTitle("PLAYER OVERVIEW","Role, team and key career information",null);
        String[] infoKeys={"country","age","date_of_birth","batting_style","bowling_style","debut","ranking"};
        for(String k:infoKeys)if(p.has(k)&&!p.isNull(k))cricketList.addView(statRow(prettyKey(k),String.valueOf(p.opt(k)),"PLAYER"));
        addClickableSectionTitle("BATTING & BOWLING","Runs, average, strike rate, overs and wickets",null);
        JSONObject stats=p.optJSONObject("stats");if(stats==null)stats=p.optJSONObject("statistics");if(stats==null)stats=p.optJSONObject("career_stats");
        if(stats!=null)renderPlayerStatBlocks(stats);
        else renderPlayerStatBlocks(p);
        JSONArray recent=findArrayDeep(d,"matches","recent_matches","match_history","fixtures","games");
        if(recent.length()>0){addClickableSectionTitle("MATCH HISTORY","Tap a match when a match id is available",null);for(int i=0;i<Math.min(30,recent.length());i++){Object x=recent.opt(i);if(x instanceof JSONObject)cricketList.addView(playerMatchHistoryRow((JSONObject)x,sport,i+1));else cricketList.addView(statRow("Match "+(i+1),String.valueOf(x),"MATCH"));}}
        addClickableSectionTitle("RAW STATISTICS","All additional fields supplied by the provider",null);
        if(stats!=null){java.util.Iterator<String> it=stats.keys();while(it.hasNext()){String k=it.next();if(!isCorePlayerStat(k))cricketList.addView(statRow(prettyKey(k),String.valueOf(stats.opt(k)),"STAT"));}}
    }

    private void renderPlayerStatBlocks(JSONObject stats){
        String[] keys={"matches","innings","runs","average","avg","highest_score","high_score","strike_rate","sr","fours","sixes","not_outs","balls","overs","maidens","wickets","economy","econ","best_bowling","five_wickets","ten_wickets","catches"};
        LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);
        for(int i=0;i<keys.length;i+=2){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);for(int j=i;j<Math.min(i+2,keys.length);j++){String k=keys[j];if(!stats.has(k)||stats.isNull(k))continue;LinearLayout cell=new LinearLayout(this);cell.setOrientation(LinearLayout.VERTICAL);cell.setGravity(Gravity.CENTER);cell.setPadding(dp(8),dp(9),dp(8),dp(9));cell.setBackground(round(darkMode?Color.rgb(24,35,46):Color.rgb(240,246,250),14));TextView v=text(String.valueOf(stats.opt(k)),16,themePrimaryText(),true);v.setGravity(Gravity.CENTER);TextView l=text(statLabel(k),9,themeSecondaryText(),true);l.setGravity(Gravity.CENTER);cell.addView(v);cell.addView(l);row.addView(cell,new LinearLayout.LayoutParams(0,dp(66),1));}if(row.getChildCount()>0){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(6));grid.addView(row,lp);}}
        cricketList.addView(grid);
    }

    private String statLabel(String k){String x=k.replace('_',' ');if("avg".equals(k))return "AVERAGE";if("sr".equals(k))return "STRIKE RATE";if("econ".equals(k))return "ECONOMY";return x.toUpperCase();}
    private boolean isCorePlayerStat(String k){String[] a={"matches","innings","runs","average","avg","highest_score","high_score","strike_rate","sr","fours","sixes","not_outs","balls","overs","maidens","wickets","economy","econ","best_bowling","five_wickets","ten_wickets","catches"};for(String x:a)if(x.equals(k))return true;return false;}

    private View playerMatchHistoryRow(JSONObject m,String sport,int no){
        String title=m.optString("name",m.optString("title",m.optString("match","Match "+no)));String id=m.optString("id",m.optString("match_id",m.optString("slug","")));String score=m.optString("score",m.optString("result",m.optString("status","")));
        LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(10),dp(9),dp(10),dp(9));r.setBackground(round(themeCard(),14));TextView t=text(title,11,themePrimaryText(),true);r.addView(t,new LinearLayout.LayoutParams(0,dp(42),1));TextView sc=text(score,10,Color.rgb(0,137,123),true);sc.setGravity(Gravity.RIGHT);r.addView(sc,new LinearLayout.LayoutParams(dp(105),dp(42)));if(!id.isEmpty())r.setOnClickListener(v->loadSportDetail(sport,id));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(5));r.setLayoutParams(lp);return r;
    }

    private void openTeamPage(String sport,String slug,String name){sportsPage="team";cricketList.removeAllViews();addBackHeader("TEAM • "+name,()->{if(currentMatchObject!=null)renderSportsDetail(wrapMatch(currentMatchObject),sport);else selectSportsCategory("cricket".equals(sport)?"Cricket Live":"SPORT:"+sport);});showInlineMessage("Loading team profile…");network.execute(()->{try{JSONObject root=new JSONObject(getUrl(BACKEND_URL+"/sports/"+sport+"/team/"+Uri.encode(slug)));runOnUiThread(()->renderTeamPage(root,sport,name));}catch(Exception e){runOnUiThread(()->showInlineMessage("Team data is temporarily unavailable."));}});}

    private void renderTeamPage(JSONObject root,String sport,String name){
        JSONObject d=root.optJSONObject("data");if(d==null)d=root;JSONObject team=d.optJSONObject("team");if(team==null)team=d;
        addTeamTabs(d,team,sport,name);
        renderTeamOverview(d,team,sport,name);
    }

    private void addTeamTabs(JSONObject d,JSONObject team,String sport,String name){
        LinearLayout tabs=new LinearLayout(this);tabs.setPadding(0,dp(8),0,dp(6));String[] labels={"OVERVIEW","SQUAD","STATS","FIXTURES"};
        for(String label:labels){Button b=sportsSegmentButton(label);b.setTextSize(9.5f);b.setOnClickListener(v->{if("OVERVIEW".equals(label))renderTeamOverview(d,team,sport,name);else if("SQUAD".equals(label))renderTeamSquad(d,team,sport,name);else if("STATS".equals(label))renderTeamStats(d,team,sport,name);else renderTeamFixtures(d,team,sport,name);});tabs.addView(b,new LinearLayout.LayoutParams(0,dp(42),1));}
        cricketList.addView(tabs);
    }

    private void clearTeamContent(){while(cricketList.getChildCount()>2)cricketList.removeViewAt(2);}

    private void renderTeamOverview(JSONObject d,JSONObject team,String sport,String name){clearTeamContent();addClickableSectionTitle("TEAM OVERVIEW",name+" • profile and performance",null);ImageView logo=teamLogoView(team.optString("logo",team.optString("logo_url",team.optString("image",""))),name);LinearLayout hero=new LinearLayout(this);hero.setGravity(Gravity.CENTER_VERTICAL);hero.setPadding(dp(12),dp(10),dp(12),dp(10));hero.setBackground(round(themeCard(),16));hero.addView(logo,new LinearLayout.LayoutParams(dp(72),dp(72)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(12),0,0,0);tx.addView(text(name,18,themePrimaryText(),true));String country=team.optString("country",team.optString("country_name",""));if(!country.isEmpty())tx.addView(text(country,10,themeSecondaryText(),false));String form=team.optString("form",team.optString("recent_form",""));if(!form.isEmpty())tx.addView(text("Form: "+form,10,Color.rgb(0,137,123),true));hero.addView(tx,new LinearLayout.LayoutParams(0,-2,1));cricketList.addView(hero);
        String[] keys={"country","venue","coach","founded","ranking","points","played","wins","draws","losses","ties","no_result","goal_difference"};for(String k:keys)if(team.has(k)&&!team.isNull(k))cricketList.addView(statRow(prettyKey(k),String.valueOf(team.opt(k)),"TEAM"));
        JSONArray top=findArrayDeep(d,"top_scorers","topScorers","scorers","leaders");if(top.length()>0){addClickableSectionTitle("TOP PERFORMERS","Highest contributors for this team",()->renderTeamStats(d,team,sport,name));for(int i=0;i<Math.min(8,top.length());i++){JSONObject p=top.optJSONObject(i);if(p!=null)cricketList.addView(teamPlayerCompact(p,sport));}}
        addClickableSectionTitle("SQUAD","All available players with photos and roles",()->renderTeamSquad(d,team,sport,name));
        renderTeamSquadPreview(d,team,sport);
    }

    private void renderTeamSquadPreview(JSONObject d,JSONObject team,String sport){JSONArray players=teamPlayers(team,d);for(int i=0;i<Math.min(6,players.length());i++){JSONObject p=players.optJSONObject(i);if(p!=null)cricketList.addView(teamPlayerCompact(p,sport));}}

    private JSONArray teamPlayers(JSONObject team,JSONObject d){String[] keys={"players","squad","squads","roster","roster_players","team_players"};for(String k:keys){JSONArray a=team.optJSONArray(k);if(a!=null&&a.length()>0)return a; a=d.optJSONArray(k);if(a!=null&&a.length()>0)return a;}return new JSONArray();}

    private View teamPlayerCompact(JSONObject p,String sport){String name=p.optString("name",p.optString("player",p.optString("player_name","Player")));String photo=p.optString("photo",p.optString("photo_url",p.optString("image",p.optString("avatar",""))));String slug=p.optString("slug",p.optString("player_slug",p.optString("id",slugifyLocal(name))));LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(10),dp(7),dp(10),dp(7));r.setBackground(round(themeCard(),14));ImageView iv=teamLogoView(photo,name);r.addView(iv,new LinearLayout.LayoutParams(dp(48),dp(48)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(10),0,0,0);TextView nm=text(name,12,themePrimaryText(),true);nm.setOnClickListener(v->openPlayerPage(sport,slug,name));tx.addView(nm);String role=p.optString("role",p.optString("position",p.optString("type","")));if(!role.isEmpty())tx.addView(text(role,9,themeSecondaryText(),false));String mini=compactPlayerStats(p);if(!mini.isEmpty())tx.addView(text(mini,9,Color.rgb(0,137,123),false));r.addView(tx,new LinearLayout.LayoutParams(0,dp(54),1));TextView ar=text("›",21,Color.rgb(20,112,196),true);r.addView(ar,new LinearLayout.LayoutParams(dp(28),dp(44)));r.setOnClickListener(v->openPlayerPage(sport,slug,name));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(5));r.setLayoutParams(lp);return r;}

    private String compactPlayerStats(JSONObject p){JSONObject s=p.optJSONObject("stats");if(s==null)s=p.optJSONObject("statistics");if(s==null)s=p;String r=s.has("runs")?"R "+s.opt("runs"):"";if(s.has("average"))r+=(r.isEmpty()?"":"  •  ")+"Avg "+s.opt("average");if(s.has("overs"))r+=(r.isEmpty()?"":"  •  ")+"O "+s.opt("overs");if(s.has("wickets"))r+=(r.isEmpty()?"":"  •  ")+"W "+s.opt("wickets");return r;}

    private void renderTeamSquad(JSONObject d,JSONObject team,String sport,String name){clearTeamContent();addClickableSectionTitle("SQUAD","Tap any player for complete profile and statistics",null);JSONArray players=teamPlayers(team,d);if(players.length()==0){showInlineMessage("Squad data is not available from the sports provider for this team yet.");return;}java.util.LinkedHashMap<String,JSONArray> groups=new java.util.LinkedHashMap<>();for(int i=0;i<players.length();i++){JSONObject p=players.optJSONObject(i);if(p==null)continue;String role=p.optString("role",p.optString("position",p.optString("type","Other")));if(role.isEmpty())role="Other";JSONArray a=groups.get(role);if(a==null){a=new JSONArray();groups.put(role,a);}a.put(p);}for(String role:groups.keySet()){addClickableSectionTitle(role.toUpperCase(),groups.get(role).length()+" players",null);JSONArray a=groups.get(role);for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p!=null)cricketList.addView(teamPlayerCompact(p,sport));}}}

    private void renderTeamStats(JSONObject d,JSONObject team,String sport,String name){clearTeamContent();addClickableSectionTitle("TEAM STATISTICS","Runs, averages, overs and wickets",null);JSONArray players=teamPlayers(team,d);if(players.length()>0){cricketList.addView(tableHeader(new String[]{"PLAYER","M","R","AVG","SR","4s","6s","O","W","ECO"}));for(int i=0;i<players.length();i++){JSONObject p=players.optJSONObject(i);if(p!=null)cricketList.addView(teamStatRow(p,sport));}}JSONObject stats=team.optJSONObject("stats");if(stats==null)stats=team.optJSONObject("statistics");if(stats!=null){java.util.Iterator<String> it=stats.keys();while(it.hasNext()){String k=it.next();cricketList.addView(statRow(prettyKey(k),String.valueOf(stats.opt(k)),"TEAM STAT"));}}}

    private View teamStatRow(JSONObject p,String sport){String name=p.optString("name",p.optString("player",p.optString("player_name","Player")));String slug=p.optString("slug",p.optString("player_slug",p.optString("id",slugifyLocal(name))));JSONObject s=p.optJSONObject("stats");if(s==null)s=p.optJSONObject("statistics");if(s==null)s=p;LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(7),dp(6),dp(7),dp(6));r.setBackground(round(themeCard(),11));TextView nm=text(name,10,themePrimaryText(),true);nm.setOnClickListener(v->openPlayerPage(sport,slug,name));r.addView(nm,new LinearLayout.LayoutParams(0,dp(40),2.3f));String[] keys={"matches","runs","average","strike_rate","fours","sixes","overs","wickets","economy"};for(String k:keys){TextView x=text(s.has(k)?String.valueOf(s.opt(k)):"-",9,themePrimaryText(),false);x.setGravity(Gravity.CENTER);r.addView(x,new LinearLayout.LayoutParams(0,dp(40),1));}return r;}

    private void renderTeamFixtures(JSONObject d,JSONObject team,String sport,String name){clearTeamContent();addClickableSectionTitle("FIXTURES & RESULTS","Recent and upcoming matches",null);JSONArray fixtures=findArrayDeep(d,"matches","fixtures","schedule","recent_matches","upcoming_matches");if(fixtures.length()==0){showInlineMessage("No fixtures were returned for this team.");return;}for(int i=0;i<Math.min(30,fixtures.length());i++){JSONObject m=fixtures.optJSONObject(i);if(m==null){cricketList.addView(statRow("Match "+(i+1),String.valueOf(fixtures.opt(i)),"FIXTURE"));continue;}String id=m.optString("id",m.optString("match_id",m.optString("slug","")));String title=m.optString("name",m.optString("title",m.optString("match",name)));String score=m.optString("score",m.optString("result",m.optString("status","")));LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),dp(8),dp(10),dp(8));row.setBackground(round(themeCard(),14));TextView t=text(title,11,themePrimaryText(),true);row.addView(t,new LinearLayout.LayoutParams(0,dp(44),1));TextView sc=text(score,10,Color.rgb(0,137,123),true);sc.setGravity(Gravity.RIGHT);row.addView(sc,new LinearLayout.LayoutParams(dp(115),dp(44)));if(!id.isEmpty())row.setOnClickListener(v->loadSportDetail(sport,id,m));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(5));row.setLayoutParams(lp);cricketList.addView(row);}}

    private String slugifyLocal(String s){return String.valueOf(s==null?"":s).toLowerCase().replaceAll("[^a-z0-9]+","-").replaceAll("^-+|-+$","");}

    private String getUrl(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(15000); c.setRequestMethod("GET");
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()))) {
            StringBuilder b = new StringBuilder(); String line;
            while ((line = r.readLine()) != null) b.append(line);
            return b.toString();
        } finally { c.disconnect(); }
    }

    private void pingViewer() {
        if (BACKEND_URL.contains("REPLACE-WITH-YOUR-WORKER") || channels.isEmpty()) return;
        if (currentIndex < 0 || currentIndex >= channels.size()) return;
        int id = channels.get(currentIndex).id;
        if (id <= 0) return;
        network.execute(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(BACKEND_URL + "/viewer/ping").openConnection();
                c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json");
                byte[] body = new JSONObject().put("viewerId", viewerId).put("channelId", id).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
                try (OutputStream out = c.getOutputStream()) { out.write(body); }
                c.getResponseCode();
            } catch (Exception ignored) {} finally { if (c != null) c.disconnect(); }
        });
    }

    private void updateNowPlaying(Channel c) {
        nowPlayingName.setText(c.name);
        nowPlayingProgram.setText("Now Playing: " + (c.programName == null || c.programName.trim().isEmpty() ? "—" : c.programName));
        if (c.showViewers && c.viewerCount > 0) {
            viewerCountView.setVisibility(View.VISIBLE);
            viewerCountView.setText("👁 " + c.viewerCount + " viewers");
        } else viewerCountView.setVisibility(View.GONE);
    }

    private void renderNotice(Notice n) {
        if (!"TV".equals(currentCategory)) { hideNotice(); return; }
        if (n == null) { hideNotice(); return; }
        String type = n.type == null ? "text" : n.type.toLowerCase();
        String html; int fallbackHeightDp;
        if ("banner".equals(type)) {
            html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head><body style='margin:0;background:#0b0f14'><img src='" + esc(n.mediaUrl) + "' style='width:100%;height:auto;display:block'></body></html>"; fallbackHeightDp = 100;
        } else if ("video".equals(type)) {
            html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head><body style='margin:0;background:#000'><video src='" + esc(n.mediaUrl) + "' controls autoplay muted playsinline loop style='width:100%;height:auto;display:block'></video></body></html>"; fallbackHeightDp = 170;
        } else {
            html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head><body style='margin:0;background:#0b0f14;color:#fff'><div style='padding:10px 14px;box-sizing:border-box'>" + n.html + "</div></body></html>"; fallbackHeightDp = 100;
        }
        noticeContainer.setVisibility(View.VISIBLE);
        ViewGroup.LayoutParams lp = noticeContainer.getLayoutParams(); lp.height = 0; noticeContainer.setLayoutParams(lp);
        noticeWebView.loadDataWithBaseURL("https://onetv.local/", html, "text/html", "UTF-8", null);
        resizeNoticeToContent(fallbackHeightDp, 250);
        resizeNoticeToContent(fallbackHeightDp, 900);
    }

    private void resizeNoticeToContent(int fallbackHeightDp, long delayMs) {
        handler.postDelayed(() -> {
            if (noticeContainer == null || noticeWebView == null || noticeContainer.getVisibility() != View.VISIBLE) return;
            float density = getResources().getDisplayMetrics().density;
            int contentPx = (int) (noticeWebView.getContentHeight() * density);
            int fallbackPx = (int) (fallbackHeightDp * density);
            ViewGroup.LayoutParams lp = noticeContainer.getLayoutParams();
            lp.height = Math.max(contentPx, fallbackPx);
            noticeContainer.setLayoutParams(lp);
        }, delayMs);
    }

    private void hideNotice() {
        if (noticeContainer == null) return;
        noticeContainer.setVisibility(View.GONE);
        ViewGroup.LayoutParams lp = noticeContainer.getLayoutParams(); lp.height = 0; noticeContainer.setLayoutParams(lp);
    }

    private String esc(String s) { return s == null ? "" : s.replace("&", "&amp;").replace("\"", "&quot;").replace("'", "&#39;").replace("<", "&lt;").replace(">", "&gt;"); }

    private Button pillButton(String label, float size, int heightPx) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(size);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setTextColor(themePrimaryText());
        b.setBackground(round(themePill(), 24));
        if (heightPx > 0) {
            b.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, heightPx));
        }
        return b;
    }

    private String sportName(String sport) {
        if (sport == null) return "SPORTS";
        String s = sport.trim().toLowerCase();
        if ("cricket".equals(s)) return "CRICKET";
        if ("football".equals(s) || "soccer".equals(s)) return "FOOTBALL";
        if ("basketball".equals(s)) return "BASKETBALL";
        if ("tennis".equals(s)) return "TENNIS";
        if (s.isEmpty()) return "SPORTS";
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

    private void loadRemoteImage(ImageView imageView, String url) {
        if (imageView == null || url == null || url.trim().isEmpty()) return;
        final String targetUrl = url.trim();
        network.execute(() -> {
            HttpURLConnection connection = null;
            InputStream input = null;
            try {
                connection = (HttpURLConnection) new URL(targetUrl).openConnection();
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(10000);
                connection.setInstanceFollowRedirects(true);
                connection.setUseCaches(true);
                connection.setRequestProperty("User-Agent", "OneTV/1.6");
                if (connection.getResponseCode() >= 200 && connection.getResponseCode() < 300) {
                    input = connection.getInputStream();
                    final Bitmap bitmap = BitmapFactory.decodeStream(input);
                    if (bitmap != null) {
                        handler.post(() -> {
                            if (imageView.getWindowToken() != null) {
                                imageView.setImageBitmap(bitmap);
                            }
                        });
                    }
                }
            } catch (Exception ignored) {
            } finally {
                try {
                    if (input != null) input.close();
                } catch (Exception ignored) {
                }
                if (connection != null) connection.disconnect();
            }
        });
    }

    private Button playerControlButton(String label) { Button b = new Button(this); b.setText(label); b.setTextSize(17); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setMinHeight(0); b.setMinWidth(0); b.setGravity(Gravity.CENTER); b.setIncludeFontPadding(false); b.setPadding(0,0,0,0); b.setBackground(round(Color.argb(105, 255, 255, 255), 11)); return b; }
    private ImageButton playerIconButton(int iconRes, String description, View.OnClickListener listener) { ImageButton b = new ImageButton(this); b.setImageResource(iconRes); b.setContentDescription(description); b.setScaleType(ImageButton.ScaleType.CENTER_INSIDE); b.setPadding(dp(7),dp(7),dp(7),dp(7)); b.setBackground(round(Color.argb(105, 255, 255, 255), 11)); b.setOnClickListener(listener); return b; }
    private Button controlButton(String label) { Button b = new Button(this); b.setText(label); b.setTextSize(12); b.setAllCaps(false); return b; }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); int resolved = (color == Color.WHITE) ? themePrimaryText() : (color == Color.LTGRAY || color == Color.GRAY ? themeSecondaryText() : color); t.setTextColor(resolved); t.setTextSize(size); if (bold) t.setTypeface(null, Typeface.BOLD); return t; }
    private GradientDrawable round(int color, float radius) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }

    private void setControlsVisible(boolean visible) { controlsVisible = visible; playerControls.setVisibility(visible ? View.VISIBLE : View.GONE); }
    private void toggleControls() { if (controlsVisible) { setControlsVisible(false); handler.removeCallbacks(hideControls); } else showControlsTemporarily(); }
    private void showControlsTemporarily() { setControlsVisible(true); handler.removeCallbacks(hideControls); handler.postDelayed(hideControls, 3500); }
    private void togglePlayback() {
        if (youtubeWebView != null && youtubeWebView.getVisibility() == View.VISIBLE) {
            if (!youtubeReady) { pendingYoutubeCommand = playbackPaused ? "playVideo" : "pauseVideo"; }
            else if (!playbackPaused) { sendYouTubeCommand("pauseVideo", "[]"); }
            else { sendYouTubeCommand("playVideo", "[]"); }
            playbackPaused = !playbackPaused;
            if (pauseResumeButton != null) pauseResumeButton.setImageResource(playbackPaused ? R.drawable.ic_play : R.drawable.ic_pause);
        } else if (player != null) {
            if (player.isPlaying()) { player.pause(); playbackPaused = true; }
            else { player.play(); playbackPaused = false; }
            if (pauseResumeButton != null) pauseResumeButton.setImageResource(playbackPaused ? R.drawable.ic_play : R.drawable.ic_pause);
        }
        showControlsTemporarily();
    }
    private void sendYouTubeCommand(String func, String args) {
        if (youtubeWebView == null) return;
        if (!youtubeReady) { pendingYoutubeCommand = func; return; }
        String payload = "{\"event\":\"command\",\"func\":\"" + func + "\",\"args\":" + args + "}";
        String escaped = payload.replace("\\", "\\\\").replace("'", "\\'");
        String js = "(function(){var f=document.getElementById('ytplayer')||document.querySelector('iframe');if(f&&f.contentWindow){f.contentWindow.postMessage('" + escaped + "','*');}})()";
        youtubeWebView.evaluateJavascript(js, null);
    }

    private void updateTimeline() {
        if (timelineSeekBar == null) return;
        if (player == null || youtubeWebView == null && playerView == null || youtubeWebView.getVisibility() == View.VISIBLE || !player.isCurrentMediaItemSeekable()) {
            timelineSeekBar.setEnabled(false);
            timelineSeekBar.setProgress(0);
            return;
        }
        long duration = player.getDuration();
        long position = player.getCurrentPosition();
        if (duration > 0 && duration != androidx.media3.common.C.TIME_UNSET) {
            timelineSeekBar.setEnabled(true);
            timelineSeekBar.setProgress((int)Math.max(0, Math.min(1000, (position * 1000L) / duration)));
        } else {
            timelineSeekBar.setEnabled(false);
            timelineSeekBar.setProgress(0);
        }
    }

    private void adjustVolume(float d) {
        int p = (youtubeWebView != null && youtubeWebView.getVisibility() == View.VISIBLE) ? lastVolume : (player == null ? lastVolume : (int)(player.getVolume()*100));
        setVolumePercent(Math.max(0, Math.min(100, p + Math.round(d*100)))); showControlsTemporarily();
    }
    private void setVolumePercent(int percent) {
        int clamped=Math.max(0,Math.min(100,percent));
        if(clamped>0) lastVolume=clamped;
        if (youtubeWebView != null && youtubeWebView.getVisibility() == View.VISIBLE) sendYouTubeCommand("setVolume", "[" + clamped + "]");
        else if (player != null) player.setVolume(clamped / 100f);
    }
    private void toggleMute() {
        if (youtubeWebView != null && youtubeWebView.getVisibility() == View.VISIBLE) {
            if (lastVolume > 0) { sendYouTubeCommand("setVolume", "[0]"); lastVolume = 0; }
            else { lastVolume = 100; sendYouTubeCommand("setVolume", "[100]"); }
        } else if (player != null) {
            if (player.getVolume() > 0) { lastVolume = Math.max(1, (int)(player.getVolume()*100)); setVolumePercent(0); }
            else setVolumePercent(lastVolume > 0 ? lastVolume : 100);
        }
        showControlsTemporarily();
    }

    private void showVolumePopup(View anchor) {
        if (volumePopup != null && volumePopup.isShowing()) { volumePopup.dismiss(); return; }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setPadding(dp(12), dp(8), dp(12), dp(8));
        box.setBackground(round(darkMode ? Color.rgb(28,34,42) : Color.WHITE, 14));
        SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        int initial = (youtubeWebView != null && youtubeWebView.getVisibility() == View.VISIBLE) ? lastVolume : (player != null ? Math.round(player.getVolume()*100) : lastVolume);
        bar.setProgress(initial);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { if (fromUser) setVolumePercent(progress); }
            public void onStartTrackingTouch(SeekBar seekBar) { handler.removeCallbacks(hideControls); }
            public void onStopTrackingTouch(SeekBar seekBar) { showControlsTemporarily(); }
        });
        box.addView(bar, new LinearLayout.LayoutParams(dp(180), dp(42)));
        volumePopup = new PopupWindow(box, dp(210), dp(58), true);
        volumePopup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        volumePopup.setOutsideTouchable(true);
        volumePopup.setElevation(dp(8));
        volumePopup.showAsDropDown(anchor, -dp(175), -dp(65));
        showControlsTemporarily();
    }
    private void showQualityMenu(View anchor) {
        PopupWindow popup = new PopupWindow(this); LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(8,8,8,8); box.setBackgroundColor(Color.rgb(35,40,48));
        for (String q : new String[]{"Auto","1080p","720p","480p","360p"}) {
            Button b = controlButton(q);
            b.setOnClickListener(v -> {
                if (youtubeWebView != null && youtubeWebView.getVisibility() == View.VISIBLE) sendYouTubeCommand("setPlaybackQuality", "[\"" + q + "\"]");
                Toast.makeText(this, "Quality: " + q, Toast.LENGTH_SHORT).show(); popup.dismiss(); showControlsTemporarily();
            });
            box.addView(b, new LinearLayout.LayoutParams(dp(180), dp(48)));
        }
        popup.setContentView(box); popup.setWidth(220); popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT); popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.rgb(35,40,48))); popup.setOutsideTouchable(true); popup.setFocusable(true); popup.showAsDropDown(anchor); showControlsTemporarily();
    }
    private void toggleFullscreen() {
        if (videoFrame == null) return;
        isFullscreen = !isFullscreen;
        ViewGroup decor = (ViewGroup) getWindow().getDecorView();
        if (isFullscreen) {
            videoFrameOriginalParent = (ViewGroup) videoFrame.getParent();
            videoFrameOriginalIndex = videoFrameOriginalParent != null ? videoFrameOriginalParent.indexOfChild(videoFrame) : 0;
            if (videoFrameOriginalParent != null) videoFrameOriginalParent.removeView(videoFrame);
            decor.addView(videoFrame, new ViewGroup.LayoutParams(-1, -1));
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            if (adSection != null) adSection.setVisibility(View.GONE);
            if (footerView != null) footerView.setVisibility(View.GONE);
            showControlsTemporarily();
        } else {
            decor.removeView(videoFrame);
            if (videoFrameOriginalParent != null) {
                videoFrameOriginalParent.addView(videoFrame, Math.min(videoFrameOriginalIndex, videoFrameOriginalParent.getChildCount()), new LinearLayout.LayoutParams(-1, normalPlayerHeight));
            }
            getWindow().getDecorView().setSystemUiVisibility(darkMode ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            if (adSection != null) adSection.setVisibility(View.VISIBLE);
            if (footerView != null) footerView.setVisibility(View.VISIBLE);
            showControlsTemporarily();
        }
    }

    private int themeBackground() { return darkMode ? Color.rgb(8,12,18) : Color.rgb(247,249,252); }
    private int themePrimaryText() { return darkMode ? Color.WHITE : Color.rgb(25,30,36); }
    private int themeSecondaryText() { return darkMode ? Color.LTGRAY : Color.rgb(92,99,108); }
    private int themeCard() { return darkMode ? Color.rgb(18,25,33) : Color.WHITE; }
    private int themePill() { return darkMode ? Color.rgb(27,35,45) : Color.rgb(232,236,241); }

    private void applySystemTheme() {
        getWindow().setStatusBarColor(darkMode ? Color.rgb(8,12,18) : Color.rgb(247,249,252));
        getWindow().setNavigationBarColor(darkMode ? Color.BLACK : Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(darkMode ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }

    private void toggleTheme() {
        darkMode = !darkMode;
        prefs.edit().putBoolean("dark_mode", darkMode).apply();
        String keepCategory = currentCategory;
        int keepIndex = currentIndex;
        boolean wasPlaying = player != null && player.isPlaying();
        buildUi();
        if (keepIndex >= 0 && keepIndex < channels.size() && wasPlaying && !keepCategory.startsWith("SPORT:") && !"Cricket Live".equals(keepCategory)) { playChannel(keepIndex); }
        loadBackendContent();
        currentCategory = keepCategory;
        showCategory(keepCategory);
        applySystemTheme();
    }

    private void applyThemeToViewTree(View view, boolean inPlayer) {
        boolean playerArea = inPlayer || view == videoFrame || view == playerControls || view == playerView || view == youtubeWebView;
        if (!playerArea) {
            if (view instanceof TextView) {
                TextView tv = (TextView)view;
                int c = tv.getCurrentTextColor();
                if (c == Color.WHITE || c == Color.LTGRAY || c == Color.GRAY) tv.setTextColor(themePrimaryText());
            }
            if (view instanceof Button && view != themeToggleButton) ((Button) view).setTextColor(themePrimaryText());
        }
        if (view instanceof ViewGroup) {
            ViewGroup group=(ViewGroup)view;
            for(int i=0;i<group.getChildCount();i++) applyThemeToViewTree(group.getChildAt(i), playerArea);
        }
    }

    @Override public void onBackPressed() {
        if (isFullscreen) { toggleFullscreen(); return; }
        boolean sports = "Cricket Live".equals(currentCategory) || currentCategory.startsWith("SPORT:");
        if (sports && cricketDetail) {
            if ("player".equals(sportsPage) || "team".equals(sportsPage) || "standings".equals(sportsPage) || "commentary".equals(sportsPage) || "stats".equals(sportsPage)) {
                if (currentMatchObject != null) { renderSportsDetail(wrapMatch(currentMatchObject), currentSport); return; }
            } else {
                cricketDetail=false; sportsPage="matches"; selectSportsCategory(currentCategory); return;
            }
        }
        super.onBackPressed();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && isFullscreen) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null); if (volumePopup != null) volumePopup.dismiss(); network.shutdownNow();
        if (player != null) { player.release(); player = null; }
        if (noticeWebView != null) noticeWebView.destroy(); if (youtubeWebView != null) youtubeWebView.destroy();
        if (nativeAd != null) { nativeAd.destroy(); nativeAd = null; }
        super.onDestroy();
    }

    static class Channel {
        int id, viewerCount; String number, name, country, category, url, sourceType, youtubeVideoId, programName; boolean showViewers, loop;
        Channel(int id, String number, String name, String country, String category, String url, String sourceType, String youtubeVideoId, String programName, int viewerCount, boolean showViewers, boolean loop) { this.id=id;this.number=number;this.name=name;this.country=country;this.category=category;this.url=url;this.sourceType=sourceType;this.youtubeVideoId=youtubeVideoId;this.programName=programName;this.viewerCount=viewerCount;this.showViewers=showViewers;this.loop=loop; }
    }
    static class Notice { String type,title,html,mediaUrl,linkUrl; Notice(String t,String ti,String h,String m,String l){type=t;title=ti;html=h;mediaUrl=m;linkUrl=l;} }
}
