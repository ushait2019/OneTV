# One TV Sports PRO UI V4

This revision follows the information architecture patterns of professional cricket score platforms such as Cricbuzz and CREX without copying their branding or page content.

## Clickable information architecture
- Competition name -> standings / league table
- Team name/logo -> team profile
- Player name/photo -> player profile
- Match card -> match centre
- Scorecard player row -> player profile
- Recent match -> match centre when a match id is available

## Team profile
- Overview
- Squad with player image, name and role
- Player quick stats when supplied by the provider: matches, runs, average, strike rate, fours, sixes, overs, wickets and economy
- Team information, form and record
- Top performers
- Fixtures and results

## Player profile
- Photo, name, role and team
- Career/season metadata
- Batting and bowling figures
- Runs, average, strike rate, balls, overs, wickets, economy, fours, sixes and other supplied statistics
- Match history

## Match centre
- Scorecard
- Ball-by-ball
- Match statistics
- Standings
- Live batsmen and bowler panels
- Clickable player and team names

## Data source
SportScore remains the primary sports entity provider. The app does not scrape Cricbuzz or CREX. Their sites were used only as UX/reference inspiration.
