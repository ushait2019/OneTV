# One TV

One TV is a GitHub Actions-buildable Android live TV application foundation developed by USHA IT.

## Important
The included streams are public test videos only. Replace them with streams that you are authorized to distribute. The production app should obtain channel metadata and authorized stream URLs from the backend/admin panel.

## Build
GitHub Actions workflow: `.github/workflows/build.yml`

Startup crash fixed: AppCompat theme is now compatible with MainActivity.

Build release APK/AAB through GitHub Actions.
