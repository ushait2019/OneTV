package com.ushait.onetv;

import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ExoPlayer player;
    private PlayerView playerView;
    private LinearLayout channelList;
    private final List<Channel> channels = new ArrayList<>();
    private int currentIndex = 0;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        seedChannels();
        buildUi();
    }

    private void seedChannels() {
        // Public test streams only. Replace these in the backend with authorized TV streams.
        channels.add(new Channel("001", "Art of Motion", "International", "Movies", "https://storage.googleapis.com/coverr-main/mp4/Mt_Baker.mp4"));
        channels.add(new Channel("002", "Big Buck Bunny", "International", "Kids", "https://storage.googleapis.com/coverr-main/mp4/Footboys.mp4"));
        channels.add(new Channel("003", "Sintel", "International", "Movies", "https://storage.googleapis.com/coverr-main/mp4/Forest.mp4"));
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(11,15,20));

        TextView title = text("ONE TV", 22, Color.WHITE, true);
        title.setPadding(20, 18, 20, 12);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        HorizontalScrollView catsScroll = new HorizontalScrollView(this);
        LinearLayout cats = new LinearLayout(this); cats.setPadding(12,0,12,8);
        for (String cat : Arrays.asList("All","News","Sports","Movies","Kids")) {
            Button b = new Button(this); b.setText(cat); b.setOnClickListener(v -> showCategory(cat));
            cats.addView(b, new LinearLayout.LayoutParams(-2, -2));
        }
        catsScroll.addView(cats); root.addView(catsScroll);

        playerView = new PlayerView(this);
        playerView.setUseController(true);
        root.addView(playerView, new LinearLayout.LayoutParams(-1, 230));

        TextView now = text("Channels", 18, Color.WHITE, true); now.setPadding(18,12,18,8);
        root.addView(now);

        ScrollView scroll = new ScrollView(this);
        channelList = new LinearLayout(this); channelList.setOrientation(LinearLayout.VERTICAL); channelList.setPadding(12,0,12,8);
        scroll.addView(channelList); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        TextView ad = text("AD SPACE  •  Banner / Video Rotation", 14, Color.LTGRAY, false);
        ad.setGravity(Gravity.CENTER); ad.setBackgroundColor(Color.rgb(25,30,36));
        root.addView(ad, new LinearLayout.LayoutParams(-1, 70));
        TextView footer = text("© 2026 USHA IT. All Rights Reserved.", 12, Color.GRAY, false);
        footer.setGravity(Gravity.CENTER); footer.setPadding(8,8,8,8); root.addView(footer);

        setContentView(root);
        showCategory("All");
        playChannel(0);
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(null,1); return t;
    }

    private void showCategory(String cat) {
        channelList.removeAllViews();
        for (int i=0;i<channels.size();i++) {
            Channel c=channels.get(i); if (!cat.equals("All") && !c.category.equals(cat)) continue;
            Button b=new Button(this); b.setText(c.number+"   "+c.name); final int idx=i; b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL); b.setOnClickListener(v -> playChannel(idx));
            channelList.addView(b,new LinearLayout.LayoutParams(-1,60));
        }
    }

    private void playChannel(int index) {
        if (channels.isEmpty()) return; currentIndex=(index+channels.size())%channels.size();
        Channel c=channels.get(currentIndex);
        if (player==null) { player=new ExoPlayer.Builder(this).build(); playerView.setPlayer(player); }
        player.setMediaItem(MediaItem.fromUri(Uri.parse(c.url))); player.prepare(); player.play();
    }

    @Override protected void onDestroy(){ if(player!=null){player.release();player=null;} super.onDestroy(); }
    static class Channel { String number,name,country,category,url; Channel(String n,String nm,String co,String ca,String u){number=n;name=nm;country=co;category=ca;url=u;} }
}
