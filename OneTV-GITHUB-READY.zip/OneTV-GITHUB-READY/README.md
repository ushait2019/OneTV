# One TV

Android live TV app by USHA IT.

## Current build
- Version 1.1
- Package: `com.ushait.onetv`
- Android Activity uses the platform theme to avoid the AppCompat startup crash.
- Media3/ExoPlayer player.
- Player controls appear on touch and auto-hide after inactivity.
- Previous / Next channel.
- Volume / Mute.
- Quality menu UI: Auto, 1080p, 720p, 480p, 360p.
- Fullscreen.
- Categories: All, News, Sports, Movies, Kids.
- Ad section placeholder above copyright.

## Streams
The included streams are public test media only. Replace them through the planned backend with authorized TV streams. Do not redistribute streams without permission.

## Build
Use the GitHub Actions workflow in `.github/workflows/` to build the APK/AAB in the cloud. Android Studio is not required.

## AdMob
- AdMob app: One TV (Android)
- App ID: `ca-app-pub-5981864080922785~4472399258`
- Home banner unit: `OneTV_Banner_Home`
- Banner ID: `ca-app-pub-5981864080922785/5178976268`
- Debug builds use Google test banner ID to avoid invalid traffic while testing. Release builds use the configured One TV banner unit.
- The banner is placed only in the Home Ads section above the USHA IT copyright. No interstitial, app-open, rewarded, or player-overlay ads are included.
