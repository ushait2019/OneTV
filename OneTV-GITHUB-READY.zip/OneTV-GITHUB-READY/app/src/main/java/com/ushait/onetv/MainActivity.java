package com.ushait.onetv;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends Activity {

    private ExoPlayer player;
    private PlayerView playerView;
    private LinearLayout channelList;
    private LinearLayout playerControls;
    private TextView playerChannelLabel;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<Channel> channels = new ArrayList<>();
    private int currentIndex = 0;
    private boolean controlsVisible = false;
    private static final String ADMOB_LIVE_BANNER_ID = "ca-app-pub-5981864080922785/5178976268";
    private static final String ADMOB_TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111";

    private final Runnable hideControls = new Runnable() {
        @Override public void run() {
            setControlsVisible(false);
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 15, 20));
        getWindow().setNavigationBarColor(Color.BLACK);
        seedChannels();
        MobileAds.initialize(this, status -> {});
        buildUi();
    }

    private void seedChannels() {
        // Public test streams only. Replace these with authorized backend-controlled streams.
        channels.add(new Channel("001", "Art of Motion", "International", "Movies",
                "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"));
        channels.add(new Channel("002", "Big Buck Bunny", "International", "Kids",
                "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"));
        channels.add(new Channel("003", "Sintel", "International", "Movies",
                "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"));
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(11, 15, 20));

        TextView title = text("ONE TV", 22, Color.WHITE, true);
        title.setPadding(20, 18, 20, 12);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        HorizontalScrollView catsScroll = new HorizontalScrollView(this);
        catsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout cats = new LinearLayout(this);
        cats.setPadding(12, 0, 12, 8);
        for (String cat : Arrays.asList("All", "News", "Sports", "Movies", "Kids")) {
            Button b = new Button(this);
            b.setText(cat);
            b.setOnClickListener(v -> showCategory(cat));
            cats.addView(b, new LinearLayout.LayoutParams(-2, -2));
        }
        catsScroll.addView(cats);
        root.addView(catsScroll);

        // Player container with responsive overlay controls.
        LinearLayout playerContainer = new LinearLayout(this);
        playerContainer.setOrientation(LinearLayout.VERTICAL);
        playerContainer.setBackgroundColor(Color.BLACK);

        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerAutoShow(false);
        playerView.setControllerHideOnTouch(false);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        playerContainer.addView(playerView, new LinearLayout.LayoutParams(-1, 230));

        // Transparent-ish overlay control area. It is hidden until the player is touched.
        playerControls = new LinearLayout(this);
        playerControls.setOrientation(LinearLayout.VERTICAL);
        playerControls.setGravity(Gravity.CENTER_HORIZONTAL);
        playerControls.setPadding(10, 8, 10, 10);
        playerControls.setBackgroundColor(Color.rgb(18, 22, 28));

        playerChannelLabel = text("No channel selected", 13, Color.WHITE, true);
        playerChannelLabel.setGravity(Gravity.CENTER);
        playerControls.addView(playerChannelLabel, new LinearLayout.LayoutParams(-1, 34));

        LinearLayout row1 = new LinearLayout(this);
        row1.setGravity(Gravity.CENTER);
        Button prev = controlButton("◀ Previous");
        Button next = controlButton("Next ▶");
        prev.setOnClickListener(v -> playChannel(currentIndex - 1));
        next.setOnClickListener(v -> playChannel(currentIndex + 1));
        row1.addView(prev, weightParams());
        row1.addView(next, weightParams());
        playerControls.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setGravity(Gravity.CENTER);
        Button volume = controlButton("🔊 Volume");
        Button mute = controlButton("🔇 Mute");
        Button quality = controlButton("Quality ▾");
        Button fullscreen = controlButton("⛶ Fullscreen");

        volume.setOnClickListener(v -> adjustVolume(0.10f));
        mute.setOnClickListener(v -> toggleMute());
        quality.setOnClickListener(v -> showQualityMenu(quality));
        fullscreen.setOnClickListener(v -> toggleFullscreen());

        row2.addView(volume, weightParams());
        row2.addView(mute, weightParams());
        row2.addView(quality, weightParams());
        row2.addView(fullscreen, weightParams());
        playerControls.addView(row2);

        playerContainer.addView(playerControls,
                new LinearLayout.LayoutParams(-1, -2));

        // Tap anywhere on the player/control area to reveal controls.
        playerContainer.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                toggleControls();
            }
            return true;
        });

        root.addView(playerContainer, new LinearLayout.LayoutParams(-1, -2));

        TextView now = text("Channels", 18, Color.WHITE, true);
        now.setPadding(18, 12, 18, 8);
        root.addView(now, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        channelList = new LinearLayout(this);
        channelList.setOrientation(LinearLayout.VERTICAL);
        channelList.setPadding(12, 0, 12, 8);
        scroll.addView(channelList);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout adSection = new LinearLayout(this);
        adSection.setOrientation(LinearLayout.VERTICAL);
        adSection.setGravity(Gravity.CENTER);
        adSection.setBackgroundColor(Color.rgb(25, 30, 36));
        adSection.setPadding(8, 6, 8, 6);

        TextView adLabel = text("ADVERTISEMENT", 10, Color.GRAY, false);
        adLabel.setGravity(Gravity.CENTER);
        adSection.addView(adLabel, new LinearLayout.LayoutParams(-1, 20));

        AdView adView = new AdView(this);
        int widthPx = getResources().getDisplayMetrics().widthPixels;
        float density = getResources().getDisplayMetrics().density;
        int adWidth = Math.max(1, (int) (widthPx / density));
        adView.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth));
        adView.setAdUnitId(BuildConfig.DEBUG ? ADMOB_TEST_BANNER_ID : ADMOB_LIVE_BANNER_ID);
        adView.loadAd(new AdRequest.Builder().build());
        adSection.addView(adView, new LinearLayout.LayoutParams(-1, -2));
        root.addView(adSection, new LinearLayout.LayoutParams(-1, -2));

        TextView footer = text("© 2026 USHA IT. All Rights Reserved.", 12, Color.GRAY, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(8, 8, 8, 8);
        root.addView(footer);

        setContentView(root);
        playerControls.setVisibility(View.GONE);
        showCategory("All");
    }

    private LinearLayout.LayoutParams weightParams() {
        return new LinearLayout.LayoutParams(0, 48, 1f);
    }

    private Button controlButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setAllCaps(false);
        return b;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, 1);
        return t;
    }

    private void showCategory(String cat) {
        channelList.removeAllViews();
        for (int i = 0; i < channels.size(); i++) {
            Channel c = channels.get(i);
            if (!cat.equals("All") && !c.category.equals(cat)) continue;
            Button b = new Button(this);
            b.setText(c.number + "   " + c.name);
            final int idx = i;
            b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            b.setOnClickListener(v -> playChannel(idx));
            channelList.addView(b, new LinearLayout.LayoutParams(-1, 60));
        }
    }

    private void playChannel(int index) {
        if (channels.isEmpty()) return;
        currentIndex = (index + channels.size()) % channels.size();
        Channel c = channels.get(currentIndex);

        if (player == null) {
            player = new ExoPlayer.Builder(this).build();
            playerView.setPlayer(player);
            player.addListener(new Player.Listener() {
                @Override public void onPlayerError(PlaybackException error) {
                    Toast.makeText(MainActivity.this,
                            "Unable to play this stream", Toast.LENGTH_SHORT).show();
                }
            });
        }

        player.setMediaItem(MediaItem.fromUri(Uri.parse(c.url)));
        player.prepare();
        player.play();

        playerChannelLabel.setText(c.number + "  " + c.name);
        showControlsTemporarily();
    }

    private void setControlsVisible(boolean visible) {
        controlsVisible = visible;
        playerControls.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    private void toggleControls() {
        if (controlsVisible) {
            setControlsVisible(false);
            handler.removeCallbacks(hideControls);
        } else {
            showControlsTemporarily();
        }
    }

    private void showControlsTemporarily() {
        setControlsVisible(true);
        handler.removeCallbacks(hideControls);
        handler.postDelayed(hideControls, 3500);
    }

    private void adjustVolume(float delta) {
        if (player == null) return;
        float v = Math.max(0f, Math.min(1f, player.getVolume() + delta));
        player.setVolume(v);
        showControlsTemporarily();
    }

    private void toggleMute() {
        if (player == null) return;
        player.setVolume(player.getVolume() > 0f ? 0f : 1f);
        showControlsTemporarily();
    }

    private void showQualityMenu(View anchor) {
        final String[] qualities = {"Auto", "1080p", "720p", "480p", "360p"};
        PopupWindow popup = new PopupWindow(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(8, 8, 8, 8);
        box.setBackgroundColor(Color.rgb(35, 40, 48));

        for (String q : qualities) {
            Button b = controlButton(q);
            b.setOnClickListener(v -> {
                // Quality switching is intentionally a UI hook until the backend
                // supplies actual HLS/DASH variants. "Auto" uses adaptive playback.
                Toast.makeText(MainActivity.this,
                        "Quality: " + q, Toast.LENGTH_SHORT).show();
                popup.dismiss();
                showControlsTemporarily();
            });
            box.addView(b, new LinearLayout.LayoutParams(180, 48));
        }

        popup.setContentView(box);
        popup.setWidth(220);
        popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.rgb(35, 40, 48)));
        popup.setOutsideTouchable(true);
        popup.setFocusable(true);
        popup.showAsDropDown(anchor);
        showControlsTemporarily();
    }

    private void toggleFullscreen() {
        int flags = getWindow().getDecorView().getSystemUiVisibility();
        boolean fullscreen = (flags & View.SYSTEM_UI_FLAG_FULLSCREEN) != 0;
        if (!fullscreen) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
        showControlsTemporarily();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }

    static class Channel {
        String number, name, country, category, url;
        Channel(String n, String nm, String co, String ca, String u) {
            number = n;
            name = nm;
            country = co;
            category = ca;
            url = u;
        }
    }
}
