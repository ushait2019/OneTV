package com.usha.onetv

/** One TV ad configuration. Keep One TV ad units separate from other apps. */
object AdConfig {
    // Values previously supplied in conversation. Verify these belong to One TV in LevelPlay before release.
    const val LEVELPLAY_APP_KEY = "291bd9bcd"
    const val LEVELPLAY_BANNER_AD_UNIT_ID = "rfvqbutm8q247lt6"
}
