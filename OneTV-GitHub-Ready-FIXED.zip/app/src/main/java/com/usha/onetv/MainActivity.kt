package com.usha.onetv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import com.usha.onetv.ui.theme.OneTVTheme
import kotlinx.coroutines.delay

private data class Channel(
    val number: Int,
    val name: String,
    val category: String,
    val country: String,
    val url: String
)

private val channels = listOf(
    Channel(1, "Art of Motion", "Sports", "Demo", "https://cdn.bitmovin.com/content/assets/art-of-motion-dash-hls-progressive/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8"),
    Channel(2, "Big Buck Bunny", "Movies", "Demo", "https://cdn.bitmovin.com/content/assets/bbb/stream.m3u8"),
    Channel(3, "Sintel", "Kids", "Demo", "https://cdn.bitmovin.com/content/assets/sintel/hls/playlist.m3u8")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OneTVTheme { OneTVApp() } }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun OneTVApp() {
    val context = LocalContext.current
    var selected by remember { mutableStateOf(channels.first()) }
    var category by remember { mutableStateOf("All") }
    var muted by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(1f) }
    var qualityMenu by remember { mutableStateOf(false) }
    var channelOverlay by remember { mutableStateOf(true) }
    var adIndex by remember { mutableIntStateOf(0) }

    val trackSelector = remember {
        DefaultTrackSelector(context).apply {
            setParameters(buildUponParameters().setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE))
        }
    }
    val player = remember {
        ExoPlayer.Builder(context).setTrackSelector(trackSelector).build().apply { playWhenReady = true }
    }

    DisposableEffect(Unit) { onDispose { player.release() } }

    LaunchedEffect(selected.url) {
        channelOverlay = true
        player.setMediaItem(MediaItem.fromUri(selected.url))
        player.prepare()
        player.play()
        delay(1800)
        channelOverlay = false
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(10000)
            adIndex = (adIndex + 1) % 2
        }
    }

    val visible = if (category == "All") channels else channels.filter { it.category == category }

    fun switchChannel(delta: Int) {
        val i = channels.indexOf(selected)
        selected = channels[(i + delta + channels.size) % channels.size]
    }

    Scaffold(containerColor = Color(0xFF0B0D10)) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("ONE TV", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("LIVE", color = Color(0xFFFF5252), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("All", "News", "Sports", "Movies", "Kids").forEach { item ->
                    FilterChip(
                        selected = category == item,
                        onClick = { category = item },
                        label = { Text(item) }
                    )
                }
            }

            // Category selection immediately reveals the channel list below the buttons.
            LazyColumn(
                Modifier.fillMaxWidth().heightIn(max = 185.dp).padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(visible, key = { it.number }) { channel ->
                    Surface(
                        onClick = { selected = channel },
                        modifier = Modifier.fillMaxWidth(),
                        color = if (channel.number == selected.number) Color(0xFF1E2935) else Color(0xFF14171C),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("%03d".format(channel.number), color = Color.Gray, fontSize = 12.sp)
                            Spacer(Modifier.width(12.dp))
                            Box(Modifier.size(28.dp).background(Color(0xFF2A2F36), RoundedCornerShape(6.dp)))
                            Spacer(Modifier.width(10.dp))
                            Text(channel.name, color = Color.White, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.weight(1f))
                            Text(channel.category, color = Color.Gray, fontSize = 10.sp)
                        }
                    }
                }
            }

            Box(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp).height(220.dp)
                    .pointerInput(selected.number) {
                        var totalDrag = 0f
                        androidx.compose.foundation.gestures.detectVerticalDragGestures(
                            onVerticalDrag = { _, dragAmount -> totalDrag += dragAmount },
                            onDragEnd = {
                                if (totalDrag < -70f) switchChannel(1)
                                if (totalDrag > 70f) switchChannel(-1)
                                totalDrag = 0f
                            }
                        )
                    }
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { PlayerView(it).apply { player = player; useController = true } }
                )
                if (channelOverlay) {
                    Surface(
                        Modifier.align(Alignment.TopCenter).padding(top = 10.dp),
                        color = Color.Black.copy(alpha = .72f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("%03d  %s".format(selected.number, selected.name), color = Color.White, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { switchChannel(-1) }) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White) }
                IconButton(onClick = {
                    muted = !muted
                    player.volume = if (muted) 0f else volume
                }) { Icon(if (muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp, "Mute", tint = Color.White) }
                IconButton(onClick = {
                    volume = (volume - .1f).coerceAtLeast(0f)
                    muted = volume == 0f
                    player.volume = volume
                }) { Icon(Icons.Default.VolumeDown, "Volume down", tint = Color.White) }
                IconButton(onClick = {
                    volume = (volume + .1f).coerceAtMost(1f)
                    muted = false
                    player.volume = volume
                }) { Icon(Icons.Default.VolumeUp, "Volume up", tint = Color.White) }
                Box {
                    OutlinedButton(onClick = { qualityMenu = true }) { Text("Quality") }
                    DropdownMenu(expanded = qualityMenu, onDismissRequest = { qualityMenu = false }) {
                        listOf("Auto", "1080p", "720p", "480p", "360p").forEach { q ->
                            DropdownMenuItem(text = { Text(q) }, onClick = {
                                val builder = trackSelector.buildUponParameters()
                                when (q) {
                                    "1080p" -> builder.setMaxVideoSize(1920, 1080)
                                    "720p" -> builder.setMaxVideoSize(1280, 720)
                                    "480p" -> builder.setMaxVideoSize(854, 480)
                                    "360p" -> builder.setMaxVideoSize(640, 360)
                                    else -> builder.setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
                                }
                                trackSelector.setParameters(builder)
                                qualityMenu = false
                            })
                        }
                    }
                }
                IconButton(onClick = { switchChannel(1) }) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White) }
            }

            Text("ADVERTISEMENT", color = Color.Gray, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            Surface(
                Modifier.fillMaxWidth().padding(12.dp).height(64.dp),
                color = Color(0xFF171A1F),
                shape = RoundedCornerShape(10.dp)
            ) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        if (adIndex == 0) "One TV • Banner Ad Slot" else "One TV • Inline Video Ad Slot (muted)",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(Modifier.weight(1f))
            Text(
                "© 2026 USHA IT. All Rights Reserved.",
                color = Color.Gray,
                fontSize = 11.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 10.dp)
            )
        }
    }
}
