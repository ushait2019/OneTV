package com.usha.onetv.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
@Composable fun OneTVTheme(content: @Composable () -> Unit) { MaterialTheme(content = content) }
