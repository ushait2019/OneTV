package com.ushait.onetv;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.ui.PlayerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Stack;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final String BACKEND_URL = BuildConfig.BACKEND_URL;
    private static final int BG = Color.rgb(5, 10, 17);
    private static final int PANEL = Color.rgb(13, 25, 39);
    private static final int CARD = Color.rgb(20, 35, 51);
    private static final int CARD_2 = Color.rgb(24, 42, 61);
    private static final int BLUE = Color.rgb(28, 126, 245);
    private static final int CYAN = Color.rgb(0, 205, 190);
    private static final int PURPLE = Color.rgb(119, 52, 245);
    private static final int TEXT = Color.WHITE;
    private static final int MUTED = Color.rgb(174, 188, 203);
    private static final int GREEN = Color.rgb(0, 194, 142);
    private static final int RED = Color.rgb(244, 63, 81);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final Stack<String> history = new Stack<>();
    private final List<Channel> channels = new ArrayList<>();

    private LinearLayout root;
    private FrameLayout contentHost;
    private LinearLayout topModeRow;
    private TextView pageTitle;
    private TextView pageSubtitle;
    private TextView headerSlogan;
    private ImageView logoView;
    private LinearLayout adRow;
    private TextView footer;
    private TextView statusText;
    private TextView notificationBadge;
    private FrameLayout playerFrame;
    private TextView customPlayerControls;
    private final Handler playerUiHandler = new Handler(Looper.getMainLooper());
    private JSONObject adConfig;

    private ExoPlayer player;
    private PlayerView playerView;
    private boolean fullscreen = false;
    private ViewGroup playerOriginalParent;
    private int playerOriginalIndex = 0;

    private String screen = "home";
    private String selectedSport = "cricket";
    private String selectedEntertainment = "TV";
    private String matchMode = "live";
    private JSONObject selectedMatch;
    private String detailTab = "SCORECARD";
    private JSONArray remoteMatches;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(Color.BLACK);
        MobileAds.initialize(this, status -> {});
        buildShell();
        showHome(false);
        loadChannels();
        loadAdConfig();
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        root.addView(buildHeader(), new LinearLayout.LayoutParams(-1, dp(84)));
        contentHost = new FrameLayout(this);
        root.addView(contentHost, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout fixedBottom = new LinearLayout(this);
        fixedBottom.setOrientation(LinearLayout.VERTICAL);
        fixedBottom.setBackgroundColor(BG);

        adRow = buildAds();
        fixedBottom.addView(adRow, new LinearLayout.LayoutParams(-1, dp(92)));

        footer = tv("© 2026 USHA IT. All Rights Reserved.", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(5), 0, dp(8));
        fixedBottom.addView(footer, new LinearLayout.LayoutParams(-1, dp(32)));

        root.addView(fixedBottom, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private View buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(18), dp(5), dp(14), dp(4));
        header.setBackgroundColor(Color.rgb(4, 9, 15));

        TextView menu = tv("☰", 25, TEXT, false);
        menu.setGravity(Gravity.CENTER);
        menu.setContentDescription("Menu");
        menu.setOnClickListener(v -> showMenuPage(true));
        header.addView(menu, new LinearLayout.LayoutParams(dp(40), dp(48)));

        logoView = new ImageView(this);
        logoView.setImageResource(R.drawable.onetv_logo);
        logoView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        header.addView(logoView, new LinearLayout.LayoutParams(dp(116), dp(56)));

        headerSlogan = tv("All in One", 17, TEXT, true);
        headerSlogan.setGravity(Gravity.CENTER_VERTICAL);
        headerSlogan.setPadding(dp(8), 0, 0, 0);
        header.addView(headerSlogan, new LinearLayout.LayoutParams(0, dp(56), 1));

        FrameLayout notification = new FrameLayout(this);
        TextView bell = tv("🔔", 21, TEXT, false);
        bell.setGravity(Gravity.CENTER);
        bell.setContentDescription("Notifications");
        bell.setOnClickListener(v -> showNotifications(true));
        notification.addView(bell, new FrameLayout.LayoutParams(dp(44), dp(48)));

        notificationBadge = tv("3", 9, TEXT, true);
        notificationBadge.setGravity(Gravity.CENTER);
        notificationBadge.setBackground(round(RED, 12));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.TOP | Gravity.END);
        bp.setMargins(0, dp(1), 0, 0);
        notification.addView(notificationBadge, bp);
        header.addView(notification, new LinearLayout.LayoutParams(dp(46), dp(48)));

        TextView sun = tv("☀", 22, Color.rgb(255, 197, 40), false);
        sun.setGravity(Gravity.CENTER);
        sun.setBackground(round(CARD, 14));
        sun.setContentDescription("Appearance");
        sun.setOnClickListener(v -> showAppearance(true));
        header.addView(sun, new LinearLayout.LayoutParams(dp(46), dp(46)));

        return header;
    }

    private LinearLayout buildAds() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(12), dp(6), dp(12), dp(6));
        addAdSlot(row, "home_1");
        addAdSlot(row, "home_2");
        return row;
    }

    private void addAdSlot(LinearLayout row, String placement) {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER);
        card.setBackground(round(PANEL, 12));
        AdView ad = new AdView(this);
        ad.setAdSize(AdSize.BANNER);
        String unit = BuildConfig.DEBUG ? "ca-app-pub-3940256099942544/6300978111" : "ca-app-pub-5981864080922785/5178976268";
        ad.setAdUnitId(unit);
        card.addView(ad, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1);
        p.setMargins(dp(3), 0, dp(3), 0);
        row.addView(card, p);
        ad.loadAd(new AdRequest.Builder().build());
    }

    private void showHome(boolean push) {
        if (push) push("home");
        screen = "home";
        clearContent();
        buildHome();
        hideAds(false);
    }

    private void buildHome() {
        LinearLayout page = page();
        topModeRow = modeRow();
        page.addView(topModeRow);
        page.addView(pageSearchButton("Search matches, videos, channels and programs", "all"));
        page.addView(sectionLabel("Sports", "Live, Upcoming, Results & More"));
        LinearLayout sportsGrid = new LinearLayout(this);
        sportsGrid.setPadding(dp(14), dp(3), dp(14), dp(10));
        String[] sports = {"Cricket", "Football", "Basketball", "Tennis"};
        String[] icons = {"🏏", "⚽", "🏀", "🎾"};
        for (int i = 0; i < sports.length; i++) {
            final String sport = sports[i].toLowerCase(Locale.US);
            LinearLayout c = featureTile(icons[i], sports[i], i == 0 ? CYAN : BLUE);
            c.setOnClickListener(v -> showSports(sport, true));
            sportsGrid.addView(c, weighted());
        }
        page.addView(sportsGrid);

        LinearLayout liveHead = new LinearLayout(this);
        liveHead.setGravity(Gravity.CENTER_VERTICAL);
        liveHead.setPadding(dp(18), dp(4), dp(18), dp(4));
        TextView live = tv("Live Now", 17, TEXT, true);
        liveHead.addView(live, new LinearLayout.LayoutParams(0, -2, 1));
        TextView see = tv("See All  ›", 11, MUTED, true);
        see.setOnClickListener(v->showSportsHome(true));
        liveHead.addView(see);
        page.addView(liveHead);

        page.addView(homeLiveCard());

        page.addView(sectionLabel("Entertainment", "TV, Movies, News, Kids & More"));
        LinearLayout entGrid = new LinearLayout(this);
        entGrid.setPadding(dp(14), dp(3), dp(14), dp(12));
        String[] e = {"TV", "Movies", "News", "Kids"};
        String[] ei = {"▣", "▤", "▥", "◉"};
        for (int i = 0; i < e.length; i++) {
            final String cat = e[i];
            LinearLayout c = featureTile(ei[i], cat, i == 1 ? PURPLE : (i == 2 ? GREEN : BLUE));
            c.setOnClickListener(v -> showEntertainment(cat, true));
            entGrid.addView(c, weighted());
        }
        page.addView(entGrid);
        addScroll(page);
    }

    private View homeLiveCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(11), dp(14), dp(11));
        card.setBackground(round(Color.WHITE, 15));
        TextView top = tv("● LIVE   Test Series  •  3rd Test", 10, RED, true);
        card.addView(top);
        LinearLayout teams = new LinearLayout(this);
        teams.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = scoreTeam("🇿🇦", "RSA", "329 & 387");
        LinearLayout right = scoreTeam("🇦🇺", "AUS", "429 & 111");
        teams.addView(left, weighted());
        TextView vs = tv("VS", 11, BLUE, true);
        vs.setGravity(Gravity.CENTER);
        teams.addView(vs, new LinearLayout.LayoutParams(dp(32), -2));
        teams.addView(right, weighted());
        card.addView(teams);
        TextView lead = tv("AUS Lead by 113 runs  ›", 10, Color.rgb(12, 105, 61), true);
        lead.setGravity(Gravity.CENTER);
        lead.setBackground(round(Color.rgb(215, 249, 224), 9));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(34));
        lp.setMargins(dp(4), dp(7), dp(4), 0);
        card.addView(lead, lp);
        card.setOnClickListener(v -> {
            selectedMatch = demoMatch("cricket", "RSA vs AUS • 3rd Test");
            showMatchDetail(true);
        });
        return card;
    }

    private void showSportsHome(boolean push) {
        if (push) push("sportsHome");
        screen = "sportsHome";
        clearContent();
        LinearLayout page = page();
        page.addView(sectionLabel("Sports", "Choose a sport"));
        page.addView(sportsProviderAttribution());
        page.addView(pageSearchButton("Search matches, teams and competitions", "sports"));
        LinearLayout grid = new LinearLayout(this);
        grid.setPadding(dp(14), 0, dp(14), dp(10));
        String[] names = {"Cricket", "Football", "Basketball", "Tennis"};
        String[] icons = {"🏏", "⚽", "🏀", "🎾"};
        for (int i=0;i<names.length;i++) {
            final String s=names[i].toLowerCase(Locale.US);
            LinearLayout c=featureTile(icons[i],names[i],BLUE);
            c.setOnClickListener(v->showSports(s,true));
            grid.addView(c, weighted());
        }
        page.addView(grid);
        page.addView(sectionLabel("Live & Upcoming", "Match center"));
        for (String s : names) {
            JSONObject m = demoMatch(s.toLowerCase(Locale.US), s + " Match");
            page.addView(sportsListCard(m, false));
        }
        addScroll(page);
    }

    private void showSports(String sport, boolean push) {
        if (push) push("sport:" + sport);
        screen = "sport";
        selectedSport = sport;
        matchMode = "live";
        remoteMatches = null;
        clearContent();
        LinearLayout page = page();
        page.addView(selectedSectionBar(sportName(sport), false));
        page.addView(sportsProviderAttribution());
        page.addView(pageSearchButton("Search matches, teams and competitions", "sports"));
        String[] modes={"LIVE","UPCOMING","RESULTS"};
        page.addView(modeTabs(page, sport, modes));
        renderSportList(page,sport);
        loadSportsFromBackend(sport, matchMode, page);
        addScroll(page);
    }

    private void renderSportList(LinearLayout page, String sport) {
        while(page.getChildCount()>4) page.removeViewAt(4);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), dp(2), dp(12), dp(18));
        if (remoteMatches != null && remoteMatches.length() > 0) {
            for (int i = 0; i < remoteMatches.length(); i++) {
                JSONObject m = remoteMatches.optJSONObject(i);
                if (m != null) list.addView(sportsListCard(m, i == 0));
            }
        } else {
            String[] titles;
            if ("football".equals(sport)) titles = new String[]{"International San Carlos vs Escorpiones Belen","Real Madrid vs Valencia","Manchester City vs Liverpool"};
            else if ("basketball".equals(sport)) titles = new String[]{"Lakers vs Warriors","Celtics vs Knicks","Nuggets vs Suns"};
            else if ("tennis".equals(sport)) titles = new String[]{"Alcaraz vs Sinner","Djokovic vs Zverev","WTA Finals"};
            else titles = new String[]{"RSA vs AUS • 3rd Test","BAN vs WI • 1st Test","IND vs NZ • 5th T20I"};
            for(int i=0;i<titles.length;i++){
                JSONObject m=demoMatch(sport,titles[i]);
                list.addView(sportsListCard(m, i==0 && "live".equals(matchMode)));
            }
        }
        page.addView(list);
        page.addView(sectionLabel("More","Explore the full "+sportName(sport)+" section"));
        page.addView(sportsMoreLinks(sport));
    }

    private LinearLayout sportsMoreLinks(String sport) {
        LinearLayout wrap=new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        String[] items;
        if("cricket".equals(sport)) items=new String[]{"Series","Teams","Players","Venues","Highlights"};
        else if("football".equals(sport)) items=new String[]{"Competitions","Teams","Players","Venues","H2H"};
        else if("basketball".equals(sport)) items=new String[]{"Leagues","Teams","Players","Standings","H2H"};
        else items=new String[]{"Tournaments","Players","Rankings","Draws","H2H"};
        for(String item:items){
            LinearLayout row=menuAction("•",item,"Open "+item.toLowerCase(Locale.US)+" page",v->showSportsDirectory(sport,item,true));
            wrap.addView(row);
        }
        return wrap;
    }

    private void showSportsDirectory(String sport,String section,boolean push) {
        if(push) push("directory:"+sport+":"+section);
        screen="directory";
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar(section,false));
        page.addView(sportsProviderAttribution());
        page.addView(sectionLabel(section,sportName(sport)+" • ONE TV"));
        String[] names;
        if("Players".equals(section)) names=new String[]{"Player Alpha","Player Bravo","Player Charlie","Player Delta"};
        else if("Teams".equals(section)) names=new String[]{"Team Alpha","Team Bravo","Team Charlie","Team Delta"};
        else if("Venues".equals(section)) names=new String[]{"National Stadium","City Arena","Central Ground","Grand Stadium"};
        else if("Rankings".equals(section)) names=new String[]{"Rank 1 • Player Alpha","Rank 2 • Player Bravo","Rank 3 • Player Charlie"};
        else if("Draws".equals(section)) names=new String[]{"Quarter Final 1","Quarter Final 2","Semi Final","Final"};
        else names=new String[]{"Current "+section+" 01","Current "+section+" 02","Current "+section+" 03","Current "+section+" 04"};
        for(String n:names) page.addView(menuAction("•",n,"Prototype data page",v->showSimple(n,"Detailed "+section+" prototype")));
        addScroll(page);
    }

    private void loadSportsFromBackend(String sport, String mode, LinearLayout page) {
        if (BACKEND_URL == null || BACKEND_URL.contains("REPLACE")) return;
        network.execute(() -> {
            try {
                String path = "cricket".equals(sport) ? "/cricket/" + mode : "/sports/" + sport + "/" + mode;
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + path));
                JSONArray arr = root.optJSONArray("matches");
                if (arr == null || arr.length()==0) return;
                runOnUiThread(() -> {
                    if (!"sport".equals(screen) || !selectedSport.equals(sport)) return;
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject item = arr.optJSONObject(i);
                        if (item != null && !item.has("sport")) try { item.put("sport", sport); } catch (Exception ignored) {}
                    }
                    remoteMatches = arr;
                    renderSportList(page, sport);
                });
            } catch(Exception ignored) {}
        });
    }

    private View sportsListCard(JSONObject m, boolean live) {
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(13),dp(11),dp(13),dp(11));
        card.setBackground(round(CARD,15));

        String sport=m.optString("sport",selectedSport);
        TextView comp=tv(m.optString("competition",sportName(sport)+" • Match Center"),10,MUTED,true);
        card.addView(comp);

        LinearLayout titleRow=new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=tv(m.optString("title",""),12,TEXT,true);
        titleRow.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        titleRow.addView(tv(live?"● LIVE":m.optString("status","UPCOMING"),10,live?RED:GREEN,true));
        card.addView(titleRow);

        LinearLayout teams=new LinearLayout(this);
        teams.setGravity(Gravity.CENTER_VERTICAL);
        JSONObject home=team(m,true), away=team(m,false);
        teams.addView(matchTeam(home,true),weighted());
        TextView vs=tv("VS",11,BLUE,true);vs.setGravity(Gravity.CENTER);
        teams.addView(vs,new LinearLayout.LayoutParams(dp(34),-2));
        teams.addView(matchTeam(away,false),weighted());
        card.addView(teams);

        if ("football".equalsIgnoreCase(sport)) {
            card.addView(detailRow("Timeline", live ? "68' • 2 goals • 3 cards" : "Full time • match events"));
        } else if ("basketball".equalsIgnoreCase(sport)) {
            card.addView(detailRow("Quarters", "Q1 24-21  •  Q2 28-26  •  Q3 19-22"));
        } else if ("tennis".equalsIgnoreCase(sport)) {
            card.addView(detailRow("Sets", "6-4  •  3-6  •  4-2  •  Games 3-2"));
        } else {
            card.addView(detailRow("Match center", live ? "Live score • required rate • current over" : "Scorecard • squads • commentary"));
        }

        card.setOnClickListener(v->{selectedMatch=m;showMatchDetail(true);});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,0,0,dp(9));
        card.setLayoutParams(p);
        return card;
    }

    private View matchTeam(JSONObject t, boolean left) {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        TextView logo=tv(t.optString("flag",left?"◉":"◉"),27,TEXT,false);
        logo.setGravity(Gravity.CENTER);
        box.addView(logo,new LinearLayout.LayoutParams(-1,dp(40)));
        TextView name=tv(t.optString("name",left?"Home":"Away"),13,TEXT,true);
        name.setGravity(Gravity.CENTER);
        name.setMaxLines(2);
        box.addView(name);
        String score=t.optString("score","");
        if(!score.isEmpty()) box.addView(tv(score,17,TEXT,true));
        return box;
    }

    private void showMatchDetail(boolean push) {
        if (push) push("match");
        screen="match";
        clearContent();
        if(selectedMatch==null) selectedMatch=demoMatch(selectedSport,"Match Centre");
        JSONObject m=selectedMatch;
        String sport=m.optString("sport",selectedSport).toLowerCase(Locale.US);

        if("cricket".equals(sport)) detailTab="OVERVIEW";
        else detailTab="OVERVIEW";

        LinearLayout shell=new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(BG);

        shell.addView(sportsProviderAttribution());
        shell.addView(matchHero(m),new LinearLayout.LayoutParams(-1,-2));

        final FrameLayout bodyHost=new FrameLayout(this);
        String[] labels;
        if("cricket".equals(sport)){
            labels=new String[]{"Overview","Live","Scorecard","Squads","Overs","Commentary","Highlights","Series"};
        } else if("football".equals(sport)){
            labels=new String[]{"Overview","Live","Stats","Lineups","Timeline","Standings","H2H"};
        } else if("basketball".equals(sport)){
            labels=new String[]{"Overview","Live","Box Score","Play-by-play","Lineups","Team Stats","Standings"};
        } else {
            labels=new String[]{"Overview","Live","Scoreboard","Point-by-point","Stats","H2H","Draw"};
        }

        HorizontalScrollView tabScroll=new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabScroll.setFillViewport(false);
        tabScroll.setBackgroundColor(Color.rgb(7,14,23));
        LinearLayout tabs=new LinearLayout(this);
        tabs.setPadding(dp(10),dp(7),dp(10),dp(7));

        for(String label:labels){
            TextView b=tab(label,label.equalsIgnoreCase(detailTab));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(112),dp(44));
            lp.setMargins(dp(3),0,dp(3),0);
            b.setOnClickListener(v->{
                detailTab=label.toUpperCase(Locale.US);
                for(int i=0;i<tabs.getChildCount();i++){
                    View child=tabs.getChildAt(i);
                    if(child instanceof TextView){
                        TextView t=(TextView)child;
                        boolean active=t.getText().toString().equalsIgnoreCase(detailTab);
                        t.setTextColor(active?TEXT:MUTED);
                        t.setBackground(round(active?BLUE:CARD,18));
                    }
                }
                renderMatchBody(bodyHost,m,sport);
            });
            tabs.addView(b,lp);
        }
        tabScroll.addView(tabs,new HorizontalScrollView.LayoutParams(-2,-2));
        shell.addView(tabScroll,new LinearLayout.LayoutParams(-1,dp(58)));

        bodyHost.setBackgroundColor(BG);
        shell.addView(bodyHost,new LinearLayout.LayoutParams(-1,0,1));
        contentHost.addView(shell,new FrameLayout.LayoutParams(-1,-1));

        renderMatchBody(bodyHost,m,sport);
    }

    private LinearLayout matchHero(JSONObject m) {
        String sport=m.optString("sport",selectedSport).toLowerCase(Locale.US);
        JSONObject home=team(m,true), away=team(m,false);
        LinearLayout hero=new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(14),dp(12),dp(14),dp(12));
        hero.setBackground(round(PANEL,0));

        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView comp=tv(m.optString("competition",sportName(sport)+" • International Match Centre"),11,MUTED,true);
        top.addView(comp,new LinearLayout.LayoutParams(0,-2,1));
        TextView status=tv(m.optString("status","LIVE").toUpperCase(Locale.US),10,
                "LIVE".equalsIgnoreCase(m.optString("status",""))?RED:GREEN,true);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(9),dp(5),dp(9),dp(5));
        status.setBackground(round(Color.rgb(32,47,61),14));
        top.addView(status);
        hero.addView(top);

        TextView title=tv(m.optString("title","Match Centre"),18,TEXT,true);
        title.setPadding(0,dp(4),0,dp(1));
        hero.addView(title);

        TextView meta=tv(matchMetaText(sport,m),10,MUTED,false);
        meta.setMaxLines(2);
        hero.addView(meta);

        LinearLayout teams=new LinearLayout(this);
        teams.setGravity(Gravity.CENTER_VERTICAL);
        teams.setPadding(0,dp(9),0,dp(5));
        teams.addView(heroTeam(home,true,sport),weighted());
        TextView vs=tv("VS",11,BLUE,true);
        vs.setGravity(Gravity.CENTER);
        vs.setBackground(round(Color.rgb(18,40,62),18));
        teams.addView(vs,new LinearLayout.LayoutParams(dp(46),dp(42)));
        teams.addView(heroTeam(away,false,sport),weighted());
        hero.addView(teams);

        if("cricket".equals(sport)){
            hero.addView(detailRow("Match state", "AUS lead • target / required rate shown in Live"));
        } else if("football".equals(sport)){
            hero.addView(detailRow("Match state", "Score • clock • cards • substitutions • VAR"));
        } else if("basketball".equals(sport)){
            hero.addView(detailRow("Match state", "Period • game clock • team fouls • timeouts"));
        } else {
            hero.addView(detailRow("Match state", "Set • games • server • break points"));
        }
        return hero;
    }

    private LinearLayout heroTeam(JSONObject t, boolean left, String sport) {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        TextView flag=tv(t.optString("flag",left?"◉":"◉"),22,TEXT,false);
        flag.setGravity(Gravity.CENTER);
        box.addView(flag,new LinearLayout.LayoutParams(-1,dp(30)));
        TextView name=tv(t.optString("name",left?"Home":"Away"),12.5f,TEXT,true);
        name.setGravity(Gravity.CENTER);
        name.setMaxLines(2);
        box.addView(name);
        String score=t.optString("score","");
        if(!score.isEmpty()) {
            TextView sc=tv(score,20,TEXT,true);
            sc.setGravity(Gravity.CENTER);
            box.addView(sc);
        }
        String form=t.optString("form","");
        if(!form.isEmpty()) box.addView(tv(form,9,MUTED,false));
        return box;
    }

    private String matchMetaText(String sport, JSONObject m) {
        if("cricket".equals(sport))
            return m.optString("date","Today") + "  •  " + m.optString("venue","Newlands") + "  •  " + m.optString("format","Test");
        if("football".equals(sport))
            return m.optString("date","Today") + "  •  " + m.optString("venue","National Stadium") + "  •  Referee " + m.optString("referee","TBD");
        if("basketball".equals(sport))
            return m.optString("date","Today") + "  •  " + m.optString("venue","Arena") + "  •  " + m.optString("round","Regular Season");
        return m.optString("date","Today") + "  •  " + m.optString("venue","Centre Court") + "  •  " + m.optString("round","Quarter-final");
    }

    private void renderMatchBody(FrameLayout host, JSONObject m, String sport) {
        host.removeAllViews();
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout body=new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(12),dp(7),dp(12),dp(26));

        String tab=detailTab;
        if("cricket".equals(sport)) {
            if(tab.contains("OVERVIEW")) renderCricketOverview(body,m);
            else if(tab.equals("LIVE")) renderCricketLive(body,m);
            else if(tab.contains("SCORECARD")) renderCricketScore(body,m);
            else if(tab.contains("SQUADS")) renderCricketSquads(body,m);
            else if(tab.contains("OVERS")) renderCricketOvers(body,m);
            else if(tab.contains("COMMENTARY")) renderCricketCommentary(body,m);
            else if(tab.contains("HIGHLIGHTS")) renderHighlights(body,"Cricket");
            else if(tab.contains("SERIES")) renderSeries(body,"Cricket");
            else renderCricketOverview(body,m);
        } else if("football".equals(sport)) {
            if(tab.contains("OVERVIEW")) renderFootballOverview(body,m);
            else if(tab.equals("LIVE")) renderFootballLive(body,m);
            else if(tab.contains("STATS")) renderFootballStats(body,m);
            else if(tab.contains("LINEUPS")) renderFootballLineups(body);
            else if(tab.contains("TIMELINE")) renderFootballTimeline(body);
            else if(tab.contains("STANDINGS")) renderStandings(body,"Football");
            else renderH2H(body,m);
        } else if("basketball".equals(sport)) {
            if(tab.contains("OVERVIEW")) renderBasketballOverview(body,m);
            else if(tab.equals("LIVE")) renderBasketballLive(body,m);
            else if(tab.contains("BOX SCORE")) renderBasketballBoxScore(body);
            else if(tab.contains("PLAY-BY-PLAY")) renderBasketballPlayByPlay(body);
            else if(tab.contains("LINEUPS")) renderLineupCards(body,"Basketball");
            else if(tab.contains("TEAM STATS")) renderBasketballTeamStats(body);
            else renderStandings(body,"Basketball");
        } else {
            if(tab.contains("OVERVIEW")) renderTennisOverview(body,m);
            else if(tab.equals("LIVE")) renderTennisLive(body,m);
            else if(tab.contains("SCOREBOARD")) renderTennisScoreboard(body);
            else if(tab.contains("POINT-BY-POINT")) renderTennisPointByPoint(body);
            else if(tab.contains("STATS")) renderTennisStats(body);
            else if(tab.contains("H2H")) renderH2H(body,m);
            else renderStandings(body,"Tennis Draw");
        }

        scroll.addView(body,new ScrollView.LayoutParams(-1,-2));
        host.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
    }

    private void renderCricketOverview(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Match overview","International cricket match centre"));
        body.addView(statCard("Current score","AUS 429 & 111/3","RSA 329 all out • AUS lead by 211"));
        body.addView(statCard("Match situation","Australia batting • 38.2 overs","Target / required rate available in Live"));
        body.addView(statCard("Current partnership","M. Marsh 42*  •  S. Smith 31*","67 runs • 118 balls"));
        body.addView(sectionLabel("Key numbers","Live match context"));
        addStatGrid(body,new String[][]{
                {"CRR","2.89","Current"},
                {"RRR","4.62","To win"},
                {"Overs","38.2","Current innings"},
                {"Wickets","3","Lost"}
        });
        body.addView(sectionLabel("Match information","Competition and venue"));
        body.addView(detailRow("Format",m.optString("format","Test")));
        body.addView(detailRow("Day / Session","Day 4 • Session 2"));
        body.addView(detailRow("Venue",m.optString("venue","Newlands")));
        body.addView(detailRow("Toss","Australia won • elected to bat"));
    }

    private void renderCricketLive(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Live cricket","Score, required rate and current over"));
        body.addView(scoreboardCard("AUS","111/3","38.2 Ov","Lead 211"));
        addStatGrid(body,new String[][]{
                {"Target","329 + 1","Match target"},
                {"Required","218","Runs to lead"},
                {"RRR","4.62","Runs per over"},
                {"CRR","2.89","Current rate"}
        });
        body.addView(sectionLabel("At the crease","Current batters"));
        body.addView(detailRow("M. Marsh  •  42* (76)","4s 5 • 6s 0 • SR 55.26"));
        body.addView(detailRow("S. Smith  •  31* (89)","4s 2 • 6s 0 • SR 34.83"));
        body.addView(sectionLabel("Current over","38th over"));
        String[] balls={"38.2 • 1 run • worked to square leg","38.1 • dot • good length","37.6 • FOUR • cover drive","37.5 • dot • defended","37.4 • 2 runs • clipped through midwicket"};
        for(String b:balls) body.addView(eventRow(b,1));
    }

    private void renderCricketScore(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Scorecard","Batting and bowling • complete innings"));
        body.addView(scoreboardCard("RSA","329/10","82.3 Ov","1st innings"));
        body.addView(sectionLabel("RSA • 1st innings","Batting"));
        LinearLayout table=tableBox();
        table.addView(tableRow(new String[]{"Batter","R","B","4s","6s","SR"},true));
        String[][] rows={
                {"Aiden Markram","78","141","10","1","55.32"},
                {"T. Bavuma (c)","65","102","7","0","63.72"},
                {"D. Bedingham","50","80","7","0","62.50"},
                {"K. Verreynne","42","71","5","1","59.15"},
                {"K. Rabada","18","31","2","0","58.06"}
        };
        for(String[] r:rows)table.addView(tableRow(r,false));
        body.addView(table);
        body.addView(sectionLabel("Bowling • AUS","Bowling figures"));
        LinearLayout bowl=tableBox();
        bowl.addView(tableRow(new String[]{"Bowler","O","M","R","W","Econ"},true));
        String[][] br={
                {"Hazlewood","22.3","5","71","3","3.15"},
                {"Starc","21","4","82","2","3.90"},
                {"Cummins","20","3","76","2","3.80"},
                {"Lyon","19","2","68","2","3.57"}
        };
        for(String[] r:br)bowl.addView(tableRow(r,false));
        body.addView(bowl);
        body.addView(statCard("Extras","14","Total 329"));
        body.addView(statCard("Fall of wickets","1-44, 2-132, 3-218, 4-266","Complete innings"));
        body.addView(statCard("Partnerships","44, 88, 86, 48, 63","Key stands"));
    }

    private void renderCricketSquads(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Playing XI & squads","Confirmed matchday players"));
        String[][] players={
                {"🇿🇦","Aiden Markram","Batter • RSA"},
                {"🇿🇦","Temba Bavuma (c)","Batter • RSA"},
                {"🇿🇦","Kagiso Rabada","Bowler • RSA"},
                {"🇿🇦","Keshav Maharaj","Bowling all-rounder • RSA"},
                {"🇦🇺","Steve Smith","Batter • AUS"},
                {"🇦🇺","Mitchell Marsh","All-rounder • AUS"},
                {"🇦🇺","Pat Cummins (c)","Bowler • AUS"},
                {"🇦🇺","Mitchell Starc","Bowler • AUS"}
        };
        for(String[] p:players) body.addView(playerRow(p[0],p[1],p[2]));
        body.addView(sectionLabel("Officials","Match officials"));
        body.addView(detailRow("On-field umpires","Umpire A • Umpire B"));
        body.addView(detailRow("Third umpire","Umpire C"));
    }

    private void renderCricketOvers(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Over by over","Structured ball-by-ball progression"));
        body.addView(scoreboardCard("AUS","111/3","38.2 Ov","CRR 2.89"));
        String[] overs={
                "38.2 • 1 run • Marsh to square leg",
                "38.1 • DOT • good length • defended",
                "37.6 • FOUR • Smith through cover",
                "37.5 • DOT • outside off",
                "37.4 • 2 runs • Marsh clips leg side",
                "37.3 • 1 run • quick single",
                "37.2 • DOT • beaten outside edge",
                "37.1 • 1 run • worked to midwicket"
        };
        for(String o:overs) body.addView(eventRow(o,1));
        body.addView(sectionLabel("Over summary","Current phase"));
        body.addView(detailRow("Last completed over","7 runs • 0 wickets"));
        body.addView(detailRow("Current partnership","67 runs • 118 balls"));
    }

    private void renderCricketCommentary(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Live commentary","Ball-by-ball • latest events"));
        String[] events={
                "38.2 • 1 run • Marsh works it behind square",
                "38.1 • DOT • good length, defended solidly",
                "37.6 • FOUR • Smith drives through extra cover",
                "37.5 • DOT • beaten outside off",
                "37.4 • 2 runs • clipped to deep midwicket",
                "37.3 • 1 run • quick single",
                "37.2 • DOT • tight line on off stump",
                "37.1 • 1 run • nudged into the leg side"
        };
        for(String e:events) body.addView(eventRow(e,1));
    }

    private void renderFootballOverview(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Match overview","International football match centre"));
        body.addView(scoreboardCard("San Carlos","2","68:24","Live"));
        body.addView(statPairCard("Score","2 — 3","Live"));
        addStatGrid(body,new String[][]{
                {"Possession","54%","Home"},
                {"Shots","12","6 on target"},
                {"Corners","5","Home"},
                {"Cards","2","Yellow"}
        });
        body.addView(sectionLabel("Match information","Competition context"));
        body.addView(detailRow("Competition","International Cup • Round of 16"));
        body.addView(detailRow("Venue",m.optString("venue","National Stadium")));
        body.addView(detailRow("Referee",m.optString("referee","TBD")));
        body.addView(detailRow("Kick-off","20:00 • Local time"));
    }

    private void renderFootballLive(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Live match","Clock, score and live events"));
        body.addView(scoreboardCard("San Carlos","2 — 3","68:24","2nd half"));
        body.addView(sectionLabel("Live events","Goals • cards • substitutions • VAR"));
        String[] events={
                "68' • GOAL • Escorpiones Belen • 2-3",
                "64' • YELLOW CARD • San Carlos",
                "61' • SUBSTITUTION • Escorpiones Belen",
                "51' • SUBSTITUTION • San Carlos",
                "45+2' • HALF TIME • 2-2",
                "23' • VAR • Goal ruled out"
        };
        for(String e:events) body.addView(eventRow(e,1));
        body.addView(sectionLabel("Live statistics","Current match totals"));
        addStatGrid(body,new String[][]{
                {"Shots","12 — 9","6 — 4 on target"},
                {"Corners","5 — 3","Home — Away"},
                {"Fouls","10 — 12","Total 22"},
                {"Offsides","2 — 1","Total 3"}
        });
    }

    private void renderFootballStats(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Football match stats","Team comparison"));
        LinearLayout table=tableBox();
        table.addView(tableRow(new String[]{"Metric","Home","Away"},true));
        String[][] rows={
                {"Possession","54%","46%"},
                {"Shots","12","9"},
                {"Shots on target","6","4"},
                {"Corners","5","3"},
                {"Fouls","10","12"},
                {"Offsides","2","1"},
                {"Passes","421","365"},
                {"Pass accuracy","88%","84%"},
                {"Tackles","14","17"},
                {"Saves","2","4"}
        };
        for(String[] r:rows)table.addView(tableRow(r,false));
        body.addView(table);
        body.addView(sectionLabel("Discipline","Cards"));
        addStatGrid(body,new String[][]{
                {"Yellow","2 — 1","Home — Away"},
                {"Red","0 — 0","None"},
                {"VAR","1","Review completed"}
        });
    }

    private void renderFootballLineups(LinearLayout body) {
        body.addView(sectionLabel("Lineups","Starting XI, bench and formations"));
        body.addView(detailRow("Home formation","4-3-3"));
        body.addView(detailRow("Away formation","4-2-3-1"));
        String[][] home={
                {"GK","Player A","Starting XI"},
                {"RB","Player B","Starting XI"},
                {"CB","Player C","Starting XI"},
                {"CB","Player D","Starting XI"},
                {"LB","Player E","Starting XI"},
                {"CM","Player F","Starting XI"},
                {"CM","Player G","Starting XI"},
                {"RW","Player H","Starting XI"},
                {"ST","Player I","Starting XI"},
                {"LW","Player J","Starting XI"}
        };
        for(String[] p:home) body.addView(playerRow("⚽",p[1],p[0]+" • "+p[2]));
        body.addView(sectionLabel("Substitutions","Changes"));
        body.addView(eventRow("64' • Player K IN  /  Player H OUT",1));
        body.addView(eventRow("61' • Player L IN  /  Player I OUT",2));
    }

    private void renderFootballTimeline(LinearLayout body) {
        body.addView(sectionLabel("Match timeline","Chronological events"));
        String[] events={
                "68' • GOAL • Escorpiones Belen • 2-3",
                "64' • YELLOW CARD • San Carlos",
                "61' • SUBSTITUTION • Escorpiones Belen",
                "51' • SUBSTITUTION • San Carlos",
                "45+2' • HALF TIME",
                "31' • GOAL • San Carlos • 2-2",
                "23' • VAR • Goal ruled out",
                "12' • GOAL • Escorpiones Belen • 1-2"
        };
        for(String e:events) body.addView(eventRow(e,1));
    }

    private void renderBasketballOverview(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Game overview","Professional basketball game centre"));
        body.addView(scoreboardCard("Lakers","102","4Q • 02:14","Warriors 98"));
        addStatGrid(body,new String[][]{
                {"Q1","24 — 21","Complete"},
                {"Q2","28 — 26","Complete"},
                {"Q3","19 — 22","Complete"},
                {"Q4","31 — 29","Live"}
        });
        body.addView(sectionLabel("Game state","Possession and team status"));
        body.addView(detailRow("Possession","Lakers • ball"));
        body.addView(detailRow("Team fouls","Lakers 14 • Warriors 17"));
        body.addView(detailRow("Timeouts","Lakers 2 • Warriors 3"));
    }

    private void renderBasketballLive(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Live basketball","Clock, score and possession"));
        body.addView(scoreboardCard("Lakers","102","02:14","4th quarter"));
        addStatGrid(body,new String[][]{
                {"Lead","Lakers +4","Current"},
                {"Possession","Lakers","Ball"},
                {"Team fouls","14 — 17","Home — Away"},
                {"Timeouts","2 — 3","Remaining"}
        });
        body.addView(sectionLabel("Play-by-play","Latest possessions"));
        String[] events={
                "02:14 • Lakers • 2 PTS • driving layup",
                "02:31 • Warriors • MISS • 3PT",
                "02:48 • Lakers • defensive rebound",
                "03:05 • Warriors • foul • team 17",
                "03:19 • Lakers • timeout"
        };
        for(String e:events) body.addView(eventRow(e,1));
    }

    private void renderBasketballBoxScore(LinearLayout body) {
        body.addView(sectionLabel("Box score","Player traditional statistics"));
        LinearLayout table=tableBox();
        table.addView(tableRow(new String[]{"Player","MIN","PTS","REB","AST","STL","BLK","TOV"},true));
        String[][] rows={
                {"LeBron James","36:12","31","10","8","2","1","3"},
                {"A. Davis","34:05","24","12","4","1","3","2"},
                {"A. Reaves","31:42","17","5","6","1","0","1"},
                {"S. Curry","35:18","29","4","7","2","0","2"},
                {"K. Thompson","32:11","21","3","3","1","0","1"}
        };
        for(String[] r:rows)table.addView(tableRow(r,false));
        body.addView(table);
        body.addView(sectionLabel("Shooting","Efficiency"));
        addStatGrid(body,new String[][]{
                {"FG","48% — 46%","Home — Away"},
                {"3PT","38% — 41%","Home — Away"},
                {"FT","82% — 78%","Home — Away"},
                {"REB","46 — 42","Total"}
        });
    }

    private void renderBasketballPlayByPlay(LinearLayout body) {
        body.addView(sectionLabel("Play-by-play","Chronological possessions"));
        String[] events={
                "02:14 • 4Q • Lakers • 2 PTS • layup",
                "02:31 • 4Q • Warriors • MISS • 3PT",
                "02:48 • 4Q • Lakers • REBOUND • defensive",
                "03:05 • 4Q • Warriors • FOUL",
                "03:19 • 4Q • Lakers • TIMEOUT",
                "03:42 • 4Q • Warriors • 3 PTS • corner three",
                "04:01 • 4Q • Lakers • TURNOVER"
        };
        for(String e:events) body.addView(eventRow(e,1));
    }

    private void renderBasketballTeamStats(LinearLayout body) {
        body.addView(sectionLabel("Team statistics","Full game comparison"));
        LinearLayout table=tableBox();
        table.addView(tableRow(new String[]{"Metric","Lakers","Warriors"},true));
        String[][] rows={
                {"Points","102","98"},
                {"FG%","48%","46%"},
                {"3PT%","38%","41%"},
                {"FT%","82%","78%"},
                {"Rebounds","46","42"},
                {"Off. rebounds","11","8"},
                {"Assists","25","22"},
                {"Turnovers","10","12"},
                {"Steals","7","6"},
                {"Blocks","5","4"},
                {"Fouls","14","17"}
        };
        for(String[] r:rows)table.addView(tableRow(r,false));
        body.addView(table);
    }

    private void renderTennisOverview(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Match overview","Professional tennis match centre"));
        body.addView(scoreboardCard("Alcaraz","2 sets","Set 3 • 4-2","Sinner 1 set"));
        addStatGrid(body,new String[][]{
                {"Set 1","6 — 4","Alcaraz"},
                {"Set 2","3 — 6","Sinner"},
                {"Set 3","4 — 2","Live"},
                {"Server","Alcaraz","Current game"}
        });
        body.addView(sectionLabel("Match context","Tournament"));
        body.addView(detailRow("Tournament",m.optString("competition","ATP • Quarter-final")));
        body.addView(detailRow("Surface","Hard court"));
        body.addView(detailRow("Round","Quarter-final"));
        body.addView(detailRow("Venue",m.optString("venue","Centre Court")));
    }

    private void renderTennisLive(LinearLayout body, JSONObject m) {
        body.addView(sectionLabel("Live tennis","Set, game and point state"));
        body.addView(scoreboardCard("Alcaraz","4 — 2","40 — 30","Serving"));
        addStatGrid(body,new String[][]{
                {"Sets","2 — 1","Match"},
                {"Games","13 — 12","Current total"},
                {"Server","Alcaraz","Right now"},
                {"Break points","1/3 — 0/2","Won / opportunities"}
        });
        body.addView(sectionLabel("Current game","Point progression"));
        String[] points={"40-30 • Alcaraz","30-30 • Sinner","30-15 • Alcaraz","15-15 • Sinner","15-0 • Alcaraz"};
        for(String p:points) body.addView(eventRow(p,1));
    }

    private void renderTennisScoreboard(LinearLayout body) {
        body.addView(sectionLabel("Set scoreboard","Games by set"));
        LinearLayout table=tableBox();
        table.addView(tableRow(new String[]{"Player","Set 1","Set 2","Set 3","Sets"},true));
        table.addView(tableRow(new String[]{"Alcaraz","6","3","4","2"},false));
        table.addView(tableRow(new String[]{"Sinner","4","6","2","1"},false));
        body.addView(table);
        body.addView(sectionLabel("Current game","Live point score"));
        body.addView(detailRow("Server","Alcaraz"));
        body.addView(detailRow("Score","40 — 30"));
        body.addView(detailRow("Break point","No"));
        body.addView(detailRow("Tiebreak","No"));
    }

    private void renderTennisPointByPoint(LinearLayout body) {
        body.addView(sectionLabel("Point-by-point","Latest points and games"));
        String[] events={
                "Set 3 • Game 7 • 40-30 • Alcaraz serving",
                "Set 3 • Game 7 • 30-30 • Sinner return",
                "Set 3 • Game 7 • 30-15 • Alcaraz winner",
                "Set 3 • Game 7 • 15-15 • Sinner winner",
                "Set 3 • Game 7 • 15-0 • Alcaraz ace",
                "Set 3 • Game 6 • Game to Sinner"
        };
        for(String e:events) body.addView(eventRow(e,1));
        body.addView(sectionLabel("Rally insight","Available when provider supplies rally data"));
        addStatGrid(body,new String[][]{
                {"Last rally","7 shots","Completed"},
                {"Longest rally","14 shots","Match"},
                {"Serve speed","198 km/h","Fastest"}
        });
    }

    private void renderTennisStats(LinearLayout body) {
        body.addView(sectionLabel("Tennis match stats","Service, return and pressure"));
        LinearLayout table=tableBox();
        table.addView(tableRow(new String[]{"Metric","Alcaraz","Sinner"},true));
        String[][] rows={
                {"Aces","8","5"},
                {"Double faults","2","3"},
                {"1st serve %","67%","61%"},
                {"1st serve pts won","78%","72%"},
                {"2nd serve pts won","56%","49%"},
                {"Break points","2/5","1/4"},
                {"Winners","31","24"},
                {"Unforced errors","18","22"},
                {"Net points won","12/17","8/14"},
                {"Return points won","39%","35%"}
        };
        for(String[] r:rows)table.addView(tableRow(r,false));
        body.addView(table);
        body.addView(sectionLabel("Advanced","Provider-dependent metrics"));
        body.addView(detailRow("Longest rally","14 shots"));
        body.addView(detailRow("Fastest serve","198 km/h"));
    }

    private void renderHighlights(LinearLayout body,String type) {
        body.addView(sectionLabel(type+" Highlights","Key moments and video placeholders"));
        String[] h={"Best moments","Top performance","Turning point","Post-match interview"};
        for(String item:h){
            LinearLayout card=contentRow(item,type+" Highlights");
            card.setOnClickListener(v->showContentDetail(item,type+" Highlights",true));
            body.addView(card,marginBottomParams(7));
        }
    }

    private void renderSeries(LinearLayout body,String type) {
        body.addView(sectionLabel("Series","Matches, standings and information"));
        body.addView(statCard("Current series","3rd Test","Match 3 of 5"));
        body.addView(statCard("Previous match","Australia won","By 7 wickets"));
        body.addView(statCard("Next match","4th Test","Upcoming"));
        body.addView(statCard("Venue","Newlands","Cape Town, South Africa"));
    }

    private void renderPlayByPlay(LinearLayout body,String type) {
        body.addView(sectionLabel(type+" Play-by-play","Live event stream"));
        String[] events={"12:43 • Score update","12:42 • Offensive play","12:41 • Defensive rebound","12:39 • Foul / free play","12:37 • Substitution"};
        for(String e:events) body.addView(eventRow(e,1));
    }

    private void renderLineupCards(LinearLayout body,String type) {
        body.addView(sectionLabel(type+" Lineups","Starting players and bench"));
        String[] p={"Starter 1","Starter 2","Starter 3","Starter 4","Starter 5","Bench"};
        for(String x:p) body.addView(statCard(x,"Player Name","Role • minutes"));
    }

    private void renderStandings(LinearLayout body,String type) {
        body.addView(sectionLabel(type+" Standings","Rank, record and points"));
        String[][] rows={{"1","Team Alpha","28 pts"},{"2","Team Bravo","24 pts"},{"3","Team Charlie","21 pts"},{"4","Team Delta","18 pts"}};
        LinearLayout box=tableBox();
        box.addView(tableRow(new String[]{"#","Team","Points"},true));
        for(String[] r:rows) box.addView(tableRow(r,false));
        body.addView(box);
    }

    private void renderH2H(LinearLayout body,JSONObject m) {
        body.addView(sectionLabel("Head to Head","Recent meetings"));
        body.addView(statCard("Last 5","2 wins — 2 wins","1 draw"));
        body.addView(statCard("Latest meeting","2 — 3","Finished"));
        body.addView(statCard("Form","W • L • W • D • W","Both teams"));
    }

    private void addStatGrid(LinearLayout body,String[][] stats) {
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        for(String[] s:stats){
            LinearLayout c=new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setGravity(Gravity.CENTER);
            c.setPadding(dp(7),dp(8),dp(7),dp(8));
            c.setBackground(round(CARD,11));
            c.addView(tv(s[0],9,MUTED,true));
            c.addView(tv(s[1],14,TEXT,true));
            c.addView(tv(s[2],8.5f,MUTED,false));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(72),1);
            cp.setMargins(dp(2),0,dp(2),0);
            row.addView(c,cp);
        }
        body.addView(row,marginBottomParams(8));
    }

    private View statPairCard(String title,String value,String sub) {
        return statCard(title,value,sub);
    }

    private LinearLayout scoreboardCard(String teamName,String score,String state,String sub) {
        LinearLayout c=new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(13),dp(11),dp(13),dp(11));
        c.setBackground(round(Color.rgb(16,35,54),14));
        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(tv(teamName,11,MUTED,true),new LinearLayout.LayoutParams(0,-2,1));
        top.addView(tv(state,10,CYAN,true));
        c.addView(top);
        c.addView(tv(score,25,TEXT,true));
        c.addView(tv(sub,9,MUTED,false));
        c.setLayoutParams(marginBottomParams(8));
        return c;
    }

    private LinearLayout playerRow(String icon,String name,String role) {
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10),dp(8),dp(10),dp(8));
        row.setBackground(round(CARD,12));
        row.addView(tv(icon,20,TEXT,false),new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout info=new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.addView(tv(name,12.5f,TEXT,true));
        info.addView(tv(role,9.5f,MUTED,false));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        return row;
    }

    private void showEntertainment(String category, boolean push) {
        if(push) push("ent:" + category);
        screen="entertainment";
        selectedEntertainment=category;
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar(category,true));
        page.addView(pageSearchButton("Search channels, programs and videos", "entertainment"));
        if("TV".equals(category)) buildTvFront(page);
        else if("Movies".equals(category)) buildMediaFront(page,"Movies");
        else if("News".equals(category)) buildMediaFront(page,"News");
        else buildMediaFront(page,category);
    }

    private void buildTvFront(LinearLayout page) {
        LinearLayout hero=heroBanner("Featured Channel","Live TV • Sports • News","WATCH LIVE",BLUE);
        hero.setOnClickListener(v->playFirstChannel());
        page.addView(hero);
        page.addView(sectionLabel("TV Channels","Live channels and categories"));
        LinearLayout list=new LinearLayout(this);
        list.setPadding(dp(12),0,dp(12),dp(12));
        String[] demo={"BTV News","Star Sports","Sony Entertainment","ATN News"};
        for(String n:demo){
            LinearLayout c=channelTile(n);
            c.setOnClickListener(v->playFirstChannel());
            list.addView(c,weighted());
        }
        page.addView(list);
        page.addView(sectionLabel("Live TV Player","In-app playback"));
        page.addView(buildPlayerCard());
        addScroll(page);
    }

    private void buildMediaFront(LinearLayout page,String type) {
        page.addView(heroBanner("Featured "+type,"Curated entertainment for ONE TV","WATCH NOW",PURPLE));
        page.addView(sectionLabel(type,"Backend-controlled content"));
        String[] titles={"The Last Mission","Matchday Highlights","Top Headlines","Prime Time","Kids Zone","New Releases"};
        for(String t:titles) page.addView(contentRow(t,type));
        addScroll(page);
    }

    private LinearLayout heroBanner(String title,String sub,String action,int accent) {
        LinearLayout h=new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);
        h.setPadding(dp(16),dp(15),dp(16),dp(15));
        h.setBackground(round(Color.rgb(24,34,55),17));
        TextView a=tv(title,19,TEXT,true);
        TextView b=tv(sub,11,MUTED,false);
        Button c=smallButton(action,accent);
        h.addView(a);h.addView(b);h.addView(c,new LinearLayout.LayoutParams(-2,dp(36)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(12),dp(8),dp(12),dp(10));h.setLayoutParams(p);
        return h;
    }

    private View buildPlayerCard() {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10),dp(10),dp(10),dp(10));
        box.setBackground(round(PANEL,16));
        FrameLayout frame=buildPlayerFrame(false);
        box.addView(frame,new LinearLayout.LayoutParams(-1,dp(230)));
        TextView label=tv("LIVE TV • In-app player • Touch for controls",11,GREEN,true);
        box.addView(label);
        box.setOnClickListener(v->playFirstChannel());
        return box;
    }

    private FrameLayout buildPlayerFrame(boolean live) {
        FrameLayout frame=new FrameLayout(this);
        frame.setBackgroundColor(Color.BLACK);
        playerFrame=frame;

        playerView=new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerShowTimeoutMs(3500);
        playerView.setControllerHideOnTouch(true);
        playerView.setControllerAutoShow(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        frame.addView(playerView,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout overlay=new LinearLayout(this);
        overlay.setGravity(Gravity.CENTER);
        overlay.setPadding(dp(8),dp(8),dp(8),dp(12));
        overlay.setBackgroundColor(Color.argb(90,0,0,0));

        TextView rewind=playerButton("↶ 10");
        TextView play=playerButton("▶");
        TextView forward=playerButton("10 ↷");
        TextView speed=playerButton("1x");
        TextView quality=playerButton("HD");
        TextView mute=playerButton("🔊");
        TextView full=playerButton("⛶");

        overlay.addView(rewind,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(play,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(forward,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(speed,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(quality,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(mute,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(full,new LinearLayout.LayoutParams(0,dp(44),1));

        FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(-1,dp(60),Gravity.BOTTOM);
        frame.addView(overlay,op);
        customPlayerControls=tv("controls",1,Color.TRANSPARENT,false);
        customPlayerControls.setVisibility(View.GONE);

        final float[] speedValue={1f};
        final int[] qualityIndex={0};
        final boolean[] muted={false};

        rewind.setOnClickListener(v->{seekBy(-10000);showPlayerControls(overlay);});
        forward.setOnClickListener(v->{seekBy(10000);showPlayerControls(overlay);});
        play.setOnClickListener(v->{
            if(player!=null){
                if(player.isPlaying()){player.pause();play.setText("▶");}
                else{player.play();play.setText("Ⅱ");}
            }
            showPlayerControls(overlay);
        });
        speed.setOnClickListener(v->{
            speedValue[0]+=0.25f;
            if(speedValue[0]>2f)speedValue[0]=0.75f;
            if(player!=null)player.setPlaybackParameters(new PlaybackParameters(speedValue[0]));
            speed.setText(String.format(Locale.US,"%.2gx",speedValue[0]));
            showPlayerControls(overlay);
        });
        quality.setOnClickListener(v->{
            String[] q={"HD","720p","480p","Auto"};
            qualityIndex[0]=(qualityIndex[0]+1)%q.length;
            quality.setText(q[qualityIndex[0]]);
            showPlayerControls(overlay);
        });
        mute.setOnClickListener(v->{
            muted[0]=!muted[0];
            if(player!=null)player.setVolume(muted[0]?0f:1f);
            mute.setText(muted[0]?"🔇":"🔊");
            showPlayerControls(overlay);
        });
        full.setOnClickListener(v->{toggleFullscreen();showPlayerControls(overlay);});

        playerView.setOnTouchListener((v,event)->{
            if(event.getAction()==MotionEvent.ACTION_UP) showPlayerControls(overlay);
            return false;
        });
        if(!live) overlay.setVisibility(View.GONE);
        return frame;
    }

    private TextView playerButton(String label) {
        TextView b=tv(label,11,TEXT,true);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        return b;
    }

    private void showPlayerControls(View overlay) {
        if(overlay==null)return;
        overlay.setVisibility(View.VISIBLE);
        playerUiHandler.removeCallbacksAndMessages(null);
        playerUiHandler.postDelayed(()->overlay.setVisibility(View.GONE),3500);
    }

    private void seekBy(long delta) {
        if(player==null)return;
        long pos=Math.max(0,player.getCurrentPosition()+delta);
        long duration=player.getDuration();
        if(duration>0)pos=Math.min(pos,duration);
        player.seekTo(pos);
    }

    private void playFirstChannel() {
        if(channels.isEmpty()){
            showSimple("Live TV","No channel is configured yet. Connect the backend to add authorized streams.");
            return;
        }
        Channel c=channels.get(0);
        if(c.url==null||c.url.isEmpty()){
            showSimple(c.name,"The channel source is not configured.");
            return;
        }

        screen="player";
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar(c.name,true));

        FrameLayout frame=buildPlayerFrame(true);
        page.addView(frame,new LinearLayout.LayoutParams(-1,dp(260)));

        LinearLayout info=new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(14),dp(10),dp(14),dp(10));
        info.addView(tv("LIVE • "+c.name,15,TEXT,true));
        info.addView(tv(c.program==null||c.program.isEmpty()?"Live programming":c.program,11,MUTED,false));
        page.addView(info);

        page.addView(sectionLabel("Player features","Timeline • Play/Pause • ±10 sec • Volume • Speed • Quality • Fullscreen"));
        addScroll(page);

        if(player!=null)player.release();
        player=new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        try{
            player.setMediaItem(MediaItem.fromUri(Uri.parse(c.url)));
            player.prepare();
            player.play();
        }catch(Exception ignored){}
    }

    private void loadChannels() {
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")) return;
        network.execute(()->{
            try{
                JSONObject root=new JSONObject(getUrl(BACKEND_URL+"/channels"));
                JSONArray arr=root.optJSONArray("channels");
                if(arr==null)return;
                List<Channel> temp=new ArrayList<>();
                for(int i=0;i<arr.length();i++){
                    JSONObject o=arr.optJSONObject(i);
                    if(o==null)continue;
                    temp.add(new Channel(o.optString("name","Channel"),o.optString("url",o.optString("sourceUrl","")),o.optString("program","")));
                }
                runOnUiThread(()->{channels.clear();channels.addAll(temp);});
            }catch(Exception ignored){}
        });
    }


    private void loadAdConfig() {
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")) return;
        network.execute(()->{
            try {
                JSONObject cfg=new JSONObject(getUrl(BACKEND_URL+"/ads"));
                adConfig=cfg;
                JSONArray active=cfg.optJSONArray("activePlatforms");
                boolean admobActive=false;
                if(active!=null) for(int i=0;i<active.length();i++){ JSONObject a=active.optJSONObject(i); if(a!=null && "admob".equalsIgnoreCase(a.optString("platform_key"))){ admobActive=true; break; } }
                final boolean enabled=admobActive;
                runOnUiThread(()->{ if(adRow!=null) adRow.setVisibility(enabled?View.VISIBLE:View.GONE); });
            } catch(Exception ignored) {}
        });
    }

    private void showMenuPage(boolean push) {
        if(push) push("menu");
        screen="menu";
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar("Menu",false));
        page.addView(sectionLabel("ONE TV","Navigate between the main services"));
        page.addView(menuAction("🏆","Sports","Cricket, Football, Basketball and Tennis",v->showSportsHome(true)));
        page.addView(menuAction("▣","Entertainment","TV, Movies, News and Kids",v->showEntertainment("TV",true)));
        page.addView(menuAction("⌕","Search","Find matches, channels, videos and programs",v->showSearch(true,"all")));
        page.addView(menuAction("🔔","Notifications","Match reminders and ONE TV updates",v->showNotifications(true)));
        page.addView(menuAction("☀","Appearance","Theme and display settings",v->showAppearance(true)));
        addScroll(page);
    }

    private LinearLayout menuAction(String icon,String title,String sub,View.OnClickListener click) {
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(13),dp(10),dp(13),dp(10));
        row.setBackground(round(CARD,14));
        row.setOnClickListener(click);
        row.addView(tv(icon,23,TEXT,false),new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout info=new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.addView(tv(title,14,TEXT,true));
        info.addView(tv(sub,10,MUTED,false));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(tv("›",24,MUTED,false));
        row.setLayoutParams(marginBottomParams(7));
        return row;
    }

    private void showNotifications(boolean push) {
        if(push) push("notifications");
        screen="notifications";
        clearContent();
        if(notificationBadge!=null) notificationBadge.setVisibility(View.GONE);
        LinearLayout page=page();
        page.addView(selectedSectionBar("Notifications",false));
        page.addView(sectionLabel("Notifications","Your match reminders and ONE TV updates"));
        page.addView(notificationCard("🔴","Live now","RSA vs AUS is live. Tap to open the match center.",v->{
            selectedMatch=demoMatch("cricket","RSA vs AUS • 3rd Test");
            showMatchDetail(true);
        }));
        page.addView(notificationCard("⏰","Match reminder","A football match starts soon. Open the match center for details.",v->{
            selectedMatch=demoMatch("football","International San Carlos vs Escorpiones Belen");
            showMatchDetail(true);
        }));
        page.addView(notificationCard("ℹ","ONE TV","Sports data and entertainment content are ready for refresh.",v->showHome(true)));
        addScroll(page);
    }

    private LinearLayout notificationCard(String icon,String title,String sub,View.OnClickListener click) {
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(13),dp(11),dp(13),dp(11));
        row.setBackground(round(CARD,14));
        row.setOnClickListener(click);
        row.addView(tv(icon,22,TEXT,false),new LinearLayout.LayoutParams(dp(46),dp(46)));
        LinearLayout info=new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.addView(tv(title,14,TEXT,true));
        info.addView(tv(sub,10,MUTED,false));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(tv("›",24,MUTED,false));
        row.setLayoutParams(marginBottomParams(7));
        return row;
    }

    private void showAppearance(boolean push) {
        if(push) push("appearance");
        screen="appearance";
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar("Appearance",false));
        page.addView(sectionLabel("Appearance","Theme settings are ready for remote configuration"));
        page.addView(menuAction("☀","Light / Dark","Choose the preferred visual theme",v->showSimple("Theme","Theme selection is ready for backend configuration")));
        page.addView(menuAction("◐","System","Follow the Android system appearance",v->showSimple("Theme","System theme is ready for backend configuration")));
        page.addView(statCard("ONE TV","USHA IT","All in One"));
        addScroll(page);
    }

    private void showSearch(boolean push,String scope) {
        if(push) push("search");
        screen="search";
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar("Search",false));

        EditText input=new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setHint("Search matches, teams, channels, videos, programs...");
        input.setTextSize(14);
        input.setPadding(dp(15),0,dp(15),0);
        input.setBackground(round(CARD,16));
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(50));
        ip.setMargins(dp(14),dp(4),dp(14),dp(8));
        page.addView(input,ip);

        LinearLayout filters=new LinearLayout(this);
        filters.setPadding(dp(12),0,dp(12),dp(8));
        String[] fs={"ALL","SPORTS","ENTERTAINMENT"};
        for(String f:fs){
            TextView chip=tab(f,"all".equalsIgnoreCase(scope)?f.equals("ALL"):f.equalsIgnoreCase(scope));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(110),dp(42));
            cp.setMargins(dp(3),0,dp(3),0);
            final String selectedScope=f.toLowerCase(Locale.US);
            chip.setOnClickListener(v->{
                showSearch(false,selectedScope);
            });
            filters.addView(chip,cp);
        }
        page.addView(filters);

        LinearLayout results=new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        page.addView(results,new LinearLayout.LayoutParams(-1,0,1));

        TextWatcher watcher=new TextWatcher(){
            public void beforeTextChanged(CharSequence c,int st,int count,int after){}
            public void onTextChanged(CharSequence c,int st,int before,int count){renderSearchResults(results,c.toString(),scope);}
            public void afterTextChanged(Editable e){}
        };
        input.addTextChangedListener(watcher);
        renderSearchResults(results,"",scope);
        addScroll(page);
    }

    private void renderSearchResults(LinearLayout results,String query,String scope) {
        results.removeAllViews();
        String q=query==null? "":query.trim().toLowerCase(Locale.US);
        if(q.isEmpty()){
            results.addView(sectionLabel("Search","Start typing to find ONE TV content"));
            results.addView(statCard("Search engine","Matches • Teams • Channels","Videos • Programs • Entertainment"));
            return;
        }

        boolean sportsAllowed="all".equalsIgnoreCase(scope)||"sports".equalsIgnoreCase(scope);
        boolean entAllowed="all".equalsIgnoreCase(scope)||"entertainment".equalsIgnoreCase(scope);
        boolean found=false;

        if(sportsAllowed){
            String[][] matches={
                {"cricket","RSA vs AUS • 3rd Test"},{"cricket","BAN vs WI • 1st Test"},{"football","International San Carlos vs Escorpiones Belen"},
                {"football","Real Madrid vs Valencia"},{"basketball","Lakers vs Warriors"},{"basketball","Celtics vs Knicks"},{"tennis","Alcaraz vs Sinner"}
            };
            for(String[] item:matches){
                if(item[1].toLowerCase(Locale.US).contains(q)){
                    found=true;
                    JSONObject m=demoMatch(item[0],item[1]);
                    results.addView(searchResult("🏆",item[1],sportName(item[0])+" • Match",v->{selectedMatch=m;showMatchDetail(true);}));
                }
            }
        }

        if(entAllowed){
            String[][] media={{"BTV News","TV Channel"},{"Star Sports","TV Channel"},{"Sony Entertainment","TV Channel"},{"ATN News","TV Channel"},
                {"The Last Mission","Movie"},{"Matchday Highlights","Video"},{"Top Headlines","News"},{"Prime Time","Program"},{"Kids Zone","Kids"}};
            for(String[] item:media){
                if(item[0].toLowerCase(Locale.US).contains(q)){
                    found=true;
                    results.addView(searchResult("▶",item[0],"Entertainment • "+item[1],v->showContentDetail(item[0],item[1],true)));
                }
            }
            for(Channel c:channels){
                if(c.name!=null && c.name.toLowerCase(Locale.US).contains(q)){
                    found=true;
                    results.addView(searchResult("📺",c.name,"Live TV • "+(c.program==null||c.program.isEmpty()?"Channel":c.program),v->playFirstChannel()));
                }
            }
        }

        if(!found) results.addView(statCard("No results","Nothing matched “"+query+"”","Try a team, channel, match or program name"));
    }

    private LinearLayout searchResult(String icon,String title,String sub,View.OnClickListener click) {
        LinearLayout r=contentRow(title,sub);
        r.setOnClickListener(click);
        return r;
    }

    private void showContentDetail(String title,String type,boolean push) {
        if(push) push("content:"+title);
        screen="content";
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar(title,false));
        page.addView(heroBanner(title,type+" • ONE TV","WATCH NOW",PURPLE));
        page.addView(sectionLabel("About","Prototype content detail page"));
        page.addView(statCard("Category",type,"Available inside ONE TV"));
        page.addView(statCard("Playback","In-app player","No external redirect"));
        page.addView(menuAction("▶","Play","Open the content in the ONE TV player",v->playDemoContent(title,type)));
        page.addView(sectionLabel("More like this","Related content"));
        page.addView(contentRow("Related "+type+" 01",type));
        page.addView(contentRow("Related "+type+" 02",type));
        addScroll(page);
    }

    private void playDemoContent(String title,String type) {
        if(player!=null) {
            showSimple("Player",title+" is ready for an authorized stream.");
        } else {
            showSimple("Player",title+" is ready for an authorized stream.");
        }
    }

    private void showSimple(String title,String subtitle) {
        clearContent();
        screen="simple";
        LinearLayout page=page();
        page.addView(selectedSectionBar(title,false));
        page.addView(sectionLabel(title,subtitle));
        page.addView(statCard("ONE TV","USHA IT","All in One"));
        addScroll(page);
    }

    private void clearContent() {
        if(contentHost!=null)contentHost.removeAllViews();
        if(statusText!=null)statusText=null;
    }

    private LinearLayout page() {
        LinearLayout p=new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundColor(BG);
        return p;
    }

    private void addScroll(LinearLayout page) {
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));
        contentHost.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
    }

    private LinearLayout modeRow() {
        LinearLayout row=new LinearLayout(this);
        row.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView s=modeButton("SPORTS",BLUE);
        s.setOnClickListener(v->showSportsHome(true));
        TextView e=modeButton("ENTERTAINMENT",PURPLE);
        e.setOnClickListener(v->showEntertainment("TV",true));

        LinearLayout.LayoutParams sp=weighted();
        sp.height=dp(48);
        sp.setMargins(dp(3),0,dp(3),0);
        LinearLayout.LayoutParams ep=weighted();
        ep.height=dp(48);
        ep.setMargins(dp(3),0,dp(3),0);
        row.addView(s,sp);
        row.addView(e,ep);
        return row;
    }

    private TextView sportsProviderAttribution() {
        TextView t=tv("Powered by SportsScore",9,MUTED,false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0,dp(2),0,dp(4));
        t.setContentDescription("Sports data provider attribution");
        return t;
    }

    private View selectedSectionBar(String name, boolean entertainment) {
        LinearLayout bar=new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(18),dp(8),dp(18),dp(5));
        TextView icon=tv(entertainment?"▣":"🏆",22,TEXT,false);
        bar.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(48)));
        TextView title=tv(name,20,TEXT,true);
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));
        return bar;
    }

    private View pageSearchButton(String hint, String scope) {
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16),dp(3),dp(16),dp(8));
        TextView button=tv("⌕  "+hint,13,MUTED,true);
        button.setGravity(Gravity.CENTER_VERTICAL);
        button.setPadding(dp(14),0,dp(14),0);
        button.setBackground(round(CARD,16));
        button.setOnClickListener(v->showSearch(true,scope));
        row.addView(button,new LinearLayout.LayoutParams(-1,dp(44)));
        return row;
    }

    private LinearLayout modeTabs(LinearLayout page, String sport, String[] modes) {
        LinearLayout row=new LinearLayout(this);
        row.setPadding(dp(12),dp(4),dp(12),dp(8));
        for(String mode:modes){
            TextView b=tab(mode, mode.equalsIgnoreCase(matchMode));
            b.setOnClickListener(v->{
                matchMode=mode.toLowerCase(Locale.US);
                remoteMatches=null;
                renderSportList(page,sport);
                loadSportsFromBackend(sport,matchMode,page);
            });
            LinearLayout.LayoutParams lp=weighted();
            lp.height=dp(48);
            lp.setMargins(dp(3),0,dp(3),0);
            row.addView(b,lp);
        }
        return row;
    }

    private View sectionLabel(String title, String sub) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(18), dp(8), dp(18), dp(6));
        TextView t = tv(title, 18, TEXT, true);
        TextView s = tv(sub, 10, MUTED, false);
        wrap.addView(t);
        if (sub != null && !sub.isEmpty()) wrap.addView(s);
        return wrap;
    }

    private TextView modeButton(String label,int accent) {
        TextView b=tv(label,14,TEXT,true);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setBackground(round(CARD,18));
        b.setPadding(0,0,0,0);
        return b;
    }

    private LinearLayout featureTile(String icon,String name,int accent) {
        LinearLayout c=new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(3),dp(8),dp(3),dp(8));
        c.setBackground(round(CARD_2,13));
        TextView i=tv(icon,25,TEXT,false);i.setGravity(Gravity.CENTER);
        TextView n=tv(name,11,TEXT,true);n.setGravity(Gravity.CENTER);
        c.addView(i,new LinearLayout.LayoutParams(-1,dp(36)));
        c.addView(n);
        LinearLayout.LayoutParams p=weighted();
        p.setMargins(dp(3),0,dp(3),0);
        c.setLayoutParams(p);
        return c;
    }

    private LinearLayout scoreTeam(String flag,String name,String score) {
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setGravity(Gravity.CENTER);
        b.addView(tv(flag,18,TEXT,false));
        b.addView(tv(name,14,Color.BLACK,true));
        b.addView(tv(score,14,Color.BLACK,true));
        return b;
    }

    private LinearLayout channelTile(String name) {
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);
        c.setPadding(dp(4),dp(8),dp(4),dp(8));c.setBackground(round(Color.WHITE,10));
        TextView icon=tv("▣",22,BLUE,true);icon.setGravity(Gravity.CENTER);
        TextView n=tv(name,9,Color.DKGRAY,true);n.setGravity(Gravity.CENTER);n.setMaxLines(2);
        c.addView(icon,new LinearLayout.LayoutParams(-1,dp(32)));c.addView(n);
        return c;
    }

    private LinearLayout contentRow(String title,String type) {
        LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(12),dp(9),dp(12),dp(9));r.setBackground(round(CARD,12));
        TextView icon=tv(type.equals("News")?"▤":"▶",20,TEXT,false);r.addView(icon,new LinearLayout.LayoutParams(dp(45),dp(45)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.addView(tv(title,13,TEXT,true));info.addView(tv(type+" • ONE TV",10,MUTED,false));
        r.addView(info,new LinearLayout.LayoutParams(0,-2,1));r.addView(tv("›",24,MUTED,false));
        return r;
    }

    private TextView tab(String label,boolean active) {
        TextView b=tv(label,12.5f,active?TEXT:MUTED,true);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setMinWidth(dp(78));
        b.setBackground(round(active?BLUE:CARD,18));
        b.setPadding(dp(10),0,dp(10),0);
        return b;
    }

    private Button smallButton(String label,int color) {
        Button b=new Button(this);b.setText(label);b.setTextSize(10);b.setTextColor(TEXT);b.setAllCaps(false);b.setMinHeight(0);b.setMinWidth(0);b.setPadding(dp(12),0,dp(12),0);b.setBackground(round(color,18));return b;
    }

    private TextView eventRow(String value,int n) {
        TextView t=tv(value,12,TEXT,false);t.setPadding(dp(12),dp(11),dp(12),dp(11));t.setBackground(round(CARD,12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(6));t.setLayoutParams(p);return t;
    }

    private View statCard(String title,String value,String sub) {
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(13),dp(10),dp(13),dp(10));r.setBackground(round(CARD,12));
        r.addView(tv(title,10,MUTED,true));r.addView(tv(value,16,TEXT,true));r.addView(tv(sub,10,MUTED,false));return r;
    }

    private LinearLayout tableBox() {
        LinearLayout t=new LinearLayout(this);t.setOrientation(LinearLayout.VERTICAL);t.setBackground(round(CARD,12));return t;
    }

    private LinearLayout tableRow(String[] values,boolean header) {
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(6),dp(6),dp(6),dp(6));
        for(int i=0;i<values.length;i++){TextView v=tv(values[i],header?8.5f:9.5f,header?MUTED:TEXT,header);v.setGravity(i==0?Gravity.LEFT:Gravity.CENTER);row.addView(v,new LinearLayout.LayoutParams(0,dp(32),i==0?2.3f:1));}
        row.setBackgroundColor(header?Color.rgb(25,45,59):Color.TRANSPARENT);return row;
    }

    private LinearLayout detailRow(String left,String right) {
        LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(10),dp(8),dp(10),dp(8));r.setBackground(round(CARD,10));r.addView(tv(left,12,TEXT,true),new LinearLayout.LayoutParams(0,-2,1));r.addView(tv(right,12,MUTED,false));return r;
    }

    private LinearLayout.LayoutParams marginBottomParams(int dp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, this.dp(dp));
        return p;
    }

    private LinearLayout.LayoutParams weighted() { return new LinearLayout.LayoutParams(0, -2, 1); }

    private JSONObject demoMatch(String sport,String title) {
        JSONObject m=new JSONObject();
        try{
            m.put("sport",sport);
            m.put("title",title);
            m.put("competition",sportName(sport)+" • Match Center");
            m.put("status","LIVE");
            m.put("result","Live • Updated just now");
            m.put("date","Today • Local time");
            JSONObject h=new JSONObject(),a=new JSONObject();
            if("cricket".equals(sport)){
                h.put("name","RSA"); h.put("flag","🇿🇦"); h.put("score","329 & 387"); h.put("form","1st innings • 329 all out");
                a.put("name","AUS"); a.put("flag","🇦🇺"); a.put("score","429 & 111/3"); a.put("form","2nd innings • 38.2 Ov");
                m.put("competition","ICC Test Championship • 3rd Test"); m.put("format","Test"); m.put("venue","Newlands, Cape Town");
                m.put("date","Day 4 • Session 2"); m.put("status","LIVE");
            } else if("football".equals(sport)){
                h.put("name","International San Carlos"); h.put("flag","⚽"); h.put("score","2");
                a.put("name","Escorpiones Belen"); a.put("flag","⚽"); a.put("score","3");
                m.put("competition","International Cup • Round of 16"); m.put("venue","National Stadium"); m.put("referee","Referee A"); m.put("date","Today • 20:00"); m.put("status","LIVE");
            } else if("basketball".equals(sport)){
                h.put("name","Lakers"); h.put("flag","LAL"); h.put("score","102");
                a.put("name","Warriors"); a.put("flag","GSW"); a.put("score","98");
                m.put("competition","NBA • Regular Season"); m.put("venue","Crypto.com Arena"); m.put("round","Regular Season"); m.put("date","Today • 20:30"); m.put("status","LIVE");
            } else {
                h.put("name","Alcaraz"); h.put("flag","ES"); h.put("score","2");
                a.put("name","Sinner"); a.put("flag","IT"); a.put("score","1");
                m.put("competition","ATP Masters • Quarter-final"); m.put("venue","Centre Court"); m.put("round","Quarter-final"); m.put("date","Today • 19:00"); m.put("status","LIVE");
            }
            m.put("home",h); m.put("away",a);
        }catch(Exception ignored){}
        return m;
    }

    private JSONObject team(JSONObject m,boolean home) {
        JSONObject t=m.optJSONObject(home?"home":"away");
        return t==null?new JSONObject():t;
    }

    private String sportName(String s) {
        if(s==null)return "Sports";
        if("football".equalsIgnoreCase(s)||"soccer".equalsIgnoreCase(s))return "Football";
        if("basketball".equalsIgnoreCase(s))return "Basketball";
        if("tennis".equalsIgnoreCase(s))return "Tennis";
        return "Cricket";
    }

    private void push(String state) {
        if(screen!=null&&!screen.equals(state))history.push(screen);
    }

    @Override public void onBackPressed() {
        if(fullscreen){exitFullscreen();return;}
        if(!history.empty()){
            String prev=history.pop();
            if("home".equals(prev))showHome(false);
            else if("sportsHome".equals(prev))showSportsHome(false);
            else if(prev.startsWith("sport:"))showSports(prev.substring(6),false);
            else if(prev.startsWith("ent:"))showEntertainment(prev.substring(4),false);
            else if("match".equals(prev)&&selectedMatch!=null)showMatchDetail(false);
            else if("menu".equals(prev))showMenuPage(false);
            else if("notifications".equals(prev))showNotifications(false);
            else if("appearance".equals(prev))showAppearance(false);
            else if("search".equals(prev))showSearch(false,"all");
            else if(prev.startsWith("content:"))showContentDetail(prev.substring(8),"Entertainment",false);
            else if(prev.startsWith("directory:")){
                String[] parts=prev.split(":",3);
                if(parts.length==3)showSportsDirectory(parts[1],parts[2],false); else showSportsHome(false);
            }
            else showHome(false);
        }else super.onBackPressed();
    }

    private void exitFullscreen() {
        if(fullscreen) toggleFullscreen();
    }

    private void toggleFullscreen() {
        if (playerFrame == null) return;
        ViewGroup decor = (ViewGroup) getWindow().getDecorView();
        if (!fullscreen) {
            playerOriginalParent = (ViewGroup) playerFrame.getParent();
            playerOriginalIndex = playerOriginalParent == null ? 0 : playerOriginalParent.indexOfChild(playerFrame);
            if (playerOriginalParent != null) playerOriginalParent.removeView(playerFrame);
            decor.addView(playerFrame, new ViewGroup.LayoutParams(-1, -1));
            playerFrame.setVisibility(View.VISIBLE);
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            if (adRow != null) adRow.setVisibility(View.GONE);
            if (footer != null) footer.setVisibility(View.GONE);
            fullscreen = true;
        } else {
            decor.removeView(playerFrame);
            if (playerOriginalParent != null) {
                playerOriginalParent.addView(playerFrame, Math.min(playerOriginalIndex, playerOriginalParent.getChildCount()),
                        new LinearLayout.LayoutParams(-1, dp(260)));
            }
            getWindow().getDecorView().setSystemUiVisibility(0);
            if (adRow != null) adRow.setVisibility(View.VISIBLE);
            if (footer != null) footer.setVisibility(View.VISIBLE);
            fullscreen = false;
        }
    }

    private void hideAds(boolean hide){if(adRow!=null)adRow.setVisibility(hide?View.GONE:View.VISIBLE);if(footer!=null)footer.setVisibility(hide?View.GONE:View.VISIBLE);}


    private TextView tv(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(android.graphics.Typeface.DEFAULT,bold?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL);t.setIncludeFontPadding(false);return t;}

    private GradientDrawable round(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}

    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}

    private LinearLayout.LayoutParams weightedLp(){return new LinearLayout.LayoutParams(0,-2,1);}

    private JSONObject getJson(String url){try{return new JSONObject(getUrl(url));}catch(Exception e){return new JSONObject();}}

    private String getUrl(String address)throws Exception{
        HttpURLConnection c=null;
        try{
            URL u=new URL(address);c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);c.setRequestMethod("GET");
            int code=c.getResponseCode();
            InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
            if(in==null)throw new Exception("HTTP "+code);
            BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder sb=new StringBuilder();String line;
            while((line=r.readLine())!=null)sb.append(line);
            return sb.toString();
        }finally{if(c!=null)c.disconnect();}
    }

    private static class Channel {
        String name,url,program;
        Channel(String n,String u,String p){name=n;url=u;program=p;}
    }

    @Override protected void onDestroy(){
        handler.removeCallbacksAndMessages(null);
        playerUiHandler.removeCallbacksAndMessages(null);
        network.shutdownNow();
        if(player!=null){player.release();player=null;}
        super.onDestroy();
    }
}
