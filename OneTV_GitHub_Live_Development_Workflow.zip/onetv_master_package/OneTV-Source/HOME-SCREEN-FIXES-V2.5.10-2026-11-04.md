# OneTV Home Screen Fixes v2.5.10 — 2026-11-04

## Applied
- Replaced the football-only Home Sports category glyph with a trophy symbol representing sports broadly.
- Replaced placeholder square glyphs on Entertainment and News cards with recognizable clapperboard and newspaper symbols.
- Added the four-item bottom navigation shown in the approved PDF Home reference: Home, Sports, Entertainment, News.
- Bottom navigation is shown only on top-level destinations and hidden on child/detail routes.
- Home live-feed parsing now rejects records explicitly marked finished, upcoming, postponed, cancelled, or abandoned.
- Home upcoming-feed parsing rejects records explicitly marked live, finished, cancelled, or abandoned.
- Preserved the single global footer ad placement and existing provider-backed content flow.

## Verification limits
- Source-level edits and ZIP integrity are checked.
- Android Gradle build and device validation have not been run in this environment.
- Provider payloads must be checked on the user's installed app to confirm each API's status vocabulary and time-zone behavior.
