# OneTV Live Development Workflow — GitHub Actions

## What this setup changes

1. `build.yml` now runs Debug CI on pushes to `main`, `master`, or `dev-live`, and on manual dispatch. It builds only a Debug APK and uploads it as a 14-day artifact.
2. `release.yml` is manual-only. Release APK/AAB are produced only when deliberately started from Actions.
3. `device-deploy.yml` is an optional self-hosted workflow. When a Windows development PC is registered as a GitHub Actions self-hosted runner and one authorized Android phone is connected by USB, a push to `dev-live` builds, installs, and launches the Debug APK automatically.

## Important limitation

GitHub-hosted runners cannot access the user's USB-connected phone. The automatic USB deployment workflow therefore requires a self-hosted runner installed on the user's own Windows PC. This is not hot reload: Android native Java/UI changes still require a new Debug APK install. It removes the manual download/copy/install steps, not the build itself.

For backend-served data and Remote Config values already supported by the app, change the backend and refresh/reopen the app. Those updates do not need an APK rebuild. A UI property can be changed remotely only if the client was coded to read that property from Remote Config.

## One-time Windows PC setup for automatic install

1. Keep the OneTV GitHub repository **Private**. Do not register a self-hosted runner for an untrusted public repository.
2. Install JDK 17, Gradle 8.13, Android SDK Platform 35, Android Build Tools 35.0.0, and Android SDK Platform Tools (`adb`) on the Windows PC.
3. Enable Developer Options and USB Debugging on the Android phone. Connect it by USB and accept the RSA authorization prompt.
4. In GitHub: repository → Settings → Actions → Runners → New self-hosted runner → Windows → x64. Follow GitHub's displayed commands on the PC. During runner configuration, add the extra label `onetv-device` (keep the default `self-hosted`, `Windows`, `X64` labels).
5. Start the runner using the generated `run.cmd` or install it as a Windows service. Keep the PC online.
6. Push development commits to `dev-live`. The `OneTV USB Device Deploy` workflow should build, install, and launch the app on the connected phone.

## Manual testing path without a self-hosted runner

Push to `main` / `master` / `dev-live` → GitHub Actions → `OneTV Debug CI` → download the `OneTV-Debug-*` artifact → install it. This still requires manual installation but avoids producing release APK/AAB on every development commit.

## Release discipline

Do not use `release.yml` for routine UI iterations. Run it only after the complete PDF route inventory, backend data validation, ad placement, permissions, privacy, and device QA have passed. Signing secrets are not configured by these workflow files; configure release signing securely before Play Store distribution.

## Security

- Store the backend URL and all provider credentials in GitHub Actions Secrets or server-side backend secrets, not in source files.
- Never expose provider API keys in Android BuildConfig or APK assets.
- Use the self-hosted runner only with a private repository and trusted branches. A self-hosted runner executes repository workflow code on your PC.
