package com.ushait.onetv;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.SharedPreferences;
import android.os.Build;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.ui.PlayerView;
import androidx.core.app.NotificationCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Stack;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final String BACKEND_URL = BuildConfig.BACKEND_URL;
    private int BG = Color.rgb(5, 10, 17);
    private int PANEL = Color.rgb(13, 25, 39);
    private int CARD = Color.rgb(20, 35, 51);
    private int CARD_2 = Color.rgb(24, 42, 61);
    private int BLUE = Color.rgb(28, 126, 245);
    private int CYAN = Color.rgb(0, 205, 190);
    private int PURPLE = Color.rgb(119, 52, 245);
    private int TEXT = Color.WHITE;
    private int MUTED = Color.rgb(174, 188, 203);
    private int GREEN = Color.rgb(0, 194, 142);
    private int RED = Color.rgb(244, 63, 81);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final Stack<String> history = new Stack<>();
    private final List<Channel> channels = new ArrayList<>();

    private LinearLayout root;
    private FrameLayout contentHost;
    private LinearLayout topModeRow;
    private TextView pageTitle;
    private TextView pageSubtitle;
    private TextView headerSlogan;
    private ImageView logoView;
    private LinearLayout adRow;
    private LinearLayout fixedBottom;
    private LinearLayout bottomNavigation;
    private View headerView;
    private TextView footer;
    private TextView statusText;
    private TextView notificationBadge;
    private ImageView headerSearch;
    private ImageView headerMenu;
    private ImageView headerNotification;
    private View menuScrim;
    private LinearLayout menuDrawer;
    private String menuOriginScreen = "home";
    private SharedPreferences prefs;
    private boolean volumePopupVisible = false;
    private android.widget.PopupWindow volumePopup;
    private long lastPlayerTapAt = 0L;
    private float lastPlayerTapX = 0f;
    private int notificationSequence = 1000;
    private int searchRequestSequence = 0;
    private FrameLayout playerFrame;
    private TextView customPlayerControls;
    private final Handler playerUiHandler = new Handler(Looper.getMainLooper());
    private JSONObject adConfig;
    private JSONObject remoteAppConfig;
    private long sportsRefreshMs = 30000L;
    private long cricketDetailRefreshMs = 20000L;
    private long notificationsRefreshMs = 30000L;
    private String remoteLiveStatusLabel = "Live Now";
    private String remoteUpcomingStatusLabel = "Upcoming";
    private String remoteFinishedStatusLabel = "Finished";
    private String remoteLiveBadgeLabel = "LIVE NOW";
    private boolean remoteLiveScoreEnabled = true;
    private boolean remoteDataEnabled = true;
    private LinearLayout activeSportsPage;
    private boolean activeSportsHome = false;
    private final Runnable sportsRefreshTask = new Runnable() {
        @Override public void run() {
            if (activeSportsPage == null) return;
            if (activeSportsHome && "sportsHome".equals(screen)) {
                loadSportsHome(activeSportsPage);
                handler.postDelayed(this, sportsRefreshMs);
            } else if (!activeSportsHome && "sport".equals(screen)) {
                loadSportsFromBackend(selectedSport, matchMode, activeSportsPage);
                handler.postDelayed(this, sportsRefreshMs);
            }
        }
    };

    private ExoPlayer player;
    private PlayerView playerView;
    private boolean fullscreen = false;
    private ViewGroup playerOriginalParent;
    private int playerOriginalIndex = 0;

    private String screen = "home";
    private String selectedSport = "cricket";
    private String selectedEntertainment = "TV";
    private boolean entertainmentContext = false;
    private String lastSearchQuery = "";
    private String matchMode = "live";
    private JSONObject selectedMatch;
    private String detailTab = "SCORECARD";
    private JSONArray remoteMatches;
    private JSONObject remoteMatchDetail;
    private JSONArray remoteContent;
    private FrameLayout matchHeroHost;
    private final Runnable matchDetailRefreshTask = new Runnable() {
        @Override public void run() {
            if (!"match".equals(screen) || selectedMatch == null) return;
            String sport = selectedMatch.optString("sport", selectedSport).toLowerCase(Locale.US);
            if (BACKEND_URL == null || BACKEND_URL.contains("REPLACE") || !remoteDataEnabled || !remoteLiveScoreEnabled) return;
            loadMatchDetail(selectedMatch, sport, activeMatchBodyHost);
        }
    };
    private FrameLayout activeMatchBodyHost;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadRemoteAppConfig();
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setNavigationBarDividerColor(BG);
        getWindow().getDecorView().setOnApplyWindowInsetsListener((v, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            int bottom = insets.getSystemWindowInsetBottom();
            if (root != null) root.setPadding(0, top, 0, bottom);
            return insets;
        });
        prefs = getSharedPreferences("onetv_prefs", MODE_PRIVATE);
        setPalette(prefs.getBoolean("dark_theme", false));
        MobileAds.initialize(this, status -> {});
        createNotificationChannel();
        showAnimatedSplash();
    }

    private boolean startupCompleted = false;

    /** Premium 1.2 second identity animation. Network bootstrap has already started in parallel. */
    private void showAnimatedSplash() {
        FrameLayout splash = new FrameLayout(this);
        splash.setBackgroundColor(Color.rgb(4, 9, 17));
        LinearLayout identity = new LinearLayout(this);
        identity.setOrientation(LinearLayout.VERTICAL);
        identity.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams identityParams = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.onetv_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(154), dp(154));
        identity.addView(logo, logoParams);
        TextView brand = tv("OneTV", 25, Color.WHITE, true);
        brand.setGravity(Gravity.CENTER);
        brand.setLetterSpacing(0.08f);
        brand.setAlpha(0f);
        identity.addView(brand, new LinearLayout.LayoutParams(-1, -2));
        TextView owner = tv("BY USHA IT", 9, Color.rgb(143, 165, 190), true);
        owner.setGravity(Gravity.CENTER);
        owner.setLetterSpacing(0.20f);
        owner.setPadding(0, dp(7), 0, 0);
        owner.setAlpha(0f);
        identity.addView(owner, new LinearLayout.LayoutParams(-1, -2));
        splash.addView(identity, identityParams);
        setContentView(splash);
        logo.setAlpha(0f);
        logo.setScaleX(0.88f);
        logo.setScaleY(0.88f);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(760).setStartDelay(90).start();
        brand.animate().alpha(1f).setDuration(420).setStartDelay(440).start();
        owner.animate().alpha(1f).setDuration(420).setStartDelay(610).start();
        handler.postDelayed(() -> {
            if (isFinishing() || startupCompleted) return;
            startupCompleted = true;
            buildShell();
            showHome(false);
            loadChannels();
            loadAdConfig();
            loadNotifications();
        }, 1200L);
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        headerView = buildHeader();
        root.addView(headerView, new LinearLayout.LayoutParams(-1, dp(78)));
        contentHost = new FrameLayout(this);
        root.addView(contentHost, new LinearLayout.LayoutParams(-1, 0, 1));

        bottomNavigation = buildBottomNavigation();
        root.addView(bottomNavigation, new LinearLayout.LayoutParams(-1, dp(58)));

        fixedBottom = new LinearLayout(this);
        fixedBottom.setOrientation(LinearLayout.VERTICAL);
        fixedBottom.setBackgroundColor(BG);

        adRow = buildAds();
        fixedBottom.addView(adRow, new LinearLayout.LayoutParams(-1, dp(84)));

        footer = tv("© 2026 USHA IT. All Rights Reserved.", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(dp(8), dp(4), dp(8), dp(5));
        fixedBottom.addView(footer, new LinearLayout.LayoutParams(-1, dp(38)));

        root.addView(fixedBottom, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        updateBottomNavigation();
    }

    private LinearLayout buildBottomNavigation() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(5), dp(5), dp(5), dp(4));
        nav.setBackgroundColor(darkTheme() ? Color.rgb(7, 15, 25) : Color.rgb(15, 24, 35));
        return nav;
    }

    private void updateBottomNavigation() {
        if (bottomNavigation == null) return;
        boolean topLevel = "home".equals(screen) || "sportsHome".equals(screen)
                || "entertainment".equals(screen) || "news".equals(screen);
        bottomNavigation.setVisibility(topLevel ? View.VISIBLE : View.GONE);
        if (!topLevel) return;
        bottomNavigation.removeAllViews();
        addBottomNavItem("Home", R.drawable.ic_home, "home".equals(screen), v -> showHome(true));
        addBottomNavItem("Sports", R.drawable.ic_sports, "sportsHome".equals(screen), v -> showSportsHome(true));
        addBottomNavItem("Entertainment", R.drawable.ic_entertainment, "entertainment".equals(screen), v -> showEntertainment("Photos", true));
        addBottomNavItem("News", R.drawable.ic_news, "news".equals(screen), v -> showNews(true));
    }

    private void addBottomNavItem(String label, int iconRes, boolean selected, View.OnClickListener click) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(2), dp(1), dp(2), dp(1));
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        icon.setColorFilter(selected ? CYAN : MUTED, android.graphics.PorterDuff.Mode.SRC_IN);
        item.addView(icon, new LinearLayout.LayoutParams(dp(21), dp(21)));
        TextView text = tv(label, 8.5f, selected ? CYAN : MUTED, selected);
        text.setGravity(Gravity.CENTER);
        text.setSingleLine(true);
        text.setPadding(0, dp(2), 0, 0);
        item.addView(text, new LinearLayout.LayoutParams(-1, -2));
        item.setContentDescription(label);
        item.setOnClickListener(click);
        bottomNavigation.addView(item, new LinearLayout.LayoutParams(0, -1, 1));
    }

    private View buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(10), 0, dp(10), 0);
        header.setBackgroundColor(darkTheme() ? Color.rgb(4, 9, 15) : BG);

        headerMenu = headerIcon(R.drawable.ic_menu, "Menu");
        headerMenu.setOnClickListener(v -> showMenuPage(true));
        LinearLayout.LayoutParams menuLp = new LinearLayout.LayoutParams(dp(38), dp(40));
        menuLp.setMargins(0, 0, dp(5), 0);
        header.addView(headerMenu, menuLp);

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView logo = new ImageView(this);
        logoView = logo;
        logo.setImageResource(R.drawable.onetv_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        brand.addView(logo, new LinearLayout.LayoutParams(dp(96), dp(44)));
        headerSlogan = tv("All in One", 11, TEXT, true);
        headerSlogan.setGravity(Gravity.CENTER);
        headerSlogan.setSingleLine(true);
        headerSlogan.setPadding(0, 0, 0, 0);
        brand.addView(headerSlogan, new LinearLayout.LayoutParams(dp(96), dp(14)));
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(dp(102), dp(60));
        brandLp.setMargins(dp(1), 0, dp(3), 0);
        header.addView(brand, brandLp);

        Space spacer = new Space(this);
        header.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1));

        headerSearch = headerIcon(R.drawable.ic_search, "Search");
        headerSearch.setBackgroundColor(Color.TRANSPARENT);
        headerSearch.setPadding(dp(7), dp(7), dp(7), dp(7));
        headerSearch.setOnClickListener(v -> showSearch(true, "all"));
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(dp(38), dp(40));
        searchLp.setMargins(dp(3), 0, dp(6), 0);
        header.addView(headerSearch, searchLp);

        headerNotification = headerIcon(R.drawable.ic_notifications, "Notifications");
        headerNotification.setOnClickListener(v -> showNotifications(true));
        FrameLayout notification = new FrameLayout(this);
        notification.addView(headerNotification, new FrameLayout.LayoutParams(dp(40), dp(40)));
        notificationBadge = tv("", 7, Color.WHITE, true);
        notificationBadge.setGravity(Gravity.CENTER);
        notificationBadge.setBackground(round(RED, 7));
        notificationBadge.setVisibility(View.GONE);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(14), dp(14), Gravity.TOP | Gravity.END);
        bp.setMargins(0, 0, dp(1), 0);
        notification.addView(notificationBadge, bp);
        header.addView(notification, new LinearLayout.LayoutParams(dp(40), dp(40)));
        return header;
    }

    private ImageView headerIcon(int resId, String description) {
        ImageView icon = new ImageView(this);
        icon.setImageResource(resId);
        icon.setContentDescription(description);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        icon.setColorFilter(TEXT, android.graphics.PorterDuff.Mode.SRC_IN);
        icon.setPadding(dp(8), dp(8), dp(8), dp(8));
        return icon;
    }

    private LinearLayout buildAds() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(12), dp(6), dp(12), dp(6));
        row.setBackgroundColor(BG);
        row.setVisibility(View.GONE);
        // One global footer placement only. No parallel/duplicate ad containers.
        addAdSlot(row, "home_footer");
        return row;
    }

    private void addAdSlot(LinearLayout row, String placement) {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER);
        card.setBackgroundColor(Color.TRANSPARENT);
        AdView ad = new AdView(this);
        ad.setBackgroundColor(Color.TRANSPARENT);
        ad.setAdSize(AdSize.BANNER);
        String unit = BuildConfig.DEBUG ? "ca-app-pub-3940256099942544/6300978111" : "ca-app-pub-5981864080922785/5178976268";
        ad.setAdUnitId(unit);
        card.addView(ad, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1);
        p.setMargins(dp(3), 0, dp(3), 0);
        row.addView(card, p);
        ad.setAdListener(new com.google.android.gms.ads.AdListener() {
            @Override public void onAdLoaded() {
                runOnUiThread(() -> {
                    if (adRow != null) {
                        adRow.setVisibility(View.VISIBLE);
                        adRow.setBackgroundColor(BG);
                    }
                });
            }
            @Override public void onAdFailedToLoad(com.google.android.gms.ads.LoadAdError error) {
                card.setVisibility(View.GONE);
                boolean anyVisible = false;
                for (int i = 0; i < row.getChildCount(); i++) {
                    if (row.getChildAt(i).getVisibility() == View.VISIBLE) { anyVisible = true; break; }
                }
                if (!anyVisible) row.setVisibility(View.GONE);
            }
        });
        ad.loadAd(new AdRequest.Builder().build());
    }

    private void showHome(boolean push) {
        stopMatchDetailAutoRefresh();
        entertainmentContext = false;
        if (push) push("home");
        screen = "home";
        clearContent();
        buildHome();
        hideAds(false);
    }

    private void buildHome() {
        LinearLayout page = page();
        page.setPadding(0, 0, 0, dp(10));

        // Featured match is populated exclusively from the validated backend feed.
        LinearLayout heroHost = new LinearLayout(this);
        heroHost.setOrientation(LinearLayout.VERTICAL);
        heroHost.setPadding(dp(14), dp(10), dp(14), dp(8));
        heroHost.addView(emptyStateCard("Featured matches", "Loading verified live and upcoming matches…"));
        page.addView(heroHost);

        // Large, image-free category tiles follow the Home composition in the approved PDF.
        // They use branded gradients and real destination routes, never fabricated media.
        page.addView(homeCategoryCard("🏆", "Sports", "Live Matches & Scores",
                new int[]{Color.rgb(9, 83, 143), Color.rgb(8, 43, 79)},
                v -> showSportsHome(true)));
        page.addView(homeCategoryCard("🎬", "Entertainment", "Photo Stories & More",
                new int[]{Color.rgb(91, 35, 168), Color.rgb(47, 24, 104)},
                v -> showEntertainment("Photos", true)));
        page.addView(homeCategoryCard("📰", "News", "Breaking & Top Stories",
                new int[]{Color.rgb(157, 25, 66), Color.rgb(83, 17, 47)},
                v -> showNews(true)));

        LinearLayout liveHead = premiumSectionHeader("Live Now", "See All", v -> showSportsHome(true));
        page.addView(liveHead);
        LinearLayout liveContainer = new LinearLayout(this);
        liveContainer.setOrientation(LinearLayout.VERTICAL);
        liveContainer.setPadding(dp(12), 0, dp(12), dp(4));
        liveContainer.addView(statCard("Live matches", "Loading…", "Provider data only"));
        page.addView(liveContainer);

        LinearLayout upHead = premiumSectionHeader("Upcoming Matches", "See All", v -> {
            matchMode = "upcoming";
            showSports("cricket", true);
        });
        page.addView(upHead);
        LinearLayout upcomingContainer = new LinearLayout(this);
        upcomingContainer.setOrientation(LinearLayout.VERTICAL);
        upcomingContainer.setPadding(dp(12), 0, dp(12), dp(4));
        upcomingContainer.addView(statCard("Upcoming", "Loading…", "Provider data only"));
        page.addView(upcomingContainer);

        LinearLayout recentHead = premiumSectionHeader("Recent Results", "See All", v -> {
            matchMode = "results";
            showSports("cricket", true);
        });
        page.addView(recentHead);
        LinearLayout recentContainer = new LinearLayout(this);
        recentContainer.setOrientation(LinearLayout.VERTICAL);
        recentContainer.setPadding(dp(12), 0, dp(12), dp(16));
        recentContainer.addView(statCard("Recent results", "Loading…", "Provider data only"));
        page.addView(recentContainer);

        addScroll(page);
        loadHomeDashboard(heroHost, liveContainer, upcomingContainer, recentContainer);
    }

    private LinearLayout homeCategoryCard(String icon, String title, String subtitle,
                                          int[] colors, View.OnClickListener click) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(11), dp(16), dp(11));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, dp(76));
        cardParams.setMargins(dp(14), dp(5), dp(14), dp(5));

        GradientDrawable gradient = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors);
        gradient.setCornerRadius(dp(17));
        gradient.setStroke(dp(1), Color.argb(35, 255, 255, 255));
        card.setBackground(gradient);
        card.setElevation(dp(2));
        card.setLayoutParams(cardParams);

        TextView glyph = tv(icon, 29, Color.WHITE, true);
        glyph.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams glyphParams = new LinearLayout.LayoutParams(dp(48), -1);
        glyphParams.setMargins(0, 0, dp(13), 0);
        card.addView(glyph, glyphParams);

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = tv(title, 17, Color.WHITE, true);
        TextView detail = tv(subtitle, 10.5f, Color.rgb(226, 233, 245), false);
        detail.setPadding(0, dp(3), 0, 0);
        labels.addView(heading);
        labels.addView(detail);
        card.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));

        TextView arrow = tv("›", 27, Color.WHITE, false);
        arrow.setGravity(Gravity.CENTER);
        card.addView(arrow, new LinearLayout.LayoutParams(dp(24), -1));
        card.setOnClickListener(click);
        return card;
    }

    private LinearLayout premiumSectionHeader(String title, String action, View.OnClickListener click) {
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(18), dp(8), dp(18), dp(5));
        TextView t = tv(title, 18, TEXT, true);
        TextView a = tv(action, 10.5f, MUTED, true);
        a.setOnClickListener(click);
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(a, new LinearLayout.LayoutParams(-2, -2));
        return head;
    }

    private View premiumMatchHero(JSONObject m) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(15), dp(18), dp(15));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{darkTheme() ? Color.rgb(15, 42, 73) : Color.rgb(47, 48, 54),
                        darkTheme() ? Color.rgb(31, 24, 71) : Color.rgb(53, 45, 67)});
        bg.setCornerRadius(dp(22));
        card.setBackground(bg);
        card.setElevation(dp(3));
        String competition = pickText(m,"competition","league","tournament","competition_name","league_name").trim();
        String status = normalizedMatchStatus(pickText(m,"status","statusText","state"));
        String statusLabel = listingStatusLabel(status, String.valueOf(m.opt("_listingMode")), false);
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView comp = tv(competition.isEmpty()?sportName(m.optString("sport",selectedSport)):competition, 10.5f, TEXT, true);
        top.addView(comp, new LinearLayout.LayoutParams(0,-2,1));
        if(!statusLabel.isEmpty()) top.addView(listingStatusBadge(statusLabel));
        card.addView(top);
        TextView title = tv(canonicalMatchTitle(m), 19, TEXT, true); title.setGravity(Gravity.CENTER); title.setPadding(0,dp(9),0,dp(6)); card.addView(title);
        LinearLayout teams = new LinearLayout(this); teams.setGravity(Gravity.CENTER_VERTICAL);
        teams.addView(matchTeam(team(m,true), true), new LinearLayout.LayoutParams(0,-2,1));
        TextView vs = tv("VS", 10, MUTED, true); vs.setGravity(Gravity.CENTER); vs.setPadding(dp(10),dp(7),dp(10),dp(7)); vs.setBackground(round(Color.argb(darkTheme()?70:35,255,255,255),18));
        teams.addView(vs, new LinearLayout.LayoutParams(dp(58),-2));
        teams.addView(matchTeam(team(m,false), false), new LinearLayout.LayoutParams(0,-2,1));
        card.addView(teams);
        String rawTime=pickText(m,"time","startsAt","starts_at","start_time","startTime");
        String schedule=formatMatchSchedule(rawTime);
        if(!schedule.isEmpty()){ TextView st=tv(schedule,9.5f,MUTED,false); st.setGravity(Gravity.CENTER); st.setPadding(0,dp(7),0,0); card.addView(st); }
        card.setOnClickListener(v->{selectedMatch=m;showMatchDetail(true);});
        return card;
    }

    private void loadHomeDashboard(LinearLayout heroHost, LinearLayout live, LinearLayout upcoming, LinearLayout recent) {
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")||!remoteDataEnabled)return;
        network.execute(() -> {
            ArrayList<JSONObject> liveItems=new ArrayList<>(), upcomingItems=new ArrayList<>(), recentItems=new ArrayList<>();
            String[] sports={"cricket","football","tennis","basketball"};
            for(String sport:sports){
                try{ JSONObject r=new JSONObject(getUrl(BACKEND_URL+"/sports/"+sport+"/live")); JSONArray a=r.optJSONArray("matches"); if(a!=null) for(int i=0;i<a.length();i++){JSONObject m=a.optJSONObject(i); if(m!=null){String st=normalizedMatchStatus(pickText(m,"status","statusText","state","match_status","matchStatus"));if(!("FINISHED".equals(st)||"UPCOMING".equals(st)||"POSTPONED".equals(st)||"CANCELLED".equals(st)||"ABANDONED".equals(st))){m.put("sport",sport);m.put("_listingMode","live");liveItems.add(m);}}} }catch(Exception ignored){}
                try{ JSONObject r=new JSONObject(getUrl(BACKEND_URL+"/sports/"+sport+"/upcoming")); JSONArray a=r.optJSONArray("matches"); if(a!=null) for(int i=0;i<a.length();i++){JSONObject m=a.optJSONObject(i); if(m!=null){String st=normalizedMatchStatus(pickText(m,"status","statusText","state","match_status","matchStatus"));if(!("LIVE".equals(st)||"FINISHED".equals(st)||"CANCELLED".equals(st)||"ABANDONED".equals(st))){m.put("sport",sport);m.put("_listingMode","upcoming");upcomingItems.add(m);}}} }catch(Exception ignored){}
                if("cricket".equals(sport)) try{ JSONObject r=new JSONObject(getUrl(BACKEND_URL+"/cricket/results")); JSONArray a=r.optJSONArray("matches"); if(a!=null) for(int i=0;i<a.length()&&recentItems.size()<6;i++){JSONObject m=a.optJSONObject(i); if(m!=null){m.put("sport","cricket");m.put("_listingMode","results");recentItems.add(m);}} }catch(Exception ignored){}
            }
            liveItems.sort((a,b)->Double.compare(b.optDouble("popularityScore",0),a.optDouble("popularityScore",0)));
            upcomingItems.sort((a,b)->Double.compare(b.optDouble("popularityScore",0),a.optDouble("popularityScore",0)));
            runOnUiThread(() -> {
                heroHost.removeAllViews();
                if(!liveItems.isEmpty()) heroHost.addView(premiumMatchHero(liveItems.get(0)));
                else if(!upcomingItems.isEmpty()) heroHost.addView(premiumMatchHero(upcomingItems.get(0)));
                else heroHost.addView(emptyStateCard("No featured match", "No verified live or upcoming match is available right now."));
                live.removeAllViews(); int lc=Math.min(3,liveItems.size()); for(int i=0;i<lc;i++) live.addView(sportsListCard(liveItems.get(i),true),marginBottomParams(8)); if(lc==0) live.addView(emptyStateCard("No live matches","No verified match is currently live."));
                upcoming.removeAllViews(); int uc=Math.min(5,upcomingItems.size()); for(int i=0;i<uc;i++) upcoming.addView(sportsListCard(upcomingItems.get(i),false),marginBottomParams(8)); if(uc==0) upcoming.addView(emptyStateCard("No upcoming matches","No verified upcoming match is available."));
                recent.removeAllViews(); int rc=Math.min(3,recentItems.size()); for(int i=0;i<rc;i++) recent.addView(sportsListCard(recentItems.get(i),false),marginBottomParams(8)); if(rc==0) recent.addView(emptyStateCard("No recent results","No verified recent result is available."));
            });
        });
    }

    private void loadHomeLive(LinearLayout container){
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE") || !remoteDataEnabled) return;
        network.execute(()->{
            ArrayList<JSONObject> all=new ArrayList<>();
            for(String sport:new String[]{"cricket","football","tennis","basketball"}){
                try{JSONObject r=new JSONObject(getUrl(BACKEND_URL+"/sports/"+sport+"/live"));JSONArray a=r.optJSONArray("matches");if(a!=null)for(int i=0;i<a.length();i++){JSONObject m=a.optJSONObject(i);if(m!=null){try{m.put("sport",sport);m.put("_listingMode","live");}catch(Exception ignored){}all.add(m);}}}catch(Exception ignored){}
            }
            runOnUiThread(()->{container.removeAllViews(); for(JSONObject m:all)container.addView(sportsListCard(m,true),marginBottomParams(8));});
        });
    }

    private void loadSportsHome(LinearLayout list){
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE") || !remoteDataEnabled) return;
        network.execute(()->{
            ArrayList<JSONObject> all=new ArrayList<>();
            String[] sports={"cricket","football","tennis","basketball"};
            for(String sport:sports){
                try{JSONObject r=new JSONObject(getUrl(BACKEND_URL+"/sports/"+sport+"/live"));JSONArray a=r.optJSONArray("matches");if(a!=null)for(int i=0;i<a.length();i++){JSONObject m=a.optJSONObject(i);if(m!=null){m.put("sport",sport);m.put("_listingMode","live");all.add(m);}}}catch(Exception ignored){}
            }
            all.sort((a,b)->Double.compare(b.optDouble("popularityScore",0),a.optDouble("popularityScore",0)));
            runOnUiThread(()->{list.removeAllViews();int n=Math.min(6,all.size());for(int i=0;i<n;i++)list.addView(sportsListCard(all.get(i),true),marginBottomParams(8));if(n==0)list.addView(emptyStateCard("No live matches","No verified live match is currently available."));});
        });
    }

    private void showSportsHome(boolean push) {
        stopMatchDetailAutoRefresh();
        entertainmentContext = false;
        stopSportsAutoRefresh();
        if (push) push("sportsHome");
        screen = "sportsHome";
        clearContent();
        LinearLayout page = page();
        page.addView(selectedSectionBar("Sports", false));
        page.addView(sportsProviderAttribution());
        LinearLayout grid = new LinearLayout(this);
        grid.setPadding(dp(12), 0, dp(12), dp(10));
        String[] names={"Cricket","Football","Tennis","Basketball"}; String[] icons={"🏏","⚽","🎾","🏀"};
        for(int i=0;i<names.length;i++){final String s=names[i].toLowerCase(Locale.US);LinearLayout c=featureTile(icons[i],names[i],i==0?CYAN:BLUE);c.setOnClickListener(v->showSports(s,true));grid.addView(c,featureTileParams());}
        page.addView(grid);
        LinearLayout homeTabs = new LinearLayout(this); homeTabs.setPadding(dp(12),dp(2),dp(12),dp(8));
        String[] homeModes={"LIVE","UPCOMING","RESULTS"};
        for(String hm:homeModes){ TextView b=tab(hm, "LIVE".equals(hm)); b.setOnClickListener(v->{ for(int i=0;i<homeTabs.getChildCount();i++){TextView t=(TextView)homeTabs.getChildAt(i);boolean on=t.getText().toString().equalsIgnoreCase(hm);t.setTextColor(on?TEXT:MUTED);t.setBackground(round(on?BLUE:CARD,18)); } }); LinearLayout.LayoutParams lp=weighted();lp.height=dp(46);lp.setMargins(dp(4),0,dp(4),0);homeTabs.addView(b,lp); }
        page.addView(homeTabs);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(12),dp(2),dp(12),dp(18));
        page.addView(sectionLabel("Live & Upcoming","Priority-ranked matches across sports"));
        page.addView(list);
        activeSportsPage=page; activeSportsHome=true;
        addSportsRefreshScroll(page,()->loadSportsHome(list));
        scheduleSportsAutoRefresh(); loadSportsHome(list);
    }

    private void showSports(String sport, boolean push) {
        showSports(sport, push, "live");
    }

    private void showSports(String sport, boolean push, String initialMode) {
        stopMatchDetailAutoRefresh();
        entertainmentContext = false;
        stopSportsAutoRefresh();
        if (push) push("sport:" + sport);
        screen = "sport";
        selectedSport = sport;
        matchMode = initialMode == null ? "live" : initialMode.toLowerCase(Locale.US);
        remoteMatches = null;
        remoteMatchDetail = null;
        clearContent();
        LinearLayout page = page();
        page.addView(selectedSectionBar(sportName(sport), false));
        page.addView(sportsProviderAttribution());
        LinearLayout featuredHost = new LinearLayout(this); featuredHost.setOrientation(LinearLayout.VERTICAL); featuredHost.setPadding(dp(14),dp(4),dp(14),dp(7));
        if ("cricket".equalsIgnoreCase(sport)) { featuredHost.addView(statCard("Featured Cricket", "Loading…", "Provider data only")); page.addView(featuredHost);
            HorizontalScrollView navScroll=new HorizontalScrollView(this); navScroll.setHorizontalScrollBarEnabled(false); LinearLayout nav=new LinearLayout(this); nav.setPadding(dp(12),dp(2),dp(12),dp(7));
            String[] navItems={"Overview","Series","Teams","Players","Venues"}; for(String item:navItems){TextView nb=tab(item,"Overview".equals(item)); nb.setOnClickListener(v->{if("Overview".equals(item)){showSports("cricket",false);}else showSportsDirectory("cricket",item,true);}); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(dp(item.equals("Overview")?92:82),dp(42));np.setMargins(dp(4),0,dp(4),0);nav.addView(nb,np);} navScroll.addView(nav); page.addView(navScroll); }
        LinearLayout quick = new LinearLayout(this); quick.setPadding(dp(12),dp(2),dp(12),dp(8));
        String[] labels={"Live Matches","Upcoming","Results"}; String[] icons={"●","▣","🏆"};
        for(int i=0;i<labels.length;i++){final String mode=new String[]{"live","upcoming","results"}[i];LinearLayout c=featureTile(icons[i],labels[i],i==0?BLUE:(i==1?CYAN:PURPLE));c.setOnClickListener(v->{matchMode=mode;remoteMatches=null;renderSportList(page,sport);loadSportsFromBackend(sport,mode,page);});quick.addView(c,weighted());}
        page.addView(quick);
        page.addView(modeTabs(page,sport,new String[]{"LIVE","UPCOMING","RESULTS"}));
        renderSportList(page,sport);
        activeSportsPage=page; activeSportsHome=false;
        addSportsRefreshScroll(page,()->loadSportsFromBackend(selectedSport,matchMode,page));
        scheduleSportsAutoRefresh(); loadSportsFromBackend(sport,matchMode,page);
        if ("cricket".equalsIgnoreCase(sport)) loadSportFeatured(featuredHost);
    }

    private void loadSportFeatured(LinearLayout host) {
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")||!remoteDataEnabled)return;
        network.execute(()->{ try { JSONObject r=new JSONObject(getUrl(BACKEND_URL+"/cricket/live")); JSONArray a=r.optJSONArray("matches"); JSONObject m=(a!=null&&a.length()>0)?a.optJSONObject(0):null; if(m==null){r=new JSONObject(getUrl(BACKEND_URL+"/cricket/upcoming"));a=r.optJSONArray("matches");m=(a!=null&&a.length()>0)?a.optJSONObject(0):null;} final JSONObject fm=m; runOnUiThread(()->{host.removeAllViews();if(fm!=null)host.addView(premiumMatchHero(fm));else host.addView(emptyStateCard("No featured cricket match","No verified live or upcoming cricket match is available."));}); } catch(Exception e){runOnUiThread(()->{host.removeAllViews();host.addView(emptyStateCard("Featured cricket unavailable","No verified provider data is available."));});} });
    }

    private String normalizedMatchStatus(String raw) {
        if (raw == null) return "";
        String s = raw.trim();
        if (s.isEmpty()) return "";
        String k = s.toLowerCase(Locale.US).replace("_", " ").replace("-", " ").replaceAll("\\s+", " ").trim();
        if (k.equals("live") || k.equals("live now") || k.equals("in play") || k.equals("inplay") || k.equals("playing") || k.equals("ongoing")
                || k.equals("started") || k.equals("1st innings") || k.equals("2nd innings") || k.equals("innings break")) return "LIVE";
        if (k.equals("upcoming") || k.equals("scheduled") || k.equals("not started") || k.equals("fixture") || k.equals("pre match")) return "UPCOMING";
        if (k.equals("finished") || k.equals("complete") || k.equals("completed") || k.equals("ended") || k.equals("end of day")) return "FINISHED";
        if (k.equals("postponed")) return "POSTPONED";
        if (k.equals("cancelled") || k.equals("canceled")) return "CANCELLED";
        if (k.equals("abandoned")) return "ABANDONED";
        // Provider-specific/unknown diagnostic states are never shown as user-facing match status.
        return "";
    }

    private void renderSportList(LinearLayout page, String sport) {
        while(page.getChildCount()>4) page.removeViewAt(4);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), dp(2), dp(12), dp(18));
        if (remoteMatches != null && remoteMatches.length() > 0) {
            for (int i = 0; i < remoteMatches.length(); i++) {
                JSONObject m = remoteMatches.optJSONObject(i);
                if (m != null) list.addView(sportsListCard(m, "live".equalsIgnoreCase(matchMode) && i == 0));
            }
        }
        page.addView(list);
        page.addView(sectionLabel("More","Explore the full "+sportName(sport)+" section"));
        page.addView(sportsMoreLinks(sport));
    }

    private LinearLayout sportsMoreLinks(String sport) {
        LinearLayout wrap=new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        String[] items;
        if("cricket".equals(sport)) items=new String[]{"Series","Teams","Players","Venues","Highlights"};
        else if("football".equals(sport)) items=new String[]{"Competitions","Teams","Players","Venues","H2H"};
        else if("basketball".equals(sport)) items=new String[]{"Leagues","Teams","Players","Standings","H2H"};
        else items=new String[]{"Tournaments","Players","Rankings","Draws","H2H"};
        for(String item:items){
            LinearLayout row=menuAction("•",item,"Open "+item.toLowerCase(Locale.US)+" page",v->showSportsDirectory(sport,item,true));
            wrap.addView(row);
        }
        return wrap;
    }

    private void showSportsDirectory(String sport,String section,boolean push) {
        stopMatchDetailAutoRefresh();
        entertainmentContext = false;
        if(push) push("directory:"+sport+":"+section);
        screen="directory";
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar(section,false));
        page.addView(sportsProviderAttribution());
        page.addView(sectionLabel(section,sportName(sport)+" • ONE TV"));
        addScroll(page);
    }

    private void loadSportsFromBackend(String sport, String mode, LinearLayout page) {
        if (BACKEND_URL == null || BACKEND_URL.contains("REPLACE") || !remoteDataEnabled) return;
        network.execute(() -> {
            try {
                String path = "cricket".equals(sport) ? "/cricket/" + mode : "/sports/" + sport + "/" + mode;
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + path));
                JSONArray fetchedMatches = root.optJSONArray("matches");
                if (fetchedMatches == null) fetchedMatches = new JSONArray();
                final JSONArray resultMatches = fetchedMatches;
                runOnUiThread(() -> {
                    if (!"sport".equals(screen) || !selectedSport.equals(sport) || !matchMode.equalsIgnoreCase(mode)) return;
                    for (int i = 0; i < resultMatches.length(); i++) {
                        JSONObject item = resultMatches.optJSONObject(i);
                        if (item != null) {
                            try {
                                if (!item.has("sport")) item.put("sport", sport);
                                item.put("_listingMode", mode);
                            } catch (Exception ignored) {}
                        }
                    }
                    remoteMatches = resultMatches;
                    renderSportList(page, sport);
                });
            } catch(Exception ignored) {}
        });
    }

    private String formatMatchSchedule(String raw){
        if(raw==null || raw.trim().isEmpty()) return "";
        String value=raw.trim();
        String[] patterns={"yyyy-MM-dd'T'HH:mm:ss.SSSX","yyyy-MM-dd'T'HH:mm:ssX","yyyy-MM-dd'T'HH:mmX","yyyy-MM-dd HH:mm:ss","yyyy-MM-dd HH:mm"};
        for(String pattern:patterns){
            try{
                java.text.SimpleDateFormat in=new java.text.SimpleDateFormat(pattern,Locale.US);
                in.setLenient(false);
                java.util.Date d=in.parse(value);
                if(d==null) continue;
                java.text.SimpleDateFormat out=new java.text.SimpleDateFormat("EEE, d MMM • h:mm a",Locale.US);
                out.setTimeZone(java.util.TimeZone.getDefault());
                return out.format(d);
            }catch(Exception ignored){}
        }
        return value.replace('T',' ');
    }

    private String canonicalMatchTitle(JSONObject m){
        JSONObject h=team(m,true), a=team(m,false);
        String hn=pickText(h,"name","team_name","short_name").trim();
        String an=pickText(a,"name","team_name","short_name").trim();
        if(!hn.isEmpty() && !an.isEmpty() && !"TBD".equalsIgnoreCase(hn) && !"TBD".equalsIgnoreCase(an)) return hn+" vs "+an;
        String raw=pickText(m,"title","name").trim();
        return raw.isEmpty()?"Match":raw;
    }

    private View sportsListCard(JSONObject m, boolean live) {
        String sport = m.optString("sport", selectedSport).toLowerCase(Locale.US);
        if ("cricket".equals(sport)) {
            return cricketListCard(m, live);
        }

        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14),dp(12),dp(14),dp(12));
        card.setBackground(round(CARD,18));
        card.setElevation(dp(2));

        String competition=m.optString("competition","").trim();
        LinearLayout meta=new LinearLayout(this);
        meta.setGravity(Gravity.CENTER_VERTICAL);
        TextView comp=tv(competition.isEmpty()?sportName(sport):competition,10,MUTED,true);
        comp.setSingleLine(true); comp.setEllipsize(android.text.TextUtils.TruncateAt.END);
        meta.addView(comp,new LinearLayout.LayoutParams(0,-2,1));
        String status=normalizedMatchStatus(pickText(m,"status","statusText","state"));
        String listingMode=String.valueOf(m.opt("_listingMode")).toLowerCase(Locale.US);
        boolean resultsListing="results".equals(listingMode);
        String statusLabel=listingStatusLabel(status, listingMode, false);
        if(!resultsListing && !statusLabel.isEmpty()){
            meta.addView(listingStatusBadge(statusLabel));
        }
        TextView fav = tv(isFavorite(m) ? "★" : "☆", 21, isFavorite(m) ? Color.rgb(255,196,55) : MUTED, true);
        fav.setGravity(Gravity.CENTER);
        fav.setContentDescription(isFavorite(m) ? "Remove from favorites" : "Add to favorites");
        fav.setOnClickListener(v -> {
            toggleFavorite(m);
            boolean now = isFavorite(m);
            fav.setText(now ? "★" : "☆");
            fav.setTextColor(now ? Color.rgb(255,196,55) : MUTED);
        });
        meta.addView(fav, new LinearLayout.LayoutParams(dp(38), dp(36)));
        card.addView(meta);

        String title=canonicalMatchTitle(m);
        TextView titleView=tv(title,14,TEXT,true);
        titleView.setSingleLine(true); titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleView.setPadding(0,dp(5),0,0);
        card.addView(titleView);

        String rawTime=pickText(m,"time","startsAt","starts_at","start_time","startTime");
        String schedule=formatMatchSchedule(rawTime);
        if(!schedule.isEmpty()){
            String scheduleLabel="LIVE".equals(status)?remoteLiveStatusLabel+" • "+schedule:schedule;
            TextView tt=tv(scheduleLabel,9,MUTED,false);
            tt.setPadding(0,dp(2),0,0);
            card.addView(tt);
        }

        LinearLayout teams=new LinearLayout(this);
        teams.setGravity(Gravity.CENTER_VERTICAL);
        teams.setPadding(0,dp(9),0,dp(6));
        JSONObject home=team(m,true), away=team(m,false);
        teams.addView(matchTeam(home,true),weighted());
        LinearLayout vsWrap=new LinearLayout(this); vsWrap.setGravity(Gravity.CENTER); vsWrap.setOrientation(LinearLayout.VERTICAL);
        TextView vs=tv("VS",10,MUTED,true); vs.setGravity(Gravity.CENTER); vs.setPadding(dp(8),dp(7),dp(8),dp(7)); vs.setBackground(round(CARD_2,16));
        vsWrap.addView(vs);
        teams.addView(vsWrap,new LinearLayout.LayoutParams(dp(58),-2));
        teams.addView(matchTeam(away,false),weighted());
        card.addView(teams);

        String venue=m.optString("venue","").trim();
        if(!venue.isEmpty()){
            TextView v=tv("⌖  "+venue,9,MUTED,false); v.setSingleLine(true); v.setEllipsize(android.text.TextUtils.TruncateAt.END); card.addView(v);
        }
        card.setOnClickListener(v->{selectedMatch=m;showMatchDetail(true);});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,dp(10)); card.setLayoutParams(p);
        return card;
    }

    private View cricketListCard(JSONObject m, boolean liveHint) {
        final String mode = matchMode == null ? "" : matchMode.toLowerCase(Locale.US);
        final String normalizedStatus = normalizedMatchStatus(pickText(m,"status","statusText","state"));
        final String listingMode = String.valueOf(m.opt("_listingMode")).toLowerCase(Locale.US);
        // The requested listing is authoritative. A provider may return a stale
        // status label, but it must never make an Upcoming/Results card render as Live.
        final boolean hasListingMode = !listingMode.isEmpty();
        final boolean isLive = hasListingMode
                ? "live".equals(listingMode)
                : ("live".equals(mode) || "LIVE".equalsIgnoreCase(normalizedStatus));
        final boolean isFinished = hasListingMode
                ? ("results".equals(listingMode) || "finished".equals(listingMode))
                : ("results".equals(mode) || "FINISHED".equalsIgnoreCase(normalizedStatus)
                    || "COMPLETED".equalsIgnoreCase(normalizedStatus) || "FINAL".equalsIgnoreCase(normalizedStatus));

        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16),dp(13),dp(16),dp(13));
        card.setBackground(round(CARD,16));
        card.setElevation(dp(1));

        // Cricket title block:
        // 1) tournament logo/monogram + tournament title
        // 2) italic match title
        // 3) schedule/date
        String competition=pickText(m,"competition","league","tournament","competition_name","league_name","tournament_name").trim();
        String competitionLogo=pickText(m,
                "competitionLogo","competition_logo","competitionLogoUrl","competition_logo_url",
                "competition_image","competitionImage","competition_image_url","competitionImageUrl",
                "leagueLogo","league_logo","leagueLogoUrl","league_logo_url",
                "league_image","leagueImage","league_image_url","leagueImageUrl",
                "tournamentLogo","tournament_logo","tournamentLogoUrl","tournament_logo_url",
                "tournament_image","tournamentImage","tournament_image_url","tournamentImageUrl").trim();

        LinearLayout tournamentRow=new LinearLayout(this);
        tournamentRow.setOrientation(LinearLayout.HORIZONTAL);
        tournamentRow.setGravity(Gravity.CENTER_VERTICAL);

        ImageView tournamentIdentity=new ImageView(this);
        tournamentIdentity.setScaleType(ImageView.ScaleType.FIT_CENTER);
        tournamentIdentity.setPadding(0,0,0,0);
        String tournamentFallbackName=competition.isEmpty()?"Cricket":competition;
        tournamentIdentity.setImageDrawable(teamMonogramDrawable(tournamentFallbackName));
        if(!competitionLogo.isEmpty()) loadImage(tournamentIdentity,competitionLogo,26);
        tournamentRow.addView(tournamentIdentity,new LinearLayout.LayoutParams(dp(26),dp(26)));

        TextView tournamentTitle=tv(competition.isEmpty()?"Cricket":competition,15.5f,TEXT,true);
        tournamentTitle.setMaxLines(2);
        tournamentTitle.setEllipsize(null);
        tournamentTitle.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        tournamentTitle.setIncludeFontPadding(false);
        tournamentTitle.setPadding(dp(8),0,0,0);
        tournamentRow.addView(tournamentTitle,new LinearLayout.LayoutParams(0,-2,1));
        String cardListingMode=String.valueOf(m.opt("_listingMode")).toLowerCase(Locale.US);
        boolean resultsListing="results".equals(cardListingMode) || "finished".equals(cardListingMode);
        String statusLabel=listingStatusLabel(normalizedStatus, cardListingMode, resultsListing);
        if(!statusLabel.isEmpty()) tournamentRow.addView(listingStatusBadge(statusLabel));
        TextView fav = tv(isFavorite(m) ? "★" : "☆", 22, isFavorite(m) ? Color.rgb(255,196,55) : MUTED, true);
        fav.setGravity(Gravity.CENTER);
        fav.setContentDescription(isFavorite(m) ? "Remove from favorites" : "Add to favorites");
        fav.setOnClickListener(v -> {
            toggleFavorite(m);
            boolean now = isFavorite(m);
            fav.setText(now ? "★" : "☆");
            fav.setTextColor(now ? Color.rgb(255,196,55) : MUTED);
            fav.setContentDescription(now ? "Remove from favorites" : "Add to favorites");
        });
        tournamentRow.addView(fav, new LinearLayout.LayoutParams(dp(38), dp(36)));
        card.addView(tournamentRow);

        String round=pickText(m,"round","round_name","roundName","roundInfo","round_info","stage","stage_name","stageName",
                "match_number","matchNumber","match_no","matchNo","match_round","matchRound","fixture_round","fixtureRound",
                "game_round","gameRound","matchday","match_day","matchday_name","matchdayName","round_display","roundDisplay",
                "fixture_number","fixtureNumber","event_round","eventRound").trim();
        String format=pickText(m,"format","match_format","matchFormat","match_type","matchType","game_type","gameType","type",
                "competition_format","competitionFormat","format_name","formatName","match_kind","matchKind","game_format","gameFormat",
                "format_short","formatShort","format_display","formatDisplay","match_type_name","matchTypeName").trim();
        if(format.isEmpty()) format=extractCricketFormat(competition);
        String venue=pickText(m,"venue","venue_name","venueName","stadium","ground","ground_name","groundName","venue_title","venueTitle",
                "location","location_name","locationName","venue_display","venueDisplay","stadium_name","stadiumName").trim();
        String providerMatchTitle=pickText(m,"match_title","matchTitle","match_name","matchName","fixture_title","fixtureTitle",
                "match_title_text","matchTitleText","fixture_name","fixtureName").trim();
        String matchTitle=cricketMatchTitle(round,format,venue,providerMatchTitle);
        if(!matchTitle.isEmpty()){
            TextView mt=tv(matchTitle,11.5f,TEXT,false);
            mt.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.ITALIC));
            mt.setMaxLines(2);
            mt.setEllipsize(null);
            mt.setIncludeFontPadding(false);
            mt.setPadding(0,dp(5),0,0);
            card.addView(mt);
        }

        String rawTime=pickText(m,"time","startsAt","starts_at","start_time","startTime","datetime","date").trim();
        String schedule=formatMatchSchedule(rawTime);
        if(!schedule.isEmpty()){
            TextView st=tv(schedule,11.5f,MUTED,false);
            st.setIncludeFontPadding(false);
            st.setPadding(0,dp(3),0,dp(9));
            card.addView(st);
        }

        View divider=new View(this);
        divider.setBackgroundColor(Color.argb(darkTheme()?38:28,255,255,255));
        card.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));

        // Team identities are always horizontal: logo + left-aligned team name.
        // Live/results add score and overs beneath the team identity.
        LinearLayout matchup=new LinearLayout(this);
        matchup.setGravity(Gravity.CENTER_VERTICAL);
        matchup.setPadding(0,dp(12),0,dp(8));

        JSONObject home=team(m,true), away=team(m,false);
        matchup.addView(cricketTeamColumn(home, isLive || isFinished, true),new LinearLayout.LayoutParams(0,-2,1));

        LinearLayout centre=new LinearLayout(this);
        centre.setOrientation(LinearLayout.VERTICAL);
        centre.setGravity(Gravity.CENTER);
        String centreText="VS";
        TextView marker=tv(centreText, 10.5f, MUTED, true);
        marker.setGravity(Gravity.CENTER);
        marker.setPadding(dp(8),dp(6),dp(8),dp(6));
        marker.setBackground(round(CARD_2,14));
        centre.addView(marker);
        matchup.addView(centre,new LinearLayout.LayoutParams(dp(52),-2));
        matchup.addView(cricketTeamColumn(away, isLive || isFinished, false),new LinearLayout.LayoutParams(0,-2,1));
        card.addView(matchup);

        String result=pickText(m,"result","result_text","resultText","outcome","winner_text").trim();
        if(isFinished && !result.isEmpty() && !isGenericCricketStatus(result)){
            TextView r=tv(result,11.5f,Color.rgb(224,92,92),true);
            r.setGravity(Gravity.CENTER);
            r.setIncludeFontPadding(false);
            r.setPadding(0,dp(7),0,dp(2));
            View d2=new View(this);
            d2.setBackgroundColor(Color.argb(darkTheme()?38:28,255,255,255));
            card.addView(d2,new LinearLayout.LayoutParams(-1,dp(1)));
            card.addView(r);
        } else if(isLive){
            String liveInfo=pickText(m,"live_info","liveInfo","result","result_text","resultText","statusText").trim();
            if(!liveInfo.isEmpty() && !isGenericCricketStatus(liveInfo) && !"LIVE".equalsIgnoreCase(liveInfo)){
                TextView li=tv(liveInfo,10.5f,MUTED,false);
                li.setGravity(Gravity.CENTER);
                li.setIncludeFontPadding(false);
                li.setPadding(0,dp(6),0,0);
                card.addView(li);
            }
        }

        card.setOnClickListener(v->{selectedMatch=m;showMatchDetail(true);});
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);
        cp.setMargins(0,0,0,dp(12));
        card.setLayoutParams(cp);
        return card;
    }

    private String extractCricketFormat(String competition){
        String c=competition==null?"":competition.trim();
        if(c.isEmpty()) return "";
        String u=c.toUpperCase(Locale.US);
        if(u.matches(".*\\bT20I\\b.*")) return "T20I";
        if(u.matches(".*\\bT20\\b.*")) return "T20";
        if(u.matches(".*\\bODI\\b.*")) return "ODI";
        if(u.matches(".*\\bTEST\\b.*")) return "Test";
        if(u.matches(".*\\bT10\\b.*")) return "T10";
        if(u.matches(".*\\bTHE HUNDRED\\b.*") || u.matches(".*\\bHUNDRED\\b.*")) return "The Hundred";
        return "";
    }

    private String cricketMatchTitle(String round, String format, String venue, String providerTitle){
        String r=round==null?"":round.trim();
        String f=format==null?"":format.trim();
        String v=venue==null?"":venue.trim();
        String p=providerTitle==null?"":providerTitle.trim();

        // Prefer explicit round/stage data. If the provider gives a round such as
        // "5th" and a format such as "T20I", present them as "5th T20I".
        String lead=r;
        if(!lead.isEmpty() && !f.isEmpty() && !lead.toLowerCase(Locale.US).contains(f.toLowerCase(Locale.US))){
            lead=lead+" "+f;
        } else if(lead.isEmpty()){
            lead=f;
        }

        // Some providers expose the complete match-title phrase instead of round/format.
        // Use it only when structured round/format data is unavailable.
        if(lead.isEmpty() && !p.isEmpty()){
            // Use an explicit provider match title only when no structured
            // round/format field is available.
            lead=p;
        }

        if(lead.isEmpty()) return v;
        if(v.isEmpty()) return lead;
        if(lead.toLowerCase(Locale.US).contains(v.toLowerCase(Locale.US))) return lead;
        return lead+" - "+v;
    }


    private String cricketDisplayScore(JSONObject t){
        String score=pickText(t,"score_text","scoreText","display_score","displayScore","score","runs","points","total").trim();
        String wickets=pickText(t,"wickets","wicket").trim();

        if(score.isEmpty()){
            String runs=pickText(t,"runs","run","total","points").trim();
            if(!runs.isEmpty()) score=runs;
        }
        if(!score.isEmpty() && !wickets.isEmpty()
                && !score.contains("-") && !score.contains("/")
                && !score.matches(".*\\b\\d+\\s*w\\b.*")){
            score=score+"-"+wickets;
        }

        if(score.matches(".*\\([^)]*\\).*")) {
            int idx=score.indexOf('(');
            if(idx>0) score=score.substring(0,idx).trim();
        }
        return score;
    }

    private String cricketScheduleLine(String round, String schedule){
        String r=round==null?"":round.trim();
        String s=schedule==null?"":schedule.trim();
        if(!r.isEmpty() && !s.isEmpty()) return r+" • "+s;
        if(!r.isEmpty()) return r;
        return s;
    }

    private View cricketTeamColumn(JSONObject t, boolean showScore, boolean left) {
        LinearLayout col=new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(left ? (Gravity.LEFT|Gravity.CENTER_VERTICAL) : (Gravity.RIGHT|Gravity.CENTER_VERTICAL));
        col.setPadding(0,0,0,0);

        String name=pickText(t,"name","team_name","short_name","shortName","teamName").trim();
        TextView n=tv(name,14.5f,TEXT,true);
        n.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        n.setMaxLines(3);
        n.setEllipsize(null);
        n.setIncludeFontPadding(false);
        if(android.os.Build.VERSION.SDK_INT>=23){
            n.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_BALANCED);
            n.setHyphenationFrequency(android.text.Layout.HYPHENATION_FREQUENCY_NONE);
        }
        n.setPadding(0,0,0,0);

        // Symmetric team identity geometry. The text block is anchored to the
        // logo on both sides, with the same 7dp visible spacing. It never
        // expands into the centre and never becomes center-aligned on the right.
        int screenWidthPx=getResources().getDisplayMetrics().widthPixels;
        int availableColumnPx=Math.max(dp(72),(screenWidthPx-dp(32)-dp(52))/2);
        int maxNamePx=Math.max(dp(72),availableColumnPx-dp(47));
        n.setMaxWidth(Math.min(dp(220),maxNamePx));

        ImageView identity=identityView(t,40);
        LinearLayout.LayoutParams logoLp=new LinearLayout.LayoutParams(dp(40),dp(40));
        logoLp.gravity=Gravity.CENTER_VERTICAL;

        LinearLayout identityRow=new LinearLayout(this);
        identityRow.setOrientation(LinearLayout.HORIZONTAL);
        identityRow.setGravity(left ? (Gravity.LEFT|Gravity.CENTER_VERTICAL)
                                    : (Gravity.RIGHT|Gravity.CENTER_VERTICAL));
        identityRow.setLayoutParams(new LinearLayout.LayoutParams(-1,-2));

        if(left){
            identityRow.addView(identity,logoLp);
            LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-2,-2);
            np.setMargins(dp(7),0,0,0);
            identityRow.addView(n,np);
        } else {
            LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-2,-2);
            np.setMargins(0,0,dp(7),0);
            identityRow.addView(n,np);
            identityRow.addView(identity,logoLp);
        }
        col.addView(identityRow);

        if(showScore){
            String score=cricketDisplayScore(t);
            String overs=pickText(t,"overs","over","overs_text","oversText","over_text","overText").trim();
            if(!score.isEmpty()){
                TextView sc=tv(score,18,TEXT,true);
                sc.setGravity(Gravity.LEFT);
                sc.setIncludeFontPadding(false);
                sc.setPadding(0,dp(3),0,0);
                col.addView(sc,new LinearLayout.LayoutParams(-1,-2));
            }
            if(!overs.isEmpty()){
                String ov=overs.toLowerCase(Locale.US).contains("over") ? overs : overs+" Over";
                TextView ot=tv(ov,10.5f,MUTED,false);
                ot.setGravity(Gravity.LEFT);
                ot.setIncludeFontPadding(false);
                ot.setPadding(0,dp(1),0,0);
                col.addView(ot,new LinearLayout.LayoutParams(-1,-2));
            }
        }
        return col;
    }

    private boolean isGenericCricketStatus(String value){
        String s=value==null?"":value.trim().toLowerCase(Locale.US).replace("_"," ");
        return s.isEmpty() || s.equals("finished") || s.equals("complete") || s.equals("completed") || s.equals("ended") || s.equals("final") || s.equals("live") || s.equals("in play") || s.equals("inplay") || s.equals("upcoming") || s.equals("scheduled");
    }

    private View matchTeam(JSONObject t, boolean left) {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(0,dp(2),0,dp(2));

        String name=pickText(t,"name","team_name","short_name");
        ImageView identity=identityView(t,40);

        TextView n=tv(name,13,TEXT,true);
        n.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        n.setMaxLines(3);
        n.setEllipsize(null);
        n.setIncludeFontPadding(false);
        n.setPadding(dp(7),0,dp(7),0);

        if(left){
            box.addView(identity,new LinearLayout.LayoutParams(dp(40),dp(40)));
            box.addView(n,new LinearLayout.LayoutParams(0,-2,1));
        } else {
            box.addView(n,new LinearLayout.LayoutParams(0,-2,1));
            box.addView(identity,new LinearLayout.LayoutParams(dp(40),dp(40)));
        }
        return box;
    }

    private void showMatchDetail(boolean push) {
        entertainmentContext = false;
        if (push) push("match");
        screen="match";
        clearContent();
        if(selectedMatch==null){ showSports(selectedSport, false); return; }
        JSONObject m=selectedMatch;
        String sport=m.optString("sport",selectedSport).toLowerCase(Locale.US);

        if("cricket".equals(sport)) detailTab="OVERVIEW";
        else detailTab="OVERVIEW";

        LinearLayout shell=new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(BG);

        shell.addView(sportsProviderAttribution());
        matchHeroHost=new FrameLayout(this);
        matchHeroHost.addView(matchHero(m),new FrameLayout.LayoutParams(-1,-2));
        shell.addView(matchHeroHost,new LinearLayout.LayoutParams(-1,-2));

        final FrameLayout bodyHost=new FrameLayout(this);
        activeMatchBodyHost=bodyHost;
        String[] labels;
        if("cricket".equals(sport)){
            labels=new String[]{"Overview","Live","Scorecard","Squads","Overs","Commentary","Highlights","Series"};
        } else if("football".equals(sport)){
            labels=new String[]{"Overview","Live","Stats","Lineups","Timeline","Standings","H2H"};
        } else if("basketball".equals(sport)){
            labels=new String[]{"Overview","Live","Box Score","Play-by-play","Lineups","Team Stats","Standings"};
        } else {
            labels=new String[]{"Overview","Live","Scoreboard","Point-by-point","Stats","H2H","Draw"};
        }

        HorizontalScrollView tabScroll=new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabScroll.setFillViewport(false);
        tabScroll.setBackgroundColor(darkTheme() ? Color.rgb(7,14,23) : PANEL);
        LinearLayout tabs=new LinearLayout(this);
        tabs.setPadding(dp(10),dp(7),dp(10),dp(7));

        for(String label:labels){
            TextView b=tab(label,label.equalsIgnoreCase(detailTab));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(112),dp(44));
            lp.setMargins(dp(5),0,dp(5),0);
            b.setOnClickListener(v->{
                detailTab=label.toUpperCase(Locale.US);
                for(int i=0;i<tabs.getChildCount();i++){
                    View child=tabs.getChildAt(i);
                    if(child instanceof TextView){
                        TextView t=(TextView)child;
                        boolean active=t.getText().toString().equalsIgnoreCase(detailTab);
                        t.setTextColor(active?TEXT:MUTED);
                        t.setBackground(round(active?BLUE:CARD,18));
                    }
                }
                renderMatchBody(bodyHost,m,sport);
            });
            tabs.addView(b,lp);
        }
        tabScroll.addView(tabs,new HorizontalScrollView.LayoutParams(-2,-2));
        shell.addView(tabScroll,new LinearLayout.LayoutParams(-1,dp(58)));

        bodyHost.setBackgroundColor(BG);
        shell.addView(bodyHost,new LinearLayout.LayoutParams(-1,0,1));
        SwipeRefreshLayout matchSwipe = new SwipeRefreshLayout(this);
        matchSwipe.setColorSchemeColors(BLUE);
        matchSwipe.setOnRefreshListener(() -> {
            refreshCurrentNonEntertainmentScreen();
            handler.postDelayed(() -> matchSwipe.setRefreshing(false), 700);
        });
        matchSwipe.addView(shell, new SwipeRefreshLayout.LayoutParams(-1,-1));
        contentHost.addView(matchSwipe,new FrameLayout.LayoutParams(-1,-1));

        renderMatchBody(bodyHost,m,sport);
        loadMatchDetail(m, sport, bodyHost);
        scheduleMatchDetailAutoRefresh(bodyHost, sport);
    }

    private void loadMatchDetail(JSONObject summary, String sport, FrameLayout host) {
        if (!remoteDataEnabled) return;
        final String id = summary.optString("id", summary.optString("providerMatchId", ""));
        if(id.isEmpty()) return;
        network.execute(() -> {
            try {
                String encoded = Uri.encode(id);
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/sports/" + sport + "/match/" + encoded));
                JSONObject detail = root.optJSONObject("match");
                if(detail == null) return;
                detail.put("provider", root.optString("provider", "SportScore"));
                runOnUiThread(() -> {
                    if(!"match".equals(screen) || selectedMatch != summary) return;
                    try {
                        // Preserve list-level provider fields if the detail endpoint
                        // omits them. Never invent values.
                        JSONObject summaryHome = summary.optJSONObject("home");
                        JSONObject summaryAway = summary.optJSONObject("away");
                        JSONObject detailHome = detail.optJSONObject("home");
                        JSONObject detailAway = detail.optJSONObject("away");
                        if (detailHome == null && summaryHome != null) { detailHome = new JSONObject(); detail.put("home", detailHome); }
                        if (detailAway == null && summaryAway != null) { detailAway = new JSONObject(); detail.put("away", detailAway); }
                        mergeMissingTeamFields(detailHome, summaryHome);
                        mergeMissingTeamFields(detailAway, summaryAway);
                        for (String key : new String[]{"competition","competitionLogo","round","format","matchTitle","venue","time","startsAt","result"}) {
                            if (pickText(detail,key).isEmpty()) {
                                String value = pickText(summary,key);
                                if (!value.isEmpty()) detail.put(key,value);
                            }
                        }
                        if (pickText(detail,"status","statusText","state").isEmpty()) {
                            String summaryStatus = pickText(summary,"status","statusText","state");
                            if (!summaryStatus.isEmpty()) detail.put("status", summaryStatus);
                        }
                        selectedMatch = detail;
                    } catch(Exception ignored) {}
                    if (matchHeroHost != null) {
                        matchHeroHost.removeAllViews();
                        matchHeroHost.addView(matchHero(detail),new FrameLayout.LayoutParams(-1,-2));
                    }
                    // The live scoring board is rendered inside the match hero,
                    // so refreshing the provider detail updates it in place with the hero.
                    renderMatchBody(host, detail, sport);
                    scheduleMatchDetailAutoRefresh(host, sport);
                });
            } catch(Exception ignored) {
                runOnUiThread(() -> {
                    if ("match".equals(screen)) scheduleMatchDetailAutoRefresh(host, sport);
                });
            }
        });
    }

    private String listingStatusLabel(String normalizedStatus, String listingMode, boolean resultsPage) {
        if ("results".equalsIgnoreCase(listingMode) || "finished".equalsIgnoreCase(listingMode) || resultsPage) {
            return remoteFinishedStatusLabel;
        }
        if ("live".equalsIgnoreCase(listingMode) || "LIVE".equalsIgnoreCase(normalizedStatus)) return remoteLiveStatusLabel;
        if ("upcoming".equalsIgnoreCase(listingMode) || "UPCOMING".equalsIgnoreCase(normalizedStatus)) return remoteUpcomingStatusLabel;
        if ("FINISHED".equalsIgnoreCase(normalizedStatus)) return remoteFinishedStatusLabel;
        if ("POSTPONED".equalsIgnoreCase(normalizedStatus)) return "Postponed";
        if ("CANCELLED".equalsIgnoreCase(normalizedStatus)) return "Cancelled";
        return "";
    }

    private TextView listingStatusBadge(String label) {
        boolean live = remoteLiveStatusLabel.equalsIgnoreCase(label);
        boolean upcoming = remoteUpcomingStatusLabel.equalsIgnoreCase(label);
        boolean finished = remoteFinishedStatusLabel.equalsIgnoreCase(label);
        // Live = green/white, Upcoming keeps the existing blue treatment,
        // Finished = red/white.
        int textColor = (live || finished) ? TEXT : (upcoming ? BLUE : MUTED);
        int background = live
                ? Color.argb(52, 0, 194, 142)
                : (finished ? Color.argb(52, 244, 63, 81) : Color.argb(34, 28, 126, 245));
        TextView badge=tv(label,9.5f,textColor,true);
        badge.setGravity(Gravity.CENTER);
        badge.setSingleLine(true);
        badge.setPadding(dp(11),dp(6),dp(11),dp(6));
        badge.setMinWidth(dp(live || finished ? 78 : 70));
        badge.setBackground(round(background,16));
        return badge;
    }

    private void scheduleMatchDetailAutoRefresh(FrameLayout host, String sport) {
        stopMatchDetailAutoRefresh();
        if (!"match".equals(screen) || host == null) return;
        activeMatchBodyHost = host;
        long delay = cricketDetailRefreshMs;
        String status = normalizedMatchStatus(pickText(selectedMatch,"status","statusText","state","match_status","matchStatus"));
        if ("FINISHED".equals(status) || "CANCELLED".equals(status) || "ABANDONED".equals(status)) return;
        handler.postDelayed(matchDetailRefreshTask, delay);
    }

    private void stopMatchDetailAutoRefresh() {
        handler.removeCallbacks(matchDetailRefreshTask);
    }

    private void mergeMissingTeamFields(JSONObject target, JSONObject source) {
        if (target == null || source == null) return;
        for (String key : new String[]{"name","slug","id","score","runs","wickets","overs","logo","flag","countryCode","country_code"}) {
            if (pickText(target,key).isEmpty()) {
                String value = pickText(source,key);
                if (!value.isEmpty()) try { target.put(key,value); } catch(Exception ignored) {}
            }
        }
    }

    private String providerStatusText(JSONObject m,String sport){
        String rawStatus=pickText(m,"status","statusText","state","match_status","matchStatus");
        String status=normalizedMatchStatus(rawStatus);
        ArrayList<String> details=new ArrayList<>();
        if("cricket".equals(sport)){
            addIfPresent(details,"Innings",pickText(m,"innings","currentInnings"));
            addIfPresent(details,"Target",pickText(m,"target"));
            addIfPresent(details,"Required",pickText(m,"runsRequired","requiredRuns"));
            addIfPresent(details,"RRR",pickText(m,"requiredRunRate","rrr"));
        } else if("football".equals(sport)){
            addIfPresent(details,"Clock",pickText(m,"clock","matchClock","minute"));
            addIfPresent(details,"Goals",pickText(m,"goals"));
            addIfPresent(details,"Cards",pickText(m,"cards"));
            addIfPresent(details,"VAR",pickText(m,"var"));
        } else if("basketball".equals(sport)){
            addIfPresent(details,"Period",pickText(m,"period","quarter"));
            addIfPresent(details,"Clock",pickText(m,"clock","gameClock"));
            addIfPresent(details,"Fouls",pickText(m,"fouls","teamFouls"));
            addIfPresent(details,"Timeouts",pickText(m,"timeouts"));
        } else {
            addIfPresent(details,"Set",pickText(m,"set","currentSet"));
            addIfPresent(details,"Game",pickText(m,"game","currentGame"));
            addIfPresent(details,"Server",pickText(m,"server"));
            addIfPresent(details,"Break",pickText(m,"breakPoint","break"));
        }
        if(status.isEmpty() && details.isEmpty()) return "";
        if(details.isEmpty()) return status;
        return status.isEmpty()?android.text.TextUtils.join(" • ",details):status+" • "+android.text.TextUtils.join(" • ",details);
    }

    private void addIfPresent(ArrayList<String> list,String label,String value){
        if(value!=null && !value.trim().isEmpty()) list.add(label+" "+value.trim());
    }

    private View cricketLiveScoreBoard(JSONObject m) {
        if (m == null) return null;
        String status = normalizedMatchStatus(pickText(m,"status","statusText","state","match_status","matchStatus"));
        String result = pickText(m,"result","result_text","resultText","outcome","winner_text","winnerText","winner");
        String display = "";

        if ("LIVE".equals(status)) {
            display = latestCricketLiveStatus(m);
            if (display.isEmpty()) {
                display = "Updating live score • Please wait…";
            }
        } else if ("FINISHED".equals(status)) {
            display = result.trim();
            if (display.isEmpty()) {
                String winner = pickText(m,"winner","winner_name","winnerName","winning_team","winningTeam","winner_text","winnerText");
                display = winner.isEmpty() ? "Match finished" : winner;
            }
        } else if ("UPCOMING".equals(status)) {
            return null;
        } else {
            return null;
        }

        TextView board = tv(display, 10.8f, TEXT, true);
        board.setGravity(Gravity.CENTER);
        board.setMaxLines(2);
        board.setEllipsize(android.text.TextUtils.TruncateAt.END);
        board.setIncludeFontPadding(false);
        board.setPadding(dp(16), dp(12), dp(16), dp(12));
        // A restrained premium green, used as the live scoring surface itself.
        int bg = "FINISHED".equals(status)
                ? Color.argb(46, 244, 63, 81)
                : Color.rgb(20, 122, 82);
        board.setBackground(round(bg, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.setMargins(dp(0), dp(8), dp(0), dp(0));
        board.setLayoutParams(lp);
        return board;
    }

    private String latestCricketLiveStatus(JSONObject m) {
        JSONObject raw = rawProvider(m);
        JSONArray a = pickArray(raw,"commentary","ball_by_ball","ballByBall","commentaries","commentary_feed","commentaryFeed");
        if (a.length() == 0) return "";

        JSONObject latest = null;
        double latestOrder = -1;
        int latestIndex = -1;
        String latestText = "";
        for (int i=0; i<a.length(); i++) {
            JSONObject x=a.optJSONObject(i);
            if(x==null) continue;
            String text=commentaryText(x);
            if(text.isEmpty()) continue;
            double order=commentaryDeliveryOrder(x);
            if(latest==null || order>latestOrder || (order<0 && latestOrder<0 && i>latestIndex)) {
                latest=x;
                latestOrder=order;
                latestIndex=i;
                latestText=text;
            }
        }
        if(latest==null) return "";

        String event=cricketEventBadge(latest, latestText);
        if(!event.isEmpty()) return event + "  •  " + latestText;
        return latestText;
    }

    private String commentaryText(JSONObject x) {
        return pickText(x,"text","commentary","comment","commText","comm_text","commtext","description","event","eventType","message","title","summary").trim();
    }

    private double commentaryDeliveryOrder(JSONObject x) {
        String over=pickText(x,"over","over_number","overNumber","over_num","overNum");
        String ball=pickText(x,"ball","ball_number","ballNumber","delivery","delivery_number","deliveryNumber");
        try {
            double o=Double.parseDouble(over.replaceAll("[^0-9.]",""));
            double b=0;
            if(!ball.isEmpty()) b=Double.parseDouble(ball.replaceAll("[^0-9.]",""));
            return o*100+b;
        } catch(Exception ignored) {
            String ts=pickText(x,"timestamp","timeStamp","commTimestamp","commentaryTimestamp","createdAt","created_at","timestamp_ms");
            try {
                if(ts.matches("\\d+")) return Double.parseDouble(ts);
                String iso = ts.trim().replace("Z", "+0000");
                if (iso.matches(".*[+-]\\d{2}:\\d{2}$")) {
                    iso = iso.substring(0, iso.length()-6) + iso.substring(iso.length()-5).replace(":", "");
                }
                java.text.SimpleDateFormat isoParser = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US);
                return isoParser.parse(iso).getTime();
            } catch(Exception ignoredTs) { return -1; }
        }
    }

    private String cricketEventBadge(JSONObject x, String text) {
        String t=(text==null?"":text).toLowerCase(Locale.US);
        String dismissal=pickText(x,"wicket_type","dismissal","dismissal_text","dismissalText","out_reason","outReason","how_out","howOut").toLowerCase(Locale.US);
        if (t.contains("bowled") || dismissal.contains("bowled")) return "BOWLED";
        if (t.contains("lbw") || dismissal.contains("lbw")) return "LBW";
        if (t.contains("caught") || dismissal.contains("caught")) return "CAUGHT";
        if (t.contains("run out") || dismissal.contains("run out")) return "RUN OUT";
        if (t.contains("stumped") || dismissal.contains("stumped")) return "STUMPED";
        if (t.contains("hit wicket") || dismissal.contains("hit wicket")) return "HIT WICKET";
        boolean wicket=boolLike(x,"isWicket","is_wicket","wicket") || !dismissal.isEmpty()
                || t.contains("wicket");
        if(wicket) return "WICKET";
        boolean six=boolLike(x,"isSix","is_six","six") || t.matches(".*\\b6\\b.*") || t.contains("six");
        if(six) return "SIX";
        boolean four=boolLike(x,"isFour","is_four","four") || t.matches(".*\\b4\\b.*") || t.contains("four");
        if(four) return "FOUR";
        if(t.contains("no ball") || t.contains("noball")) return "NO BALL";
        if(t.contains("wide")) return "WIDE";
        if(t.contains("leg bye") || t.contains("leg-bye")) return "LEG BYE";
        if(t.contains("player") && (t.contains("enter") || t.contains("comes in") || t.contains("coming in"))) return "PLAYER IN";
        if(t.contains("break") || t.contains("interval") || t.contains("drinks") || t.contains("lunch") || t.contains("tea")) return "BREAK";
        String runs=pickText(x,"runs","run","bat_runs","batRuns","total_runs","totalRuns","totalRunsValue","score");
        if("1".equals(runs)) return "1 RUN";
        if("2".equals(runs)) return "2 RUNS";
        if("3".equals(runs)) return "3 RUNS";
        if("0".equals(runs) || t.contains("dot ball") || t.contains("no run")) return "DOT BALL";
        return "";
    }

    private LinearLayout matchHero(JSONObject m) {
        String sport=m.optString("sport",selectedSport).toLowerCase(Locale.US);
        JSONObject home=team(m,true), away=team(m,false);
        LinearLayout hero=new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL); hero.setPadding(dp(16),dp(14),dp(16),dp(14)); hero.setBackground(round(PANEL,20));

        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView comp=tv(m.optString("competition",sportName(sport)+" • International Match Centre"),10,MUTED,true); comp.setSingleLine(true); comp.setEllipsize(android.text.TextUtils.TruncateAt.END); top.addView(comp,new LinearLayout.LayoutParams(0,-2,1));
        String displayStatus=normalizedMatchStatus(pickText(m,"status","statusText","state","match_status","matchStatus"));
        if(!displayStatus.isEmpty()){
            TextView st=tv("LIVE".equals(displayStatus)?remoteLiveBadgeLabel:remoteStatusLabel(displayStatus),11.5f,"LIVE".equals(displayStatus)?RED:GREEN,true);
            st.setGravity(Gravity.CENTER);
            st.setMinWidth(dp("LIVE".equals(displayStatus)?86:76));
            st.setMinHeight(dp(36));
            st.setPadding(dp(14),dp(8),dp(14),dp(8));
            st.setLetterSpacing(.04f);
            st.setBackground(round("LIVE".equals(displayStatus)?Color.argb(48,244,63,81):Color.argb(34,0,194,142),18));
            top.addView(st);
        }
        hero.addView(top);

        String titleText=canonicalMatchTitle(m);
        if(!titleText.isEmpty()){TextView title=tv(titleText,16,TEXT,true);title.setPadding(0,dp(7),0,0);hero.addView(title);}
        String metaText=matchMetaText(sport,m);
        if(!metaText.isEmpty()){TextView meta=tv(metaText,9.5f,MUTED,false);meta.setMaxLines(2);meta.setPadding(0,dp(3),0,0);hero.addView(meta);}

        LinearLayout teams=new LinearLayout(this); teams.setGravity(Gravity.CENTER_VERTICAL); teams.setPadding(0,dp(15),0,dp(9));
        teams.addView(heroTeam(home,true,sport),weighted());
        LinearLayout centre=new LinearLayout(this); centre.setOrientation(LinearLayout.VERTICAL); centre.setGravity(Gravity.CENTER);
        TextView vs=tv("VS",9,MUTED,true);vs.setGravity(Gravity.CENTER);vs.setPadding(dp(10),dp(7),dp(10),dp(7));vs.setBackground(round(CARD_2,16));centre.addView(vs);
        String time=pickText(m,"time","startsAt","starts_at","start_time","startTime"); if(!time.isEmpty()){TextView tt=tv(formatMatchSchedule(time),8.5f,MUTED,false);tt.setGravity(Gravity.CENTER);tt.setPadding(0,dp(6),0,0);centre.addView(tt);}
        teams.addView(centre,new LinearLayout.LayoutParams(dp(64),-2));
        teams.addView(heroTeam(away,false,sport),weighted()); hero.addView(teams);

        if ("cricket".equalsIgnoreCase(sport)) {
            View scoringBoard = cricketLiveScoreBoard(m);
            if (scoringBoard != null) hero.addView(scoringBoard);
        } else {
            String stateText=providerStatusText(m,sport);
            if(!stateText.isEmpty()){
                TextView state=tv(stateText,9,MUTED,true);
                state.setGravity(Gravity.CENTER);
                state.setPadding(dp(10),dp(8),dp(10),dp(8));
                state.setBackground(round(CARD,12));
                hero.addView(state);
            }
        }
        return hero;
    }

    private LinearLayout heroTeam(JSONObject t, boolean left, String sport) {
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);
        box.addView(identityView(t,60),new LinearLayout.LayoutParams(-1,dp(62)));
        TextView name=tv(pickText(t,"name","team_name","short_name"),13,TEXT,true);name.setGravity(Gravity.CENTER);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);box.addView(name);
        String score=pickText(t,"score","runs","points","total","score_text","scoreText"); if(!score.isEmpty()){TextView sc=tv(score,24,TEXT,true);sc.setGravity(Gravity.CENTER);sc.setPadding(0,dp(4),0,0);box.addView(sc);}
        String form=pickText(t,"form"); if(!form.isEmpty())box.addView(tv(form,8.5f,MUTED,false)); return box;
    }

    private String matchMetaText(String sport, JSONObject m) {
        ArrayList<String> parts = new ArrayList<>();
        String date = pickText(m, "date", "startTime", "start_time", "scheduledAt", "scheduled_at");
        String venue = pickText(m, "venue", "venueName");
        String format = pickText(m, "format", "round", "stage", "competitionRound");
        String referee = pickText(m, "referee", "official", "officials");
        if(!date.isEmpty()) parts.add(date);
        if(!venue.isEmpty()) parts.add(venue);
        if(!format.isEmpty()) parts.add(format);
        if("football".equals(sport) && !referee.isEmpty()) parts.add("Referee " + referee);
        return parts.isEmpty() ? "" : android.text.TextUtils.join("  •  ", parts);
    }

    private void renderMatchBody(FrameLayout host, JSONObject m, String sport) {
        host.removeAllViews();
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(12),dp(7),dp(12),dp(26));
        String tab=detailTab;
        if("cricket".equals(sport)) renderProviderCricket(body,m,tab);
        else if("football".equals(sport)) renderProviderFootball(body,m,tab);
        else if("basketball".equals(sport)) renderProviderBasketball(body,m,tab);
        else renderProviderTennis(body,m,tab);
        scroll.addView(body,new ScrollView.LayoutParams(-1,-2)); host.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
    }

    private JSONObject rawProvider(JSONObject m){
        if(m==null)return new JSONObject();
        JSONObject raw=m.optJSONObject("rawProviderData");
        if(raw==null)return m;
        try{
            JSONObject merged=new JSONObject(raw.toString());
            JSONArray names=m.names();
            if(names!=null)for(int i=0;i<names.length();i++){
                String k=names.optString(i);
                if(!"rawProviderData".equals(k) && !merged.has(k)) merged.put(k,m.opt(k));
            }
            return merged;
        }catch(Exception ignored){return m;}
    }

    // Provider payloads are not guaranteed to use one fixed nesting level.
    // Match detail data may arrive directly, under data/match/result, or inside
    // a provider-specific container. These helpers deliberately search the
    // existing payload without inventing or merging values from another match.
    private Object findDeep(JSONObject root, String[] keys, int depth){
        if(root==null || depth<0) return null;
        for(String k:keys){
            Object v=root.opt(k);
            if(v!=null && !(v instanceof JSONObject && ((JSONObject)v).length()==0) && !(v instanceof JSONArray && ((JSONArray)v).length()==0)) return v;
        }
        if(depth==0) return null;
        JSONArray names=root.names();
        if(names!=null){
            for(int i=0;i<names.length();i++){
                Object v=root.opt(names.optString(i));
                if(v instanceof JSONObject){
                    Object found=findDeep((JSONObject)v,keys,depth-1);
                    if(found!=null) return found;
                }else if(v instanceof JSONArray){
                    JSONArray a=(JSONArray)v;
                    for(int j=0;j<a.length();j++){
                        Object item=a.opt(j);
                        if(item instanceof JSONObject){
                            Object found=findDeep((JSONObject)item,keys,depth-1);
                            if(found!=null) return found;
                        }
                    }
                }
            }
        }
        return null;
    }

    private String pickText(JSONObject o,String... keys){
        if(o==null) return "";
        for(String k:keys){
            Object v=o.opt(k);
            if(v!=null && !(v instanceof JSONObject) && !(v instanceof JSONArray) && !String.valueOf(v).trim().isEmpty()) return String.valueOf(v);
        }
        Object found=findDeep(o,keys,5);
        if(found!=null && !(found instanceof JSONObject) && !(found instanceof JSONArray) && !String.valueOf(found).trim().isEmpty()) return String.valueOf(found);
        return "";
    }

    private JSONArray pickArray(JSONObject o,String... keys){
        if(o==null) return new JSONArray();
        for(String k:keys){
            JSONArray a=o.optJSONArray(k);
            if(a!=null && a.length()>0) return a;
            JSONObject container=o.optJSONObject(k);
            if(container!=null){
                for(String ck:new String[]{"items","data","results","list","entries","records","rows","values","events"}){
                    JSONArray ca=container.optJSONArray(ck);
                    if(ca!=null && ca.length()>0) return ca;
                }
            }
        }
        Object found=findDeep(o,keys,5);
        if(found instanceof JSONArray && ((JSONArray)found).length()>0) return (JSONArray)found;
        if(found instanceof JSONObject){
            JSONObject x=(JSONObject)found;
            for(String ck:new String[]{"items","data","results","list","entries","records","rows","values","events"}){
                JSONArray ca=x.optJSONArray(ck);
                if(ca!=null && ca.length()>0) return ca;
            }
        }
        return new JSONArray();
    }

    private JSONObject pickObject(JSONObject o,String... keys){
        if(o==null) return new JSONObject();
        for(String k:keys){JSONObject x=o.optJSONObject(k);if(x!=null)return x;}
        Object found=findDeep(o,keys,5);
        return found instanceof JSONObject ? (JSONObject)found : new JSONObject();
    }
    private void providerUnavailable(LinearLayout b,String title){ /* unavailable provider fields are intentionally omitted */ }
    private void providerTeamHeader(LinearLayout b,JSONObject m){
        JSONObject h=team(m,true),a=team(m,false);
        String homeName=pickText(h,"name","team_name","short_name");
        String awayName=pickText(a,"name","team_name","short_name");
        String homeScore=pickText(h,"score","runs","points","total");
        String awayScore=pickText(a,"score","runs","points","total");
        if(homeName.isEmpty()) homeName=pickText(m,"home_name","homeTeamName");
        if(awayName.isEmpty()) awayName=pickText(m,"away_name","awayTeamName");
        if(homeScore.isEmpty()) homeScore=pickText(m,"home_score","homeScore");
        if(awayScore.isEmpty()) awayScore=pickText(m,"away_score","awayScore");
        if(!homeName.isEmpty()||!awayName.isEmpty()||!homeScore.isEmpty()||!awayScore.isEmpty()){
            b.addView(scoreboardCard(homeName,homeScore,normalizedMatchStatus(pickText(m,"status","statusText","state","match_status","matchStatus")),awayName+(awayScore.isEmpty()?"":"  "+awayScore)));
        }
    }
    private void addMatchInfo(LinearLayout b, JSONObject m){
        JSONObject raw=rawProvider(m);
        ArrayList<String[]> info=new ArrayList<>();
        String series=pickText(m,"series","series_name","seriesName","tournament","competition");
        String date=pickText(m,"date","match_date","matchDate","scheduledAt","scheduled_at","start_date","startDate");
        String time=pickText(m,"time","match_time","matchTime","start_time","startTime","startsAt","starts_at");
        String venue=pickText(m,"venue","venue_name","venueName","ground","stadium");
        String city=pickText(m,"city","venue_city","venueCity");
        String country=pickText(m,"country","venue_country","venueCountry");
        String format=pickText(m,"format","match_format","matchFormat","round","stage","competitionRound");
        String toss=pickText(m,"toss","toss_result","tossResult");
        String result=pickText(m,"result","match_result","matchResult","outcome");
        String status=normalizedMatchStatus(pickText(m,"status","statusText","state","match_status","matchStatus"));
        String officials=pickText(m,"officials","umpires","umpire","referee");

        if(series.isEmpty()) series=pickText(raw,"series","series_name","seriesName","tournament","competition");
        if(date.isEmpty()) date=pickText(raw,"date","match_date","matchDate","scheduledAt","scheduled_at","start_date","startDate");
        if(time.isEmpty()) time=pickText(raw,"time","match_time","matchTime","start_time","startTime","startsAt","starts_at");
        if(venue.isEmpty()) venue=pickText(raw,"venue","venue_name","venueName","ground","stadium");
        if(city.isEmpty()) city=pickText(raw,"city","venue_city","venueCity");
        if(country.isEmpty()) country=pickText(raw,"country","venue_country","venueCountry");
        if(format.isEmpty()) format=pickText(raw,"format","match_format","matchFormat","round","stage","competitionRound");
        if(toss.isEmpty()) toss=pickText(raw,"toss","toss_result","tossResult");
        if(result.isEmpty()) result=pickText(raw,"result","match_result","matchResult","outcome");
        if(status.isEmpty()) status=normalizedMatchStatus(pickText(raw,"status","statusText","state","match_status","matchStatus"));
        if(officials.isEmpty()) officials=pickText(raw,"officials","umpires","umpire","referee");

        if(!series.isEmpty()) info.add(new String[]{"Series",series});
        if(!date.isEmpty()) info.add(new String[]{"Date",date});
        if(!time.isEmpty()) info.add(new String[]{"Time",formatMatchSchedule(time)});
        if(!venue.isEmpty()) info.add(new String[]{"Venue",venue});
        String location=city;
        if(!country.isEmpty()) location=location.isEmpty()?country:location+", "+country;
        if(!location.isEmpty()) info.add(new String[]{"Location",location});
        if(!format.isEmpty()) info.add(new String[]{"Format",format});
        if(!toss.isEmpty()) info.add(new String[]{"Toss",toss});
        if(!result.isEmpty()) info.add(new String[]{"Result",result});
        if(!status.isEmpty()) info.add(new String[]{"Status",status});
        if(!officials.isEmpty()) info.add(new String[]{"Officials",officials});
        if(info.isEmpty()) return;

        b.addView(sectionLabel("Match Information","Verified provider fields only"));
        for(String[] item:info){
            View row=detailRow(item[0],item[1]);
            row.setLayoutParams(marginBottomParams(5));
            b.addView(row);
        }
    }

    private void renderProviderCricket(LinearLayout b,JSONObject m,String tab){
        JSONObject raw=rawProvider(m);
        b.addView(sectionLabel("Cricket Match Centre",m.optString("competition","")));
        if("OVERVIEW".equals(tab)){
            providerTeamHeader(b,m);
            addCricketOverviewState(b,m,raw);
            addMatchInfo(b,m);
            return;
        }
        if("LIVE".equals(tab)){
            renderCricketLiveBoard(b,m,raw);
            return;
        }
        if("SCORECARD".equals(tab)){
            renderCricketScorecard(b,m,raw);
            return;
        }
        if("SQUADS".equals(tab)){
            renderProviderPeople(b,pickArray(raw,"squads","squad","playing_xi","playingXI","playing_xi_players","team_players","lineups"),"Squads");
            return;
        }
        if("OVERS".equals(tab)){
            JSONArray overs=pickArray(raw,"overs","over_by_over","overByOver","over_summary","overSummary");
            renderCricketOvers(b,overs);
            return;
        }
        if("COMMENTARY".equals(tab)){
            JSONArray commentary=pickArray(raw,"commentary","ball_by_ball","ballByBall","commentaries","commentary_feed","commentaryFeed");
            renderProviderEvents(b,commentary,"Commentary");
            return;
        }
        if("HIGHLIGHTS".equals(tab)){
            JSONArray highlights=pickArray(raw,"highlights","highlight","key_events","keyEvents");
            renderProviderEvents(b,highlights,"Highlights");
            return;
        }
        if("SERIES".equals(tab)){
            renderCricketSeries(b,m,raw);
            return;
        }
        providerUnavailable(b,tab);
    }

    private void renderCricketScorecard(LinearLayout b, JSONObject m, JSONObject raw) {
        b.addView(sectionLabel("Scorecard", "Batting • Bowling • Extras • Fall of Wickets • Partnerships"));
        JSONArray innings=pickArray(raw,"innings","innings_summary","inningsSummary");
        if(innings.length()>0){
            for(int i=0;i<innings.length();i++){
                JSONObject inn=innings.optJSONObject(i);
                if(inn!=null) renderCricketInningsScorecard(b,inn,i+1,m,raw);
            }
            return;
        }

        // Some providers expose scorecard sections at the match root instead of
        // nesting them under innings. Keep the same professional section order.
        renderCricketSectionArray(b,"Batting",collectFeatureArray(raw,"batting","batting_scorecard","battingScorecard"),true);
        renderCricketSectionArray(b,"Bowling",collectFeatureArray(raw,"bowling","bowling_scorecard","bowlingScorecard"),false);
        renderExtrasSection(b,collectFeatureArray(raw,"extras"));
        renderFowSection(b,collectFeatureArray(raw,"fall_of_wickets","fallOfWickets","fow"));
        renderPartnershipSection(b,collectFeatureArray(raw,"partnerships","partnership"));
        if(!hasCricketScorecardData(raw)){
            JSONObject home=team(m,true), away=team(m,false);
            String hs=pickText(home,"score","runs","points","total","score_text","scoreText");
            String as=pickText(away,"score","runs","points","total","score_text","scoreText");
            if(!hs.isEmpty()||!as.isEmpty()) b.addView(scoreboardCard(pickText(home,"name","team_name","short_name"),hs,"",pickText(away,"name","team_name","short_name")+(as.isEmpty()?"":"  "+as)));
        }
    }

    private void renderCricketInningsScorecard(LinearLayout b, JSONObject inn, int number, JSONObject match, JSONObject raw){
        String teamName=pickText(inn,"team","team_name","teamName","batting_team","battingTeam","name");
        String score=pickText(inn,"score","score_text","scoreText","total");
        String overs=pickText(inn,"overs","over","overs_text","oversText");
        String wickets=pickText(inn,"wickets","wicket");
        String subtitle=teamName;
        if(score.isEmpty()) score=pickText(inn,"runs");
        if(!score.isEmpty()) subtitle+=(subtitle.isEmpty()?"":"  ")+score+(overs.isEmpty()?"":" ("+overs+" Ov)");
        if(!wickets.isEmpty() && !score.contains("/")) subtitle+=(score.isEmpty()?"":"  ")+"/"+wickets;
        if(subtitle.isEmpty()) subtitle="Innings "+number;
        b.addView(sectionLabel("Innings "+number,subtitle));
        renderCricketSectionArray(b,"Batting",collectFeatureArray(inn,"batting","batting_scorecard","battingScorecard","batters","batsmen"),true);
        renderCricketSectionArray(b,"Bowling",collectFeatureArray(inn,"bowling","bowling_scorecard","bowlingScorecard","bowlers"),false);
        renderExtrasSection(b,collectFeatureArray(inn,"extras"));
        renderFowSection(b,collectFeatureArray(inn,"fall_of_wickets","fallOfWickets","fow"));
        renderPartnershipSection(b,collectFeatureArray(inn,"partnerships","partnership"));
    }

    private JSONArray collectFeatureArray(JSONObject root,String... keys){
        JSONArray out=new JSONArray();
        collectFeatureArrayRecursive(root,out,keys,0);
        return out;
    }

    private void collectFeatureArrayRecursive(Object node,JSONArray out,String[] keys,int depth){
        if(node==null||depth>7)return;
        if(node instanceof JSONArray){
            JSONArray a=(JSONArray)node;
            for(int i=0;i<a.length();i++)collectFeatureArrayRecursive(a.opt(i),out,keys,depth+1);
            return;
        }
        if(!(node instanceof JSONObject))return;
        JSONObject o=(JSONObject)node;
        for(String key:keys){
            JSONArray a=o.optJSONArray(key);
            if(a!=null&&a.length()>0){
                for(int i=0;i<a.length();i++)putUniqueFeature(out,a.opt(i));
            }else{
                JSONObject obj=o.optJSONObject(key);
                if(obj!=null){
                    JSONArray nested=objectArray(obj);
                    for(int i=0;i<nested.length();i++)putUniqueFeature(out,nested.opt(i));
                }
            }
        }
        JSONArray names=o.names();
        if(names!=null)for(int i=0;i<names.length();i++){
            Object v=o.opt(names.optString(i));
            if(v instanceof JSONObject||v instanceof JSONArray)collectFeatureArrayRecursive(v,out,keys,depth+1);
        }
    }

    private void putUniqueFeature(JSONArray out,Object value){
        if(value==null)return;
        String sig=String.valueOf(value);
        for(int i=0;i<out.length();i++)if(sig.equals(String.valueOf(out.opt(i))))return;
        out.put(value);
    }

    private JSONArray objectArray(JSONObject o){
        JSONArray out=new JSONArray();
        for(String k:new String[]{"items","data","results","list","entries","records","rows","values"}){
            JSONArray a=o.optJSONArray(k); if(a!=null&&a.length()>0)return a;
        }
        return out;
    }

    private boolean hasCricketScorecardData(JSONObject raw){
        return collectFeatureArray(raw,"batting","batting_scorecard","battingScorecard","batters","batsmen").length()>0
                || collectFeatureArray(raw,"bowling","bowling_scorecard","bowlingScorecard","bowlers").length()>0
                || collectFeatureArray(raw,"extras").length()>0
                || collectFeatureArray(raw,"fall_of_wickets","fallOfWickets","fow").length()>0
                || collectFeatureArray(raw,"partnerships","partnership").length()>0;
    }

    private void renderCricketSectionArray(LinearLayout b,String title,JSONArray a,boolean batting){
        if(a==null||a.length()==0)return;
        b.addView(sectionLabel(title,batting?"R  B  4s  6s  SR":"O  M  R  W  ECO"));
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);
            if(x==null){b.addView(eventRow(String.valueOf(a.opt(i)),i));continue;}
            String name=pickText(x,"name","player_name","playerName","full_name","fullName","batter","batsman","bowler");
            String status=pickText(x,"status","dismissal","dismissal_text","dismissalText","out_reason","outReason","how_out","howOut");
            String avatar=pickText(x,"avatar_url","avatar","image_url","image","photo_url","photo","headshot_url","headshot","profile_image","player_image","playerImage");
            String gender=pickText(x,"gender","sex","player_gender","playerGender","gender_code","genderCode");
            JSONObject player=x.optJSONObject("player");
            if(player!=null){
                if(name.isEmpty())name=pickText(player,"name","player_name","full_name");
                if(avatar.isEmpty())avatar=pickText(player,"avatar_url","avatar","image_url","image","photo_url","photo","headshot_url","headshot","profile_image");
                if(gender.isEmpty())gender=pickText(player,"gender","sex","player_gender","playerGender","gender_code","genderCode");
            }
            if(name.isEmpty())name=flattenProviderObject(x);
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),dp(9),dp(10),dp(9));row.setBackground(round(CARD,12));
            if(!avatar.isEmpty()||!name.isEmpty()){
                ImageView im=new ImageView(this);
                im.setScaleType(ImageView.ScaleType.CENTER_CROP);
                im.setBackground(circleDrawable(CARD_2));
                im.setClipToOutline(true);
                im.setImageDrawable(initialsAvatar(name));
                if(!avatar.isEmpty()) loadPlayerAvatar(im,avatar,name);
                row.addView(im,new LinearLayout.LayoutParams(dp(34),dp(34)));
            }
            LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(8),0,dp(6),0);
            TextView nm=tv(name,11.5f,TEXT,true);nm.setMaxLines(2);info.addView(nm);
            if(!status.isEmpty()) {TextView st=tv(status,8.5f,MUTED,false);st.setMaxLines(2);info.addView(st);}
            row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            String[] vals=batting?new String[]{pickText(x,"runs","run","r"),pickText(x,"balls","ball","b"),pickText(x,"fours","four","4s"),pickText(x,"sixes","six","6s"),pickText(x,"strike_rate","strikeRate","sr")}:
                    new String[]{pickText(x,"overs","over","o"),pickText(x,"maidens","maiden","m"),pickText(x,"runs","run","r"),pickText(x,"wickets","wicket","w"),pickText(x,"economy","economy_rate","economyRate","eco")};
            LinearLayout stats=new LinearLayout(this);stats.setGravity(Gravity.CENTER_VERTICAL);stats.setPadding(dp(4),0,0,0);
            for(String v:vals){TextView z=tv(v.isEmpty()?"-":v,10.5f,TEXT,true);z.setGravity(Gravity.CENTER);stats.addView(z,new LinearLayout.LayoutParams(dp(38),-2));}
            row.addView(stats);
            b.addView(row,new LinearLayout.LayoutParams(-1,-2));
            Space gap=new Space(this);b.addView(gap,new LinearLayout.LayoutParams(1,dp(5)));
        }
    }

    private void renderExtrasSection(LinearLayout b,JSONArray a){
        if(a==null||a.length()==0)return;
        b.addView(sectionLabel("Extras","Byes • Leg byes • Wides • No balls • Penalty"));
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);
            if(x==null){b.addView(eventRow(String.valueOf(a.opt(i)),i));continue;}
            String text=pickText(x,"summary","description","text","total","value");
            if(text.isEmpty()){
                ArrayList<String> parts=new ArrayList<>();
                for(String[] f:new String[][]{{"b","Byes"},{"lb","Leg byes"},{"w","Wides"},{"nb","No balls"},{"p","Penalty"},{"total","Total"}}){String v=pickText(x,f[0],f[1],f[1].toLowerCase(Locale.US));if(!v.isEmpty())parts.add(f[1]+" "+v);}
                text=android.text.TextUtils.join("  •  ",parts);
            }
            if(!text.isEmpty())b.addView(detailRow("Extras",text));
        }
    }

    private void renderFowSection(LinearLayout b,JSONArray a){
        if(a==null||a.length()==0)return;
        b.addView(sectionLabel("Fall of Wickets","Wicket • Score • Over"));
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i); if(x==null){b.addView(eventRow(String.valueOf(a.opt(i)),i));continue;}
            String player=pickText(x,"player","player_name","playerName","batter","batsman","name");
            String score=pickText(x,"score","team_score","teamScore","runs","total");
            String over=pickText(x,"over","overs","ball","delivery");
            String text=(player.isEmpty()?"Wicket "+(i+1):player)+(score.isEmpty()?"":"  •  "+score)+(over.isEmpty()?"":"  •  "+over);
            b.addView(detailRow(""+(i+1),text));
        }
    }

    private void renderPartnershipSection(LinearLayout b,JSONArray a){
        if(a==null||a.length()==0)return;
        b.addView(sectionLabel("Partnerships","Runs • Balls • Batters"));
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i); if(x==null){b.addView(eventRow(String.valueOf(a.opt(i)),i));continue;}
            String p1=pickText(x,"player1","player_1","batter1","batter_1","first_player","firstPlayer");
            String p2=pickText(x,"player2","player_2","batter2","batter_2","second_player","secondPlayer");
            if(p1.isEmpty()||p2.isEmpty()){
                JSONArray players=x.optJSONArray("players"); if(players!=null&&players.length()>0){p1=pickText(players.optJSONObject(0),"name","player_name");if(players.length()>1)p2=pickText(players.optJSONObject(1),"name","player_name");}
            }
            String runs=pickText(x,"runs","partnership_runs","partnershipRuns","total");
            String balls=pickText(x,"balls","partnership_balls","partnershipBalls");
            String text=(p1.isEmpty()?"Batter 1":p1)+"  +  "+(p2.isEmpty()?"Batter 2":p2);
            String meta=(runs.isEmpty()?"":runs+" runs")+(balls.isEmpty()?"":"  •  "+balls+" balls");
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(10),dp(9),dp(10),dp(9));row.setBackground(round(CARD,12));row.addView(tv(text,11,TEXT,true));if(!meta.isEmpty())row.addView(tv(meta,9,MUTED,false));b.addView(row,new LinearLayout.LayoutParams(-1,-2));Space gap=new Space(this);b.addView(gap,new LinearLayout.LayoutParams(1,dp(5)));
        }
    }

    private void addCricketOverviewState(LinearLayout b,JSONObject m,JSONObject raw){
        ArrayList<String[]> stats=new ArrayList<>();
        String score=pickText(raw,"current_score","currentScore","score","innings_score","inningsScore");
        String overs=pickText(raw,"current_over","currentOver","overs","over");
        String target=pickText(raw,"target","target_score","targetScore");
        String required=pickText(raw,"runs_required","runsRequired","required_runs","requiredRuns");
        String crr=pickText(raw,"crr","current_run_rate","currentRunRate","run_rate","runRate");
        String rrr=pickText(raw,"rrr","required_run_rate","requiredRunRate");
        if(!score.isEmpty())stats.add(new String[]{"Score",score,""});if(!overs.isEmpty())stats.add(new String[]{"Overs",overs,""});if(!target.isEmpty())stats.add(new String[]{"Target",target,""});if(!required.isEmpty())stats.add(new String[]{"Required",required,""});if(!crr.isEmpty())stats.add(new String[]{"CRR",crr,""});if(!rrr.isEmpty())stats.add(new String[]{"RRR",rrr,""});
        if(!stats.isEmpty())addStatGrid(b,stats.toArray(new String[0][]));
    }

    private void renderCurrentBatters(LinearLayout b,JSONObject raw){
        JSONArray a=pickArray(raw,"current_batters","currentBatters");
        if(a.length()==0)return;
        renderCricketSectionArray(b,"Current Batters",a,true);
    }

    private void renderCurrentBowler(LinearLayout b,JSONObject raw){
        JSONArray a=pickArray(raw,"current_bowler","currentBowler");
        if(a.length()==0){JSONObject o=pickObject(raw,"current_bowler","currentBowler");if(o.length()>0){a=new JSONArray();a.put(o);}}
        if(a.length()==0)return;
        renderCricketSectionArray(b,"Current Bowler",a,false);
    }

    private void renderCricketLiveBoard(LinearLayout b, JSONObject m, JSONObject raw) {
        b.addView(sectionLabel("Live Scoreboard", "Auto-updating • ball-by-ball cricket coverage"));

        JSONObject home=team(m,true), away=team(m,false);
        String homeName=pickText(home,"name","team_name","short_name");
        String awayName=pickText(away,"name","team_name","short_name");
        String homeScore=pickText(home,"score","runs","points","total","score_text","scoreText");
        String awayScore=pickText(away,"score","runs","points","total","score_text","scoreText");
        String currentScore=pickText(raw,"current_score","currentScore","score","innings_score","inningsScore");
        String currentOver=pickText(raw,"current_over","currentOver","overs","over");
        String result=pickText(m,"result","result_text","resultText","outcome","winner_text");
        String status=normalizedMatchStatus(pickText(m,"status","statusText","state","match_status","matchStatus"));

        if(!homeName.isEmpty() || !awayName.isEmpty()){
            LinearLayout scoreCard=new LinearLayout(this);
            scoreCard.setOrientation(LinearLayout.VERTICAL);
            scoreCard.setPadding(dp(13),dp(12),dp(13),dp(12));
            scoreCard.setBackground(round(CARD,16));
            LinearLayout teams=new LinearLayout(this); teams.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout hbox=liveScoreTeam(homeName,homeScore,home);
            LinearLayout abox=liveScoreTeam(awayName,awayScore,away);
            teams.addView(hbox,new LinearLayout.LayoutParams(0,-2,1));
            TextView vs=tv("VS",9,MUTED,true);vs.setGravity(Gravity.CENTER);vs.setPadding(dp(9),dp(6),dp(9),dp(6));vs.setBackground(round(CARD_2,14));
            teams.addView(vs,new LinearLayout.LayoutParams(dp(52),-2));
            teams.addView(abox,new LinearLayout.LayoutParams(0,-2,1));
            scoreCard.addView(teams);
            if(!currentScore.isEmpty() || !currentOver.isEmpty()){
                LinearLayout liveLine=new LinearLayout(this);liveLine.setGravity(Gravity.CENTER_VERTICAL);liveLine.setPadding(0,dp(10),0,0);
                TextView sc=tv(currentScore.isEmpty()?"Live":currentScore,18,TEXT,true);liveLine.addView(sc,new LinearLayout.LayoutParams(0,-2,1));
                String ov=currentOver.isEmpty()?"":(currentOver.toLowerCase(Locale.US).contains("over")?currentOver:currentOver+" Ov");
                if(!ov.isEmpty())liveLine.addView(tv(ov,10,MUTED,true));
                scoreCard.addView(liveLine);
            }
            if(!result.isEmpty() && ("FINISHED".equals(status) || !"LIVE".equals(status))){
                TextView r=tv(result,10.5f,Color.rgb(224,92,92),true);r.setPadding(0,dp(8),0,0);r.setGravity(Gravity.CENTER);scoreCard.addView(r);
            } else if("LIVE".equals(status)){
                TextView r=tv("LIVE NOW",9.5f,RED,true);r.setGravity(Gravity.CENTER);r.setPadding(0,dp(8),0,0);scoreCard.addView(r);
            }
            b.addView(scoreCard,marginBottomParams(8));
        }

        addCricketOverviewState(b,m,raw);
        renderCurrentBatters(b,raw);
        renderCurrentBowler(b,raw);

        JSONArray overs=pickArray(raw,"overs","over_by_over","overByOver","over_summary","overSummary");
        if(overs.length()>0) renderCricketOvers(b,overs);

        JSONArray commentary=pickArray(raw,"commentary","ball_by_ball","ballByBall","commentaries","commentary_feed","commentaryFeed");
        if(commentary.length()>0) renderCricketCommentary(b,commentary);
        else if(overs.length()==0) providerUnavailable(b,"Live ball-by-ball commentary is not available from the active provider");
    }

    private LinearLayout liveScoreTeam(String name,String score,JSONObject team){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);
        box.addView(identityView(team,38),new LinearLayout.LayoutParams(-1,dp(40)));
        box.addView(tv(name.isEmpty()?"Team":name,11.5f,TEXT,true));
        if(!score.isEmpty())box.addView(tv(score,17,TEXT,true));
        String overs=pickText(team,"overs","over","overs_text","oversText","over_text","overText");
        if(!overs.isEmpty())box.addView(tv(overs.toLowerCase(Locale.US).contains("over")?overs:overs+" Ov",8.5f,MUTED,false));
        return box;
    }

    private void renderCricketCommentary(LinearLayout b,JSONArray a){
        if(a==null||a.length()==0)return;
        b.addView(sectionLabel("Ball-by-Ball Commentary","Latest delivery first when supplied by the provider"));
        int shown=0;
        for(int i=a.length()-1;i>=0 && shown<80;i--){
            JSONObject x=a.optJSONObject(i);
            if(x==null){String raw=String.valueOf(a.opt(i));if(!raw.trim().isEmpty())b.addView(eventRow(raw,shown++));continue;}
            String over=pickText(x,"over","over_number","overNumber","over_num","overNum");
            String ball=pickText(x,"ball","ball_number","ballNumber","delivery","delivery_number","deliveryNumber");
            String batsman=pickText(x,"batsman","batter","batter_name","batsman_name","striker","striker_name");
            String bowler=pickText(x,"bowler","bowler_name","bowlerName");
            String runs=pickText(x,"runs","run","bat_runs","batRuns","total_runs","totalRuns","totalRunsValue","score");
            String extras=pickText(x,"extras","extra","extra_runs","extraRuns");
            String text=pickText(x,"text","commentary","comment","commText","comm_text","commtext","description","event","eventType","message","title","summary");
            boolean four=boolLike(x,"isFour","is_four","four") || "4".equals(runs);
            boolean six=boolLike(x,"isSix","is_six","six") || "6".equals(runs);
            boolean wicket=boolLike(x,"isWicket","is_wicket","wicket") || !pickText(x,"wicket_type","dismissal","dismissal_text","outcome").isEmpty();
            if(text.isEmpty()){
                StringBuilder sb=new StringBuilder();
                if(!batsman.isEmpty())sb.append(batsman);
                if(!bowler.isEmpty()){if(sb.length()>0)sb.append(" • ");sb.append("vs ").append(bowler);}
                if(!runs.isEmpty()){if(sb.length()>0)sb.append(" • ");sb.append(runs).append(" run").append("6".equals(runs)||"4".equals(runs)?"s":"");}
                if(!extras.isEmpty()){if(sb.length()>0)sb.append(" • ");sb.append(extras);}
                text=sb.toString();
            }
            if(text.isEmpty())text=flattenProviderObject(x);
            if(text.isEmpty())continue;
            LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(9),dp(9),dp(9),dp(9));row.setBackground(round(CARD,12));
            String overLabel=over.isEmpty()?"":(ball.isEmpty()?over:over+"."+ball);
            TextView ov=tv(overLabel.isEmpty()?"•":overLabel,9,MUTED,true);ov.setGravity(Gravity.CENTER);row.addView(ov,new LinearLayout.LayoutParams(dp(44),dp(34)));
            TextView desc=tv(text,10.5f,TEXT,false);desc.setMaxLines(4);desc.setEllipsize(android.text.TextUtils.TruncateAt.END);desc.setPadding(dp(7),0,dp(7),0);row.addView(desc,new LinearLayout.LayoutParams(0,-2,1));
            String badgeText=wicket?"WICKET":(six?"6":(four?"4":(!runs.isEmpty()?runs:"")));
            if(!badgeText.isEmpty()){TextView badge=tv(badgeText,9,wicket?RED:(four||six?TEXT:CYAN),true);badge.setGravity(Gravity.CENTER);badge.setPadding(dp(7),dp(5),dp(7),dp(5));badge.setBackground(round(wicket?Color.argb(45,244,63,81):(four||six?Color.argb(38,28,126,245):Color.argb(30,0,205,190)),12));row.addView(badge,new LinearLayout.LayoutParams(-2,dp(30)));}
            b.addView(row,marginBottomParams(5));
            shown++;
        }
    }

    private boolean boolLike(JSONObject o,String...keys){
        for(String k:keys){Object v=o.opt(k);if(v instanceof Boolean && (Boolean)v)return true;String s=String.valueOf(v==null?"":v).trim().toLowerCase(Locale.US);if("true".equals(s)||"yes".equals(s)||"1".equals(s))return true;}
        return false;
    }

    private void renderCricketOvers(LinearLayout b,JSONArray a){
        if(a==null||a.length()==0)return;
        b.addView(sectionLabel("Overs","Over-by-over breakdown"));
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);if(x==null){b.addView(eventRow(String.valueOf(a.opt(i)),i));continue;}
            String over=pickText(x,"over","over_number","overNumber","number");
            String runs=pickText(x,"runs","score","total");
            String bowler=pickText(x,"bowler","bowler_name","bowlerName");
            String deliveries=pickText(x,"deliveries","balls","events");
            String title=(over.isEmpty()?"Over "+(i+1):"Over "+over)+(runs.isEmpty()?"":"  •  "+runs+" runs")+(bowler.isEmpty()?"":"  •  "+bowler);
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(10),dp(9),dp(10),dp(9));row.setBackground(round(CARD,12));row.addView(tv(title,11,TEXT,true));String details=deliveries.isEmpty()?flattenProviderObject(x):deliveries;if(!details.isEmpty()&&!details.equals(title))row.addView(tv(details,9,MUTED,false));b.addView(row,new LinearLayout.LayoutParams(-1,-2));Space gap=new Space(this);b.addView(gap,new LinearLayout.LayoutParams(1,dp(5)));
        }
    }

    private void renderCricketSeries(LinearLayout b,JSONObject m,JSONObject raw){
        JSONObject series=pickObject(raw,"series","series_data","seriesData","seriesDetails");
        String name=pickText(raw,"series","series_name","seriesName","tournament","competition");
        if(name.isEmpty())name=pickText(m,"competition");
        if(!name.isEmpty())b.addView(statCard("Series",name,""));
        if(series.length()>0){
            JSONArray matches=pickArray(series,"matches","fixtures","games","results");
            if(matches.length()>0){renderProviderEvents(b,matches,"Series matches");}
            String detail=flattenProviderObject(series);if(!detail.isEmpty()&&!detail.equals(name))b.addView(eventRow(detail,1));
        }
    }

    private void renderProviderFootball(LinearLayout b,JSONObject m,String tab){JSONObject raw=rawProvider(m);b.addView(sectionLabel("Football Match Centre",m.optString("competition","")));if("OVERVIEW".equals(tab)||"LIVE".equals(tab)){providerTeamHeader(b,m);renderProviderMetrics(b,raw,new String[]{"possession","shots","shots_on_target","corners","fouls","offsides","passes","pass_accuracy","tackles","saves","xg"},"Match statistics");renderProviderEvents(b,pickArray(raw,"timeline","events","goals","cards","substitutions"),"Timeline");return;}if("STATS".equals(tab)){renderProviderMetrics(b,raw,new String[]{"possession","shots","shots_on_target","corners","fouls","offsides","passes","pass_accuracy","tackles","saves","xg"},"Statistics");return;}if("LINEUPS".equals(tab)){renderProviderPeople(b,pickArray(raw,"lineups","players","formations"),"Lineups");return;}if("TIMELINE".equals(tab)){renderProviderEvents(b,pickArray(raw,"timeline","events","goals","cards","substitutions"),"Timeline");return;}if("STANDINGS".equals(tab)){renderProviderTables(b,raw,new String[]{"standings","table"},"Standings");return;}renderProviderTables(b,raw,new String[]{"h2h","head_to_head","recent_meetings"},"Head to Head");}
    private void renderProviderBasketball(LinearLayout b,JSONObject m,String tab){JSONObject raw=rawProvider(m);b.addView(sectionLabel("Basketball Match Centre",m.optString("competition","")));if("OVERVIEW".equals(tab)||"LIVE".equals(tab)){providerTeamHeader(b,m);renderProviderMetrics(b,raw,new String[]{"quarter","quarters","game_clock","possession","team_fouls","timeouts","points","fg_percentage","three_point_percentage","free_throw_percentage","rebounds","assists","turnovers"},"Game state");renderProviderEvents(b,pickArray(raw,"play_by_play","playByPlay","events","timeline"),"Play-by-play");return;}if("BOX SCORE".equals(tab)){renderProviderTables(b,raw,new String[]{"box_score","boxScore","players"},"Box Score");return;}if("PLAY-BY-PLAY".equals(tab)){renderProviderEvents(b,pickArray(raw,"play_by_play","playByPlay","events","timeline"),"Play-by-play");return;}if("LINEUPS".equals(tab)){renderProviderPeople(b,pickArray(raw,"lineups","players"),"Lineups");return;}if("TEAM STATS".equals(tab)){renderProviderMetrics(b,raw,new String[]{"fg_percentage","three_point_percentage","free_throw_percentage","rebounds","offensive_rebounds","assists","turnovers","steals","blocks","team_fouls"},"Team statistics");return;}renderProviderTables(b,raw,new String[]{"standings","table"},"Standings");}
    private void renderProviderTennis(LinearLayout b,JSONObject m,String tab){JSONObject raw=rawProvider(m);b.addView(sectionLabel("Tennis Match Centre",m.optString("competition","")));if("OVERVIEW".equals(tab)||"LIVE".equals(tab)){providerTeamHeader(b,m);renderProviderMetrics(b,raw,new String[]{"set","sets","game","games","point","server","break_point","tiebreak","aces","double_faults","first_serve_percentage","first_serve_points_won","second_serve_points_won"},"Match state");renderProviderEvents(b,pickArray(raw,"point_by_point","pointByPoint","points","events"),"Point-by-point");return;}if("SCOREBOARD".equals(tab)){renderProviderTables(b,raw,new String[]{"scoreboard","sets","score"},"Scoreboard");return;}if("POINT-BY-POINT".equals(tab)){renderProviderEvents(b,pickArray(raw,"point_by_point","pointByPoint","points","events"),"Point-by-point");return;}if("STATS".equals(tab)){renderProviderMetrics(b,raw,new String[]{"aces","double_faults","first_serve_percentage","first_serve_points_won","second_serve_points_won","break_points","winners","unforced_errors","net_points","rally_length","serve_speed"},"Tennis statistics");return;}if("H2H".equals(tab)){renderProviderTables(b,raw,new String[]{"h2h","head_to_head","recent_meetings"},"Head to Head");return;}renderProviderTables(b,raw,new String[]{"draw","bracket"},"Draw");}
    private void renderProviderMetrics(LinearLayout b,JSONObject raw,String[] keys,String title){ArrayList<String[]> a=new ArrayList<>();for(String k:keys){String v=pickText(raw,k);if(!v.isEmpty())a.add(new String[]{prettyKey(k),v,""});}if(a.isEmpty()){providerUnavailable(b,title);return;}for(int i=0;i<a.size();i+=3){int end=Math.min(i+3,a.size());addStatGrid(b,a.subList(i,end).toArray(new String[0][]));}}
    private String prettyKey(String k){String x=k.replace('_',' ');return x.length()==0?x:x.substring(0,1).toUpperCase(Locale.US)+x.substring(1);}
    private void addProviderEvents(LinearLayout b, JSONArray a, String title) {
        renderProviderEvents(b, a, title);
    }
    private void renderProviderEvents(LinearLayout b,JSONArray a,String title){
        if(a==null||a.length()==0)return;
        ArrayList<String> rows=new ArrayList<>();
        for(int i=0;i<a.length();i++){
            Object v=a.opt(i);
            String text=v instanceof JSONObject?flattenProviderObject((JSONObject)v):String.valueOf(v);
            if(!text.isEmpty())rows.add(text);
        }
        if(rows.isEmpty())return;
        b.addView(sectionLabel(title,""));
        for(String text:rows)b.addView(eventRow(text,1));
    }
    private void renderProviderPeople(LinearLayout b,JSONArray a,String title){
        if(a==null||a.length()==0)return;
        b.addView(sectionLabel(title,""));
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);
            if(x!=null){
                String name=pickText(x,"name","player_name","full_name","title");
                String role=pickText(x,"role","position","type","status");
                String avatar=pickText(x,"avatar_url","avatar","image_url","image","photo_url","photo","headshot_url","headshot","profile_image","player_image","playerImage","profile_photo","profilePhoto");
                String gender=pickText(x,"gender","sex","player_gender","playerGender","gender_type","genderType","gender_code","genderCode");
                JSONObject nested=x.optJSONObject("player");
                if(avatar.isEmpty() && nested!=null) avatar=pickText(nested,"avatar_url","avatar","image_url","image","photo_url","photo","headshot_url","headshot","profile_image","player_image","playerImage","profile_photo","profilePhoto");
                if(gender.isEmpty() && nested!=null) gender=pickText(nested,"gender","sex","player_gender","playerGender","gender_type","genderType","gender_code","genderCode");
                if(name.isEmpty() && nested!=null) name=pickText(nested,"name","player_name","full_name");
                if(name.isEmpty())name=flattenProviderObject(x);
                b.addView(playerRow(avatar,name,role,gender));
            }else b.addView(eventRow(String.valueOf(a.opt(i)),1));
        }
    }
    private void renderProviderTables(LinearLayout b,JSONObject raw,String[] keys,String title){
        JSONArray a=pickArray(raw,keys);
        if(a!=null&&a.length()>0){
            b.addView(sectionLabel(title,""));
            for(int i=0;i<a.length();i++){
                Object v=a.opt(i);
                String text=v instanceof JSONObject?flattenProviderObject((JSONObject)v):String.valueOf(v);
                if(!text.isEmpty())b.addView(eventRow(text,1));
            }
            return;
        }
        JSONObject o=pickObject(raw,keys);
        String text=flattenProviderObject(o);
        if(!text.isEmpty()){b.addView(sectionLabel(title,""));b.addView(eventRow(text,1));}
    }

    private String flattenProviderObject(JSONObject o){
        if(o==null)return "";
        StringBuilder b=new StringBuilder();
        appendFlatFields(b,o,0);
        return b.toString();
    }

    private void appendFlatFields(StringBuilder out,JSONObject o,int depth){
        if(o==null||depth>2)return;
        JSONArray names=o.names();
        if(names==null)return;
        for(int i=0;i<names.length();i++){
            String k=names.optString(i);
            Object v=o.opt(k);
            if(v==null)continue;
            if(v instanceof JSONObject){
                appendFlatFields(out,(JSONObject)v,depth+1);
                continue;
            }
            if(v instanceof JSONArray){
                JSONArray a=(JSONArray)v;
                for(int j=0;j<a.length() && j<4;j++){
                    Object item=a.opt(j);
                    if(item instanceof JSONObject) appendFlatFields(out,(JSONObject)item,depth+1);
                    else if(item!=null) appendFlatValue(out,k,String.valueOf(item));
                }
                continue;
            }
            String value=String.valueOf(v).trim();
            if(value.isEmpty() || "null".equalsIgnoreCase(value))continue;
            if(value.startsWith("http://")||value.startsWith("https://"))continue;
            appendFlatValue(out,k,value);
        }
    }

    private void appendFlatValue(StringBuilder out,String key,String value){
        if(out.length()>0)out.append(" • ");
        out.append(prettyKey(key)).append(": ").append(value);
    }

    private void addStatGrid(LinearLayout body,String[][] stats) {
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        for(String[] s:stats){
            LinearLayout c=new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setGravity(Gravity.CENTER);
            c.setPadding(dp(7),dp(8),dp(7),dp(8));
            c.setBackground(round(CARD,11));
            c.addView(tv(s[0],9,MUTED,true));
            c.addView(tv(s[1],14,TEXT,true));
            c.addView(tv(s[2],8.5f,MUTED,false));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(72),1);
            cp.setMargins(dp(2),0,dp(2),0);
            row.addView(c,cp);
        }
        body.addView(row,marginBottomParams(8));
    }

    private View statPairCard(String title,String value,String sub) {
        return statCard(title,value,sub);
    }

    private LinearLayout scoreboardCard(String teamName,String score,String state,String sub) {
        LinearLayout c=new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(13),dp(11),dp(13),dp(11));
        c.setBackground(round(CARD,14));
        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(tv(teamName,11,MUTED,true),new LinearLayout.LayoutParams(0,-2,1));
        top.addView(tv(state,10,CYAN,true));
        c.addView(top);
        c.addView(tv(score,25,TEXT,true));
        c.addView(tv(sub,9,MUTED,false));
        c.setLayoutParams(marginBottomParams(8));
        return c;
    }

    private LinearLayout playerRow(String avatarUrl,String name,String role,String gender) {
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(10),dp(12),dp(10));row.setBackground(round(CARD,14));
        ImageView avatar=new ImageView(this);avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);avatar.setBackground(circleDrawable(CARD_2));avatar.setClipToOutline(true);
        String normalizedGender=normalizePlayerGender(gender);
        // Always paint a deterministic fallback first. If the provider image loads successfully,
        // loadPlayerAvatar() replaces it. If the URL is invalid or unavailable, the fallback remains visible.
        avatar.setImageDrawable(initialsAvatar(name));
        if(avatarUrl!=null && !avatarUrl.trim().isEmpty()) loadPlayerAvatar(avatar,avatarUrl.trim(),name);
        row.addView(avatar,new LinearLayout.LayoutParams(dp(50),dp(50)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(12),0,0,0);
        info.addView(tv(name,12.5f,TEXT,true)); if(role!=null&&!role.trim().isEmpty())info.addView(tv(role,9.5f,MUTED,false));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        return row;
    }

    private String normalizePlayerGender(String value){
        String g=value==null?"":value.trim().toLowerCase(Locale.US);
        if(g.equals("m")||g.equals("male")||g.equals("man")||g.equals("men")||g.equals("boy")||g.equals("masculine")||g.equals("1")) return "male";
        if(g.equals("f")||g.equals("female")||g.equals("woman")||g.equals("women")||g.equals("girl")||g.equals("feminine")||g.equals("2")) return "female";
        return "";
    }

    private android.graphics.drawable.Drawable playerGenderAvatar(String name,String gender){
        int size=120;
        android.graphics.Bitmap bm=android.graphics.Bitmap.createBitmap(size,size,android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c=new android.graphics.Canvas(bm);
        android.graphics.Paint p=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        p.setColor(CARD_2); c.drawCircle(60,60,58,p);
        if("male".equals(gender)||"female".equals(gender)){
            p.setColor(TEXT);
            c.drawCircle(60,43,17,p);
            android.graphics.RectF body=new android.graphics.RectF(29,60,91,111);
            c.drawRoundRect(body,24,24,p);
            if("female".equals(gender)){
                p.setColor(TEXT);
                c.drawCircle(60,40,22,p);
                p.setColor(CARD_2);
                c.drawCircle(60,45,15,p);
                android.graphics.Path hair=new android.graphics.Path();
                hair.moveTo(37,43); hair.quadTo(31,67,38,82); hair.quadTo(46,72,45,52); hair.close(); c.drawPath(hair,p);
                hair=new android.graphics.Path();
                hair.moveTo(83,43); hair.quadTo(89,67,82,82); hair.quadTo(74,72,75,52); hair.close(); c.drawPath(hair,p);
            }
        } else {
            // Gender is intentionally not guessed when the provider does not supply it.
            return initialsAvatar(name);
        }
        return new android.graphics.drawable.BitmapDrawable(getResources(),bm);
    }

    private ImageView identityView(JSONObject entity,int sizeDp){
        ImageView image=new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setPadding(dp(3),dp(3),dp(3),dp(3));
        image.setBackgroundColor(Color.TRANSPARENT);
        String logo=pickText(entity,"logo","logo_url","image","image_url","badge","crest","team_logo","teamLogo","logoUrl","logoURL");
        String flag=pickText(entity,"flag","country_flag","countryCode","country_code","countryCode2","country_iso","countryIso","iso2");
        if(flag.isEmpty()){
            JSONObject country=pickObject(entity,"country","nation","nationality");
            flag=pickText(country,"code","iso2","countryCode","country_code","flag");
        }
        String name=pickText(entity,"name","team_name","short_name","shortName","teamName","player_name","full_name");
        // Initial/monogram is the deterministic default. A provider asset replaces it only
        // after a valid provider image/flag is actually available. This prevents blank identities.
        image.setImageDrawable(teamMonogramDrawable(name));
        if(!logo.isEmpty()){
            image.setBackground(circleDrawable(Color.argb(24,255,255,255)));
            image.setClipToOutline(true);
            loadImage(image,logo,sizeDp);
        } else if(!flag.isEmpty() && !"_".equals(flag.trim())) {
            String f=flag.trim();
            if(f.length()==2 && f.matches("[A-Za-z]{2}")) f=countryFlagEmoji(f);
            image.setImageDrawable(flagDrawable(f,Math.max(18,sizeDp/2)));
        }
        image.setContentDescription(name);
        return image;
    }

    private android.graphics.drawable.Drawable flagDrawable(String text,int sp){
        int w=150,h=96;
        android.graphics.Bitmap bm=android.graphics.Bitmap.createBitmap(w,h,android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c=new android.graphics.Canvas(bm);
        android.graphics.Paint bg=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        bg.setColor(Color.argb(24,255,255,255));
        c.drawRoundRect(2,2,w-2,h-2,10,10,bg);
        android.graphics.Paint p=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE); p.setTextSize(sp*2.0f); p.setTextAlign(android.graphics.Paint.Align.CENTER);
        p.setTypeface(android.graphics.Typeface.DEFAULT);
        android.graphics.Paint.FontMetrics fm=p.getFontMetrics();
        float y=h/2f-(fm.ascent+fm.descent)/2f;
        c.drawText(text,w/2f,y,p);
        return new android.graphics.drawable.BitmapDrawable(getResources(),bm);
    }

    private android.graphics.drawable.Drawable teamMonogramDrawable(String name){
        String[] parts=String.valueOf(name==null?"":name).trim().split("\\s+");
        String mon="";
        for(String part:parts){ if(!part.isEmpty()){ mon+=part.substring(0,1).toUpperCase(Locale.US); if(mon.length()>=2) break; }}
        if(mon.isEmpty()) mon="?";
        int size=120;
        android.graphics.Bitmap bm=android.graphics.Bitmap.createBitmap(size,size,android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c=new android.graphics.Canvas(bm);
        android.graphics.Paint bg=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG); bg.setColor(CARD_2); c.drawCircle(60,60,56,bg);
        android.graphics.Paint p=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG); p.setColor(TEXT); p.setTextSize(42); p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); p.setTextAlign(android.graphics.Paint.Align.CENTER);
        android.graphics.Paint.FontMetrics fm=p.getFontMetrics(); float y=60-(fm.ascent+fm.descent)/2; c.drawText(mon,60,y,p);
        return new android.graphics.drawable.BitmapDrawable(getResources(),bm);
    }

    private android.graphics.drawable.Drawable textDrawable(String text,int sp,int color,boolean bold){
        android.graphics.Bitmap bm=android.graphics.Bitmap.createBitmap(120,120,android.graphics.Bitmap.Config.ARGB_8888);android.graphics.Canvas c=new android.graphics.Canvas(bm);
        android.graphics.Paint p=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);p.setColor(Color.argb(38,255,255,255));c.drawCircle(60,60,58,p);p.setColor(color);p.setTextSize(sp*2.1f);p.setTypeface(bold?android.graphics.Typeface.DEFAULT_BOLD:android.graphics.Typeface.DEFAULT);p.setTextAlign(android.graphics.Paint.Align.CENTER);android.graphics.Paint.FontMetrics fm=p.getFontMetrics();float y=60-(fm.ascent+fm.descent)/2;c.drawText(text,60,y,p);return new android.graphics.drawable.BitmapDrawable(getResources(),bm);
    }

    private String countryFlagEmoji(String code){String c=code.toUpperCase(Locale.US); if(c.length()!=2)return c; return new String(Character.toChars(0x1F1E6+c.charAt(0)-'A'))+new String(Character.toChars(0x1F1E6+c.charAt(1)-'A'));}

    private void loadImage(ImageView target,String imageUrl,int sizeDp){
        network.execute(()->{
            android.graphics.Bitmap bitmap=null;
            HttpURLConnection c=null;
            try{
                URL u=new URL(imageUrl);
                c=(HttpURLConnection)u.openConnection();
                c.setConnectTimeout(5000);
                c.setReadTimeout(7000);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent","ONE-TV/2.4");
                c.connect();
                if(c.getResponseCode()>=200&&c.getResponseCode()<300){
                    try(InputStream in=c.getInputStream()){bitmap=android.graphics.BitmapFactory.decodeStream(in);}
                }
            }catch(Exception ignored){}finally{if(c!=null)c.disconnect();}
            if(bitmap==null) return;
            final android.graphics.Bitmap source=bitmap;
            final int canvasPx=Math.max(1,dp(sizeDp));
            final int maxPx=Math.max(1,Math.round(canvasPx*0.88f));
            final float scale=Math.min((float)maxPx/source.getWidth(),(float)maxPx/source.getHeight());
            final int dw=Math.max(1,Math.round(source.getWidth()*scale));
            final int dh=Math.max(1,Math.round(source.getHeight()*scale));
            final android.graphics.Bitmap normalized=android.graphics.Bitmap.createBitmap(canvasPx,canvasPx,android.graphics.Bitmap.Config.ARGB_8888);
            android.graphics.Canvas canvas=new android.graphics.Canvas(normalized);
            android.graphics.Paint paint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG|android.graphics.Paint.FILTER_BITMAP_FLAG);
            float left=(canvasPx-dw)/2f, top=(canvasPx-dh)/2f;
            canvas.drawBitmap(source,null,new android.graphics.RectF(left,top,left+dw,top+dh),paint);
            runOnUiThread(()->{target.setImageBitmap(normalized);target.setBackground(circleDrawable(Color.TRANSPARENT));});
        });
    }

    private GradientDrawable circleDrawable(int color){
        GradientDrawable d=new GradientDrawable(); d.setShape(GradientDrawable.OVAL); d.setColor(color); return d;
    }

    private GradientDrawable searchButtonBackground(){
        GradientDrawable d=new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(Color.argb(darkTheme()?34:22,255,255,255));
        d.setStroke(dp(1), Color.argb(darkTheme()?70:48,255,255,255));
        return d;
    }

    private android.graphics.drawable.Drawable initialsAvatar(String name){
        int size=96;
        android.graphics.Bitmap bm=android.graphics.Bitmap.createBitmap(size,size,android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas canvas=new android.graphics.Canvas(bm);
        android.graphics.Paint bgPaint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        bgPaint.setColor(BLUE); canvas.drawCircle(size/2f,size/2f,size/2f,bgPaint);
        String initials="";
        if(name!=null){String[] parts=name.trim().split("\\s+");for(String part:parts){if(!part.isEmpty()) initials+=part.substring(0,1).toUpperCase(Locale.US);if(initials.length()>=2)break;}}
        if(initials.isEmpty()) initials="•";
        android.graphics.Paint textPaint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.WHITE); textPaint.setTextSize(34); textPaint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); textPaint.setTextAlign(android.graphics.Paint.Align.CENTER);
        android.graphics.Paint.FontMetrics fm=textPaint.getFontMetrics();
        float y=size/2f-(fm.ascent+fm.descent)/2f; canvas.drawText(initials,size/2f,y,textPaint);
        return new android.graphics.drawable.BitmapDrawable(getResources(),bm);
    }

    private void loadPlayerAvatar(ImageView target,String imageUrl,String playerName){
        network.execute(()->{
            android.graphics.Bitmap bitmap=null;
            HttpURLConnection c=null;
            try{
                URL u=new URL(imageUrl); c=(HttpURLConnection)u.openConnection();
                c.setConnectTimeout(5000); c.setReadTimeout(7000); c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent","ONE-TV/2.2"); c.connect();
                if(c.getResponseCode()>=200 && c.getResponseCode()<300){
                    try(InputStream in=c.getInputStream()){bitmap=android.graphics.BitmapFactory.decodeStream(in);}
                }
            }catch(Exception ignored){} finally {if(c!=null)c.disconnect();}
            android.graphics.Bitmap result=bitmap;
            if(result!=null) runOnUiThread(()->{target.setImageBitmap(result);target.setBackground(circleDrawable(Color.TRANSPARENT));});
        });
    }

    private void showNews(boolean push) {
        stopMatchDetailAutoRefresh(); stopSportsAutoRefresh(); entertainmentContext=false;
        if(push) push("news"); screen="news"; clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar("News", false));
        TextView intro=tv("International sports & current affairs • original editorial summaries",10.5f,MUTED,false); intro.setPadding(dp(18),0,dp(18),dp(8)); page.addView(intro);
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(12),0,dp(12),dp(18));
        page.addView(list); addScroll(page); loadNews(list);
    }

    private void loadNews(LinearLayout list) {
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")||!remoteDataEnabled){list.addView(emptyStateCard("News unavailable","Connect the ONE TV backend to load verified news."));return;}
        network.execute(()->{
            try{JSONObject r=new JSONObject(getUrl(BACKEND_URL+"/news?limit=30"));JSONArray a=r.optJSONArray("items");runOnUiThread(()->{list.removeAllViews();if(a==null||a.length()==0){list.addView(emptyStateCard("No published news","The automatic editorial pipeline has not published a verified item yet."));return;}for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)list.addView(newsCard(x),marginBottomParams(9));}});}catch(Exception e){runOnUiThread(()->{list.removeAllViews();list.addView(emptyStateCard("News unavailable","Please try again later."));});}
        });
    }

    private View newsCard(JSONObject x) {
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(15),dp(13),dp(15),dp(13)); card.setBackground(round(CARD,17));
        LinearLayout meta=new LinearLayout(this); meta.setGravity(Gravity.CENTER_VERTICAL);
        TextView cat=tv(x.optString("category","News"),9.5f,CYAN,true); meta.addView(cat,new LinearLayout.LayoutParams(0,-2,1));
        String source=x.optString("source_name",""); if(!source.isEmpty())meta.addView(tv(source,8.5f,MUTED,false)); card.addView(meta);
        String imageUrl=x.optString("image_url", "");
        if (isValidProviderImageUrl(imageUrl)) {
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackground(round(CARD_2, 10));
            LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(-1, dp(154));
            imageParams.topMargin = dp(8);
            card.addView(image, imageParams);
            loadProviderPhoto(image, imageUrl);
        }
        TextView h=tv(x.optString("headline","News"),15.5f,TEXT,true);h.setPadding(0,dp(6),0,dp(4));h.setMaxLines(3);card.addView(h);
        String summary=x.optString("summary","");if(!summary.isEmpty()){TextView sm=tv(summary,10.5f,MUTED,false);sm.setMaxLines(4);card.addView(sm);}
        String published=x.optString("published_at","");if(!published.isEmpty()){TextView p=tv("Published • "+formatNewsTime(published),8.5f,MUTED,false);p.setPadding(0,dp(7),0,0);card.addView(p);}
        card.setOnClickListener(v->openNewsDetail(x)); return card;
    }

    private String formatNewsTime(String raw){try{java.text.SimpleDateFormat in=new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX",Locale.US);java.util.Date d=in.parse(raw);if(d!=null){java.text.SimpleDateFormat out=new java.text.SimpleDateFormat("d MMM • h:mm a",Locale.US);out.setTimeZone(java.util.TimeZone.getDefault());return out.format(d);}}catch(Exception ignored){}return raw.replace('T',' ');}

    private void openNewsDetail(JSONObject x){
        if(x==null)return; push("newsDetail:"+x.optString("id","")); screen="newsDetail"; clearContent(); LinearLayout page=page(); page.addView(selectedSectionBar("News",false));
        TextView cat=tv(x.optString("category","News"),10,CYAN,true);cat.setPadding(dp(18),dp(5),dp(18),dp(4));page.addView(cat);
        String articleImage=x.optString("image_url", "");
        if (isValidProviderImageUrl(articleImage)) {
            ImageView photo=new ImageView(this); photo.setScaleType(ImageView.ScaleType.CENTER_CROP); photo.setBackground(round(CARD_2,12));
            LinearLayout.LayoutParams photoParams=new LinearLayout.LayoutParams(-1,dp(210)); photoParams.setMargins(dp(14),dp(4),dp(14),dp(10));
            page.addView(photo,photoParams); loadProviderPhoto(photo,articleImage);
        }
        TextView h=tv(x.optString("headline","News"),22,TEXT,true);h.setPadding(dp(18),dp(3),dp(18),dp(8));page.addView(h);
        TextView src=tv("Source: "+x.optString("source_name",""),9,MUTED,false);src.setPadding(dp(18),0,dp(18),dp(10));page.addView(src);
        TextView body=tv(x.optString("body",x.optString("summary","")),11.5f,TEXT,false);body.setLineSpacing(dp(3),1.0f);body.setPadding(dp(18),0,dp(18),dp(10));page.addView(body);
        TextView sourceUrl=tv("Original source: "+x.optString("source_url",""),8.5f,MUTED,false);sourceUrl.setPadding(dp(18),dp(7),dp(18),dp(14));sourceUrl.setMaxLines(2);sourceUrl.setEllipsize(android.text.TextUtils.TruncateAt.END);page.addView(sourceUrl);addScroll(page);
    }

    private void showEntertainment(String category, boolean push) {
        entertainmentContext = true;
        if(push) push("ent:" + category);
        screen="entertainment";
        selectedEntertainment=category;
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar(category,true));
        buildPhotoFront(page);
    }

    /** Photo-only discovery. Images are shown only when the licensed news provider supplies a real image URL. */
    private void buildPhotoFront(LinearLayout page) {
        page.addView(sectionLabel("Photo Stories", "Provider-sourced editorial photography"));
        TextView note = tv("Only source-linked images are displayed. Unavailable images are omitted, never substituted.", 9.5f, MUTED, false);
        note.setPadding(dp(16), 0, dp(16), dp(10));
        page.addView(note);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), 0, dp(12), dp(18));
        page.addView(list);
        addScroll(page);
        if (BACKEND_URL == null || BACKEND_URL.contains("REPLACE") || !remoteDataEnabled) {
            list.addView(emptyStateCard("Photo stories unavailable", "Connect the licensed content provider to load real editorial images."));
            return;
        }
        network.execute(() -> {
            try {
                JSONObject response = new JSONObject(getUrl(BACKEND_URL + "/media?type=photo&limit=40"));
                JSONArray items = response.optJSONArray("items");
                runOnUiThread(() -> {
                    list.removeAllViews();
                    int shown = 0;
                    if (items != null) for (int i = 0; i < items.length(); i++) {
                        JSONObject item = items.optJSONObject(i);
                        if (item == null || !isValidProviderImageUrl(item.optString("media_url", ""))) continue;
                        list.addView(authorizedMediaPhotoCard(item), marginBottomParams(10));
                        shown++;
                    }
                    if (shown == 0) list.addView(emptyStateCard("No verified photos available", "The configured provider has not supplied publishable images for current stories."));
                });
            } catch (Exception e) {
                runOnUiThread(() -> { list.removeAllViews(); list.addView(emptyStateCard("Photo stories unavailable", "The content provider could not be reached.")); });
            }
        });
    }

    private View authorizedMediaPhotoCard(JSONObject item) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(12));
        card.setBackground(round(CARD, 16));
        ImageView photo = new ImageView(this);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photo.setBackground(round(CARD_2, 12));
        card.addView(photo, new LinearLayout.LayoutParams(-1, dp(178)));
        loadProviderPhoto(photo, item.optString("media_url", ""));
        TextView category = tv(item.optString("category", "Photo Story"), 9.5f, CYAN, true);
        category.setPadding(dp(2), dp(9), dp(2), dp(2));
        card.addView(category);
        TextView headline = tv(item.optString("title", ""), 15.5f, TEXT, true);
        headline.setPadding(dp(2), dp(2), dp(2), dp(4));
        card.addView(headline);
        String source = item.optString("source_name", "");
        if (!source.isEmpty()) card.addView(tv("Source: " + source, 8.5f, MUTED, false));
        String description = item.optString("description", "");
        if (!description.isEmpty()) card.addView(tv(description, 10f, MUTED, false));
        return card;
    }

    private boolean isValidProviderImageUrl(String value) {
        try {
            Uri uri = Uri.parse(value == null ? "" : value.trim());
            return "https".equalsIgnoreCase(uri.getScheme()) && !android.text.TextUtils.isEmpty(uri.getHost());
        } catch (Exception ignored) { return false; }
    }

    private View photoStoryCard(JSONObject item) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(12));
        card.setBackground(round(CARD, 16));
        ImageView photo = new ImageView(this);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photo.setBackground(round(CARD_2, 12));
        card.addView(photo, new LinearLayout.LayoutParams(-1, dp(178)));
        loadProviderPhoto(photo, item.optString("image_url", ""));
        TextView category = tv(item.optString("category", "Photo Story"), 9.5f, CYAN, true);
        category.setPadding(dp(2), dp(9), dp(2), dp(2));
        card.addView(category);
        TextView headline = tv(item.optString("headline", ""), 15.5f, TEXT, true);
        headline.setPadding(dp(2), dp(2), dp(2), dp(4));
        card.addView(headline);
        String source = item.optString("source_name", "");
        if (!source.isEmpty()) card.addView(tv("Photo source: " + source, 8.5f, MUTED, false));
        card.setOnClickListener(v -> openNewsDetail(item));
        return card;
    }

    private void loadProviderPhoto(ImageView target, String imageUrl) {
        if (!isValidProviderImageUrl(imageUrl)) return;
        network.execute(() -> {
            android.graphics.Bitmap bitmap = null;
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(imageUrl).openConnection();
                connection.setConnectTimeout(6000);
                connection.setReadTimeout(8000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("Accept", "image/*");
                connection.setRequestProperty("User-Agent", "OneTV/2.5.7");
                connection.connect();
                String type = connection.getContentType();
                if (connection.getResponseCode() >= 200 && connection.getResponseCode() < 300 && type != null && type.toLowerCase(Locale.US).startsWith("image/")) {
                    try (InputStream input = connection.getInputStream()) { bitmap = android.graphics.BitmapFactory.decodeStream(input); }
                }
            } catch (Exception ignored) { } finally { if (connection != null) connection.disconnect(); }
            android.graphics.Bitmap result = bitmap;
            if (result != null) runOnUiThread(() -> target.setImageBitmap(result));
        });
    }

    private void buildTvFront(LinearLayout page) {
        page.addView(sectionLabel("TV Channels", "Live channels"));
        LinearLayout list=new LinearLayout(this);
        list.setPadding(dp(12),0,dp(12),dp(12));
        list.setOrientation(LinearLayout.VERTICAL);
        if(!channels.isEmpty()){
            for(Channel c:channels){
                LinearLayout row=channelListRow(c);
                row.setOnClickListener(v->openChannel(c));
                list.addView(row, marginBottomParams(7));
            }
        }
        page.addView(list);
        addScroll(page);
    }

    private LinearLayout channelListRow(Channel c){
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(13),dp(10),dp(13),dp(10));
        row.setBackground(round(CARD,14));
        TextView icon=tv("📺",22,TEXT,false);
        row.addView(icon,new LinearLayout.LayoutParams(dp(46),dp(46)));
        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
        info.addView(tv(c.name,14,TEXT,true));
        String state=c.connected?"CONNECTED":"COMING SOON";
        info.addView(tv((c.program==null||c.program.isEmpty()?c.category:c.program)+" • "+state,10,c.connected?GREEN:MUTED,false));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(tv("›",24,MUTED,false));
        return row;
    }

    private void openChannel(Channel c){
        showSimple("Video sections unavailable", "OneTV is currently configured for sports data, news and provider-sourced photo content. Video playback sections have been removed from this app build.");
    }

    private void showComingSoon(Channel c){
        push("comingSoon"); clearContent(); screen="comingSoon";
        LinearLayout page=page();
        page.addView(selectedSectionBar(c.name,true));
        page.addView(sectionLabel("Coming soon","This channel is being prepared for playback."));
        page.addView(statCard("Channel status","COMING SOON", "Playback will be available when the channel is connected."));
        page.addView(detailRow("Category", c.category));
        page.addView(detailRow("Country", c.country));
        addScroll(page);
    }

    private void buildMediaFront(LinearLayout page,String type) {
        page.addView(sectionLabel(type,"Entertainment"));
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(12),0,dp(12),dp(18));
        boolean found=false;
        for(Channel c:channels){ if(type.equalsIgnoreCase(c.category)){ LinearLayout row=channelListRow(c); row.setOnClickListener(v->openChannel(c)); list.addView(row,marginBottomParams(7)); found=true; } }
        page.addView(list); addScroll(page);
    }

    private LinearLayout heroBanner(String title,String sub,String action,int accent) {
        LinearLayout h=new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);
        h.setPadding(dp(16),dp(15),dp(16),dp(15));
        h.setBackground(round(Color.rgb(24,34,55),17));
        TextView a=tv(title,19,TEXT,true);
        TextView b=tv(sub,11,MUTED,false);
        Button c=smallButton(action,accent);
        h.addView(a);h.addView(b);h.addView(c,new LinearLayout.LayoutParams(-2,dp(36)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(12),dp(8),dp(12),dp(10));h.setLayoutParams(p);
        return h;
    }

    private FrameLayout buildPlayerFrame(boolean live) {
        FrameLayout frame=new FrameLayout(this);
        frame.setBackgroundColor(Color.BLACK);
        playerFrame=frame;

        playerView=new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerShowTimeoutMs(3500);
        playerView.setControllerHideOnTouch(false);
        playerView.setControllerAutoShow(true);
        playerView.setShowRewindButton(false);
        playerView.setShowFastForwardButton(false);
        playerView.setShowPreviousButton(false);
        playerView.setShowNextButton(false);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        frame.addView(playerView,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout overlay=new LinearLayout(this);
        overlay.setGravity(Gravity.CENTER_VERTICAL);
        overlay.setPadding(dp(8),dp(8),dp(8),dp(8));
        overlay.setBackgroundColor(Color.argb(92,0,0,0));

        TextView play=playerButton("▶");
        TextView speed=playerButton("1x");
        TextView quality=playerButton("Auto");
        TextView volume=playerButton("🔊");
        TextView full=playerButton("⛶");
        overlay.addView(play,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(speed,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(quality,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(volume,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(full,new LinearLayout.LayoutParams(0,dp(44),1));
        FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(-1,dp(60),Gravity.BOTTOM);
        frame.addView(overlay,op);

        final float[] speedValue={1f};
        final boolean[] muted={false};
        final long[] lastTap={0L};
        final float[] tapX={0f};

        play.setOnClickListener(v->{
            if(player!=null){
                if(player.isPlaying()){player.pause();play.setText("▶");}
                else{player.play();play.setText("Ⅱ");}
            }
            showPlayerControls(overlay);
        });
        speed.setOnClickListener(v->{
            speedValue[0]+=0.25f; if(speedValue[0]>2f)speedValue[0]=0.75f;
            if(player!=null)player.setPlaybackParameters(new PlaybackParameters(speedValue[0]));
            speed.setText(String.format(Locale.US,"%.2gx",speedValue[0])); showPlayerControls(overlay);
        });
        quality.setOnClickListener(v->{
            String[] q={"Auto","1080p","720p","480p"};
            int next=0; String current=quality.getText().toString();
            for(int i=0;i<q.length;i++) if(q[i].equals(current)) next=(i+1)%q.length;
            quality.setText(q[next]); showPlayerControls(overlay);
        });
        volume.setOnClickListener(v->{
            if(muted[0]){
                muted[0]=false; if(player!=null)player.setVolume(1f); volume.setText("🔊");
                showVolumeSlider(frame, volume, player); return;
            }
            if(volumePopupVisible){
                muted[0]=true; if(player!=null)player.setVolume(0f); volume.setText("🔇"); hideVolumeSlider();
            }else{
                showVolumeSlider(frame, volume, player);
            }
            showPlayerControls(overlay);
        });
        full.setOnClickListener(v->{toggleFullscreen();showPlayerControls(overlay);});

        playerView.setOnTouchListener((v,event)->{
            if(event.getAction()==MotionEvent.ACTION_UP){
                long now=System.currentTimeMillis();
                float x=event.getX();
                if(now-lastTap[0] < 320){
                    if(x < playerView.getWidth()/2f) seekBy(-10000); else seekBy(10000);
                    lastTap[0]=0L;
                }else{
                    lastTap[0]=now; tapX[0]=x;
                    showPlayerControls(overlay);
                }
            }
            return false;
        });
        if(!live) overlay.setVisibility(View.GONE);
        return frame;
    }

    private void showVolumeSlider(FrameLayout anchor, TextView icon, ExoPlayer exo){
        hideVolumeSlider();
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(10),dp(8),dp(10),dp(8)); box.setGravity(Gravity.CENTER_VERTICAL);
        box.setBackground(round(darkTheme() ? Color.rgb(24,34,48) : CARD_2,14));
        SeekBar bar=new SeekBar(this); bar.setMax(100); bar.setProgress(exo==null?100:(int)(exo.getVolume()*100f));
        box.addView(bar,new LinearLayout.LayoutParams(dp(150),dp(42)));
        volumePopup=new android.widget.PopupWindow(box,dp(170),dp(58),true);
        volumePopup.setBackgroundDrawable(round(darkTheme() ? Color.rgb(24,34,48) : CARD_2,14)); volumePopup.setOutsideTouchable(true);
        volumePopup.setOnDismissListener(()->volumePopupVisible=false);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean from){if(from && exo!=null)exo.setVolume(p/100f); icon.setText(p==0?"🔇":"🔊");}
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
        });
        volumePopup.showAtLocation(anchor,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL,0,dp(74)); volumePopupVisible=true;
    }

    private void hideVolumeSlider(){if(volumePopup!=null){volumePopup.dismiss();volumePopup=null;} volumePopupVisible=false;}

    private TextView playerButton(String label) {
        TextView b=tv(label,11,TEXT,true);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        return b;
    }

    private void showPlayerControls(View overlay) {
        if(overlay==null)return;
        overlay.setVisibility(View.VISIBLE);
        playerUiHandler.removeCallbacksAndMessages(null);
        playerUiHandler.postDelayed(()->overlay.setVisibility(View.GONE),3500);
    }

    private void seekBy(long delta) {
        if(player==null)return;
        long pos=Math.max(0,player.getCurrentPosition()+delta);
        long duration=player.getDuration();
        if(duration>0)pos=Math.min(pos,duration);
        player.seekTo(pos);
    }

    private void playFirstChannel() {
        for(Channel c:channels){ if(c.connected && c.url!=null && !c.url.isEmpty()){ playChannel(c); return; } }
        if(!channels.isEmpty()) showComingSoon(channels.get(0));
        else showSimple("Live TV","No channel is configured. Add an authorized source from the backend.");
    }

    private void playChannel(Channel c) {
        push("player"); screen="player"; clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar(c.name,true));
        FrameLayout frame=buildPlayerFrame(true);
        page.addView(frame,new LinearLayout.LayoutParams(-1,dp(260)));
        addScroll(page);
        if(player!=null)player.release();
        player=new ExoPlayer.Builder(this).build(); playerView.setPlayer(player);
        try{player.setMediaItem(MediaItem.fromUri(Uri.parse(c.url)));player.prepare();player.play();}catch(Exception ignored){}
    }

    private void loadRemoteAppConfig() {
        if (BACKEND_URL == null || BACKEND_URL.contains("REPLACE")) return;
        network.execute(() -> {
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/config"));
                JSONObject cfg = root.optJSONObject("config");
                if (cfg == null) return;
                remoteAppConfig = cfg;
                sportsRefreshMs = Math.max(5000L, cfg.optLong("sports_refresh_ms", sportsRefreshMs));
                cricketDetailRefreshMs = Math.max(5000L, cfg.optLong("cricket_detail_refresh_ms", cricketDetailRefreshMs));
                notificationsRefreshMs = Math.max(5000L, cfg.optLong("notifications_refresh_ms", notificationsRefreshMs));
                remoteLiveStatusLabel = cfg.optString("status_live", remoteLiveStatusLabel);
                remoteUpcomingStatusLabel = cfg.optString("status_upcoming", remoteUpcomingStatusLabel);
                remoteFinishedStatusLabel = cfg.optString("status_finished", remoteFinishedStatusLabel);
                remoteLiveBadgeLabel = cfg.optString("status_live_badge", remoteLiveBadgeLabel);
                remoteLiveScoreEnabled = cfg.optBoolean("live_score_refresh_enabled", true);
                remoteDataEnabled = cfg.optBoolean("remote_data_enabled", true);
            } catch (Exception ignored) {}
        });
    }

    private String remoteStatusLabel(String normalized) {
        if ("LIVE".equalsIgnoreCase(normalized)) return remoteLiveStatusLabel;
        if ("UPCOMING".equalsIgnoreCase(normalized)) return remoteUpcomingStatusLabel;
        if ("FINISHED".equalsIgnoreCase(normalized)) return remoteFinishedStatusLabel;
        return normalized == null ? "" : normalized;
    }

    private void loadChannels() {
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")) return;
        network.execute(()->{
            try{
                JSONObject root=new JSONObject(getUrl(BACKEND_URL+"/channels")); JSONArray arr=root.optJSONArray("channels");
                if(arr==null)return; List<Channel> temp=new ArrayList<>();
                for(int i=0;i<arr.length();i++){ JSONObject o=arr.optJSONObject(i); if(o==null)continue;
                    String url=o.optString("url",o.optString("streamUrl",o.optString("sourceUrl","")));
                    boolean connected=o.optBoolean("connected",!url.isEmpty());
                    temp.add(new Channel(o.optInt("id",0),o.optString("name","Channel"),url,o.optString("program",o.optString("programName","")),o.optString("category","TV"),o.optString("country","International"),connected));
                }
                runOnUiThread(()->{channels.clear();channels.addAll(temp); if("entertainment".equals(screen)){clearContent();LinearLayout p=page();p.addView(selectedSectionBar(selectedEntertainment,true)); buildPhotoFront(p);}});
            }catch(Exception ignored){}
        });
    }

    private void loadAdConfig() {
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")) return;
        network.execute(()->{
            try {
                JSONObject cfg=new JSONObject(getUrl(BACKEND_URL+"/ads"));
                adConfig=cfg;
                JSONArray active=cfg.optJSONArray("activePlatforms");
                boolean admobActive=false;
                if(active!=null) for(int i=0;i<active.length();i++){ JSONObject a=active.optJSONObject(i); if(a!=null && "admob".equalsIgnoreCase(a.optString("platform_key"))){ admobActive=true; break; } }
                final boolean enabled=admobActive;
                runOnUiThread(()->{ if(adRow!=null) adRow.setVisibility(enabled?View.VISIBLE:View.GONE); });
            } catch(Exception ignored) {}
        });
    }

    private void showMenuPage(boolean push) {
        entertainmentContext = false;
        stopMatchDetailAutoRefresh();
        stopSportsAutoRefresh();
        if (push) push("menu");
        menuOriginScreen = screen == null ? "home" : screen;
        screen = "menu";
        if (menuScrim != null || menuDrawer != null) closeMenuDrawer(false);
        if (headerView != null) headerView.setVisibility(View.GONE);
        if (fixedBottom != null) fixedBottom.setVisibility(View.GONE);
        contentHost.removeAllViews();

        FrameLayout overlay = new FrameLayout(this);
        menuScrim = new View(this);
        menuScrim.setBackgroundColor(Color.argb(165, 0, 0, 0));
        menuScrim.setOnClickListener(v -> closeMenuDrawer(true));
        overlay.addView(menuScrim, new FrameLayout.LayoutParams(-1, -1));

        menuDrawer = new LinearLayout(this);
        menuDrawer.setOrientation(LinearLayout.VERTICAL);
        menuDrawer.setPadding(dp(18), dp(16), dp(16), dp(10));
        menuDrawer.setElevation(dp(14));
        menuDrawer.setBackground(menuDrawerBackground());
        FrameLayout.LayoutParams drawerLp = new FrameLayout.LayoutParams(
                (int)(getResources().getDisplayMetrics().widthPixels * 0.82f), -1);
        drawerLp.gravity = Gravity.LEFT;
        overlay.addView(menuDrawer, drawerLp);
        buildPremiumMenuDrawer(menuDrawer);
        contentHost.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
    }

    private GradientDrawable menuDrawerBackground() {
        int[] colors = darkTheme()
                ? new int[]{Color.rgb(8,8,31), Color.rgb(7,13,30), Color.rgb(18,5,31)}
                : new int[]{Color.rgb(31,31,32), Color.rgb(40,40,42), Color.rgb(35,29,40)};
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        g.setCornerRadius(dp(2));
        return g;
    }

    private void buildPremiumMenuDrawer(LinearLayout drawer) {
        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        brandRow.setPadding(dp(2), dp(2), 0, dp(12));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.onetv_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        brandRow.addView(logo, new LinearLayout.LayoutParams(dp(88), dp(62)));

        LinearLayout brandText = new LinearLayout(this);
        brandText.setOrientation(LinearLayout.VERTICAL);
        brandText.setPadding(dp(8), 0, 0, 0);
        TextView title = tv("One TV", 25, TEXT, true);
        title.setIncludeFontPadding(false);
        brandText.addView(title);
        TextView tagline = tv("Sports • Entertainment • News", 10.5f, MUTED, false);
        tagline.setPadding(0, dp(3), 0, 0);
        brandText.addView(tagline);
        brandRow.addView(brandText, new LinearLayout.LayoutParams(0, -2, 1));

        ImageView close = headerIcon(R.drawable.ic_close, "Close menu");
        close.setColorFilter(TEXT, android.graphics.PorterDuff.Mode.SRC_IN);
        close.setPadding(dp(7), dp(7), dp(7), dp(7));
        close.setOnClickListener(v -> closeMenuDrawer(true));
        brandRow.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));
        drawer.addView(brandRow);

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        boolean menuHome = "home".equals(menuOriginScreen);
        boolean menuSports = "sportsHome".equals(menuOriginScreen) || "sport".equals(menuOriginScreen) || "match".equals(menuOriginScreen) || menuOriginScreen.startsWith("sport:");
        boolean menuEntertainment = menuOriginScreen.startsWith("ent:") || "entertainment".equals(menuOriginScreen);
        boolean menuNews = "news".equals(menuOriginScreen) || "newsDetail".equals(menuOriginScreen);

        body.addView(drawerMenuItem(R.drawable.ic_home, "Home", menuHome, null, v -> closeMenuAndOpen(() -> showHome(false))));
        body.addView(drawerMenuItem(R.drawable.ic_sports, "Sports", menuSports, "⌄", v -> closeMenuAndOpen(() -> showSportsHome(false))));
        body.addView(drawerMenuItem(R.drawable.ic_entertainment, "Photo Stories", menuEntertainment, null, v -> closeMenuAndOpen(() -> showEntertainment("Photos", false))));
        body.addView(drawerMenuItem(R.drawable.ic_news, "News", menuNews, null, v -> closeMenuAndOpen(() -> showNews(false))));
        body.addView(drawerDivider());
        body.addView(drawerMenuItem(R.drawable.ic_schedule, "Schedule", false, null, v -> closeMenuAndOpen(() -> showSports("cricket", false, "upcoming"))));
        body.addView(drawerMenuItem(R.drawable.ic_favorite, "Favorites", false, null, v -> closeMenuAndOpen(() -> showFavorites(false))));
        body.addView(drawerMenuItem(R.drawable.ic_notifications, "Notifications", false, null, v -> closeMenuAndOpen(() -> showNotifications(false))));
        body.addView(drawerDivider());
        body.addView(drawerMenuItem(R.drawable.ic_settings, "Settings", false, null, v -> closeMenuAndOpen(() -> showSettings(false))));
        body.addView(drawerMenuItem(R.drawable.ic_help, "Help & Support", false, null, v -> closeMenuAndOpen(() -> showSupport(false))));
        body.addView(drawerMenuItem(R.drawable.ic_info, "About One TV", false, null, v -> closeMenuAndOpen(() -> showAboutOneTv(true))));

        scrollView.addView(body, new ScrollView.LayoutParams(-1, -2));
        drawer.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private View drawerDivider() {
        View line = new View(this);
        line.setBackgroundColor(Color.argb(55, 150, 160, 210));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(dp(12), dp(8), dp(12), dp(8));
        line.setLayoutParams(lp);
        return line;
    }

    private LinearLayout drawerMenuItem(int iconRes, String title, boolean active, String trailing, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), 0, dp(10), 0);
        row.setMinimumHeight(dp(58));
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(click);
        if (active) {
            GradientDrawable selected = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Color.rgb(220,22,61), Color.rgb(65,15,76)});
            selected.setCornerRadius(dp(15));
            row.setBackground(selected);
        } else row.setBackgroundColor(Color.TRANSPARENT);

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        icon.setColorFilter(TEXT, android.graphics.PorterDuff.Mode.SRC_IN);
        row.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(44)));

        TextView label = tv(title, 15.5f, TEXT, active);
        label.setGravity(Gravity.CENTER_VERTICAL);
        label.setIncludeFontPadding(false);
        row.addView(label, new LinearLayout.LayoutParams(0, -1, 1));

        if (trailing != null) {
            TextView chevron = tv(trailing, 24, MUTED, false);
            chevron.setGravity(Gravity.CENTER);
            row.addView(chevron, new LinearLayout.LayoutParams(dp(36), -1));
        }
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(58));
        rp.setMargins(0, dp(2), 0, dp(2));
        row.setLayoutParams(rp);
        return row;
    }

    private void closeMenuAndOpen(Runnable action) {
        closeMenuDrawer(false);
        action.run();
    }

    private void closeMenuDrawer(boolean restorePrevious) {
        menuScrim = null;
        menuDrawer = null;
        if (contentHost != null) contentHost.removeAllViews();
        if (headerView != null) headerView.setVisibility(View.VISIBLE);
        if (fixedBottom != null) fixedBottom.setVisibility(View.VISIBLE);
        if (restorePrevious) {
            if (!history.empty()) {
                String prev = history.pop();
                if ("home".equals(prev)) showHome(false);
                else if ("sportsHome".equals(prev)) showSportsHome(false);
                else if ("news".equals(prev)) showNews(false);
                else if (prev.startsWith("sport:")) showSports(prev.substring(6), false);
                else if (prev.startsWith("ent:")) showEntertainment(prev.substring(4), false);
                else if ("notifications".equals(prev)) showNotifications(false);
                else if ("favorites".equals(prev)) showFavorites(false);
                else if ("support".equals(prev)) showSupport(false);
                else if ("about".equals(prev)) showAboutOneTv(false);
                else if ("privacy".equals(prev)) showPrivacyPolicy(false);
                else if ("terms".equals(prev)) showTermsOfUse(false);
                else if ("licenses".equals(prev)) showLicenses(false);
                else if ("settings".equals(prev)) showSettings(false);
                else if ("playback".equals(prev)) showPlaybackSettings(false);
                else showHome(false);
            } else showHome(false);
        }
    }

    private void showSupport(boolean push) {
        entertainmentContext = false;
        if (push) push("support");
        screen = "support";
        clearContent();
        LinearLayout page = page();
        page.addView(selectedSectionBar("Help & Support", false));
        page.addView(sectionLabel("Help & Support", "Get help with playback, data and app issues"));
        page.addView(menuAction("◌", "Report a Problem", "Review the issue details before contacting support",
                v -> showSimple("Report a Problem", "Include the screen, match or channel affected and the exact error message when reporting a problem.")));
        page.addView(menuAction("?", "FAQ", "Common questions about ONE TV",
                v -> showSimple("FAQ", "Refresh the current page and retry a verified source when a stream or score is unavailable.")));
        page.addView(menuAction("ⓘ", "App Information", "ONE TV by USHA IT",
                v -> showAboutOneTv(true)));
        addScroll(page);
    }

    private void showFavorites(boolean push) {
        entertainmentContext = false;
        if (push) push("favorites");
        screen = "favorites";
        clearContent();
        LinearLayout page = page();
        page.addView(selectedSectionBar("Favorites", false));
        page.addView(sectionLabel("Favorites", "Your saved matches"));
        JSONArray saved = getFavoriteMatches();
        if (saved.length() == 0) page.addView(emptyStateCard("No favorites yet", "Open a verified match and tap the star icon to save it."));
        else {
            LinearLayout list = new LinearLayout(this);
            list.setOrientation(LinearLayout.VERTICAL);
            list.setPadding(dp(12), dp(4), dp(12), dp(18));
            for (int i = 0; i < saved.length(); i++) {
                JSONObject m = saved.optJSONObject(i);
                if (m != null) list.addView(sportsListCard(m, false));
            }
            page.addView(list);
        }
        addScroll(page);
    }

    private String favoriteKey(JSONObject m) {
        String id = pickText(m, "id", "providerMatchId", "matchId", "eventId");
        return id.isEmpty() ? canonicalMatchTitle(m) : id;
    }

    private JSONArray getFavoriteMatches() {
        JSONArray out = new JSONArray();
        String raw = prefs == null ? "[]" : prefs.getString("favorite_matches", "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject m = a.optJSONObject(i);
                if (m != null) out.put(m);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private boolean isFavorite(JSONObject m) {
        String key = favoriteKey(m);
        JSONArray a = getFavoriteMatches();
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x != null && key.equals(favoriteKey(x))) return true;
        }
        return false;
    }

    private void toggleFavorite(JSONObject m) {
        if (prefs == null || m == null) return;
        JSONArray a = getFavoriteMatches();
        String key = favoriteKey(m);
        JSONArray out = new JSONArray();
        boolean removed = false;
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x == null) continue;
            if (key.equals(favoriteKey(x))) removed = true;
            else out.put(x);
        }
        if (!removed) out.put(m);
        prefs.edit().putString("favorite_matches", out.toString()).apply();
    }

    private void showSettings(boolean push){
        entertainmentContext = false;
        if(push) push("settings"); screen="settings"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar("Settings",false));
        page.addView(sectionLabel("Settings","App preferences"));
        page.addView(themeSettingRow());
        page.addView(menuAction("🔔","Notifications","Allow ONE TV match and backend alerts",v->requestNotificationPermission()));
        page.addView(playbackSettingsRow());
        page.addView(menuAction("ⓘ","About","App information and legal details",v->showAboutOneTv(true)));
        addScroll(page);
    }

    private LinearLayout themeSettingRow() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(10), dp(12), dp(10));
        row.setBackground(round(CARD, 16));

        TextView ico = tv("◐", 21, TEXT, false);
        ico.setGravity(Gravity.CENTER);
        row.addView(ico, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.addView(tv("Theme", 14, TEXT, true));
        info.addView(tv("Choose your viewing theme", 10, MUTED, false));
        row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));

        TextView value = tv(darkTheme() ? "Dark" : "Default", 12, TEXT, true);
        value.setGravity(Gravity.CENTER);
        value.setPadding(dp(14), 0, dp(8), 0);
        value.setCompoundDrawablesWithIntrinsicBounds(0,0,android.R.drawable.arrow_down_float,0);
        value.setCompoundDrawablePadding(dp(5));
        value.setBackground(round(CARD_2, 13));
        value.setMinimumWidth(dp(108));
        value.setContentDescription("Theme selector");
        value.setOnClickListener(v -> showThemePopup(value));
        row.addView(value, new LinearLayout.LayoutParams(dp(118), dp(42)));

        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.setMargins(dp(12),0,dp(12),dp(8));
        row.setLayoutParams(rp);
        return row;
    }

    private void showThemePopup(TextView anchor){
        final android.widget.PopupWindow popup = new android.widget.PopupWindow(this);
        LinearLayout menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setPadding(dp(6),dp(6),dp(6),dp(6));
        menu.setBackground(round(PANEL,16));
        String[] options={"Default","Dark"};
        for(String option:options){
            TextView item=tv(option,12,TEXT,true);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(14),0,dp(14),0);
            item.setBackground(round(option.equals(anchor.getText().toString())?CARD_2:PANEL,11));
            item.setOnClickListener(v->{
                boolean dark="Dark".equals(((TextView)v).getText().toString());
                prefs.edit().putBoolean("dark_theme",dark).apply();
                popup.dismiss();
                setPalette(dark);
                showSettings(false);
            });
            menu.addView(item,new LinearLayout.LayoutParams(dp(136),dp(44)));
        }
        popup.setContentView(menu);
        popup.setWidth(dp(148));
        popup.setHeight(dp(104));
        popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(true);
        popup.setFocusable(true);
        popup.setElevation(dp(8));
        popup.showAsDropDown(anchor, -dp(18), dp(6));
    }

    private LinearLayout playbackSettingsRow() {
        LinearLayout row = menuAction("▶", "Playback", "Player behavior and quality", v -> {});
        row.setOnClickListener(v -> showPlaybackSettings(true));
        return row;
    }

    private void showPlaybackSettings(boolean push) {
        entertainmentContext = false;
        if(push) push("playback"); screen="playback"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar("Playback",false));
        page.addView(sectionLabel("Playback","Controls used when a channel or video is opened"));
        page.addView(menuAction("▶","Autoplay","Start connected playback automatically",v->showSimple("Autoplay","Autoplay is used for connected sources only.")));
        page.addView(menuAction("HD","Quality","Use the highest quality supplied by the source",v->showSimple("Quality","Quality choices are available in the player when the source provides multiple variants.")));
        page.addView(menuAction("🔊","Volume","Open the volume slider from the player",v->showSimple("Volume","Tap the volume icon to open the slider. Tap it again to mute or unmute.")));
        page.addView(menuAction("⛶","Fullscreen","Use landscape/fullscreen playback when supported",v->showSimple("Fullscreen","Fullscreen is available from the player controls.")));
        addScroll(page);
    }

    private boolean darkTheme(){ return prefs != null && prefs.getBoolean("dark_theme", false); }

    private void setPalette(boolean dark){
        if(dark){
            // Dark: keep the existing cool, slightly lighter content surfaces.
            BG=Color.rgb(5,10,17); PANEL=Color.rgb(13,25,39); CARD=Color.rgb(20,35,51); CARD_2=Color.rgb(24,42,61); BLUE=Color.rgb(28,126,245); CYAN=Color.rgb(0,205,190); PURPLE=Color.rgb(119,52,245); TEXT=Color.WHITE; MUTED=Color.rgb(174,188,203); GREEN=Color.rgb(0,194,142); RED=Color.rgb(244,63,81);
        }else{
            // Default: premium charcoal presentation instead of the previous pale/light palette.
            BG=Color.rgb(34,34,34); PANEL=Color.rgb(40,40,43); CARD=Color.rgb(47,47,51); CARD_2=Color.rgb(56,56,61); BLUE=Color.rgb(91,140,255); CYAN=Color.rgb(66,214,197); PURPLE=Color.rgb(155,108,255); TEXT=Color.rgb(245,245,247); MUTED=Color.rgb(181,184,193); GREEN=Color.rgb(57,217,138); RED=Color.rgb(255,77,103);
        }
        if(root!=null) root.setBackgroundColor(BG);
        if(fixedBottom!=null) fixedBottom.setBackgroundColor(BG);
        if(adRow!=null){
            adRow.setBackgroundColor(BG);
            for(int i=0;i<adRow.getChildCount();i++) adRow.getChildAt(i).setBackground(round(PANEL,12));
        }
        if(footer!=null) footer.setTextColor(MUTED);
        if(headerView!=null) headerView.setBackgroundColor(dark?Color.rgb(4,9,15):BG);
        if(headerSlogan!=null) headerSlogan.setTextColor(TEXT);
        if(headerMenu!=null) headerMenu.setColorFilter(TEXT, android.graphics.PorterDuff.Mode.SRC_IN);
        if(headerSearch!=null){ headerSearch.setBackground(circleDrawable(dark?CARD:CARD_2)); headerSearch.setColorFilter(TEXT, android.graphics.PorterDuff.Mode.SRC_IN); }
        if(headerNotification!=null) headerNotification.setColorFilter(TEXT, android.graphics.PorterDuff.Mode.SRC_IN);
        if(getWindow()!=null){
            // Both palettes are intentionally dark-premium, so keep system-bar icons light.
            getWindow().setStatusBarColor(dark?Color.rgb(4,9,15):BG);
            getWindow().setNavigationBarColor(dark?Color.BLACK:BG);
            int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    private void showNotifications(boolean push) {
        entertainmentContext = false;
        if(push) push("notifications"); screen="notifications"; clearContent();
        if(notificationBadge!=null) notificationBadge.setVisibility(View.GONE);
        LinearLayout page=page(); page.addView(selectedSectionBar("Notifications",false));
        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(18),dp(8),dp(18),dp(18));
        page.addView(list);
        addScroll(page);
        loadNotificationsInto(list);
    }

    private void loadNotifications(){
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")) return;
        network.execute(()->{try{JSONObject r=new JSONObject(getUrl(BACKEND_URL+"/notifications")); int count=r.optInt("unreadCount",0); runOnUiThread(()->{if(notificationBadge!=null){notificationBadge.setText(count>0?String.valueOf(Math.min(count,99)):"");notificationBadge.setVisibility(count>0?View.VISIBLE:View.GONE);}}); if(count>0) postLocalNotification(r.optJSONArray("items"));}catch(Exception ignored){}});
        handler.postDelayed(this::loadNotifications,notificationsRefreshMs);
    }

    private void loadNotificationsInto(LinearLayout list){
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")) return;
        network.execute(()->{
            try{
                JSONObject r=new JSONObject(getUrl(BACKEND_URL+"/notifications"));
                JSONArray items=r.optJSONArray("items");
                runOnUiThread(()->{
                    list.removeAllViews();
                    if(items==null||items.length()==0){
                        list.addView(emptyStateCard("No notifications","New alerts will appear here when they arrive."));
                        return;
                    }
                    for(int i=0;i<items.length();i++){
                        JSONObject n=items.optJSONObject(i);
                        if(n==null) continue;
                        final JSONObject notice=n;
                        boolean hasTarget=!n.optString("sport","").trim().isEmpty()
                                && !n.optString("matchId",n.optString("providerMatchId","")).trim().isEmpty();
                        View.OnClickListener click=hasTarget
                                ? v->{ try { openNotificationTarget(notice); } catch (Exception ignored) { showNotifications(false); } }
                                : null;
                        list.addView(notificationCard(n.optString("icon","ℹ"),n.optString("title","ONE TV"),
                                n.optString("body",n.optString("html","")),click));
                    }
                });
            }catch(Exception ignored){ runOnUiThread(list::removeAllViews); }
        });
    }

    private void openNotificationTarget(JSONObject n){
        if(n==null){ showNotifications(false); return; }
        String sport=n.optString("sport","").trim().toLowerCase(Locale.US);
        String id=n.optString("matchId",n.optString("providerMatchId","")).trim();
        if(sport.isEmpty() || id.isEmpty() || BACKEND_URL==null || BACKEND_URL.contains("REPLACE")){ showNotifications(false); return; }
        try{
            JSONObject target=new JSONObject();
            target.put("id",id); target.put("sport",sport);
            target.put("title",n.optString("title","Match Centre"));
            target.put("status",n.optString("status",""));
            JSONObject home=n.optJSONObject("home"); JSONObject away=n.optJSONObject("away");
            if(home!=null)target.put("home",home); if(away!=null)target.put("away",away);
            selectedMatch=target;
        }catch(Exception ignored){ showNotifications(false); return; }
        try { showMatchDetail(true); } catch(Exception ignored) { showNotifications(false); }
    }

    private void postLocalNotification(JSONArray items){
        if(items==null||items.length()==0)return; JSONObject n=items.optJSONObject(0); if(n==null)return;
        String key=n.optString("id",n.optString("title","")); String last=prefs.getString("last_notice_key",""); if(key.equals(last))return; prefs.edit().putString("last_notice_key",key).apply();
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); if(nm==null)return;
        Intent i=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(this,"onetv_updates").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(n.optString("title","ONE TV")).setContentText(n.optString("body",n.optString("html",""))).setAutoCancel(true).setContentIntent(pi);
        nm.notify(++notificationSequence,b.build());
    }

    private void createNotificationChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); if(nm!=null)nm.createNotificationChannel(new NotificationChannel("onetv_updates","ONE TV Updates",NotificationManager.IMPORTANCE_DEFAULT));}}
    private void requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},901); else showSimple("Notifications","Notifications are enabled for this Android version.");}

    private LinearLayout notificationCard(String icon,String title,String sub,View.OnClickListener click) {
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14),dp(12),dp(14),dp(12));
        row.setBackground(round(CARD,16));
        if(click!=null){
            row.setClickable(true);
            row.setOnClickListener(click);
        }
        row.addView(tv(icon,20,TEXT,false),new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout info=new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.addView(tv(title,14,TEXT,true));
        if(sub!=null && !sub.trim().isEmpty()) info.addView(tv(sub,10,MUTED,false));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        if(click!=null) row.addView(tv("›",22,MUTED,false));
        row.setLayoutParams(marginBottomParams(8));
        return row;
    }

    private LinearLayout emptyStateCard(String title,String subtitle){
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(18),dp(22),dp(18),dp(22));
        card.setBackground(round(CARD,16));
        card.addView(tv(title,15,TEXT,true));
        card.addView(tv(subtitle,10,MUTED,false));
        return card;
    }

    private void showAppearance(boolean push){ showSettings(push); }

    private void showSearch(boolean push,String scope) { showSearch(push,scope,""); }

    private void showSearch(boolean push,String scope,String initialQuery) {
        entertainmentContext = false;
        if(push) push("search"); screen="search"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar("Search",false));

        LinearLayout searchWrap=new LinearLayout(this);
        searchWrap.setGravity(Gravity.CENTER_VERTICAL);
        searchWrap.setPadding(dp(14),0,dp(7),0);
        GradientDrawable searchBg=round(CARD,15);
        searchBg.setStroke(dp(1),Color.argb(darkTheme()?48:30,255,255,255));
        searchWrap.setBackground(searchBg);

        EditText input=new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setHint("Search matches, teams, channels or programs");
        input.setTextSize(13);
        input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        input.setPadding(0,0,dp(6),0);
        input.setBackgroundColor(Color.TRANSPARENT);
        searchWrap.addView(input,new LinearLayout.LayoutParams(0,dp(46),1));
        ImageButton searchButton=new ImageButton(this);
        searchButton.setImageResource(R.drawable.ic_search);
        searchButton.setColorFilter(TEXT,android.graphics.PorterDuff.Mode.SRC_IN);
        searchButton.setScaleType(ImageView.ScaleType.CENTER);
        searchButton.setPadding(dp(6),dp(6),dp(6),dp(6));
        searchButton.setBackgroundColor(Color.TRANSPARENT);
        searchButton.setContentDescription("Search");
        searchWrap.addView(searchButton,new LinearLayout.LayoutParams(dp(40),dp(40)));

        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(48));
        ip.setMargins(dp(14),dp(5),dp(14),dp(10));
        page.addView(searchWrap,ip);

        LinearLayout results=new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        results.setPadding(dp(14),0,dp(14),dp(18));
        page.addView(results,new LinearLayout.LayoutParams(-1,-2));

        if(initialQuery!=null && !initialQuery.trim().isEmpty()){
            input.setText(initialQuery.trim());
            input.setSelection(input.length());
            loadSearchResults(results,input.getText().toString());
        }

        input.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence c,int st,int count,int after){}
            public void onTextChanged(CharSequence c,int st,int before,int count){ if(c.length()==0) loadSearchResults(results,""); }
            public void afterTextChanged(Editable e){}
        });
        searchButton.setOnClickListener(v->{ loadSearchResults(results,input.getText().toString()); ((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0); });
        input.setOnEditorActionListener((v,action,event)->{
            if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){
                loadSearchResults(results,input.getText().toString());
                ((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(input.getWindowToken(),0);
                return true;
            }
            return false;
        });

        addScroll(page);
        
    }

    private void loadSearchResults(LinearLayout results,String query){
        String q=query==null?"":query.trim();
        lastSearchQuery=q;
        final int requestId=++searchRequestSequence;
        results.removeAllViews();
        if(q.isEmpty()) return;
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")){
            results.addView(emptyStateCard("Search unavailable","Connect the ONE TV backend to search live data."));
            return;
        }
        network.execute(()->{
            try{
                JSONObject r=new JSONObject(getUrl(BACKEND_URL+"/search?q="+Uri.encode(q)));
                JSONArray items=r.optJSONArray("items");
                runOnUiThread(()->{
                    if(requestId!=searchRequestSequence) return;
                    results.removeAllViews();
                    if(items==null||items.length()==0){
                        results.addView(emptyStateCard("No results found","Try a team, match, channel or program name."));
                        return;
                    }
                    for(int i=0;i<items.length();i++){
                        JSONObject item=items.optJSONObject(i);
                        if(item==null) continue;
                        String sub=item.optString("subtitle","");
                        if("match".equals(item.optString("kind",""))){
                            String schedule=formatMatchSchedule(item.optString("time",item.optString("startsAt","")));
                            if(!schedule.isEmpty()) sub=(sub.isEmpty()?"":sub+" • ")+schedule;
                        }
                        results.addView(searchResult(item.optString("icon","•"),
                                item.optString("title",item.optString("name","")),
                                sub,
                                v->openSearchItem(item)));
                    }
                });
            }catch(Exception e){
                runOnUiThread(()->{
                    if(requestId!=searchRequestSequence) return;
                    results.removeAllViews();
                    results.addView(emptyStateCard("Search unavailable","Please try again in a moment."));
                });
            }
        });
    }

    private void openSearchItem(JSONObject item){String kind=item.optString("kind",""); if("match".equals(kind)){selectedMatch=item;showMatchDetail(true);} else if("channel".equals(kind)){showSimple("Video sections unavailable", "OneTV is currently configured for sports data, news and provider-sourced photo content.");} else showContentDetail(item.optString("title","Content"),item.optString("subtitle","Entertainment"),true);}

    private LinearLayout searchResult(String icon,String title,String sub,View.OnClickListener click) {
        LinearLayout r=contentRow(title,sub);
        r.setOnClickListener(click);
        return r;
    }

    private void showContentDetail(String title,String type,boolean push) {
        entertainmentContext = "entertainment".equalsIgnoreCase(type);
        if(push) push("content:"+title); screen="content"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar(title,false));
        page.addView(sectionLabel(type,"Entertainment"));
        page.addView(sectionLabel("Content",type));
        page.addView(statCard("Playback","Coming soon","Playback will be available when this content is connected."));
        addScroll(page);
    }

    private void showSimple(String title,String subtitle) {
        if (title != null && title.toLowerCase(Locale.US).contains("about")) { showAboutOneTv(true); return; }
        clearContent();
        screen="simple";
        LinearLayout page=page();
        page.addView(selectedSectionBar(title,false));
        page.addView(sectionLabel(title,subtitle));
        addScroll(page);
    }

    private void showAboutOneTv(boolean pushHistory) {
        if (pushHistory) push("about");
        entertainmentContext=false; screen="about"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar("About OneTV",false));
        LinearLayout identity=new LinearLayout(this); identity.setOrientation(LinearLayout.VERTICAL);
        identity.setGravity(Gravity.CENTER); identity.setPadding(dp(20),dp(24),dp(20),dp(20));
        identity.setBackground(round(PANEL,20));
        ImageView oneLogo=new ImageView(this); oneLogo.setImageResource(R.drawable.onetv_logo);
        oneLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        identity.addView(oneLogo,new LinearLayout.LayoutParams(dp(150),dp(82)));
        identity.addView(tv("OneTV - All in One",18,TEXT,true));
        identity.addView(tv("Version "+BuildConfig.VERSION_NAME,12,MUTED,false));
        View gap=new View(this); identity.addView(gap,new LinearLayout.LayoutParams(1,dp(18)));
        TextView developed=tv("Developed and owned by",12,MUTED,false); identity.addView(developed);
        ImageView ushaLogo=new ImageView(this); ushaLogo.setImageResource(R.drawable.usha_it_full_logo_white);
        ushaLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams ulp=new LinearLayout.LayoutParams(dp(190),dp(62)); ulp.setMargins(0,dp(5),0,dp(5)); identity.addView(ushaLogo,ulp);
        identity.addView(tv("© 2026 USHA IT. All Rights Reserved.",11,MUTED,false));
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2); ip.setMargins(dp(14),dp(12),dp(14),dp(12)); page.addView(identity,ip);
        page.addView(menuAction("▤","Privacy Policy","How OneTV handles information and permissions",v->showPrivacyPolicy(true)));
        page.addView(menuAction("§","Terms of Use","Rules and conditions for using OneTV",v->showTermsOfUse(true)));
        page.addView(menuAction("©","Licenses & Attributions","Third-party services, data and media credits",v->showLicenses(true)));
        addScroll(page);
    }

    private void legalSection(LinearLayout page,String heading,String body) {
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15),dp(13),dp(15),dp(13)); card.setBackground(round(CARD,14));
        TextView h=tv(heading,14,TEXT,true); h.setPadding(0,0,0,dp(7)); card.addView(h);
        TextView b=tv(body,12,MUTED,false); b.setLineSpacing(dp(3),1f); card.addView(b);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(dp(12),dp(4),dp(12),dp(5)); page.addView(card,lp);
    }

    private void showPrivacyPolicy(boolean pushHistory) {
        if(pushHistory) push("privacy"); entertainmentContext=false; screen="privacy"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar("Privacy Policy",false));
        page.addView(sectionLabel("Privacy Policy","OneTV • USHA IT • Effective 3 November 2026"));
        legalSection(page,"1. Who we are","OneTV is a sports, entertainment and news application developed and owned by USHA IT (\"USHA IT\", \"we\", \"us\" or \"our\"). This policy explains how information may be handled when you use the app and its connected services.");
        legalSection(page,"2. Guest use and account information","Basic browsing is designed to work without requiring an account. Favorites, reminders, preferences and viewing history may be stored locally on your device. If optional account or synchronization features are enabled in a future release, only information needed to provide that feature and information you choose to submit will be processed under the applicable in-app flow.");
        legalSection(page,"3. Information processed","Depending on the features you use, the app and its service providers may process app settings, saved-item identifiers, reminder preferences, content and playback requests, device/app version, network address, timestamps, crash or diagnostic details, and security/rate-limit signals. We do not ask for contacts, microphone, camera or precise location for ordinary browsing. Android notification permission is requested only for notifications where required.");
        legalSection(page,"4. Sports, news and entertainment providers","OneTV requests data and media metadata from configured third-party providers, such as sports-data, news, catalogue, streaming and image services. Those providers may receive technical request information under their own privacy policies. OneTV preserves source attribution where required. Provider availability and data coverage may vary.");
        legalSection(page,"5. Advertising","The app may display advertising in its dedicated bottom/footer advertising area. Advertising partners may use device identifiers, cookies or similar technologies, where supported and permitted by Android and applicable law, to deliver, measure or limit advertising. Ad availability and partner behavior are governed by the relevant partner policies. OneTV does not intentionally place a second floating or player-covering ad container.");
        legalSection(page,"6. Storage, cache and retention","The app may cache provider responses and permitted media metadata to improve performance and reduce repeated requests. Local favorites, reminders, preferences and history remain on the device until cleared or the app data is removed, unless an enabled sync feature states otherwise. Server logs and operational records are retained only as reasonably needed for service operation, security, troubleshooting and legal obligations.");
        legalSection(page,"7. Why information is used","Information is used to operate the app, return requested content, maintain saved preferences, schedule reminders, protect services against abuse, diagnose errors, measure service reliability, manage advertising and comply with legal obligations. We do not sell personal information as a standalone product.");
        legalSection(page,"8. Sharing and service providers","Information may be processed by hosting, database, content, sports-data, news, streaming, analytics or advertising providers that support OneTV. It may also be disclosed where required by law, to protect users or the service, or as part of a business transfer subject to applicable law. Provider credentials and private API keys are kept server-side and are not intended to be exposed in the app.");
        legalSection(page,"9. Children","OneTV is a general-audience service and is not designed to knowingly collect personal information from children. A parent or guardian who believes a child has submitted personal information may contact us through the app's Help & Support section so the matter can be reviewed.");
        legalSection(page,"10. Security and international processing","We use reasonable technical and organizational safeguards appropriate to the service, including encrypted transport where supported, access controls and server-side secret storage. No internet transmission or storage system can be guaranteed completely secure. Providers may process information in countries other than your own.");
        legalSection(page,"11. Your choices and controls","You can manage Android notification permission in device settings, clear app storage/cache through Android settings, and remove locally saved favorites or history where those controls are available. You may stop using the app at any time. Requests about information processed by OneTV can be submitted through Help & Support.");
        legalSection(page,"12. Third-party links and policies","Content may identify or link to third-party sources. Their services are not controlled by USHA IT. Review their privacy notices and terms before using them. A source's presence in OneTV does not mean USHA IT owns that source or its content.");
        legalSection(page,"13. Changes to this policy","We may update this policy when the app, providers or applicable requirements change. The revised policy will be published in the app with an updated effective date. Continued use after an update means the updated notice is available to you; it does not remove rights provided by applicable law.");
        legalSection(page,"14. Contact","For privacy questions or requests, use Help & Support in OneTV and select Report a Problem or the available contact route. Please include \"Privacy Request\" in the message. Do not include passwords, payment credentials or API keys.");
        legalSection(page,"Developer and owner","USHA IT • © 2026 USHA IT. All Rights Reserved.");
        addScroll(page);
    }

    private void showTermsOfUse(boolean pushHistory) {
        if(pushHistory) push("terms"); entertainmentContext=false; screen="terms"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar("Terms of Use",false));
        page.addView(sectionLabel("Terms of Use","OneTV • USHA IT • Effective 3 November 2026"));
        legalSection(page,"1. Agreement","These Terms govern your access to and use of OneTV, developed and owned by USHA IT. By accessing or using the app, you agree to these Terms. If you do not agree, stop using the app.");
        legalSection(page,"2. Service description","OneTV provides interfaces for sports information, live scores, schedules, commentary, news, entertainment catalogues and, where a valid authorized source is available, in-app audio/video playback. Features and regional availability may change as providers and technical capabilities change.");
        legalSection(page,"3. Eligibility and permitted use","Use OneTV only where you are legally permitted to do so. You must comply with applicable laws, these Terms and the rules of each connected provider. You may use the app for personal, lawful, non-commercial viewing and information unless USHA IT expressly authorizes another use in writing.");
        legalSection(page,"4. Accounts and device data","Basic browsing may be available as a guest. If optional account features are introduced or enabled, provide accurate information, protect your credentials and use sign-out controls on shared devices. You are responsible for activity performed through your account or device, subject to applicable law.");
        legalSection(page,"5. Content, data and accuracy","Scores, fixtures, commentary, news, schedules, images, programme details and other metadata are supplied by third-party sources and may be delayed, incomplete, corrected or unavailable. OneTV displays provider-backed information and does not guarantee uninterrupted availability or absolute accuracy. Official competition and broadcaster sources should be consulted for authoritative decisions.");
        legalSection(page,"6. Streaming and media rights","Playback is provided only when a valid source is configured and its use is permitted. Content may be subject to copyright, broadcast rights, territorial limits, subscription requirements, DRM, expiry and provider conditions. You must not bypass DRM, access controls, geographic restrictions or technical protections, and must not record, redistribute, rebroadcast, download or commercially exploit content unless the rights holder expressly permits it.");
        legalSection(page,"7. Acceptable use","You must not misuse the service, interfere with its operation, probe or attack its infrastructure, scrape or automate requests in a harmful way, reverse engineer except where law permits, upload malicious material, impersonate another person, infringe intellectual property, or attempt to access private APIs, credentials or administrative systems.");
        legalSection(page,"8. Intellectual property and attribution","The OneTV name, app design, software and USHA IT branding are owned by or licensed to USHA IT. Third-party names, logos, data, artwork and media remain the property of their respective owners. Provider attribution and notices must not be removed or misrepresented. No ownership of third-party content is transferred to you.");
        legalSection(page,"9. Advertising","Advertisements may appear only in the app's designated advertising placement and are supplied by advertising partners. Interaction with an advertisement, offer or advertiser is between you and the relevant third party. USHA IT does not endorse an advertiser merely by displaying an eligible advertisement.");
        legalSection(page,"10. Third-party services","OneTV may rely on external data, hosting, streaming, news, catalogue and advertising services. Those services may have separate terms, privacy notices, fees or eligibility rules. USHA IT is not responsible for services it does not operate, subject to rights and responsibilities that cannot be excluded by law.");
        legalSection(page,"11. Availability and changes","We may update, suspend or discontinue features, sources or parts of the service for maintenance, provider changes, security, legal compliance or operational reasons. We will not promise that every event, channel, video, region or provider will always be available. Cached data may be marked stale when a provider is unavailable.");
        legalSection(page,"12. Disclaimers","To the extent permitted by applicable law, OneTV is provided on an \"as available\" basis. We do not warrant uninterrupted access, error-free operation, provider accuracy, availability of a particular stream, or suitability for a particular purpose. Nothing in these Terms excludes a guarantee or right that cannot legally be excluded.");
        legalSection(page,"13. Limitation of liability","To the maximum extent permitted by applicable law, USHA IT will not be liable for indirect, incidental, special or consequential loss arising from third-party provider outages, inaccurate or delayed feeds, network failures, device incompatibility or unavailable media. These Terms do not limit liability where such limitation is prohibited by law, including applicable consumer rights.");
        legalSection(page,"14. Suspension and termination","We may restrict access where reasonably necessary to protect the service, comply with law, respond to abuse or enforce these Terms. You may stop using OneTV at any time and uninstall it through your device settings.");
        legalSection(page,"15. Changes to these Terms","We may revise these Terms as the service evolves. The current version and effective date will be shown in the app. Material changes will be presented through an appropriate in-app notice where reasonably practicable.");
        legalSection(page,"16. Governing law and mandatory rights","These Terms are subject to applicable laws. Any governing-law or dispute-resolution provision will operate only to the extent permitted by the law applicable to you. Nothing here removes mandatory consumer or statutory rights.");
        legalSection(page,"17. Contact","For questions about these Terms, use OneTV's Help & Support section and submit a report mentioning \"Terms of Use\". Do not send passwords, payment details or private API credentials.");
        legalSection(page,"Developer and owner","USHA IT • © 2026 USHA IT. All Rights Reserved.");
        addScroll(page);
    }

    private void showLicenses(boolean pushHistory) {
        if(pushHistory) push("licenses"); entertainmentContext=false; screen="licenses"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar("Licenses & Attributions",false));
        page.addView(sectionLabel("Third-party acknowledgements","Ownership remains with each respective provider."));
        legalSection(page,"Data and media providers","Sports data, news metadata, entertainment catalogues, images, logos and video streams may be supplied by third-party providers. Attribution and permitted-use notices are displayed or maintained according to each provider's requirements. Availability depends on active, authorized integrations.");
        legalSection(page,"Software components","OneTV uses third-party Android libraries and services. Their respective copyright and license terms remain applicable. A complete component/license inventory should be generated from the release dependency manifest before public distribution.");
        legalSection(page,"USHA IT","OneTV is developed and owned by USHA IT. © 2026 USHA IT. All Rights Reserved.");
        addScroll(page);
    }

    private void clearContent() {
        hideVolumeSlider();
        if(contentHost!=null)contentHost.removeAllViews();
        if(statusText!=null)statusText=null;
        updateBottomNavigation();
    }

    private LinearLayout page() {
        LinearLayout p=new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundColor(BG);
        return p;
    }

    private void scheduleSportsAutoRefresh() {
        handler.removeCallbacks(sportsRefreshTask);
        handler.postDelayed(sportsRefreshTask, sportsRefreshMs);
    }

    private void stopSportsAutoRefresh() {
        handler.removeCallbacks(sportsRefreshTask);
        activeSportsPage = null;
    }

    private void addSportsRefreshScroll(LinearLayout page, Runnable refreshAction) {
        contentHost.removeAllViews();
        SwipeRefreshLayout swipe = new SwipeRefreshLayout(this);
        swipe.setColorSchemeColors(BLUE);
        swipe.setOnRefreshListener(() -> {
            refreshAction.run();
            handler.postDelayed(() -> swipe.setRefreshing(false), 700);
        });
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));
        swipe.addView(scroll, new SwipeRefreshLayout.LayoutParams(-1, -1));
        contentHost.addView(swipe, new FrameLayout.LayoutParams(-1, -1));
    }

    private void addScroll(LinearLayout page) {
        contentHost.removeAllViews();
        page.setPadding(page.getPaddingLeft(),page.getPaddingTop(),page.getPaddingRight(),dp(14));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));

        // Global pull-to-refresh is enabled throughout ONE TV except the Entertainment sector.
        // Sports pages use their dedicated refresh wrapper, while this wrapper covers Home and
        // all other non-entertainment scrollable screens.
        if (!entertainmentContext) {
            SwipeRefreshLayout swipe = new SwipeRefreshLayout(this);
            swipe.setColorSchemeColors(BLUE);
            swipe.setOnRefreshListener(() -> {
                refreshCurrentNonEntertainmentScreen();
                handler.postDelayed(() -> swipe.setRefreshing(false), 700);
            });
            swipe.addView(scroll, new SwipeRefreshLayout.LayoutParams(-1, -1));
            contentHost.addView(swipe, new FrameLayout.LayoutParams(-1, -1));
        } else {
            contentHost.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        }
    }

    private void refreshCurrentNonEntertainmentScreen() {
        if (entertainmentContext) return;
        if ("home".equals(screen)) {
            showHome(false);
        } else if ("news".equals(screen)) {
            showNews(false);
        } else if ("notifications".equals(screen)) {
            showNotifications(false);
        } else if ("settings".equals(screen)) {
            showSettings(false);
        } else if ("playback".equals(screen)) {
            showPlaybackSettings(false);
        } else if ("search".equals(screen)) {
            showSearch(false, "", lastSearchQuery);
        } else if ("match".equals(screen)) {
            showMatchDetail(false);
        } else if ("menu".equals(screen)) {
            showMenuPage(false);
        } else if ("favorites".equals(screen)) {
            showFavorites(false);
        } else if ("support".equals(screen)) {
            showSupport(false);
        }
    }

    private LinearLayout modeRow() {
        LinearLayout row=new LinearLayout(this);
        row.setPadding(dp(10),dp(5),dp(10),dp(5));
        TextView s=modeButton("SPORTS",BLUE); s.setOnClickListener(v->showSportsHome(true));
        TextView e=modeButton("PHOTOS",PURPLE); e.setOnClickListener(v->showEntertainment("Photos",true));
        TextView n=modeButton("NEWS",GREEN); n.setOnClickListener(v->showNews(true));
        TextView[] buttons={s,e,n};
        for(TextView b:buttons){LinearLayout.LayoutParams lp=weighted();lp.height=dp(46);lp.setMargins(dp(4),0,dp(4),0);row.addView(b,lp);}
        return row;
    }

    private TextView sportsProviderAttribution() {
        TextView t=tv("Powered by SportsScore",9,MUTED,false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0,dp(2),0,dp(4));
        t.setContentDescription("Sports data provider attribution");
        return t;
    }

    private View selectedSectionBar(String name, boolean entertainment) {
        LinearLayout bar=new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(18),dp(7),dp(18),dp(4));
        boolean sportsSection = !entertainment && (
                "Cricket".equalsIgnoreCase(name) || "Football".equalsIgnoreCase(name)
                || "Basketball".equalsIgnoreCase(name) || "Tennis".equalsIgnoreCase(name)
                || "Series".equalsIgnoreCase(name) || "Teams".equalsIgnoreCase(name)
                || "Players".equalsIgnoreCase(name) || "Venues".equalsIgnoreCase(name)
                || "Competitions".equalsIgnoreCase(name) || "Leagues".equalsIgnoreCase(name)
                || "Standings".equalsIgnoreCase(name) || "H2H".equalsIgnoreCase(name)
                || "Tournaments".equalsIgnoreCase(name) || "Rankings".equalsIgnoreCase(name)
                || "Draws".equalsIgnoreCase(name) || "Highlights".equalsIgnoreCase(name));
        if(sportsSection){
            TextView icon=tv(sportGlyph(name),22,TEXT,false);
            icon.setGravity(Gravity.CENTER);
            bar.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(44)));
        } else if(entertainment){
            TextView icon=tv("▣",20,TEXT,false);
            icon.setGravity(Gravity.CENTER);
            bar.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(44)));
        }
        TextView title=tv(name,20,TEXT,true);
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title,new LinearLayout.LayoutParams(0,dp(44),1));
        return bar;
    }

    private String sportGlyph(String name){
        if(name==null)return "◈";
        if(name.equalsIgnoreCase("Cricket"))return "◉";
        if(name.equalsIgnoreCase("Football"))return "●";
        if(name.equalsIgnoreCase("Basketball"))return "◌";
        if(name.equalsIgnoreCase("Tennis"))return "◍";
        return "◇";
    }

    private LinearLayout modeTabs(LinearLayout page, String sport, String[] modes) {
        LinearLayout row=new LinearLayout(this);
        row.setPadding(dp(12),dp(4),dp(12),dp(8));
        for(String mode:modes){
            TextView b=tab(mode, mode.equalsIgnoreCase(matchMode));
            b.setOnClickListener(v->{
                matchMode=mode.toLowerCase(Locale.US);
                remoteMatches=null;
                for(int i=0;i<row.getChildCount();i++){
                    View child=row.getChildAt(i);
                    if(child instanceof TextView){
                        TextView t=(TextView)child;
                        boolean active=t.getText().toString().equalsIgnoreCase(mode);
                        t.setTextColor(active?TEXT:MUTED);
                        t.setBackground(round(active?BLUE:CARD,18));
                    }
                }
                renderSportList(page,sport);
                activeSportsPage = page;
                activeSportsHome = false;
                loadSportsFromBackend(sport,matchMode,page);
                scheduleSportsAutoRefresh();
            });
            LinearLayout.LayoutParams lp=weighted();
            lp.height=dp(48);
            lp.setMargins(dp(5),0,dp(5),0);
            row.addView(b,lp);
        }
        return row;
    }

    private View sectionLabel(String title, String sub) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(18), dp(8), dp(18), dp(6));
        TextView t = tv(title, 18, TEXT, true);
        TextView s = tv(sub, 10, MUTED, false);
        wrap.addView(t);
        if (sub != null && !sub.isEmpty()) wrap.addView(s);
        return wrap;
    }

    private TextView modeButton(String label,int accent) {
        TextView b=tv(label,14,TEXT,true);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setBackground(round(CARD,18));
        b.setPadding(0,0,0,0);
        return b;
    }

    private LinearLayout featureTile(String icon,String name,int accent) {
        LinearLayout c=new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setMinimumHeight(dp(62));
        c.setPadding(dp(1),dp(2),dp(1),dp(2));
        c.setBackground(round(CARD_2,12));
        TextView i=tv(icon,20,TEXT,false);
        i.setGravity(Gravity.CENTER);
        TextView n=tv(name,10.5f,TEXT,true);
        n.setGravity(Gravity.CENTER);
        n.setSingleLine(true);
        n.setEllipsize(android.text.TextUtils.TruncateAt.END);
        c.addView(i,new LinearLayout.LayoutParams(-1,dp(29)));
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(16));
        np.setMargins(dp(1),dp(1),dp(1),0);
        c.addView(n,np);
        LinearLayout.LayoutParams p=weighted();
        p.setMargins(dp(5),0,dp(5),0);
        c.setLayoutParams(p);
        return c;
    }

    private LinearLayout.LayoutParams featureTileParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(62), 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        return p;
    }

    private LinearLayout homeSearchBox() {
        LinearLayout wrap=new LinearLayout(this);
        wrap.setGravity(Gravity.CENTER_VERTICAL);
        wrap.setPadding(dp(14),0,dp(8),0);
        GradientDrawable bg=round(CARD,15);
        bg.setStroke(dp(1),Color.argb(darkTheme()?42:28,255,255,255));
        wrap.setBackground(bg);

        EditText input=new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setHint("Search matches, teams, channels or programs");
        input.setTextSize(12.5f);
        input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        input.setPadding(0,0,dp(6),0);
        input.setBackgroundColor(Color.TRANSPARENT);
        wrap.addView(input,new LinearLayout.LayoutParams(0,dp(46),1));

        ImageButton button=new ImageButton(this);
        button.setImageResource(R.drawable.ic_search);
        button.setColorFilter(TEXT,android.graphics.PorterDuff.Mode.SRC_IN);
        button.setScaleType(ImageView.ScaleType.CENTER);
        button.setPadding(dp(7),dp(7),dp(7),dp(7));
        button.setBackgroundColor(Color.TRANSPARENT);
        button.setContentDescription("Search");
        wrap.addView(button,new LinearLayout.LayoutParams(dp(38),dp(38)));

        View.OnClickListener go=v->{
            String q=input.getText().toString().trim();
            showSearch(true,"all",q);
        };
        button.setOnClickListener(go);
        input.setOnEditorActionListener((v,action,event)->{
            if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){go.onClick(v);return true;}
            return false;
        });

        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));
        lp.setMargins(dp(14),dp(2),dp(14),dp(8));
        wrap.setLayoutParams(lp);
        return wrap;
    }

    private LinearLayout scoreTeam(String flag,String name,String score) {
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setGravity(Gravity.CENTER);
        b.addView(tv(flag,18,TEXT,false));
        b.addView(tv(name,14,TEXT,true));
        b.addView(tv(score,14,TEXT,true));
        return b;
    }

    private LinearLayout channelTile(String name) {
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);
        c.setPadding(dp(4),dp(8),dp(4),dp(8));c.setBackground(round(CARD,10));
        TextView icon=tv("▣",22,BLUE,true);icon.setGravity(Gravity.CENTER);
        TextView n=tv(name,9,TEXT,true);n.setGravity(Gravity.CENTER);n.setMaxLines(2);
        c.addView(icon,new LinearLayout.LayoutParams(-1,dp(32)));c.addView(n);
        return c;
    }

    private LinearLayout menuAction(String icon, String title, String subtitle, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(13), dp(12), dp(13), dp(12));
        row.setBackground(round(CARD, 14));
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(click);
        TextView ico = tv(icon, 22, TEXT, false);
        ico.setGravity(Gravity.CENTER);
        row.addView(ico, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(4), 0, dp(6), 0);
        TextView t = tv(title, 14, TEXT, true);
        t.setMaxLines(2);
        TextView st = tv(subtitle, 10, MUTED, false);
        st.setMaxLines(2);
        info.addView(t);
        info.addView(st);
        row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        TextView arrow = tv("›", 24, MUTED, false);
        arrow.setGravity(Gravity.CENTER);
        row.addView(arrow, new LinearLayout.LayoutParams(dp(30), dp(48)));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.setMargins(dp(12), 0, dp(12), dp(8));
        row.setLayoutParams(rp);
        return row;
    }

    private LinearLayout contentRow(String title,String type) {
        LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(12),dp(9),dp(12),dp(9));r.setBackground(round(CARD,12));
        TextView icon=tv(type.equals("News")?"▤":"▶",20,TEXT,false);r.addView(icon,new LinearLayout.LayoutParams(dp(45),dp(45)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.addView(tv(title,13,TEXT,true));info.addView(tv(type+" • ONE TV",10,MUTED,false));
        r.addView(info,new LinearLayout.LayoutParams(0,-2,1));r.addView(tv("›",24,MUTED,false));
        return r;
    }

    private TextView tab(String label,boolean active) {
        TextView b=tv(label,12.5f,active?TEXT:MUTED,true);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setMinWidth(dp(78));
        b.setBackground(round(active?BLUE:CARD,18));
        b.setPadding(dp(10),0,dp(10),0);
        return b;
    }

    private Button smallButton(String label,int color) {
        Button b=new Button(this);b.setText(label);b.setTextSize(10);b.setTextColor(TEXT);b.setAllCaps(false);b.setMinHeight(0);b.setMinWidth(0);b.setPadding(dp(12),0,dp(12),0);b.setBackground(round(color,18));return b;
    }

    private TextView eventRow(String value,int n) {
        TextView t=tv(value,12,TEXT,false);t.setPadding(dp(12),dp(11),dp(12),dp(11));t.setBackground(round(CARD,12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(6));t.setLayoutParams(p);return t;
    }

    private View statCard(String title,String value,String sub) {
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(13),dp(10),dp(13),dp(10));r.setBackground(round(CARD,12));
        r.addView(tv(title,10,MUTED,true));r.addView(tv(value,16,TEXT,true));r.addView(tv(sub,10,MUTED,false));return r;
    }

    private LinearLayout tableBox() {
        LinearLayout t=new LinearLayout(this);t.setOrientation(LinearLayout.VERTICAL);t.setBackground(round(CARD,12));return t;
    }

    private LinearLayout tableRow(String[] values,boolean header) {
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(6),dp(6),dp(6),dp(6));
        for(int i=0;i<values.length;i++){TextView v=tv(values[i],header?8.5f:9.5f,header?MUTED:TEXT,header);v.setGravity(i==0?Gravity.LEFT:Gravity.CENTER);row.addView(v,new LinearLayout.LayoutParams(0,dp(32),i==0?2.3f:1));}
        row.setBackgroundColor(header?Color.rgb(25,45,59):Color.TRANSPARENT);return row;
    }

    private LinearLayout detailRow(String left,String right) {
        LinearLayout r=new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(12),dp(9),dp(12),dp(9));
        r.setBackground(round(CARD,10));
        TextView l=tv(left,11.5f,TEXT,true);
        l.setSingleLine(true);
        l.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView rr=tv(right,11.5f,MUTED,false);
        rr.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        rr.setMaxLines(3);
        rr.setEllipsize(android.text.TextUtils.TruncateAt.END);
        r.addView(l,new LinearLayout.LayoutParams(0,-2,0.34f));
        r.addView(rr,new LinearLayout.LayoutParams(0,-2,0.66f));
        return r;
    }

    private LinearLayout.LayoutParams marginBottomParams(int dp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, this.dp(dp));
        return p;
    }

    private LinearLayout.LayoutParams weighted() { return new LinearLayout.LayoutParams(0, -2, 1); }

    private JSONObject team(JSONObject m, boolean home) {
        String side = home ? "home" : "away";
        JSONObject t = m.optJSONObject(side);
        if(t == null) t = m.optJSONObject(side + "Team");
        if(t == null) t = m.optJSONObject(home ? "home_team" : "away_team");
        if(t != null) return t;
        JSONArray teams = m.optJSONArray("teams");
        if(teams != null && teams.length() >= 2) {
            JSONObject x = teams.optJSONObject(home ? 0 : 1);
            if(x != null) return x;
        }
        JSONObject raw = rawProvider(m);
        t = raw.optJSONObject(side);
        if(t == null) t = raw.optJSONObject(home ? "home_team" : "away_team");
        if(t != null) return t;
        JSONArray participants = raw.optJSONArray("participants");
        if(participants != null && participants.length() >= 2) {
            JSONObject x = participants.optJSONObject(home ? 0 : 1);
            if(x != null) return x;
        }
        return new JSONObject();
    }

    private String sportName(String s) {
        if(s==null)return "Sports";
        if("football".equalsIgnoreCase(s)||"soccer".equalsIgnoreCase(s))return "Football";
        if("basketball".equalsIgnoreCase(s))return "Basketball";
        if("tennis".equalsIgnoreCase(s))return "Tennis";
        if("baseball".equalsIgnoreCase(s))return "Baseball";
        return "Cricket";
    }

    private void push(String state) {
        if(screen!=null&&!screen.equals(state))history.push(screen);
    }

    @Override public void onBackPressed() {
        if(fullscreen){exitFullscreen();return;}
        if("menu".equals(screen) && menuDrawer != null){
            closeMenuDrawer(true);
            return;
        }
        if(!history.empty()){
            String prev=history.pop();
            if("home".equals(prev))showHome(false);
            else if("sportsHome".equals(prev))showSportsHome(false);
            else if("news".equals(prev))showNews(false);
            else if(prev.startsWith("sport:"))showSports(prev.substring(6),false);
            else if(prev.startsWith("ent:"))showEntertainment(prev.substring(4),false);
            else if("match".equals(prev)&&selectedMatch!=null)showMatchDetail(false);
            else if("notifications".equals(prev))showNotifications(false);
            else if("favorites".equals(prev))showFavorites(false);
            else if("support".equals(prev))showSupport(false);
            else if("about".equals(prev))showAboutOneTv(false);
            else if("privacy".equals(prev))showPrivacyPolicy(false);
            else if("terms".equals(prev))showTermsOfUse(false);
            else if("licenses".equals(prev))showLicenses(false);
            else if("appearance".equals(prev))showSettings(false);
            else if("settings".equals(prev))showSettings(false);
            else if("playback".equals(prev))showSettings(false);
            else if("comingSoon".equals(prev))showHome(false);
            else if("search".equals(prev))showSearch(false,"all");
            else if(prev.startsWith("content:"))showContentDetail(prev.substring(8),"Entertainment",false);
            else if(prev.startsWith("directory:")){
                String[] parts=prev.split(":",3);
                if(parts.length==3)showSportsDirectory(parts[1],parts[2],false); else showSportsHome(false);
            }
            else showHome(false);
        }else super.onBackPressed();
    }

    private void exitFullscreen() {
        if(fullscreen) toggleFullscreen();
    }

    private void toggleFullscreen() {
        if (playerFrame == null) return;
        ViewGroup decor = (ViewGroup) getWindow().getDecorView();
        if (!fullscreen) {
            playerOriginalParent = (ViewGroup) playerFrame.getParent();
            playerOriginalIndex = playerOriginalParent == null ? 0 : playerOriginalParent.indexOfChild(playerFrame);
            if (playerOriginalParent != null) playerOriginalParent.removeView(playerFrame);
            decor.addView(playerFrame, new ViewGroup.LayoutParams(-1, -1));
            playerFrame.setVisibility(View.VISIBLE);
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            if (adRow != null) adRow.setVisibility(View.GONE);
            if (footer != null) footer.setVisibility(View.GONE);
            fullscreen = true;
        } else {
            decor.removeView(playerFrame);
            if (playerOriginalParent != null) {
                playerOriginalParent.addView(playerFrame, Math.min(playerOriginalIndex, playerOriginalParent.getChildCount()),
                        new LinearLayout.LayoutParams(-1, dp(260)));
            }
            getWindow().getDecorView().setSystemUiVisibility(0);
            if (adRow != null) adRow.setVisibility(View.VISIBLE);
            if (footer != null) footer.setVisibility(View.VISIBLE);
            fullscreen = false;
        }
    }

    private void hideAds(boolean hide){
        if(adRow!=null){
            if(hide) adRow.setVisibility(View.GONE);
            // When there is no loaded ad, keep this row GONE so the content area expands.
        }
        if(footer!=null) footer.setVisibility(hide?View.GONE:View.VISIBLE);
    }


    private TextView tv(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(android.graphics.Typeface.DEFAULT,bold?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL);t.setIncludeFontPadding(false);return t;}

    private GradientDrawable round(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}

    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}

    private LinearLayout.LayoutParams weightedLp(){return new LinearLayout.LayoutParams(0,-2,1);}

    private JSONObject getJson(String url){try{return new JSONObject(getUrl(url));}catch(Exception e){return new JSONObject();}}

    private String getUrl(String address)throws Exception{
        HttpURLConnection c=null;
        try{
            URL u=new URL(address);c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);c.setRequestMethod("GET");
            int code=c.getResponseCode();
            InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
            if(in==null)throw new Exception("HTTP "+code);
            BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder sb=new StringBuilder();String line;
            while((line=r.readLine())!=null)sb.append(line);
            return sb.toString();
        }finally{if(c!=null)c.disconnect();}
    }

    private static class Channel {
        int id; String name,url,program,category,country; boolean connected;
        Channel(int i,String n,String u,String p,String cat,String ctry,boolean ok){id=i;name=n;url=u;program=p;category=cat;country=ctry;connected=ok;}
    }

    @Override protected void onResume(){
        super.onResume();
        if(activeSportsPage!=null && ("sportsHome".equals(screen) || "sport".equals(screen))) scheduleSportsAutoRefresh();
    }

    @Override protected void onPause(){
        handler.removeCallbacks(sportsRefreshTask);
        super.onPause();
    }

    @Override protected void onDestroy(){
        handler.removeCallbacksAndMessages(null);
        playerUiHandler.removeCallbacksAndMessages(null);
        network.shutdownNow();
        if(player!=null){player.release();player=null;}
        super.onDestroy();
    }
}
