ONE TV MASTER SOURCE - CURRENT BASELINE
Prepared: 2026-11-04

This package consolidates the latest available One TV v2.5.6 source snapshot,
the two project specification PDFs, and the supplied USHA IT brand assets.

IMPORTANT IMPLEMENTATION STATUS
- Existing Google Mobile Ads SDK dependency and Banner AdView integration are present.
- Backend currently seeds/configures 10 ad platform records and exposes /ads and admin controls.
- The current Android app only actively renders the AdMob banner integration.
- Native SDK adapters for AppLovin, Unity LevelPlay, Meta Audience Network, Liftoff,
  InMobi, Pangle, Mintegral, DT Exchange and BIGO are NOT integrated/verified in this snapshot.
- Additional ad formats (native, interstitial, rewarded, app-open, etc.) are NOT fully
  implemented as executable Android placements in this snapshot.
- Therefore this archive is a consolidated current source baseline, NOT a completed
  production-final build and NOT proof that all ad platforms/formats are operational.

Before production finalization, each SDK integration requires dependency/version and
Android compatibility checks, applicable account/app IDs and ad-unit configuration,
manifest/ProGuard review, consent/privacy compliance, test-device validation, and
provider-side approval. Backend switches cannot install a missing native SDK.

The supplied project PDFs remain the controlling project specifications. Preserve
existing UI, global bottom ad placements, provider logic and other locked requirements.


ONE TV 2.5.7 IMPLEMENTATION UPDATE (2026-11-04)
- Added a 1.2-second animated OneTV startup identity sequence.
- Consumer Live TV/video discovery routes are disabled; the home/drawer entry now opens Photo Stories.
- Photo Stories and news cards use only HTTPS image URLs supplied by the configured licensed news provider.
- Player/team photo fallbacks use neutral initials/monograms rather than a different athlete's photo or a generated gender avatar.
- News image_url is persisted and returned by the backend; news scheduler candidate fetch now receives its Worker environment.
- Version is 2.5.7 / versionCode 47.

IMPORTANT RELEASE STATUS
This is an updated source archive, not a certified production release. Android SDK/Gradle are not available in the build environment, so no APK/AAB or device-level full-route QA was produced. The complete 72-page route inventory is not yet fully implemented in this source snapshot. Real news/photo content requires a licensed provider API and server-side credentials. Sports images require the configured sports provider to return images attached to the exact player/team entities. The approved single footer ad slot remains unchanged; no additional ad containers were added.


Latest source update: OneTV v2.5.8 / versionCode 48 (2026-11-04). Added rights-gated media registry and minute polling; Photo Stories now uses the approved photo feed. Video API feed is exposed but consumer video playback UI is not yet integrated. Provider API credentials and explicit rights metadata are required. This remains a source ZIP, not a verified APK/AAB; full 72-page PDF UI acceptance is not complete.


WORKING BASELINE HANDOFF — 2026-11-04
- This archive is designated as the staged backend-first completion baseline.
- See OneTV-Source/BACKEND-FIRST-COMPLETION-ROADMAP.md for locked rules, stages and release gates.
- This is NOT a completed PDF-wide implementation or Play Store release. No APK/AAB is certified here.


ONE TV v2.5.9 HOME SCREEN INCREMENT (2026-11-04)
- Reworked Home to follow the PDF page 6 structure more closely: featured match region and large Sports, Entertainment and News cards.
- Featured and match data remain backend/provider sourced; no fake media or match data added.
- Retained the existing global footer and copyright. Android ad rendering now has one AdView placement rather than two parallel AdViews.
- Version 2.5.9 / versionCode 49.
- This is a source increment only. APK build/device QA and full PDF route acceptance remain outstanding.
See HOME-SCREEN-IMPLEMENTATION-V2.5.9-2026-11-04.md.


ONE TV HOME SCREEN FIX UPDATE — v2.5.10 / versionCode 50 (2026-11-04)
- Home Sports category uses a general trophy symbol instead of a football-only icon.
- Entertainment and News category symbols are more recognizable.
- Added PDF-referenced bottom navigation for Home, Sports, Entertainment and News.
- Bottom navigation is hidden on child/detail routes.
- Explicitly non-live statuses are filtered from the Home live feed; contradictory statuses are filtered from upcoming.
- Single global footer ad placement remains unchanged.
- Source archive only; Android Gradle build/device validation remain pending.


LIVE DEVELOPMENT WORKFLOW UPDATE — 2026-11-04
- build.yml now builds Debug APK artifacts for development pushes; it no longer builds Release APK/AAB on every push.
- release.yml is a separate manual-only Release APK/AAB workflow.
- device-deploy.yml supports automatic USB install/launch through a Windows self-hosted GitHub Actions runner labelled onetv-device.
- This is automated build/deploy, not Android hot reload. Native UI/code changes still require a Debug APK install; supported backend content/config updates do not.
- See LIVE-DEVELOPMENT-WORKFLOW-GITHUB-ACTIONS.md for setup and security requirements.
