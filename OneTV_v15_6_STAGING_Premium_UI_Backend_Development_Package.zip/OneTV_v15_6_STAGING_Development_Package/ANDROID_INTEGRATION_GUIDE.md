# OneTV Android Integration Map — preserve the real app

This document is a source-integration checklist, NOT an Android project or a tested APK. The latest native Android project ZIP was not present in the available uploads, so no existing Android file was modified or overwritten.

## 1. Lock the existing app shell
- Keep the exact existing `Home | Sports | Entertainment | News` navigation. Never replace its header or nav components with the browser mockup.
- Leave Home and Sports Scoring screens, their data/provider logic, caches, reminders, existing attribution, and navigation unchanged.
- Reuse the existing OneTV search control; do not add a new global search bar, side drawer or bottom nav.

## 2. Integrate the data-driven directories
- Fetch `GET /directory/channels` for Entertainment; paginate if the catalog exceeds API limit. Sort/order is provided by the backend. Render content-area horizontally scrolling category chips derived from the returned active category names; preserve the existing TOP navigation.
- Fetch `GET /directory/publishers` for News. Render publisher name/logo directory ONLY, not news articles, headlines or editorial feeds.
- Query `GET /directory/search?section=entertainment&q=<encoded>` or `?section=news&q=<encoded>` from the existing Search Bar. Do not change the untouched Sports search route until comparing with existing sources.
- Channel JSON is defined by the Worker; fields include id,name,category,aliases,officialUrl,logoUrl,openingMode,featured,priority,popularity, and locale metadata. Publisher data have the same shape.
- Only show `logoUrl` when backend provides it. For missing/unverified marks, render attractive, neutral text-based tiles. Use FIT_CENTER / contentScale.Fit, never crop or stretch.
- Adapt grids for phone widths, tablets, display scale, portrait and landscape; minimum 48dp touch targets, accessible labels, stable typography and contrast.

## 3. Native open logic and playback
- `openingMode=IN_APP` is only a rights-record result; runtime must independently check compatibility and safe navigation. On blocked/unverified sites use official external URLs. Never bypass DRM, geo restrictions, anti-frame controls or auth.
- For official YouTube tile, PDF chooses `https://m.youtube.com/` within a dedicated Android WebView (Option C). That behavior is NOT implemented in this ZIP and must pass independent app-policy, Android WebView and account-login testing before release. If unsupported, use a compliant external destination instead; no credential collection.
- Do not use native HLS/DASH or custom stream extraction except with explicit rights. Do not proxy, re-stream, record or cache content.

## 4. Bottom ads and full screen
- Preserve OneTV's current fixed BOTTOM ad placement, rotation/frequency caps and footer `© 2026 USHA IT. All Rights Reserved.`
- No eligible ad / ad failed: collapse the entire reserved ad height so content fills the remaining screen. Active ad: allocate layout ABOVE the ad, not underneath it.
- Suppress *OneTV* ad placements whenever the dedicated YouTube website is in view, including fullscreen, absent written permission and current policy clearance. Preserve YouTube's own player/ads/branding.

## 5. Security and deployment
- The staging Worker is in `Backend_Staging/OneTV_v15_6_STAGING_Premium_Directory.js` and `.txt` (identical content). Do not overwrite production. Use the staging-only migration AFTER backup. Secrets stay in Worker environment bindings and never in an APK.
- The new directory catalog initially has ZERO authorized entries. Permission evidence, expiry, territory and source ownership must be verified before enabling real channels/publishers.
- Never hard-code the fictional browser-preview cards into a production APK.

## 6. Acceptance test gates before native release
1. Compare the latest real Android project ZIP and its manifest, resources, main activity/navigation, ads, webview and sports source before modifying anything.
2. Integrate ONLY the Entertainment/News content surfaces and existing section-aware search callback; preserve the locked UI.
3. Verify open mode and safe redirects on real Android devices.
4. Regress Sports Scoring, scorecards, ads/rotation, API calls, sync, home navigation, Back, search, rotation, tablet and accessibility.
5. Test YouTube navigation, account restrictions, fullscreen and review current platform/store policies.
6. Package a new native Android build ONLY after all gates pass.

**Current state:** Staging backend patch and interactive browser preview built; native Android integration pending genuine latest app source ZIP.
