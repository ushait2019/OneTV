# Explicitly creates ONLY the additive onetv_directory_* staging schema.
# Back up staging worker and D1 before continuing. Never use on Production.
$ErrorActionPreference = 'Stop'
$base = 'https://one-tv-backend-staging.ushait2019.workers.dev'
Write-Host 'TARGET: STAGING ONLY - one-tv-backend-staging'
$confirm = Read-Host 'Have you backed up the STAGING Worker and D1? Type YES to proceed'
if ($confirm -cne 'YES') { Write-Host 'Canceled; no changes'; exit 0 }
$secure = Read-Host 'Paste STAGING ADMIN_TOKEN (input hidden)' -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try {
    $token = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr).Trim()
    if ($token.Length -lt 10) { throw 'Token appears too short. Copy the correct secret from secure storage.' }
    $r = Invoke-RestMethod -Uri "$base/admin/directory/migrate" -Method POST -Headers @{Authorization=('Bearer ' + $token)} -TimeoutSec 30
    if (-not $r.ok) {throw 'Migration response not OK'}
    Write-Host 'PASS: Staging directory tables installed (or already existed). No sample records seeded.'
} catch {
    Write-Warning ('Migration failed: ' + $_.Exception.Message)
    exit 1
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
    $token = $null
    $secure = $null
}
