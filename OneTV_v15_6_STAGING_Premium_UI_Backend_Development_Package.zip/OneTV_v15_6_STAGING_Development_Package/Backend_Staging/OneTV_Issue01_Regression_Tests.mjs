// OneTV Issue 01 - fixtures reconciled between Live / Upcoming / Finished.
// Usage: node OneTV_Issue01_Regression_Tests.mjs <path-to-worker.txt>
// No Cloudflare secrets, D1 connection, or external network requests are needed.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const filename = process.argv[2];
if (!filename) { console.error('Usage: node OneTV_Issue01_Regression_Tests.mjs "OneTV_v15_2_Issue01_Fixed.txt"'); process.exit(2); }
const source = fs.readFileSync(filename, 'utf8');
const converted = source.replace(/export\s+default\s*\{/, 'globalThis.__onetvWorker = {');
if (converted === source) throw Error('Worker export not found');
const context = vm.createContext({ console, Date, URL, URLSearchParams, Request, Response, AbortSignal, TextEncoder, TextDecoder, setTimeout, clearTimeout });
new vm.Script(converted + '\nglobalThis.__case = { onetvCanonicalFeedViews, onetvSameCanonicalFixture, statusBucket };', {filename}).runInContext(context, {timeout: 5000});
const {onetvCanonicalFeedViews, onetvSameCanonicalFixture, statusBucket} = context.__case;
const nowMs = Date.parse('2026-11-06T10:00:00.000Z');
const at = (iso) => Math.floor(Date.parse(iso) / 1000);
const match = ({id='sportscore:football:fixture-12', time='2026-11-06T08:00:00.000Z', status='UPCOMING', home='Ferro Carril', away='Nacional Montevideo', provider='SportScore', competition='Premier', sport='football', homeScore='', awayScore=''}={}) => ({id,time,status,home:{name:home,score:homeScore},away:{name:away,score:awayScore},provider,competition,sport});
const feed = (bucket, fetchedAt, matches) => ({bucket,fetched_at:at(fetchedAt),payload_json:JSON.stringify(matches),provider:'SportScore'});
let pass = 0, fail = 0;
function test(label, fn) { try { fn(); console.log('PASS', label); pass++; } catch(e) {console.error('FAIL', label, '-',e.message); fail++;} }

test('same fixture, stale upcoming and verified finished -> finished only', ()=>{
 const a=match({status:'UPCOMING'}),b=match({status:'FINISHED',homeScore:'2',awayScore:'1'});
 const v=onetvCanonicalFeedViews([feed('upcoming','2026-11-06T08:10:00Z',[a]),feed('finished','2026-11-06T09:00:00Z',[b])],'football',nowMs);
 assert.equal(v.upcoming.length,0);assert.equal(v.finished.length,1);assert.equal(v.finished[0].home.score,'2');
});
test('same ID, old finished and future new fixture -> remain two distinct matches', ()=>{
 const id='sportscore:football:reused-slug';
 const old=match({id,status:'FINISHED',time:'2026-11-05T09:00:00Z',homeScore:'3',awayScore:'1'});
 const future=match({id,status:'UPCOMING',time:'2026-11-08T09:00:00Z'});
 const v=onetvCanonicalFeedViews([feed('finished','2026-11-05T11:00:00Z',[old]),feed('upcoming','2026-11-06T09:00:00Z',[future])],'football',nowMs);
 assert.equal(v.finished.length,1);assert.equal(v.upcoming.length,1);
});
test('same ID, two unrelated teams -> never combine', ()=>{
 const id='sportscore:football:fixture-12';
 const original=match({id,status:'FINISHED',time:'2026-11-06T09:00:00Z'});
 const other=match({id,status:'UPCOMING',time:'2026-11-06T09:00:00Z',home:'Auckland FC',away:'Wellington Phoenix'});
 const v=onetvCanonicalFeedViews([feed('finished','2026-11-06T09:10:00Z',[original]),feed('upcoming','2026-11-06T09:11:00Z',[other])],'football',nowMs);
 assert.equal(v.finished.length,1);assert.equal(v.upcoming.length,1);
});
test('same provider, different IDs, same exact fixture -> deduplicate', ()=>{
 const a=match({id:'sportscore:football:fixture-abc',status:'UPCOMING'});
 const b=match({id:'sportscore:football:fixture-def',status:'LIVE'});
 const v=onetvCanonicalFeedViews([feed('upcoming','2026-11-06T08:00:00Z',[a]),feed('live','2026-11-06T09:00:00Z',[b])],'football',nowMs);
 assert.equal(v.upcoming.length,0);assert.equal(v.live.length,1);
});
test('same teams but kickoff 60 minutes apart -> distinct', ()=>{
 const a=match({id:'match-A',status:'LIVE',time:'2026-11-06T08:00:00Z'});
 const b=match({id:'match-B',status:'UPCOMING',time:'2026-11-06T09:00:00Z'});
 const v=onetvCanonicalFeedViews([feed('live','2026-11-06T09:00:00Z',[a]),feed('upcoming','2026-11-06T09:00:00Z',[b])],'football',nowMs);
 assert.equal(v.live.length,1);assert.equal(v.upcoming.length,1);
});
test('same teams and kickoff but contradictory competition -> distinct', ()=>{
 const a=match({id:'match-A',status:'LIVE',competition:'League A'});
 const b=match({id:'match-B',status:'UPCOMING',competition:'League B'});
 const v=onetvCanonicalFeedViews([feed('live','2026-11-06T09:00:00Z',[a]),feed('upcoming','2026-11-06T09:00:00Z',[b])],'football',nowMs);
 assert.equal(v.live.length,1);assert.equal(v.upcoming.length,1);
});
test('different providers with same verified kickoff and teams -> one fixture', ()=>{
 const a=match({id:'provider-one:abc',status:'UPCOMING',provider:'SportScore'});
 const b=match({id:'provider-two:456',status:'LIVE',provider:'SportsAPI'});
 const v=onetvCanonicalFeedViews([feed('upcoming','2026-11-06T08:00:00Z',[a]),feed('live','2026-11-06T09:00:00Z',[b])],'football',nowMs);
 assert.equal(v.upcoming.length,0);assert.equal(v.live.length,1);
});
test('reversed sides within same fixture -> align actual score with correct team', ()=>{
 const a=match({id:'xyz',status:'FINISHED',homeScore:'',awayScore:''});
 const b=match({id:'xyz',status:'FINISHED',home:'Nacional Montevideo',away:'Ferro Carril',homeScore:'1',awayScore:'2'});
 const v=onetvCanonicalFeedViews([feed('finished','2026-11-06T09:00:00Z',[a]),feed('finished','2026-11-06T08:30:00Z',[b])],'football',nowMs);
 assert.equal(v.finished.length,1);
 assert.equal(v.finished[0].home.score,'2');assert.equal(v.finished[0].away.score,'1');
});
test('unverified overdue upcoming is quarantined, not fabricated as finished', ()=>{
 const a=match({status:'UPCOMING',time:'2026-11-05T08:00:00Z'});
 const v=onetvCanonicalFeedViews([feed('upcoming','2026-11-06T09:00:00Z',[a])],'football',nowMs);
 assert.equal(v.upcoming.length,0);assert.equal(v.finished.length,0);assert.equal(v.quarantined.upcoming,1);
});
test('unknown provider status does not invent LIVE/FINISHED', ()=>{
 const m=match({status:'unknown',time:'2026-11-05T08:00:00Z'});
 assert.equal(statusBucket(m),'');
});
test('two entries from same fixture and bucket -> only one copy', ()=>{
 const a=match({status:'LIVE'}),b=match({status:'LIVE'});
 const v=onetvCanonicalFeedViews([feed('live','2026-11-06T08:00:00Z',[a,b])],'football',nowMs);
 assert.equal(v.live.length,1);
});
// A small D1 stub also checks the actual readStoredFeed() integration path.
context.onetvOverlayFinishedResultDetails = async (_env,_sport,rows) => rows;
context.onetvOverlayFeaturedDetailMetadata = async (_env,_sport,rows) => rows;
context.onetvAttachMedia = async (_env,_sport,rows) => rows;
context.onetvDecorateScoreboard = m => m;
const dbRows = [
 feed('upcoming','2026-11-06T08:10:00Z',[match({status:'UPCOMING'})]),
 feed('finished','2026-11-06T09:00:00Z',[match({status:'FINISHED',homeScore:'2',awayScore:'1'})])
];
const db = {prepare(query){
 assert.match(query,/FROM sports_feed_snapshots/);
 return {bind(sport){assert.equal(sport,'football');return {all:async()=>({results:dbRows})};}};
}};
try {
 const future = await context.readStoredFeed({DB:db},'football','upcoming');
 const final = await context.readStoredFeed({DB:db},'football','finished');
 assert.equal(future.matches.length,0);
 assert.equal(final.matches.length,1);
 assert.equal(final.matches[0].home.score,'2');
 console.log('PASS readStoredFeed() D1-only public list integration'); pass++;
} catch(e) { console.error('FAIL readStoredFeed() integration -',e.message); fail++; }

console.log(`\nIssue 01 regression result: ${pass} passed, ${fail} failed`);
process.exitCode=fail?1:0;
