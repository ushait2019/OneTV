// OneTV Issue 02: local regression checks, no external network or D1 writes.
// Usage: node OneTV_Issue02_Regression_Tests.mjs "OneTV_v15_3_Issue02_Cricket_Score_Fix.txt"
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const filename=process.argv[2]||'OneTV_v15_3_Issue02_Cricket_Score_Fix.txt';
const source=fs.readFileSync(filename,'utf8');
const converted=source.replace(/export\s+default\s*\{/, 'globalThis.__onetvWorker = {');
if(converted===source)throw Error('Worker export not found');
const context=vm.createContext({console,Date,URL,URLSearchParams,Request,Response,AbortSignal,TextEncoder,TextDecoder,setTimeout,clearTimeout});
new vm.Script(converted+`\nglobalThis.__case={onetvCricketTeamKey,onetvSameCricketTeam,
 sameCricketFixture,mergeSportsSources,onetvOverlayMissingFinishedCricketScores,
 onetvFixtureCanonicalPair,onetvCanonicalFeedViews,onetvDetailPrefetchSelection};`,{filename})
 .runInContext(context,{timeout:5000});
const {onetvCricketTeamKey, onetvSameCricketTeam, sameCricketFixture,
  mergeSportsSources, onetvOverlayMissingFinishedCricketScores,
  onetvFixtureCanonicalPair, onetvCanonicalFeedViews, onetvDetailPrefetchSelection}=context.__case;

const start='2026-11-05T14:30:00+00:00';
const sample=(home='Abu Dhabi',away='Ecb Blues',time=start,status='FINISHED')=>({
  id:'sportscore:cricket:abu-dhabi-vs-ecb-blues:2026-11-05t14:30:00+00:00',
  provider:'SportScore',sport:'cricket',home:{name:home,score:''},
  away:{name:away,score:''},time,status,competition:'Emirates D20'
});
const fixture=sample();
const other={...sample('Abu Dhabi','Emirates Blues'),provider:'Cricbuzz',
  id:'cricbuzz:cricket:9999',home:{name:'Abu Dhabi',score:'158/6',overs:'20'},
  away:{name:'Emirates Blues',score:'151/8',overs:'20'}};
const clone=x=>JSON.parse(JSON.stringify(x));
let passed=0;
async function check(name,fn){
  await fn();passed++;console.log('PASS',String(passed).padStart(2),name);
}
await check('explicit cricket alias maps ECB Blues',()=>{
  assert.equal(onetvCricketTeamKey('ECB Blues'),'emirates-blues');
  assert.equal(onetvCricketTeamKey('Emirates Blues'),'emirates-blues');
});
await check('alias does not accept unrelated Blues teams',()=>{
  assert.equal(onetvSameCricketTeam('ECB Blues','Emirates Blues'),true);
  assert.equal(onetvSameCricketTeam('ECB Blues','Dubai Blues'),false);
  assert.equal(onetvSameCricketTeam('ECB Blues','ECB Blue'),false);
});
await check('same fixture bridges aliases with exact start',()=>{
  assert.equal(sameCricketFixture(fixture,other),true);
});
await check('same fixture bridges reversed sides',()=>{
  assert.equal(sameCricketFixture(fixture,{...other,home:other.away,away:other.home}),true);
});
await check('alias cannot bridge a 11-minute kickoff gap',()=>{
  assert.equal(sameCricketFixture(fixture,{...other,time:'2026-11-05T14:41:00+00:00'}),false);
});
await check('alias cannot bridge different day',()=>{
  assert.equal(sameCricketFixture(fixture,{...other,time:'2026-11-06T14:30:00+00:00'}),false);
});
await check('alias cannot bridge different opponent',()=>{
  assert.equal(sameCricketFixture(fixture,{...other,home:{name:'Dubai',score:'158/6'}}),false);
});
await check('alias does not work without a parsed start',()=>{
  assert.equal(sameCricketFixture(fixture,{...other,time:''}),false);
});
await check('source merge keeps SportScore identity and maps both correct scores',()=>{
  const rows=mergeSportsSources([clone(fixture)],[clone(other)],'licensed-provider');
  assert.equal(rows.length,1);
  assert.equal(rows[0].id,fixture.id);
  assert.equal(rows[0].home.score,'158/6');
  assert.equal(rows[0].away.score,'151/8');
});
await check('source merge handles reversed order without swapping scores',()=>{
  const rows=mergeSportsSources([clone(fixture)],[{...clone(other),home:clone(other.away),away:clone(other.home)}],'licensed-provider');
  assert.equal(rows.length,1);
  assert.equal(rows[0].home.score,'158/6');
  assert.equal(rows[0].away.score,'151/8');
});
await check('source merge preserves explicit existing score if source conflicts',()=>{
  const previous=clone(fixture);previous.home.score='157/6';
  const rows=mergeSportsSources([previous],[clone(other)],'licensed-provider');
  assert.equal(rows[0].home.score,'157/6');
  assert.equal(rows[0].away.score,'151/8');
});
await check('fixture matching rejects a different-day source score',()=>{
  const rows=mergeSportsSources([clone(fixture)],[{...clone(other),time:'2026-11-06T14:30:00+00:00'}],'licensed-provider');
  assert.equal(rows.length,2);
  assert.equal(rows[0].home.score,'');
});
await check('canonical identity aligns only cricket alias',()=>{
  assert.equal(onetvFixtureCanonicalPair(fixture),onetvFixtureCanonicalPair(other));
  const footballAlias={...fixture,sport:'football'};
  assert.notEqual(onetvFixtureCanonicalPair(footballAlias),onetvFixtureCanonicalPair({...other,sport:'football'}));
});
const fakeEnv=records=>({DB:{prepare(sql){
  assert.match(sql,/FROM sports_match_snapshots/);
  let args=[];
  return {bind(...v){args=v;return this},async all(){return {results:records.filter(r=>args.includes(r.match_id))}}};
}}});
const record=(match)=>({match_id:fixture.id,payload_json:JSON.stringify(match),fetched_at:1793953200});
await check('D1 exact finished detail recovers missing scores',async()=>{
  const patched=await onetvOverlayMissingFinishedCricketScores(fakeEnv([record(other)]),'cricket',[clone(fixture)]);
  assert.equal(patched[0].home.score,'158/6');
  assert.equal(patched[0].away.score,'151/8');
  assert.equal(patched[0].dataSources.recoveredFromVerifiedDetail,'D1');
});
await check('D1 does not replace already existing final score',async()=>{
  const fixtureWithScore=clone(fixture);fixtureWithScore.home.score='158/6';
  const patched=await onetvOverlayMissingFinishedCricketScores(fakeEnv([record(other)]),'cricket',[fixtureWithScore]);
  assert.equal(patched[0].home.score,'158/6');
  assert.equal(patched[0].away.score,'151/8');
});
await check('D1 does not assign finished score to LIVE fixture',async()=>{
  const live=sample('Abu Dhabi','Ecb Blues',start,'LIVE');
  const patched=await onetvOverlayMissingFinishedCricketScores(fakeEnv([record(other)]),'cricket',[live]);
  assert.equal(patched[0].home.score,'');
});
await check('D1 rejects mismatched detail start timestamp',async()=>{
  const bad={...other,time:'2026-11-05T14:41:00+00:00'};
  const patched=await onetvOverlayMissingFinishedCricketScores(fakeEnv([record(bad)]),'cricket',[clone(fixture)]);
  assert.equal(patched[0].home.score,'');
});
await check('D1 with missing source scores leaves feed unmodified',async()=>{
  const patched=await onetvOverlayMissingFinishedCricketScores(fakeEnv([record({...other,home:{...other.home,score:''},away:{...other.away,score:''}})]),'cricket',[clone(fixture)]);
  assert.equal(patched[0].home.score,'');
  assert.equal(patched[0].away.score,'');
});
await check('canonical buckets do not duplicate matching alias fixture',()=>{
  const view=onetvCanonicalFeedViews([
    {payload_json:JSON.stringify([fixture]),bucket:'finished',fetched_at:1793953200},
    {payload_json:JSON.stringify([{...other,status:'UPCOMING'}]),bucket:'upcoming',fetched_at:1793950000}
  ],'cricket',Date.parse('2026-11-06T00:00:00Z'));
  assert.equal(view.finished.length,1);
  assert.equal(view.upcoming.length,0);
});
await check('live match and missing final both get bounded prefetch slots',()=>{
  const jobs=[{key:'live:a',bucket:'live',missingScore:false},
    {key:'final:b',bucket:'finished',missingScore:true},
    {key:'upcoming:c',bucket:'upcoming',missingScore:false}];
  assert.equal(onetvDetailPrefetchSelection(jobs).map(x=>x.key).join(','),'live:a,final:b');
});
await check('no live jobs: only one missing final is selected',()=>{
  const jobs=[{key:'final:a',bucket:'finished',missingScore:true},
    {key:'final:b',bucket:'finished',missingScore:true}];
  assert.equal(onetvDetailPrefetchSelection(jobs).map(x=>x.key).join(','),'final:a');
});
await check('no candidates means no upstream detail calls',()=>{
  assert.equal(onetvDetailPrefetchSelection([]).length,0);
});
console.log(`\n${passed}/${passed} Issue02 regression checks passed`);
