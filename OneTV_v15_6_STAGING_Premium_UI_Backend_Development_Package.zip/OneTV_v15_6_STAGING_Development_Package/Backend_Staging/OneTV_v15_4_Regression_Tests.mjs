// OneTV v15.4 score-aware scheduled detail tests. Fully offline, no real APIs or D1 writes.
// node .\OneTV_v15_4_Regression_Tests.mjs .\OneTV_v15_4_Live_Score_Reliability_Fix.txt
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const file=process.argv[2]||'OneTV_v15_4_Live_Score_Reliability_Fix.txt';
const source=fs.readFileSync(file,'utf8');
const converted=source.replace(/export\s+default\s*\{/, 'globalThis.__worker = {');
assert.notEqual(converted,source,'Worker export should be present');
const context=vm.createContext({console,Date,URL,URLSearchParams,Request,Response,AbortSignal,TextEncoder,TextDecoder,setTimeout,clearTimeout});
new vm.Script(converted+`\nglobalThis.__case={onetvV154CricketDetailSlugs,onetvV154DetailFixtureSafe,scheduledSportScoreDetail,onetvOverlayRecentLiveCricketScores,onetvV154PreserveRecentLiveDetailScore};`,{filename:file}).runInContext(context,{timeout:5000});
const {onetvV154CricketDetailSlugs,onetvV154DetailFixtureSafe,scheduledSportScoreDetail,onetvOverlayRecentLiveCricketScores,onetvV154PreserveRecentLiveDetailScore}=context.__case;
const checkedAt=new Date();
const TIME='2026-11-06T05:00:00+00:00';
const ID='sportscore:cricket:india-u19-vs-nepal-u19:2026-11-06t05:00:00+00:00';
const fixture=()=>({id:ID,sport:'cricket',provider:'SportScore',name:'India U19 vs Nepal U19',home:{name:'India U19',score:''},away:{name:'Nepal U19',score:''},status:'LIVE',time:TIME,competition:'ACC MEN\'S U19 ASIA CUP'});
const raw=(homeScore='-',awayScore='-',time=TIME,home='India U19',away='Nepal U19')=>({match:{home,away,home_score:homeScore,away_score:awayScore,status:'live',status_text:'1st innings (away)',time,competition:"ACC MEN'S U19 ASIA CUP"}});
let passed=0;
async function check(label,fn){await fn();passed++;console.log('PASS',String(passed).padStart(2),label);}
await check('canonical and reversed slug candidates',()=>{
  assert.equal(onetvV154CricketDetailSlugs(fixture()).join(','),'india-u19-vs-nepal-u19,nepal-u19-vs-india-u19');
});
await check('timestamped synthetic match key is never a provider slug',()=>{
  assert.ok(!onetvV154CricketDetailSlugs(fixture()).some(x=>x.includes(':2026')));
});
await check('detail matching accepts exact fixture',()=>{
  assert.equal(onetvV154DetailFixtureSafe({...fixture()},fixture(),'cricket'),true);
});
await check('detail matching rejects 11-minute rematch',()=>{
  assert.equal(onetvV154DetailFixtureSafe({...fixture(),time:'2026-11-06T05:11:00Z'},fixture(),'cricket'),false);
});
await check('detail matching rejects different opponents',()=>{
  assert.equal(onetvV154DetailFixtureSafe({...fixture(),away:{name:'Pakistan U19'}},fixture(),'cricket'),false);
});
function stubRequests(handler){
  const calls=[];
  context.activeSourcesFor=async()=>[{source_id:'sportscore',enabled:1,license_approved:1}];
  context.sourceRequest=async(_env,_source,key,url)=>{
    calls.push({key,url});
    return handler({key,url,calls});
  };
  return calls;
}
await check('scoreless first endpoint does not stop later verified score',async()=>{
  const calls=stubRequests(({url})=>({raw:url.includes('nepal-u19-vs-india-u19')&&url.includes('/api/widget/match/')?raw('0/0','30/3'):raw()}));
  const detail=await scheduledSportScoreDetail('cricket',fixture(),{});
  assert.equal(detail?.away?.score,'30/3');
  assert.equal(detail?.home?.score,'0/0');
  assert.ok(detail?.scoreVerifiedAt);
  assert.equal(calls.length,4);
});
await check('per-slug cooldown keys differ and allow retry',async()=>{
  const calls=stubRequests(({url})=>({raw:url.includes('nepal-u19-vs-india-u19')&&url.includes('/api/widget/match/')?raw('0/0','30/3'):raw()}));
  await scheduledSportScoreDetail('cricket',fixture(),{});
  assert.equal(new Set(calls.map(x=>x.key)).size,4);
});
await check('scoreless returned detail never falsely claims a verified score',async()=>{
  stubRequests(()=>({raw:raw()}));
  const detail=await scheduledSportScoreDetail('cricket',fixture(),{});
  assert.ok(detail?.detailAvailable);
  assert.equal(detail?.scoreVerifiedAt,undefined);
  assert.equal(detail?.away?.score,'');
});
await check('wrong opponent with score cannot contaminate correct fixture',async()=>{
  stubRequests(({url})=>({raw:url.includes('/api/widget/match/')?raw('0/0','120/3',TIME,'India U19','Pakistan U19'):raw()}));
  const detail=await scheduledSportScoreDetail('cricket',fixture(),{});
  assert.equal(detail?.away?.score,'');
});
await check('budget skip of first variant still searches reverse',async()=>{
  const calls=stubRequests(({url})=>url.includes('india-u19-vs-nepal-u19')?{skipped:true}:{raw:raw('0/0','30/3')});
  const detail=await scheduledSportScoreDetail('cricket',fixture(),{});
  assert.equal(detail?.away?.score,'30/3');
  assert.ok(calls.length>=3);
});
await check('non-cricket remains first-valid-detail behavior',async()=>{
  const football={...fixture(),id:'sportscore:football:india-u19-vs-nepal-u19:2026-11-06t05:00:00+00:00',sport:'football'};
  const calls=stubRequests(()=>({raw:raw('1','0')}));
  const detail=await scheduledSportScoreDetail('football',football,{});
  assert.ok(detail);
  assert.equal(calls.length,1);
});
function fakeD1(records){return {DB:{prepare(q){assert.match(q,/FROM sports_match_snapshots/);let params=[];return {bind(...args){params=args;return this;},async all(){return {results:records.filter(r=>params.includes(r.match_id))};}};}}};}
const recentMs=Date.now()-60*1000;
const detail=(changes={})=>({...fixture(),home:{name:'India U19',score:'0/0'},away:{name:'Nepal U19',score:'30/3'},scoreVerifiedAt:new Date(recentMs).toISOString(),...changes});
const record=(d=detail())=>({match_id:ID,payload_json:JSON.stringify(d),fetched_at:Math.floor(Date.now()/1000)-60});
await check('live feed recovers recent scored D1 detail',async()=>{
  const enriched=await onetvOverlayRecentLiveCricketScores(fakeD1([record()]),'cricket',[fixture()]);
  assert.equal(enriched[0].away.score,'30/3');
  assert.equal(enriched[0].scoreFromVerifiedDetail,true);
});
await check('reversed source teams retain correct target alignment',async()=>{
  const old=detail({home:{name:'Nepal U19',score:'30/3'},away:{name:'India U19',score:'0/0'}});
  const enriched=await onetvOverlayRecentLiveCricketScores(fakeD1([record(old)]),'cricket',[fixture()]);
  assert.equal(enriched[0].away.score,'30/3');
  assert.equal(enriched[0].home.score,'0/0');
});
await check('live feed keeps current known score over detail score',async()=>{
  const known=fixture();known.away.score='38/3';
  const enriched=await onetvOverlayRecentLiveCricketScores(fakeD1([record()]),'cricket',[known]);
  assert.equal(enriched[0].away.score,'38/3');
});
await check('older than six minutes is not presented as LIVE',async()=>{
  const stale=detail({scoreVerifiedAt:new Date(Date.now()-7*60000).toISOString()});
  const enriched=await onetvOverlayRecentLiveCricketScores(fakeD1([record(stale)]),'cricket',[fixture()]);
  assert.equal(enriched[0].away.score,'');
});
await check('future timestamp is not treated as a verified new score',async()=>{
  const future=detail({scoreVerifiedAt:new Date(Date.now()+2*60000).toISOString()});
  const enriched=await onetvOverlayRecentLiveCricketScores(fakeD1([record(future)]),'cricket',[fixture()]);
  assert.equal(enriched[0].away.score,'');
});
await check('finished detail is not promoted into a LIVE match',async()=>{
  const finished=detail({status:'FINISHED'});
  const enriched=await onetvOverlayRecentLiveCricketScores(fakeD1([record(finished)]),'cricket',[fixture()]);
  assert.equal(enriched[0].away.score,'');
});
await check('another match cannot donate its score',async()=>{
  const mismatched=detail({away:{name:'Pakistan U19',score:'30/3'}});
  const enriched=await onetvOverlayRecentLiveCricketScores(fakeD1([record(mismatched)]),'cricket',[fixture()]);
  assert.equal(enriched[0].away.score,'');
});
await check('same teams with different start time are rejected',async()=>{
  const mismatched=detail({time:'2026-11-06T05:11:00+00:00'});
  const enriched=await onetvOverlayRecentLiveCricketScores(fakeD1([record(mismatched)]),'cricket',[fixture()]);
  assert.equal(enriched[0].away.score,'');
});
await check('only cricket is affected by live D1 overlay',async()=>{
  const football={...fixture(),sport:'football'};
  const enriched=await onetvOverlayRecentLiveCricketScores(fakeD1([record()]),'football',[football]);
  assert.equal(enriched[0].away.score,'');
});
await check('short-lived provider score drop retains recent score only',()=>{
  const current=fixture();
  const prior=detail();
  const after=onetvV154PreserveRecentLiveDetailScore(current,prior);
  assert.equal(after.away.score,'30/3');
  assert.equal(after.scoreVerifiedAt,prior.scoreVerifiedAt);
  assert.equal(after.scoreFromPreviousSnapshot,true);
});
await check('carried score expires after six minutes and never refreshes itself',()=>{
  const current=fixture();
  const prior=detail({scoreVerifiedAt:new Date(Date.now()-7*60000).toISOString()});
  const after=onetvV154PreserveRecentLiveDetailScore(current,prior);
  assert.equal(after.away.score,'');
  assert.equal(after.scoreVerifiedAt,undefined);
});
await check('verified new side score cannot be overwritten by older observation',()=>{
  const current=fixture();current.away.score='42/3';
  const after=onetvV154PreserveRecentLiveDetailScore(current,detail());
  assert.equal(after.away.score,'42/3');
});
await check('retention rejects unrelated opponent',()=>{
  const previous=detail({away:{name:'Pakistan U19',score:'30/3'}});
  assert.equal(onetvV154PreserveRecentLiveDetailScore(fixture(),previous).away.score,'');
});
console.log(`\n${passed}/${passed} v15.4 regression checks passed`);
