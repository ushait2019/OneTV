// Node.js offline regression checks. No network calls or production writes.
// node OneTV_v15_5_Internet_Source_Tests.mjs OneTV_v15_5_STAGING_Internet_Discovery_MultiSport.txt
import fs from 'node:fs';
import assert from 'node:assert/strict';
import vm from 'node:vm';
const path=process.argv[2]||'OneTV_v15_5_STAGING_Internet_Discovery_MultiSport.txt';
const code=fs.readFileSync(path,'utf8');
const source=code.replace(/export\s+default\s*\{/, 'globalThis.__worker = {');
assert.notEqual(source,code);
const context=vm.createContext({console,Date,URL,URLSearchParams,Request,Response,AbortSignal,TextEncoder,TextDecoder,setTimeout,clearTimeout});
new vm.Script(source+`
globalThis.__v155={SPORTS,onetvOpenTeamScore,onetvNormalizeOpenObservation,onetvOpenMatchesFixture,onetvOpenConsensus,onetvApplyOpenConsensus,onetvInternetSearchRequest,onetvInternetCandidateDomain,onetvInternetDiscoveryMatches,onetvStagingInternetDiscovery,onetvDiscoverLicensedSportFixtures,onetvStagingSelectedSportOnce,webResearchEnabled};`,{filename:path}).runInContext(context,{timeout:6000});
const t=context.__v155;
let n=0;
function check(name,fn){fn();n++;console.log('PASS',String(n).padStart(2),name)}
const now=new Date(),time=new Date(now-5*60000).toISOString();
const date=time.slice(0,10);
function fixture(sport='cricket',options={}){return {sport,id:'fixture1',name:'Team Alpha vs Team Beta',time,
  status:'LIVE',home:{name:'Team Alpha',score:''},away:{name:'Team Beta',score:''},...options};}
function observation(sport='football',options={}){return {sport,time,updatedAt:now.toISOString(),status:'LIVE',
  home:{name:'Team Alpha',score:sport==='cricket'?'130/2':'2'},away:{name:'Team Beta',score:sport==='cricket'?'120/4':'1'},...options};}
function publisher(id,host){return {source_id:id,publisher_id:id,feed_url:`https://${host}/scores.json`,license_code:'CC0-1.0',license_url:'https://rights.test/licence',attribution:''};}
const pub1=publisher('independent_a','scores-one.org'),pub2=publisher('independent_b','scores-two.org');
function obs(sport='football',options={}){return t.onetvNormalizeOpenObservation(observation(sport,options),sport)}
const sources=(sport='football')=>[{source:pub1,observation:obs(sport)},{source:pub2,observation:obs(sport)}];
check('supported sports exactly five',()=>assert.equal(t.SPORTS.join(','),'football,basketball,cricket,tennis,baseball'));
check('cricket runs wickets admitted',()=>assert.equal(t.onetvOpenTeamScore({score:'125/4'},'cricket').score,'125/4'));
check('football goals admitted',()=>assert.equal(t.onetvOpenTeamScore({score:'2'},'football').score,'2'));
check('football unrealistic score rejected',()=>assert.equal(t.onetvOpenTeamScore({score:'81'},'football'),null));
check('basketball points admitted',()=>assert.equal(t.onetvOpenTeamScore({score:'115'},'basketball').score,'115'));
check('basketball overflow rejected',()=>assert.equal(t.onetvOpenTeamScore({score:'501'},'basketball'),null));
check('baseball score admitted',()=>assert.equal(t.onetvOpenTeamScore({score:'13'},'baseball').score,'13'));
check('tennis sets admitted (not games)',()=>assert.equal(t.onetvOpenTeamScore({score:'2'},'tennis').score,'2'));
check('tennis sets overflow rejected',()=>assert.equal(t.onetvOpenTeamScore({score:'7'},'tennis'),null));
check('unsupported sport rejected',()=>assert.equal(t.onetvOpenTeamScore({score:'3'},'rugby'),null));
check('normalized football',()=>assert.equal(obs('football').homeScore.score,'2'));
check('normalized basketball',()=>assert.equal(obs('basketball').homeScore.score,'2'));
check('normalized baseball',()=>assert.equal(obs('baseball').homeScore.score,'2'));
check('normalized tennis',()=>assert.equal(obs('tennis').homeScore.score,'2'));
check('invalid match score rejected',()=>assert.equal(t.onetvNormalizeOpenObservation(observation('football',{home:{name:'Team Alpha',score:'-'},away:{name:'Team Beta',score:'-'}}),'football'),null));
check('same team rejected',()=>assert.equal(t.onetvNormalizeOpenObservation(observation('football',{away:{name:'Team Alpha',score:'1'}}),'football'),null));
check('different sport not mixed',()=>assert.equal(Object.keys(t.onetvOpenConsensus(fixture('cricket'),sources('football'),'live',now.valueOf()).consensus).length,0));
check('two independent publishers required',()=>assert.equal(t.onetvOpenConsensus(fixture('football'),sources(),'live',now.valueOf()).consensus.home.score,'2'));
check('single feed cannot publish',()=>assert.equal(Object.keys(t.onetvOpenConsensus(fixture('football'),sources().slice(0,1),'live',now.valueOf()).consensus).length,0));
check('same publisher two domains not independent',()=>{
  const entries=sources();entries[1].source={...pub2,publisher_id:pub1.publisher_id};
  assert.equal(Object.keys(t.onetvOpenConsensus(fixture('football'),entries,'live',now.valueOf()).consensus).length,0);
});
check('same host two publishers not independent',()=>{
  const entries=sources();entries[1].source={...pub2,feed_url:pub1.feed_url};
  assert.equal(Object.keys(t.onetvOpenConsensus(fixture('football'),entries,'live',now.valueOf()).consensus).length,0);
});
check('contradictory sources suppress publication',()=>{
  const entries=sources();entries[1].observation.homeScore.score='3';
  const c=t.onetvOpenConsensus(fixture('football'),entries,'live',now.valueOf());
  assert.equal(!!c.consensus.home,false);assert.equal(c.conflicting.home,'conflicting_scores');
});
check('reversed team order maps score to proper side',()=>{
  const entries=sources();
  for(const e of entries)e.observation={...e.observation,home:'Team Beta',away:'Team Alpha',homeScore:{score:'1'},awayScore:{score:'2'}};
  assert.equal(t.onetvOpenConsensus(fixture('football'),entries,'live',now.valueOf()).consensus.home.score,'2');
});
check('another opponent rejected',()=>{
  const entries=sources();entries.forEach(e=>{e.observation.away='Other Team'});
  assert.equal(Object.keys(t.onetvOpenConsensus(fixture('football'),entries,'live',now.valueOf()).consensus).length,0);
});
check('11 minute kickoff difference rejected',()=>{
  const entries=sources();entries.forEach(e=>e.observation.time=new Date(Date.parse(time)+11*60000).toISOString());
  assert.equal(Object.keys(t.onetvOpenConsensus(fixture('football'),entries,'live',now.valueOf()).consensus).length,0);
});
check('stale live observations rejected',()=>{
  const entries=sources();entries.forEach(e=>e.observation.updated=new Date(now-22*60000).toISOString());
  assert.equal(Object.keys(t.onetvOpenConsensus(fixture('football'),entries,'live',now.valueOf()).consensus).length,0);
});
check('licensed consensus enriches absent noncricket score',()=>{
  const c=t.onetvOpenConsensus(fixture('football'),sources(),'live',now.valueOf());
  const enriched=t.onetvApplyOpenConsensus(fixture('football'),c);
  assert.equal(enriched.home.score,'2');assert.equal(enriched.away.score,'1');
  assert.equal(enriched.home.scoreOrigin,'open_public_feed');
});
check('official existing score never overwritten',()=>{
  const c=t.onetvOpenConsensus(fixture('football'),sources(),'live',now.valueOf());
  const original=fixture('football',{home:{name:'Team Alpha',score:'5'}});
  const protectedOne=t.onetvApplyOpenConsensus(original,c);
  assert.equal(protectedOne.home.score,'5');
  assert.equal(protectedOne.away.score,'1');
});
check('public score changed only if already verified as open feed',()=>{
  const c=t.onetvOpenConsensus(fixture('football'),sources(),'live',now.valueOf());
  const original=fixture('football',{home:{name:'Team Alpha',score:'0',scoreOrigin:'open_public_feed'}});
  const next=t.onetvApplyOpenConsensus(original,c);
  assert.equal(next.home.score,'2');
});
check('new verified football fixture from two licensed sources',()=>{
  const rows=sources('football').map(e=>({source_id:e.source.source_id,payload_json:JSON.stringify(e.observation)}));
  const lookup=new Map([[pub1.source_id,pub1],[pub2.source_id,pub2]]);
  const items=t.onetvDiscoverLicensedSportFixtures(rows,lookup,'football','live',now.valueOf(),[]);
  assert.equal(items.length,1);assert.equal(items[0].sport,'football');
  assert.equal(items[0].home.score,'2');assert.equal(items[0].away.score,'1');
});
check('single publisher cannot discover new fixture',()=>{
  const rows=sources('football').slice(0,1).map(e=>({source_id:e.source.source_id,payload_json:JSON.stringify(e.observation)}));
  assert.equal(t.onetvDiscoverLicensedSportFixtures(rows,new Map([[pub1.source_id,pub1]]),'football','live',now.valueOf(),[]).length,0);
});
check('existing fixture never duplicated by licensed source',()=>{
  const rows=sources('football').map(e=>({source_id:e.source.source_id,payload_json:JSON.stringify(e.observation)}));
  const lookup=new Map([[pub1.source_id,pub1],[pub2.source_id,pub2]]);
  assert.equal(t.onetvDiscoverLicensedSportFixtures(rows,lookup,'football','live',now.valueOf(),[fixture('football')]).length,0);
});
check('conflicting score blocks newly discovered fixture',()=>{
  const entries=sources('football');entries[1].observation.homeScore.score='4';
  const rows=entries.map(e=>({source_id:e.source.source_id,payload_json:JSON.stringify(e.observation)}));
  assert.equal(t.onetvDiscoverLicensedSportFixtures(rows,new Map([[pub1.source_id,pub1],[pub2.source_id,pub2]]),'football','live',now.valueOf(),[]).length,0);
});
check('fixed safe Brave host',()=>assert.equal(new URL(t.onetvInternetSearchRequest('football',fixture('football'),'live')).hostname,'api.search.brave.com'));
check('date and sport included in query',()=>{
  const q=new URL(t.onetvInternetSearchRequest('football',fixture('football'),'live')).searchParams.get('q');
  assert(q.includes('football'));assert(q.includes(date));
});
check('invalid sport blocks discovery',()=>assert.throws(()=>t.onetvInternetSearchRequest('rugby',fixture('rugby'),'live')));
check('nonhttps and internal domains rejected',()=>{
  assert.equal(t.onetvInternetCandidateDomain('http://example.com/x'),'');
  assert.equal(t.onetvInternetCandidateDomain('https://localhost/x'),'');
  assert.equal(t.onetvInternetCandidateDomain('https://10.0.0.1/x'),'');
});
check('different domains needed for discovery',()=>{
  const data={web:{results:[{title:'Team Alpha vs Team Beta '+date,url:'https://scores-a.org/m',page_age:now.toISOString()},
    {title:'Team Alpha vs Team Beta '+date,url:'https://scores-b.org/m',page_age:now.toISOString()}]}};
  const result=t.onetvInternetDiscoveryMatches(data,fixture(),'live',now.valueOf());
  assert.equal(result.independentDiscovery,true);assert.equal(result.publicationEligible,false);
});
check('no snippets or score copied in preview',()=>{
  const data={web:{results:[{title:'Team Alpha vs Team Beta '+date,url:'https://scores-a.org/m',description:'UNLICENSED SECRET SCORE 100/2',page_age:now.toISOString()}]}};
  const result=t.onetvInternetDiscoveryMatches(data,fixture(),'live',now.valueOf());
  assert.equal(JSON.stringify(result).includes('UNLICENSED'),false);
});
check('discovery rejects stale sources',()=>{
  const data={web:{results:[{title:'Team Alpha vs Team Beta '+date,url:'https://scores-a.org/m',page_age:new Date(now-40*60000).toISOString()}]}};
  assert.equal(t.onetvInternetDiscoveryMatches(data,fixture(),'live',now.valueOf()).distinctDomains,0);
});
check('default legacy snippet publish OFF',()=>assert.equal(t.webResearchEnabled({ONETV_WEB_RESEARCH_ENABLED:'true',BRAVE_SEARCH_API_KEY:'x'}),false));
check('new source preview route is admin and staging gated',()=>{
  const route=code.indexOf("url.pathname==='/admin/sports/staging-internet-discovery'");
  assert(route>code.indexOf('if (!adminOk(request, env))'));
  assert(code.slice(route,route+350).includes("url.hostname!=='one-tv-backend-staging.ushait2019.workers.dev'"));
});
check('public GET still D1 only',()=>assert(code.indexOf('const cachedSportsReply = await serveStoredSports(request, url, env)')>0));
async function asyncCheck(name,fn){await fn();n++;console.log('PASS',String(n).padStart(2),name)}
await asyncCheck('missing Brave key refuses network without DB writes',async()=>{
  context.readStoredFeed=async()=>({matches:[fixture('football')],ready:true});
  context.fetch=async()=>{throw new Error('should never fetch')};
  const x=await t.onetvStagingInternetDiscovery({},{sport:'football',bucket:'live'});
  assert.equal(x.reason,'brave_search_api_key_not_configured');
  assert.equal(x.writesD1,false);
});
await asyncCheck('configured discovery fetches only fixed search API host',async()=>{
  let searched=0,used=0;
  context.readStoredFeed=async()=>({matches:[fixture('football')],ready:true});
  context.fetch=async(url,options)=>{
    searched++;
    assert.equal(new URL(url).hostname,'api.search.brave.com');
    assert.equal(options.headers['X-Subscription-Token'],'MOCK_API_KEY');
    return {ok:true,json:async()=>({web:{results:[
      {title:'Team Alpha vs Team Beta '+date,url:'https://a-scores.org/a',page_age:now.toISOString()},
      {title:'Team Alpha vs Team Beta '+date,url:'https://b-scores.org/b',page_age:now.toISOString()}
    ]}})};
  };
  const env={BRAVE_SEARCH_API_KEY:'MOCK_API_KEY',DB:{prepare(sql){
    assert(sql.includes('internet_discovery'));
    return {bind(){return this},async first(){used++;return {calls:used}}};
  }}};
  const x=await t.onetvStagingInternetDiscovery(env,{sport:'football',bucket:'live'});
  assert.equal(x.ok,true);assert.equal(x.scanned,1);assert.equal(searched,1);
  assert.equal(x.results[0].independentDiscovery,true);
  assert.equal(x.results[0].publicationEligible,false);
  assert.equal(x.writesSportsData,false);assert.equal(x.budgetMetadataWritten,true);
});
await asyncCheck('daily search cap blocks all search requests',async()=>{
  let called=false;
  context.readStoredFeed=async()=>({matches:[fixture('football')],ready:true});
  context.fetch=async()=>{called=true;throw new Error('called unexpectedly')};
  const env={BRAVE_SEARCH_API_KEY:'MOCK_API_KEY',DB:{prepare(){
    return {bind(){return this},async first(){return null}};
  }}};
  const x=await t.onetvStagingInternetDiscovery(env,{sport:'football',bucket:'live'});
  assert.equal(x.results[0].error,'daily_search_limit_20');assert.equal(called,false);
});
await asyncCheck('staging universal once accepts football queue, without other Cron work',async()=>{
  let fetched=0,deleted=0,released=0;
  context.ensureSportsSnapshotSchema=async()=>{};
  context.ensureSportsControlSchema=async()=>{};
  context.readSportsSettings=async()=>({paused:false});
  context.activeSourcesFor=async()=>[{source_id:'sportscore',license_approved:1}];
  context.sportsJob=async()=>({last_attempt:0,next_allowed:0});
  context.acquireSportsCronLease=async()=>true;
  context.releaseSportsCronLease=async()=>{released++};
  context.runSportsFeedJob=async()=>{fetched++;return true};
  context.readStoredFeed=async()=>({ready:true,provider:'SportScore',matches:[fixture('football')]});
  const env={DB:{prepare(sql){return {
    bind(){return this},async first(){return {requested_at:123}},
    async run(){if(sql.includes('DELETE FROM sports_force_jobs'))deleted++;return {}}
  }}}};
  const r=await t.onetvStagingSelectedSportOnce(env,'football','live');
  assert.equal(r.ok,true);assert.equal(r.sport,'football');
  assert.equal(r.otherScheduledWorkflowsRun,false);
  assert.deepEqual([fetched,deleted,released],[1,1,1]);
});
await asyncCheck('universal one-shot rejects unsupported sport',async()=>{
  const r=await t.onetvStagingSelectedSportOnce({},'rugby','live');
  assert.equal(r.reason,'invalid_sport_or_bucket');
});
await asyncCheck('universal one-shot requires rights-approved active provider',async()=>{
  context.ensureSportsSnapshotSchema=async()=>{};
  context.ensureSportsControlSchema=async()=>{};
  context.readSportsSettings=async()=>({paused:false});
  context.activeSourcesFor=async()=>[];
  const r=await t.onetvStagingSelectedSportOnce({},'football','live');
  assert.equal(r.reason,'no_active_rights_approved_provider');
});
console.log(`\n${n}/${n} v15.5 new multi-source safety checks passed`);
