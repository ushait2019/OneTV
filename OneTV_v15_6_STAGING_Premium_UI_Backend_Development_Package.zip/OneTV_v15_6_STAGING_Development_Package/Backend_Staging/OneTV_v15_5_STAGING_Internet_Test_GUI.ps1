# OneTV v15.5 - STAGING ONLY - Internet discovery and selected-sport one-shot
# Secret is requested in a masked password box and never written to disk.
# Requires Windows PowerShell with WinForms. Do not use for Production.
$ErrorActionPreference = 'Stop'
$base = 'https://one-tv-backend-staging.ushait2019.workers.dev'
try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
} catch {
    Write-Host 'Windows Forms is required. Use Windows PowerShell 5.1.'
    exit 1
}
$form = New-Object System.Windows.Forms.Form
$form.Text = 'OneTV v15.5 - STAGING Internet Source Testing'
$form.StartPosition = 'CenterScreen'
$form.ClientSize = [System.Drawing.Size]::new(570,260)
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$header = New-Object System.Windows.Forms.Label
$header.Location = [System.Drawing.Point]::new(18,12)
$header.Size = [System.Drawing.Size]::new(530,40)
$header.Text = "STAGING ONLY - research does NOT auto-publish web results.`r`nSelected sport sync requires a queued job in Staging Sports Admin."
$form.Controls.Add($header)
$sportLabel = New-Object System.Windows.Forms.Label
$sportLabel.Location = [System.Drawing.Point]::new(18,65)
$sportLabel.Size = [System.Drawing.Size]::new(80,22)
$sportLabel.Text = 'Sport'
$form.Controls.Add($sportLabel)
$sport = New-Object System.Windows.Forms.ComboBox
$sport.Location = [System.Drawing.Point]::new(90,62)
$sport.Size = [System.Drawing.Size]::new(140,26)
$sport.DropDownStyle = 'DropDownList'
[void]$sport.Items.AddRange([object[]]@('cricket','football','basketball','tennis','baseball'))
$sport.SelectedIndex = 0
$form.Controls.Add($sport)
$bucketLabel = New-Object System.Windows.Forms.Label
$bucketLabel.Location = [System.Drawing.Point]::new(253,65)
$bucketLabel.Size = [System.Drawing.Size]::new(70,22)
$bucketLabel.Text = 'Feed'
$form.Controls.Add($bucketLabel)
$bucket = New-Object System.Windows.Forms.ComboBox
$bucket.Location = [System.Drawing.Point]::new(305,62)
$bucket.Size = [System.Drawing.Size]::new(216,26)
$bucket.DropDownStyle = 'DropDownList'
[void]$bucket.Items.AddRange([object[]]@('live','finished','upcoming'))
$bucket.SelectedIndex = 0
$form.Controls.Add($bucket)
$modeLabel = New-Object System.Windows.Forms.Label
$modeLabel.Location = [System.Drawing.Point]::new(18,104)
$modeLabel.Size = [System.Drawing.Size]::new(90,22)
$modeLabel.Text = 'Operation'
$form.Controls.Add($modeLabel)
$mode = New-Object System.Windows.Forms.ComboBox
$mode.Location = [System.Drawing.Point]::new(110,100)
$mode.Size = [System.Drawing.Size]::new(411,26)
$mode.DropDownStyle = 'DropDownList'
[void]$mode.Items.AddRange([object[]]@('Discover Internet Sources (review only)','Run Queued Sport Sync Once'))
$mode.SelectedIndex = 0
$form.Controls.Add($mode)
$label = New-Object System.Windows.Forms.Label
$label.Location = [System.Drawing.Point]::new(18,147)
$label.Size = [System.Drawing.Size]::new(165,22)
$label.Text = 'STAGING ADMIN_TOKEN'
$form.Controls.Add($label)
$input = New-Object System.Windows.Forms.TextBox
$input.Location = [System.Drawing.Point]::new(182,143)
$input.Size = [System.Drawing.Size]::new(339,27)
$input.UseSystemPasswordChar = $true
$input.ShortcutsEnabled = $true
$form.Controls.Add($input)
$go = New-Object System.Windows.Forms.Button
$go.Location = [System.Drawing.Point]::new(269,195)
$go.Size = [System.Drawing.Size]::new(251,34)
$go.Text = 'Run ONCE on STAGING'
$go.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.Controls.Add($go)
$form.AcceptButton = $go
$cancel = New-Object System.Windows.Forms.Button
$cancel.Location = [System.Drawing.Point]::new(18,195)
$cancel.Size = [System.Drawing.Size]::new(95,34)
$cancel.Text = 'Cancel'
$cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.Controls.Add($cancel)
$form.CancelButton = $cancel
$token = $null
try {
    if ($form.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        Write-Host 'Cancelled; no API request made.'
        exit 0
    }
    $token = [string]$input.Text.Trim()
    $input.Clear()
    if ($token.Length -lt 20 -or $token -match '[\x00-\x1F\x7F]') {
        Write-Host 'ERROR: Paste only the complete STAGING token into the masked box.'
        exit 1
    }
    $selection = [string]$mode.SelectedItem
    if ($selection -like 'Discover*') {
        if ($bucket.SelectedItem -eq 'upcoming') {
            Write-Host 'Discovery supports live or finished fixtures, not upcoming.'
            exit 1
        }
        $endpoint = '/admin/sports/staging-internet-discovery'
    } else {
        $endpoint = '/admin/sports/staging-selected-sport-once'
    }
    $body = @{ sport = [string]$sport.SelectedItem; bucket = [string]$bucket.SelectedItem } | ConvertTo-Json -Compress
    Write-Host ('STAGING operation: ' + $selection)
    Write-Host ('Sport: ' + $sport.SelectedItem + '; feed: ' + $bucket.SelectedItem)
    $data = Invoke-RestMethod -Uri ($base + $endpoint) -Method POST `
        -Headers @{ Authorization = ('Bearer ' + $token) } `
        -Body $body -ContentType 'application/json' -TimeoutSec 50 -ErrorAction Stop
    $data | ConvertTo-Json -Depth 15
} catch {
    Write-Host ('Request error: ' + $_.Exception.Message)
    if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
        Write-Host $_.ErrorDetails.Message
    }
} finally {
    $token = $null
    if ($input) { $input.Clear() }
    if ($form) { $form.Dispose() }
    try { Set-Clipboard -Value '' -ErrorAction SilentlyContinue } catch { }
}
