import fs from 'node:fs';
import assert from 'node:assert/strict';
const code=fs.readFileSync(new URL('./OneTV_v15_5_STAGING_Internet_Discovery_MultiSport.txt',import.meta.url),'utf8');
const start=code.indexOf('async function onetvStagingCricketLiveOnce(env){');
const end=code.indexOf('\n// STAGING ONLY: run one queued selected sport',start);
assert(start>0&&end>start,'staging once function present');
const body=code.slice(start,end);
assert.match(code,/if\(url\.hostname!=='one-tv-backend-staging\.ushait2019\.workers\.dev'\)/);
assert.match(code,/if \(!adminOk\(request, env\)\) return json\(\{error:"Unauthorized"\}, 401\)/);
assert(code.indexOf('if (!adminOk(request, env))')<code.indexOf("url.pathname==='/admin/sports/staging-cricket-live-once'"));
assert.doesNotMatch(body,/\bonetvVerifiedMediaSync\(|\bonetvTeamLogosScheduledSync\(|\bpublishOneNewsArticle\(|\brefreshAuthorizedMedia\(|\bscheduled\(/);
console.log('PASS staging hostname, admin token and sports-only route');
let checks=1;
async function invoke({paused=false,approved=true,leased=true,queued=true,failed=false,cooldown=false,recent=false,detail=true}={}){
 let calls={fetch:0,details:0,delete:0,release:0};
 const db={prepare(sql){return {
  first:async()=>queued?{requested_at:1000}:null,
  bind(){return this},
  run:async()=>{if(sql.includes('DELETE FROM sports_force_jobs')){calls.delete++;queued=false};return {}}
 }}};
 const fn = new Function('ensureSportsSnapshotSchema','ensureSportsControlSchema', 'readSportsSettings',
  'activeSourcesFor','sportsJob','acquireSportsCronLease','releaseSportsCronLease',
  'readStoredFeed','runSportsFeedJob','runSportsDetailPrefetch','webResearchPerCron',
  'sportsSourceScore','providerStatusError',body+'\nreturn onetvStagingCricketLiveOnce;')(
  async()=>{},async()=>{},async()=>({paused,detail_prefetch:detail}),
  async()=>approved?[{source_id:'sportscore'}]:[],
  async()=>({next_allowed:cooldown?Date.now()/1000+60:0,last_attempt:recent?Date.now()/1000:0,last_error:'provider_failure'}),
  async()=>leased,async()=>{calls.release++},
  async()=>({matches:[{home:{score:'10/1'},away:{score:'-'}}],provider:'SportScore',ready:true}),
  async()=>{calls.fetch++;return !failed},async()=>{calls.details++},
  ()=>0,(m)=>m.home?.score==='10/1',e=>String(e));
 const result=await fn({DB:db,SPORTS_DETAIL_PREFETCH_DISABLED:'false'});
 return {result,calls};
}
const tests=[
 ['success',{},{ok:true},[1,1,1,1]],
 ['success without prefetch',{detail:false},{ok:true},[1,0,1,1]],
 ['paused',{paused:true},{reason:'sports_paused'},[0,0,0,0]],
 ['no approved source',{approved:false},{reason:'sportscore_not_active_approved'},[0,0,0,0]],
 ['cooldown',{cooldown:true},{reason:'feed_in_cooldown'},[0,0,0,0]],
 ['minimum gap',{recent:true},{reason:'minimum_120_second_gap'},[0,0,0,0]],
 ['lease busy',{leased:false},{reason:'sports_lease_busy'},[0,0,0,0]],
 ['no queue',{queued:false},{reason:'no_queued_cricket_live_job'},[0,0,0,1]],
 ['feed failure',{failed:true},{reason:'feed_request_failed'},[1,0,0,1]],
 ];
for(const [name,opts,expected,counts] of tests){
 const {result,calls}=await invoke(opts);
 for(const [k,v] of Object.entries(expected))assert.equal(result[k],v,`${name}: ${k}`);
 assert.deepEqual([calls.fetch,calls.details,calls.delete,calls.release],counts,`${name}: exact side effects`);
 console.log('PASS '+name);checks++;
}
console.log(`${checks}/${checks} staging one-shot safety tests passed`);
