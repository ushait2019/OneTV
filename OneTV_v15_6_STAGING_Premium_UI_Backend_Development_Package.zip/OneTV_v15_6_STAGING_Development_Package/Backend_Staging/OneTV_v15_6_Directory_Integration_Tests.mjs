import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import worker from './OneTV_v15_6_STAGING_Premium_Directory.mjs';

const database=new DatabaseSync(':memory:');
const env={ADMIN_TOKEN:'local-testing-not-a-real-secret',DB:{
  prepare(sql){
    const statement=database.prepare(sql);let args=[];
    return {
      bind(...v){args=v;return this},
      async run(){return statement.run(...args)},
      async all(){return {results:statement.all(...args)}},
      async first(){return statement.get(...args)||null}
    }
  }
}};
let pass=0;
const base='https://one-tv-backend-staging.ushait2019.workers.dev';
async function request(path,method='GET',body,token=false){
  const headers={'Content-Type':'application/json'};
  if(token)headers.Authorization='Bearer '+env.ADMIN_TOKEN;
  const r=await worker.fetch(new Request(base+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body)}),env);
  return {status:r.status,data:await r.json().catch(()=>null)};
}
const test=async(label,fn)=>{await fn();pass++;console.log(`PASS ${pass}: ${label}`)};

await test('admin migration is protected',async()=>{
  const r=await request('/admin/directory/migrate','POST');assert.equal(r.status,401)
});
await test('additive migration creates empty tables',async()=>{
  const r=await request('/admin/directory/migrate','POST',undefined,true);
  assert.equal(r.status,200);assert.equal(r.data.seeded,0);
  const rows=database.prepare("SELECT name FROM sqlite_master WHERE name LIKE 'onetv_directory_%' AND type='table'").all();
  assert.equal(rows.length,3);
});
await test('migration is idempotent',async()=>{
  const r=await request('/admin/directory/migrate','POST',undefined,true);
  assert.equal(r.status,200)
});
await test('public directory starts empty — no invented rights or branding',async()=>{
  const [a,b]=await Promise.all([request('/directory/channels'),request('/directory/publishers')]);
  assert.equal(a.data.count,0);assert.equal(b.data.count,0)
});
const channel={id:'official-sports-demo',name:'Official Sports Demo',aliases:['খেলা টিভি','Sports Live'],category:'sports',country:'International',language:'English',official_url:'https://example.org/live',logo_url:'https://example.org/logo.png',logo_permission:'unknown',webview_permission:'unknown',requested_open_mode:'IN_APP',featured:true,priority:40,popularity:22,enabled:true};
await test('channel POST requires admin auth',async()=>{
  const r=await request('/admin/directory/channels','POST',channel);assert.equal(r.status,401)
});
await test('admin can add official HTTPS channel record',async()=>{
  const r=await request('/admin/directory/channels','POST',channel,true);assert.equal(r.status,201)
});
await test('public channel hides logo without permission',async()=>{
  const r=await request('/directory/channels');assert.equal(r.status,200);
  assert.equal(r.data.channels[0].logoUrl,null);
  assert.equal(r.data.channels[0].openingMode,'EXTERNAL');
  assert.equal(r.data.channels[0].officialUrl,'https://example.org/live');
  assert.deepEqual(r.data.categories,['sports']);
});
await test('channel filters by category',async()=>{
  const r=await request('/directory/channels?category=kids');assert.equal(r.data.count,0)
});
await test('section-aware search resolves Bangla alias',async()=>{
  const r=await request('/directory/search?section=entertainment&q='+encodeURIComponent('খেলা টিভি'));
  assert.equal(r.data.items[0].id,channel.id)
});
await test('legacy search path supports explicit scoped Entertainment',async()=>{
  const r=await request('/search?section=entertainment&q=Sports');
  assert.equal(r.data.items[0].id,channel.id)
});
await test('cannot add duplicate stable ID via POST',async()=>{
  const r=await request('/admin/directory/channels','POST',channel,true);assert.equal(r.status,409)
});
await test('no arbitrary http URLs allowed',async()=>{
  const r=await request('/admin/directory/channels','POST',{...channel,id:'untrusted-http',official_url:'http://example.org/stream'},true);
  assert.equal(r.status,400)
});
await test('no localhost or internal URLs allowed',async()=>{
  const r=await request('/admin/directory/channels','POST',{...channel,id:'untrusted-local',official_url:'https://localhost:443/'},true);
  assert.equal(r.status,400)
});
await test('verified logo requires evidence',async()=>{
  const r=await request('/admin/directory/channels/'+channel.id,'PATCH',{logo_permission:'verified'},true);
  assert.equal(r.status,400)
});
await test('verified WebView requires documented rights',async()=>{
  const r=await request('/admin/directory/channels/'+channel.id,'PATCH',{webview_permission:'verified'},true);
  assert.equal(r.status,400)
});
await test('verified WebView + logo accepted with rights evidence',async()=>{
  const r=await request('/admin/directory/channels/'+channel.id,'PATCH',{
    webview_permission:'verified',webview_evidence:'rights-owner contract document reference 2026/1',
    webview_expires_at:'2035-01-01',
    logo_permission:'verified',logo_evidence:'logo asset license grant document 2026/2',logo_expires_at:'2035-01-01'
  },true);
  assert.equal(r.status,200);
  const p=await request('/directory/channels');
  assert.equal(p.data.channels[0].openingMode,'IN_APP');
  assert.equal(p.data.channels[0].logoUrl,'https://example.org/logo.png');
});
await test('expired permissions are safely downgraded',async()=>{
  const r=await request('/admin/directory/channels/'+channel.id,'PATCH',{
    webview_expires_at:'2020-01-01',logo_expires_at:'2020-01-01'
  },true);assert.equal(r.status,200);
  const p=await request('/directory/channels');assert.equal(p.data.channels[0].openingMode,'EXTERNAL');assert.equal(p.data.channels[0].logoUrl,null)
});
await test('newspaper publisher directory excludes article content',async()=>{
  const body={id:'daily-test',name:'দৈনিক পরীক্ষা',aliases:['Dainik Porikkha','Daily Test'],category:'general',country:'Bangladesh',language:'Bangla',official_url:'https://news.example.org/',requested_open_mode:'IN_APP',enabled:true};
  const r=await request('/admin/directory/publishers','POST',body,true);assert.equal(r.status,201);
  const p=await request('/directory/publishers');assert.equal(p.data.publishers[0].openingMode,'EXTERNAL');
  assert.equal('articles' in p.data,false);
});
await test('publisher searchable by English alias',async()=>{
  const r=await request('/directory/search?section=news&q=Dainik%20Porikkha');
  assert.equal(r.data.items[0].id,'daily-test')
});
await test('cannot change stable id via patch',async()=>{
  const r=await request('/admin/directory/publishers/daily-test','PATCH',{id:'other-daily'},true);
  assert.equal(r.status,400)
});
await test('unknown section rejects instead of searching the web',async()=>{
  const r=await request('/directory/search?section=sports&q=anything');assert.equal(r.status,400)
});
await test('admin evidence never leaks into public replies',async()=>{
  const r=await request('/directory/channels');assert.ok(!JSON.stringify(r.data).includes('rights-owner contract'));
});
await test('admin audit records changes',async()=>{
  const r=await request('/admin/directory/audit','GET',undefined,true);
  assert.equal(r.status,200);assert.ok(r.data.events.length>=4);
});
await test('deleted record removed from public directory',async()=>{
  const d=await request('/admin/directory/publishers/daily-test','DELETE',undefined,true);
  assert.equal(d.status,200);
  const r=await request('/directory/publishers');assert.equal(r.data.count,0)
});
await test('global health route unchanged',async()=>{
  const r=await request('/health');assert.equal(r.status,200);assert.equal(r.data.ok,true)
});
console.log(`\n${pass}/${pass} OneTV v15.6 directory integration tests passed`);
