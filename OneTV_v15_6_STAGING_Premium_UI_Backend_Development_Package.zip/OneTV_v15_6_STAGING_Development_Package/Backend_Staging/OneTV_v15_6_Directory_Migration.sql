-- OneTV v15.6: additive schema only; no existing tables modified.
-- Apply ONLY to `one-tv-staging-db` after backup, or use POST /admin/directory/migrate.
-- Never run against production before acceptance review.

CREATE TABLE IF NOT EXISTS onetv_directory_channels (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, aliases_json TEXT NOT NULL DEFAULT '[]',
    category TEXT NOT NULL DEFAULT 'general', country TEXT NOT NULL DEFAULT '',
    language TEXT NOT NULL DEFAULT '', official_url TEXT NOT NULL,
    logo_url TEXT NOT NULL DEFAULT '', logo_permission TEXT NOT NULL DEFAULT 'unknown',
    logo_evidence TEXT NOT NULL DEFAULT '', logo_expires_at TEXT NOT NULL DEFAULT '',
    webview_permission TEXT NOT NULL DEFAULT 'unknown',
    webview_evidence TEXT NOT NULL DEFAULT '', webview_expires_at TEXT NOT NULL DEFAULT '',
    requested_open_mode TEXT NOT NULL DEFAULT 'AUTO',
    featured INTEGER NOT NULL DEFAULT 0, priority INTEGER NOT NULL DEFAULT 100,
    popularity REAL NOT NULL DEFAULT 0, enabled INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE IF NOT EXISTS onetv_directory_publishers (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, aliases_json TEXT NOT NULL DEFAULT '[]',
    category TEXT NOT NULL DEFAULT 'general', country TEXT NOT NULL DEFAULT '',
    language TEXT NOT NULL DEFAULT '', official_url TEXT NOT NULL,
    logo_url TEXT NOT NULL DEFAULT '', logo_permission TEXT NOT NULL DEFAULT 'unknown',
    logo_evidence TEXT NOT NULL DEFAULT '', logo_expires_at TEXT NOT NULL DEFAULT '',
    webview_permission TEXT NOT NULL DEFAULT 'unknown',
    webview_evidence TEXT NOT NULL DEFAULT '', webview_expires_at TEXT NOT NULL DEFAULT '',
    requested_open_mode TEXT NOT NULL DEFAULT 'AUTO',
    featured INTEGER NOT NULL DEFAULT 0, priority INTEGER NOT NULL DEFAULT 100,
    popularity REAL NOT NULL DEFAULT 0, enabled INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE IF NOT EXISTS onetv_directory_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL,
    record_id TEXT NOT NULL, action TEXT NOT NULL,
    performed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);

CREATE INDEX IF NOT EXISTS idx_onetv_directory_channel_rank ON onetv_directory_channels(enabled,category,featured,priority,popularity);

CREATE INDEX IF NOT EXISTS idx_onetv_directory_publisher_rank ON onetv_directory_publishers(enabled,priority,popularity);
