ONE TV v15.5 - STAGING-ONLY INTERNET MULTI-SOURCE PACKAGE
============================================================
Version: experimental staging, November 6, 2026.
NOT deployed. NOT a production release. Do NOT paste into one-tv-backend.

WHAT IS REAL IN THIS CODE
- Keeps existing SportScore API, D1 public-cache-only reads and v15.4 recovery.
- Supports cricket, football, basketball, tennis (sets-won score only), baseball
  in the licensed PUBLIC JSON feed consensus engine.
- Two independent source publishers AND hostnames must agree exactly on a score.
- Rejects mismatched teams/sport/date, timestamp gaps >10m, stale live scores,
  implausible scores and conflicting observations. Preserves primary API scores.
- Prevents verified duplicate fixtures; handles reversed team order.
- Existing licensed-feed sources are configured via /admin/sports/open-sources.
  Source is OFF by default, requires independently verified rights and CC0/PD
  to publish to the currently implemented Android display.
- Adds a staging-only Internet source discovery preview for any of five sports.
  Searches for missing-score cached fixtures with Brave Search API, returns
  candidate links/domains for review, does not scrape pages, store search snippets
  or publish search results. Needs BRAVE_SEARCH_API_KEY on STAGING worker.
- Caps on-demand discovery to 2 searches per request and 20/day (D1 daily counter).
- Adds staging-only selected-sport one-shot sync (only an explicitly queued job),
  no global Cron, news, logos or media workflows.
- Legacy web-snippet auto-publishing now requires two additional opt-in rights
  flags, default OFF. Do not enable without specific licence verification.

IMPORTANT LIMITATION
Searching the internet is not the same as obtaining rights to republish data.
No software can guarantee a search of EVERY website on the internet.
Brave's standard Search API terms prohibit persisting/redistributing search
results; its web results are discovery clues, not licenced score feeds.
The new engine is NOT a web scraper. Automatically publishing facts requires
TWO independent publisher-owned, machine-readable, explicitly licensed feeds.
No such two independent LIVE cricket feeds were yet verified in this conversation.
Live Cricket score can still be unavailable; never fabricate it.
Brave's Search API requires a separate account/key and may require account
payment verification; inspect current terms and costs before connecting.

LOCAL TEST COMMANDS (Windows PowerShell, after extracting ZIP to Downloads)
cd "$env:USERPROFILE\Downloads\OneTV_v15_5_Staging_Internet_MultiSource"
node --check ".\OneTV_v15_5_STAGING_Internet_Discovery_MultiSport.mjs"
node ".\OneTV_v15_5_Internet_Source_Tests.mjs" ".\OneTV_v15_5_STAGING_Internet_Discovery_MultiSport.txt"
node ".\OneTV_v15_4_Regression_Tests.mjs" ".\OneTV_v15_5_STAGING_Internet_Discovery_MultiSport.txt"
node ".\OneTV_Issue02_Regression_Tests.mjs" ".\OneTV_v15_5_STAGING_Internet_Discovery_MultiSport.txt"
node ".\OneTV_Issue01_Regression_Tests.mjs" ".\OneTV_v15_5_STAGING_Internet_Discovery_MultiSport.txt"

EXPECTED: 49 new checks + 24 v15.4 + 22 issue02 + 12 issue01 = 107.
(PLUS staging one-shot safety suite included separately if desired.)

STAGING DEPLOYMENT (ONLY AFTER TESTS & CONFIRMATION)
- Backup currently ACTIVE one-tv-backend-staging code. Never touch production.
- Paste full TXT in Cloudflare Worker `one-tv-backend-staging` Edit Code.
- Binding `DB` => `one-tv-staging-db`; keep staging ADMIN_TOKEN.
- Do NOT add a Cron Trigger; preview discovery uses explicit authenticated POST.
- Test /health first. No code has been deployed by this ZIP.

RESEARCH API (authenticated, exact staging host, POST):
  /admin/sports/staging-internet-discovery
  JSON body: {"sport":"cricket","bucket":"live"}
  Other supported sports: football, basketball, tennis, baseball.
  0-2 read-only searches; 20 per day. Budget counter is the only D1 write.
  WITHOUT BRAVE_SEARCH_API_KEY -> `brave_search_api_key_not_configured`.

STAGING SELECTED-SPORT ONE-SHOT (authenticated, exact staging host, POST):
  /admin/sports/staging-selected-sport-once
  JSON body: {"sport":"football","bucket":"live"}
  First use Staging Sports Admin to Queue Refresh for same sport/bucket.
  There must be an enabled/rights-approved data provider.
  Only one queued job is consumed, no global Cron workflow invoked.

OPTIONAL WINDOWS GUI
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\OneTV_v15_5_STAGING_Internet_Test_GUI.ps1"
  Enter STAGING_ADMIN_TOKEN in masked box, select operation/sport.
  Do NOT share token or send screenshots containing it.

PUBLIC LICENSED FEED INPUT
  A permitted source returns HTTPS Content-Type application/json of form:
  {"matches":[{
    "sport":"football", "status":"LIVE",
    "time":"2026-11-06T14:00:00Z", "updatedAt":"2026-11-06T14:05:00Z",
    "competition":"Sample Championship",
    "home":{"name":"Team Alpha","score":"2"},
    "away":{"name":"Team Beta","score":"1"}
  }]}
  Cricket uses score strings like "130/4" and optional team.overs, other
  sports use numeric team scores. Tennis fields represent sets won, not
  detailed per-set games or points.
  Never register hypothetical test host as a legitimate content provider.
  A registered source needs proof of automated access AND redistribution
  permissions; public reachability alone is not proof.

KNOWN ISSUE/BOUNDARY
  Football/basketball/tennis/baseball adapters currently support scores,
  status and competition; not full sport-specific scorecards/commentary.
  Complete sports coverage and rights must be added per publisher.
  Staging local tests are synthetic, not evidence of an available licensed feed.
  The previously shared Sportmonks token should be REVOKED/ROTATED.

REFERENCE MATERIAL
  https://api-dashboard.search.brave.com/documentation/resources/terms-of-service
  https://api-dashboard.search.brave.com/documentation/pricing
  https://cricsheet.org/licensing/
