# READ-ONLY STAGING check, no admin token or D1 writes.
$ErrorActionPreference = 'Stop'
$base = 'https://one-tv-backend-staging.ushait2019.workers.dev'
try {
  $health = Invoke-RestMethod -Uri "$base/health" -TimeoutSec 20
  $channels = Invoke-RestMethod -Uri "$base/directory/channels?limit=20" -TimeoutSec 20
  $publishers = Invoke-RestMethod -Uri "$base/directory/publishers?limit=20" -TimeoutSec 20
  Write-Host ('STAGING HEALTH: ' + $health.ok)
  Write-Host ('AUTHORIZED CHANNELS: ' + $channels.count)
  Write-Host ('AUTHORIZED PUBLISHERS: ' + $publishers.count)
  Write-Host 'PASS: Directory API is reachable. Counts may legitimately be 0.'
} catch {
  Write-Warning ('STAGING CHECK FAILED: ' + $_.Exception.Message)
  Write-Host 'The new Worker and/or additive schema may not have been deployed. Production was not touched.'
  exit 1
}
