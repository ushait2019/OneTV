# OneTV PDF v2026-11-07 — Implementation Status Matrix

| PDF requirement | Staging Worker | Browser preview | Actual Android app |
|---|---|---|---|
| Preserve Home/Sports/Entertainment/News order | No change to existing sports/backend | Four tabs in required order | Pending latest Android source comparison |
| Entertainment premium responsive channel tiles | New data-driven channel endpoint | Implemented: 2/3/4 columns, category chips | Not yet merged |
| Final revision p23–27 category selector *inside Entertainment* | Category IDs + server ranking | Implemented; overrides earlier no-category instruction | Not yet merged |
| Only authorized logos, correct aspect ratio | Hide logo unless verified evidence unexpired | `object-fit:contain`; fallback monograms | Not yet merged |
| Newspaper publisher directory, **not** news feed | New standalone publishers tables/endpoints; no articles | Premium publisher tiles; no headlines | Not yet merged |
| URL/permission-aware opening | Official HTTPS; permission statuses & expiry; EXTERNAL default | Preview never opens unverified URLs | Native URL routing and redirects not tested |
| YouTube `m.youtube.com` in isolated WebView | No video hosting/proxy/embedding | Placeholder only | Not implemented, requires rights/policy/compatibility test |
| OneTV ads disabled on YouTube screen | Existing ad backend untouched | Hidden for YouTube preview route | Native ad SDK condition pending |
| Fixed bottom ad, collapse when empty | Existing backend untouched | Collapse/expand simulated | Existing native implementation must be audited |
| Search UI unchanged + scoped multilingual matching | New optional `section=entertainment|news`; unchanged default Sports | Existing preview search callback; no second search control | App search integration pending |
| Sports Scoring and providers locked | Preserved v15.5 code and jobs; regression tested | Sports represented as **protected placeholder**, not redesigned | Existing real Sports app source must be preserved |
| Backend dynamic management | Admin CRUD + D1 schema + audit for directory | Optional staging-backed preview | Admin UI enhancement pending; endpoint ready |
| Security/rights/attribution | Token-protected admin, HTTPS checks, rights/expiry gating | Text fallback; no scraped media | Full release security audit pending |
| Device QA | D1/Worker tests locally | Browser small phone, phone, tablet, ads, search | Physical Android QA pending |
| Release candidate | **NOT READY** | **DESIGN PREVIEW ONLY** | Requires latest source, permissions, and end-to-end testing |

The supplied PDF includes conflicting early and late channel-category instructions. The *final visual revision*, p23–27, supersedes the earlier instruction: content-area horizontal category chips **are included**; top navigation remains locked.
