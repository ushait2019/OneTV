# OneTV — Premium International UI Concept
**USHA IT | Based on approved 07 November 2026 Design & Implementation Specification**

## What has been delivered
- Self-contained, responsive, interactive **HTML/CSS/JavaScript design prototype** for OneTV's Entertainment and News content regions.
- Entertainment: mobile-first channel cards, horizontal category chips, data-driven category visibility, featured/priority ordering, missing-logo-safe typographic preview artwork.
- News: original editorial publisher grid using text-based identities rather than unapproved third-party logos.
- Interactive existing four-tab shell representation: `Home | Sports | Entertainment | News`; Home and Sports are intentionally **not redesigned**.
- Scoped search behavior exposed through `window.OneTVPreview.search('query')` for later wiring to the **existing app search bar**. No duplicate search UI.
- Global ad placement is collapsed by default; preview it with `?ad=1` or call `OneTVPreview.setAdAvailable(true)`. Ad is hidden on YouTube conceptual route.
- Example channel/publisher data and a production backend field contract.
- PNG screenshots for phone and tablet visual review.

## Launch
Open `index.html` in Chrome or Edge (no server required). Use top tabs to switch sections. Tap channel/publisher cards to inspect example behavior.

URL tests: `index.html?view=news`, `index.html?view=entertainment&ad=1`, `index.html?view=news&q=World`.

## Design rules from PDF — reconciled
- **Pages 23–27 are the FINAL visual correction**. Therefore compact horizontal category chips **inside Entertainment content** are retained, overriding the earlier no-visible-categories direction on pages 2–4. The app's main tabs are unchanged.
- **Do not** hard-code reference channel/publisher inventories, reuse third-party trademarks/logos without permission, scrape news content, or silently enable streams.
- The current OneTV header and search visual must be preserved **from the latest Android source**. This HTML reproduces only a presentational shell because no Android source ZIP was provided with this request. Do not replace the production app header with the prototype header without baseline comparison.
- Sports Scoring remains fully locked; no actual sports/provider code touched.
- YouTube option C from the PDF: `https://m.youtube.com/` in isolated Android WebView, subject to actual YouTube compatibility and policy review. This HTML only shows an explicit placeholder: it does not load, imitate, log into, or proxy YouTube.
- No OneTV ads on the YouTube screen; do not bypass platform restrictions. Other authorized ad slots must collapse to **zero height** when empty and never overlay content.
- Publisher content remains on the publishers' official sites. If in-app embedding rights are missing, use external browser.

## What is NOT implemented
- This is **not an APK**, an Android WebView, a streaming service, a live/authorized catalogue, a redesigned Sports screen, or a deployed Cloudflare Worker/D1 modification.
- Demo names are fictional placeholders; permissions, logos, stream endpoints and official links must be verified before production.
- Existing Android app navigation/header/ads/search styling must be inspected before integration. Without the latest Android project ZIP these cannot be guaranteed pixel-perfect.

## Proposed Android integration sequence
1. Audit latest Android source ZIP and current app shell; preserve all locked source/versions.
2. Translate `assets/app.css` layout tokens and `assets/app.js` category/search logic into the project's existing native UI technology.
3. Fetch authorised channel/publisher records from backend; validate HTTPS URLs, allowlist domains and permission status.
4. Display authorized logos with `contain/fit`, otherwise fallback to typography. Use official destinations only.
5. Integrate YouTube option C in an isolated Android test branch with ad-off/fullscreen/back handling; validate relevant platform policies before release.
6. Regression-test Ads, Home, Sports, Search, Navigation, security, performance, Bangla fonts, phones/tablets, errors, and backups.

## Preview colors and dimensions
- Primary ink: `#111F36`; brand blue: `#285EE9`; base: `#F7F9FC`; surface: `#FFFFFF`; line: `#E4EAF2`.
- Mobile: 2-column responsive cards; tablet: 3; wide: 4. All interactive tiles are responsive and keyboard focusable.
- Original fictional wordmarks and gradient monograms replace unauthorized brand assets.

All app modifications remain **pending** until latest Android source ZIP is supplied and verified.
