/* OneTV responsive concept — presentation prototype, not installed Android code.
   No scraping, video proxying, auto-play, unverified external destination or backend call. */
(function () {
  'use strict';
  const catalogue = window.ONETV_PREVIEW_CATALOGUE || { categories: [], channels: [], publishers: [] };
  const params = new URLSearchParams(window.location.search);
  const allowedPages = new Set(['home','sports','entertainment','news','youtube']);
  const initialPage = (params.get('view') || 'entertainment').toLowerCase();
  const state = { page: allowedPages.has(initialPage) ? initialPage : 'entertainment', category: 'all', query: params.get('q') || '', adAvailable: params.get('ad') === '1' };
  const elements = {
    tabs: Array.from(document.querySelectorAll('.tab')), main: document.getElementById('main'),
    channels: document.getElementById('channelsGrid'), publishers: document.getElementById('publishersGrid'),
    chips: document.getElementById('categoryChips'), channelCount: document.getElementById('channelCount'),
    publisherCount: document.getElementById('publisherCount'), emptyChannel: document.getElementById('channelEmpty'),
    emptyPublisher: document.getElementById('publisherEmpty'), ad: document.getElementById('adSlot'),
    backdrop: document.getElementById('detailBackdrop'), modalClose: document.getElementById('modalClose'),
    modalDone: document.getElementById('modalDone'), modalMark: document.getElementById('modalMark'),
    modalTitle: document.getElementById('modalTitle'), modalDescription: document.getElementById('modalDescription'),
    modalNotice: document.getElementById('modalNotice'), modalEyebrow: document.getElementById('modalEyebrow')
  };
  let previousFocus = null;
  const norm = value => String(value || '').normalize('NFKC').toLocaleLowerCase().replace(/[\p{P}\p{S}]+/gu, ' ').replace(/\s+/g,' ').trim();
  const match = item => {
    if (!state.query.trim()) return true;
    const q = norm(state.query);
    return [item.name,item.wordmark,item.subtitle,item.country,item.language,...(item.aliases||[])].some(value => norm(value).includes(q));
  };
  const label = (tag, className, text) => {const el=document.createElement(tag);if(className)el.className=className;if(text!==undefined)el.textContent=text;return el;};
  function channels() {
    return (catalogue.channels || []).filter(item => item.enabled === true)
      .filter(item => state.category === 'all' || (item.categories||[]).includes(state.category)).filter(match)
      .sort((a,b) => (b.priority||0)-(a.priority||0) || (b.popularity||0)-(a.popularity||0) || a.name.localeCompare(b.name));
  }
  function publishers() {
    return (catalogue.publishers||[]).filter(item => item.enabled===true).filter(match)
      .sort((a,b) => (b.priority||0)-(a.priority||0) || a.name.localeCompare(b.name));
  }
  function renderChips() {
    elements.chips.replaceChildren();
    const availableCategories = (catalogue.categories||[]).filter(cat => cat.id==='all' || (catalogue.channels||[]).some(item => item.enabled && (item.categories||[]).includes(cat.id)));
    for (const cat of availableCategories) {
      const chip=label('button','chip'+(state.category===cat.id?' active':''),cat.label);
      chip.type='button';chip.dataset.category=cat.id;chip.setAttribute('aria-pressed', String(state.category===cat.id));
      chip.addEventListener('click',()=>{state.category=cat.id;renderChips();renderChannels();});elements.chips.append(chip);
    }
  }
  function renderChannels() {
    const list=channels();elements.channels.replaceChildren();elements.channelCount.textContent=`${list.length} CHANNEL${list.length===1?'':'S'}`;
    elements.emptyChannel.hidden=list.length!==0;
    for (const item of list) {
      const card=label('button','channel-tile');card.type='button';card.setAttribute('aria-label', `${item.name}, ${item.subtitle}. View catalogue details.`);
      const art=label('span','channel-top palette-'+(item.palette||'slate'));
      if(item.logoPermissionVerified && item.logoUrl){
        const img=label('img','channel-logo');img.alt=item.name+' logo';img.loading='lazy';img.referrerPolicy='no-referrer';img.src=item.logoUrl;
        img.addEventListener('error',()=>{img.remove();art.append(label('span','channel-monogram',item.short||item.name.charAt(0)));});art.append(img);
      }else art.append(label('span','channel-monogram'+(String(item.short||'').length>1?' two':''),item.short||item.name.charAt(0)));
      const body=label('span','tile-meta');const left=label('span','tile-meta-left');left.append(label('span','tile-name',item.name),label('span','tile-subtitle',item.subtitle||'CHANNEL'));
      body.append(left,label('span','tile-arrow','↗'));card.append(art,body);card.addEventListener('click',()=>openDetails(item,'channel'));elements.channels.append(card);
    }
  }
  function renderPublishers() {
    const list=publishers();elements.publishers.replaceChildren();elements.publisherCount.textContent=`${list.length} PUBLISHER${list.length===1?'':'S'}`;
    elements.emptyPublisher.hidden=list.length!==0;
    for(const item of list){
      const card=label('button','publisher-tile wm-'+(item.palette||'navy'));card.type='button';card.setAttribute('aria-label',`${item.name}, ${item.language}. View publisher details.`);
      const kicker=label('span','publisher-kicker',item.caption||'PUBLISHER');
      const wordmark=label('span','publisher-wordmark'+((item.wordmark||'')===(item.wordmark||'').toUpperCase()?' uppercase':''),item.wordmark||item.name);
      const origin=label('span','publisher-origin',`${item.country||'Global'} · ${item.language||'English'}`);
      if(item.logoPermissionVerified && item.logoUrl){
        const img=label('img','publisher-logo');img.alt=item.name+' logo';img.loading='lazy';img.referrerPolicy='no-referrer';img.src=item.logoUrl;
        img.addEventListener('error',()=>{img.remove();card.insertBefore(wordmark,card.querySelector('.publisher-rule'));});
        card.append(kicker,img,label('span','publisher-rule'),origin);
      }else card.append(kicker,wordmark,label('span','publisher-rule'),origin);card.addEventListener('click',()=>openDetails(item,'publisher'));elements.publishers.append(card);
    }
  }
  function navigate(page) {
    if(!allowedPages.has(page))return;
    state.page=page;
    for (const el of elements.tabs) {const active=el.dataset.page===page;el.classList.toggle('active',active);el.setAttribute('aria-current',active?'page':'false');}
    for (const key of ['home','sports','entertainment','news','youtube']) document.getElementById(key+'Page').hidden=(page!==key);
    // The existing ad placement is hidden during the complete YouTube web experience.
    elements.ad.hidden=!state.adAvailable||page==='youtube';
    elements.main.scrollTop=0;window.scrollTo({top:0,behavior:'instant'});
    if (page==='entertainment'){renderChips();renderChannels();}if(page==='news')renderPublishers();
  }
  function openDetails(item,kind){
    if(item.openingMode==='YOUTUBE_WEBVIEW'){navigate('youtube');return;}
    previousFocus=document.activeElement;
    elements.modalMark.textContent=kind==='channel'?(item.short||item.name[0]):'▤';
    elements.modalMark.className='detail-mark '+(kind==='channel'?'palette-'+(item.palette||'slate'):'palette-slate');
    elements.modalEyebrow.textContent=kind==='channel'?'CHANNEL DIRECTORY':'PUBLISHER DIRECTORY';
    elements.modalTitle.textContent=item.name;
    elements.modalDescription.textContent=kind==='channel'?(item.subtitle||'Channel catalogue entry'):`${item.country||'International'} · ${item.language||'English'}`;
    elements.modalNotice.textContent='Illustrative entry only. A real URL/player is intentionally not connected. Production opens only approved official destinations after rights and technical checks; otherwise it uses an external official link.';
    elements.backdrop.hidden=false;document.body.style.overflow='hidden';elements.modalClose.focus();
  }
  function closeDetails(){elements.backdrop.hidden=true;document.body.style.overflow='';if(previousFocus && previousFocus.isConnected)previousFocus.focus();}
  for(const tab of elements.tabs) tab.addEventListener('click',()=>navigate(tab.dataset.page));
  elements.modalClose.addEventListener('click',closeDetails);elements.modalDone.addEventListener('click',closeDetails);
  elements.backdrop.addEventListener('click',event=>{if(event.target===elements.backdrop)closeDetails();});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!elements.backdrop.hidden)closeDetails();});
  document.getElementById('youtubeReturn').addEventListener('click',()=>navigate('entertainment'));
  // Connect this behavior to the app's EXISTING search UI during Android integration. No duplicate search widget added.
  window.OneTVPreview={navigate,search(query){state.query=String(query||'');renderChannels();renderPublishers();},setAdAvailable(value){state.adAvailable=Boolean(value);elements.ad.hidden=!state.adAvailable||state.page==='youtube';},setCatalogue(next){if(next && Array.isArray(next.channels) && Array.isArray(next.publishers) && Array.isArray(next.categories)){catalogue.channels=next.channels;catalogue.publishers=next.publishers;catalogue.categories=next.categories;renderChips();renderChannels();renderPublishers();}}};
  navigate(state.page);
})();
