from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
root=Path(__file__).resolve().parent
W,H=1920,1080
im=Image.new('RGB',(W,H))
pix=im.load()
for y in range(H):
    r=int(244 - (y/H)*8);g=int(248 - (y/H)*7);b=int(253 - (y/H)*6)
    for x in range(W): pix[x,y]=(r,g,b)
d=ImageDraw.Draw(im)
# original presentation decor: subtle ring shapes
for step in range(5):
    d.ellipse((1370-110-step*70,-180-step*70,2060+step*70,530+step*70),outline=(225+min(step,3),232+min(step,3),247),width=2)
d.ellipse((-450,700,470,1640),outline=(226,235,249),width=3)
font_reg='/usr/share/fonts/opentype/inter/Inter-Regular.otf'
font_bold='/usr/share/fonts/opentype/inter/Inter-Bold.otf'
font_semi='/usr/share/fonts/opentype/inter/Inter-SemiBold.otf'
font_light='/usr/share/fonts/opentype/inter/Inter-Medium.otf'
def font(path,size):return ImageFont.truetype(path,size)
# brand top
d.rounded_rectangle((100,86,152,138),radius=14,fill=(43,95,233))
d.polygon([(120,100),(120,124),(139,112)],fill='white')
d.text((169,94),'OneTV',font=font(font_bold,34),fill='#11233d')
d.ellipse((278,118,287,127),fill='#2865ee')
d.text((104,185),'2026 / UI DESIGN SYSTEM',font=font(font_bold,18),fill='#3768b5',stroke_width=0)
# headline
d.text((95,246),'A cleaner way',font=font(font_bold,76),fill='#0c1d34')
d.text((95,333),'to discover.',font=font(font_bold,76),fill='#0c1d34')
d.text((100,454),'OneTV • Entertainment & Newspapers',font=font(font_semi,25),fill='#2d4566')
d.text((100,501),'A premium, mobile-first interface built around',font=font(font_reg,22),fill='#64758e')
d.text((100,532),'familiar navigation and effortless discovery.',font=font(font_reg,22),fill='#64758e')
# callouts
features=[('01','Curated channel directory'),('02','Smart category discovery'),('03','Publisher-first experience'),('04','Responsive by design')]
for idx,(num,txt) in enumerate(features):
    top=630+idx*76
    d.rounded_rectangle((100,top,613,top+58),radius=14,fill=(255,255,255),outline=(228,235,246),width=2)
    d.rounded_rectangle((114,top+12,149,top+45),radius=10,fill=(234,240,255))
    d.text((120,top+19),num,font=font(font_semi,13),fill='#315fdc')
    d.text((164,top+16),txt,font=font(font_semi,21),fill='#344963')

# phones: use first 844 CSS px of captures (generated at DPR=2)
for x,source,title in [(790,'OneTV_Entertainment_Mobile.png','ENTERTAINMENT'),(1320,'OneTV_News_Mobile.png','NEWSPAPERS')]:
    screen=Image.open(root/'previews'/source).convert('RGB')
    sw,sh=screen.size
    # crop viewport; if full image was larger, capture first 844 CSS pixels
    screen=screen.crop((0,0,sw,min(sh,1688)))
    screen=screen.resize((410,887),Image.Resampling.LANCZOS)
    # phone frame (soft drop shadow)
    frame=Image.new('RGBA',(449,932),(0,0,0,0));fd=ImageDraw.Draw(frame)
    fd.rounded_rectangle((9,9,441,925),radius=43,fill=(16,32,52,30))
    frame=frame.filter(ImageFilter.GaussianBlur(12)); im.paste(frame,(x-18,107),frame)
    d.rounded_rectangle((x-9,118,x+419,1024),radius=42,fill=(16,29,49))
    d.rounded_rectangle((x-3,125,x+413,1015),radius=34,fill=(255,255,255))
    # create rounded screen mask
    mask=Image.new('L',screen.size,0); m=ImageDraw.Draw(mask);m.rounded_rectangle((0,0,410,887),radius=31,fill=255)
    im.paste(screen,(x,128),mask)
    # subtle top speaker
    d.rounded_rectangle((x+169,130,x+243,135),radius=4,fill=(217,224,235))
    d.rounded_rectangle((x+112,1042,x+300,1071),radius=12,fill=(232,239,250))
    d.text((x+131,1049),title,font=font(font_bold,14),fill='#536b91')

output=root/'previews/OneTV_Premium_UI_Design_Board.png'
im.save(output,optimize=True)
print(output, im.size)
# Optional single-page PDF review artifact from the tested screenshot montage
im.save(root/'OneTV_Premium_UI_Design_Board.pdf','PDF',resolution=150)
