/* ILLUSTRATIVE PREVIEW DATA ONLY. These are NOT verified real channels, publishers, logos, streams, or permissions.
   Production source of truth: authenticated/authorized OneTV backend catalogue and permission records. */
window.ONETV_PREVIEW_CATALOGUE = {
  categories: [
    { id: 'all', label: 'All Channels' },
    { id: 'sports', label: 'Sports' },
    { id: 'news', label: 'News' },
    { id: 'movies', label: 'Movies & Series' },
    { id: 'kids', label: 'Kids' },
    { id: 'music', label: 'Music' },
    { id: 'lifestyle', label: 'Lifestyle' },
    { id: 'documentary', label: 'Documentary' }
  ],
  channels: [
    { id:'arena', name:'Arena Live', short:'A', categories:['sports'], subtitle:'SPORTS CHANNEL', palette:'blue', priority:90, popularity:990, enabled:true, openingMode:'EXTERNAL', rightsStatus:'unverified', officialUrl:null },
    { id:'worlddesk', name:'World Desk', short:'W', categories:['news'], subtitle:'GLOBAL NEWS', palette:'umber', priority:86, popularity:900, enabled:true, openingMode:'EXTERNAL', rightsStatus:'unverified', officialUrl:null },
    { id:'novacinema', name:'Nova Cinema', short:'N', categories:['movies'], subtitle:'MOVIES & SERIES', palette:'violet', priority:84, popularity:880, enabled:true, openingMode:'EXTERNAL', rightsStatus:'unverified', officialUrl:null },
    { id:'matchday', name:'Matchday', short:'M', categories:['sports'], subtitle:'MATCH COVERAGE', palette:'teal', priority:81, popularity:854, enabled:true, openingMode:'EXTERNAL', rightsStatus:'unverified', officialUrl:null },
    { id:'littleplanet', name:'Little Planet', short:'L', categories:['kids'], subtitle:'KIDS CHANNEL', palette:'coral', priority:78, popularity:823, enabled:true, openingMode:'EXTERNAL', rightsStatus:'unverified', officialUrl:null },
    { id:'pulsemusic', name:'Pulse Music', short:'P', categories:['music'], subtitle:'MUSIC CHANNEL', palette:'magenta', priority:75, popularity:809, enabled:true, openingMode:'EXTERNAL', rightsStatus:'unverified', officialUrl:null },
    { id:'atlasstories', name:'Atlas Stories', short:'AT', categories:['documentary'], subtitle:'DOCUMENTARY', palette:'forest', priority:72, popularity:781, enabled:true, openingMode:'EXTERNAL', rightsStatus:'unverified', officialUrl:null },
    { id:'earthline', name:'Earthline', short:'E', categories:['lifestyle'], subtitle:'LIFESTYLE', palette:'sunset', priority:70, popularity:765, enabled:true, openingMode:'EXTERNAL', rightsStatus:'unverified', officialUrl:null },
    { id:'courtside', name:'Courtside', short:'C', categories:['sports'], subtitle:'BASKETBALL', palette:'royal', priority:66, popularity:722, enabled:true, openingMode:'EXTERNAL', rightsStatus:'unverified', officialUrl:null },
    { id:'afterhours', name:'After Hours', short:'AH', categories:['movies'], subtitle:'ENTERTAINMENT', palette:'slate', priority:60, popularity:630, enabled:true, openingMode:'EXTERNAL', rightsStatus:'unverified', officialUrl:null },
    { id:'youtube', name:'YouTube', short:'▶', categories:['movies','music','news','sports'], subtitle:'OFFICIAL MOBILE SITE', palette:'youtube', priority:0, popularity:0, enabled:true, openingMode:'YOUTUBE_WEBVIEW', rightsStatus:'policy-review-required', officialUrl:'https://m.youtube.com/' }
  ],
  publishers: [
    {id:'northstar', name:'The Northstar', wordmark:'NORTHSTAR', caption:'THE DAILY', country:'Global', language:'English', aliases:['Northstar Daily'], priority:99, palette:'navy', enabled:true, officialUrl:null, rightsStatus:'unverified'},
    {id:'morningpost', name:'Morning Post', wordmark:'Morning Post', caption:'INDEPENDENT JOURNALISM', country:'Global', language:'English', aliases:['The Morning Post'], priority:92, palette:'wine', enabled:true, officialUrl:null, rightsStatus:'unverified'},
    {id:'deshbulletin', name:'দেশ বুলেটিন', wordmark:'দেশ বুলেটিন', caption:'বাংলা সংবাদ', country:'Bangladesh', language:'বাংলা', aliases:['Desh Bulletin','Desh'], priority:87, palette:'indigo', enabled:true, officialUrl:null, rightsStatus:'unverified'},
    {id:'worldtimes', name:'World Times', wordmark:'WORLD TIMES', caption:'GLOBAL EDITION', country:'Global', language:'English', aliases:['The World Times'], priority:85, palette:'black', enabled:true, officialUrl:null, rightsStatus:'unverified'},
    {id:'marketjournal', name:'Market Journal', wordmark:'Market Journal', caption:'BUSINESS & FINANCE', country:'Global', language:'English', aliases:['Financial Markets'], priority:80, palette:'emerald', enabled:true, officialUrl:null, rightsStatus:'unverified'},
    {id:'cityherald', name:'City Herald', wordmark:'CITY HERALD', caption:'PEOPLE & PLACES', country:'Global', language:'English', aliases:['The City Herald'], priority:78, palette:'copper', enabled:true, officialUrl:null, rightsStatus:'unverified'},
    {id:'dailyreport', name:'Daily Report', wordmark:'DAILY REPORT', caption:'TODAY IN FOCUS', country:'Global', language:'English', aliases:['The Daily Report'], priority:74, palette:'royal', enabled:true, officialUrl:null, rightsStatus:'unverified'},
    {id:'weeklyreview', name:'Weekly Review', wordmark:'The Weekly', caption:'WEEKLY REVIEW', country:'Global', language:'English', aliases:['The Weekly Review'], priority:70, palette:'slate', enabled:true, officialUrl:null, rightsStatus:'unverified'}
  ]
};
