/* Optional staging-catalogue bridge for the browser preview only.
   To activate, open index.html?catalog=staging on a local test browser.
   Does not alter the native OneTV app or the staging backend.
   No channel owner credentials, media bytes or streams are requested. */
(function () {
  'use strict';
  if (new URLSearchParams(location.search).get('catalog') !== 'staging') return;
  const BASE = 'https://one-tv-backend-staging.ushait2019.workers.dev';
  const titles = { sports:'Sports', news:'News', movies:'Movies & Series',kids:'Kids',music:'Music',lifestyle:'Lifestyle',documentary:'Documentary',general:'General' };
  function channel(item){
    return {
      id:item.id,name:item.name,short:item.logoFallback||item.name[0],
      categories:[item.category],subtitle:(titles[item.category]||'Channel').toUpperCase() + ' CHANNEL',
      palette:'blue',priority:item.priority,popularity:item.popularity,enabled:true,
      logoUrl:item.logoUrl,logoPermissionVerified:!!item.logoUrl,openingMode:item.openingMode,
      rightsStatus:item.webviewAllowed?'verified':'external-only',officialUrl:item.officialUrl,
      aliases:item.aliases||[],country:item.country,language:item.language
    };
  }
  function publisher(item){
    return {
      id:item.id,name:item.name,wordmark:item.name,caption:'OFFICIAL PUBLISHER',
      aliases:item.aliases||[],country:item.country,language:item.language,
      palette:'navy',priority:item.priority,popularity:item.popularity,enabled:true,
      logoUrl:item.logoUrl,logoPermissionVerified:!!item.logoUrl,
      openingMode:item.openingMode,officialUrl:item.officialUrl
    };
  }
  async function load(){
    try {
      const options={headers:{Accept:'application/json'},cache:'no-store'};
      const responses=await Promise.all([
        fetch(BASE+'/directory/channels?limit=200',options),
        fetch(BASE+'/directory/publishers?limit=200',options)
      ]);
      if (responses.some(x=>!x.ok)) throw new Error('Staging directory endpoints unavailable. Run the additive migration.');
      const [a,b]=await Promise.all(responses.map(x=>x.json()));
      const categories=[{id:'all',label:'All Channels'},...(a.categories||[]).map(id=>({id,label:titles[id]||id}))];
      window.OneTVPreview.setCatalogue({channels:(a.channels||[]).map(channel),publishers:(b.publishers||[]).map(publisher),categories});
      console.info('OneTV preview: live staging directory records loaded (zero is valid).');
    } catch (e) {
      console.warn('OneTV preview: staging directory unavailable',e.message);
      // Fail closed: do NOT fall back to fictional catalogue when live staging was requested.
      window.OneTVPreview.setCatalogue({channels:[],publishers:[],categories:[{id:'all',label:'All Channels'}]});
    }
  }
  load();
}());
