"""Offline contract test: new staging API shapes map into browser UI correctly.
No outbound network or live OneTV access is used.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).parent.resolve()
html = (root/'index.html').read_text(encoding='utf-8')
css = (root/'assets/app.css').read_text(encoding='utf-8')
catalogue = (root/'data/catalog.sample.js').read_text(encoding='utf-8')
app = (root/'assets/app.js').read_text(encoding='utf-8')
adapter = (root/'data/staging-catalog-adapter.js').read_text(encoding='utf-8')

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':390,'height':844})
    page.set_content(html)
    page.add_style_tag(content=css)
    page.evaluate(catalogue)
    page.evaluate(app)
    # The adapter is gated by the exact query string, and fetch is stubbed.
    # This is deterministic local QA, not a deployed-staging or CORS test.
    page.evaluate("""() => {
      window.fetch = async (url) => ({
        ok: true,
        json: async () => String(url).includes('/directory/channels') ?
          {categories: ['sports'], channels: [{id:'qa-test',name:'QA Sports Test',category:'sports',
            aliases:['পরীক্ষা'],country:'International',language:'English',officialUrl:'https://example.org',
            logoUrl:null,openingMode:'EXTERNAL',webviewAllowed:false,featured:true,priority:10,popularity:2}]} :
          {publishers:[{id:'qa-daily',name:'QA Daily Test',category:'general',country:'Bangladesh',
            language:'Bangla',aliases:['QA Test'],officialUrl:'https://example.org',logoUrl:null,
            openingMode:'EXTERNAL',featured:false,priority:1,popularity:0}]}
      });
    }""")
    # Only the query-string activation line is bypassed because set_content has about:blank origin.
    page.evaluate(adapter.replace("if (new URLSearchParams(location.search).get('catalog') !== 'staging') return;", "/* activated by offline test harness */"))
    page.wait_for_function("document.querySelectorAll('#channelsGrid .channel-tile').length === 1")
    assert page.get_by_text('QA Sports Test').count() == 1
    assert page.locator('#categoryChips .chip').count() == 2
    page.locator('.tab[data-page="news"]').click()
    assert page.locator('#publishersGrid .publisher-tile').count() == 1
    assert page.get_by_text('QA Daily Test').count() == 1
    assert page.get_by_text('Morning Post').count() == 0
    print('PASS: local staging API contract maps dynamic channel/publisher records; no preview entries leak')
    browser.close()
