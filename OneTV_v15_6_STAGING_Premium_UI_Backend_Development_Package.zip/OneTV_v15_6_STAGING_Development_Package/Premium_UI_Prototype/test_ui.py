from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parent
html=(root/'index.html').read_text()
css=(root/'assets/app.css').read_text()
catalogue_js=(root/'data/catalog.sample.js').read_text()
app_js=(root/'assets/app.js').read_text()

def load(page):
    page.set_content(html)
    page.add_style_tag(content=css)
    page.evaluate(catalogue_js)
    page.evaluate(app_js)

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    phone = browser.new_page(viewport={'width':390,'height':844}, device_scale_factor=2)
    load(phone)
    phone.wait_for_load_state('load')
    print('ENTERTAINMENT', phone.locator('#channelsGrid .channel-tile').count(), 'category chips', phone.locator('#categoryChips .chip').count())
    assert phone.locator('#channelsGrid .channel-tile').count() == 11
    assert phone.locator('#adSlot').is_hidden()
    phone.screenshot(path=str(root/'previews/OneTV_Entertainment_Mobile.png'),full_page=True)
    phone.get_by_role('button',name='Sports',exact=True).last.click() if False else None
    phone.locator('#categoryChips .chip[data-category="sports"]').click()
    assert phone.locator('#channelsGrid .channel-tile').count()==4
    print('SPORTS CATEGORY',phone.locator('#channelsGrid .channel-tile').count())
    phone.locator('#categoryChips .chip[data-category="all"]').click()
    phone.locator('#channelsGrid .channel-tile').first.click()
    assert phone.locator('#detailBackdrop').is_visible()
    phone.locator('#modalDone').click()
    assert phone.locator('#detailBackdrop').is_hidden()
    phone.locator('.tab[data-page="news"]').click()
    assert phone.locator('#publishersGrid .publisher-tile').count()==8
    print('NEWS',phone.locator('#publishersGrid .publisher-tile').count())
    phone.screenshot(path=str(root/'previews/OneTV_News_Mobile.png'),full_page=True)
    phone.evaluate("window.OneTVPreview.search('বাংলা')")
    assert phone.locator('#publishersGrid .publisher-tile').count()==1
    print('BANGLA SEARCH',phone.locator('#publishersGrid .publisher-tile').count())
    phone.evaluate("window.OneTVPreview.search('')")
    assert phone.locator('#publishersGrid .publisher-tile').count()==8
    print('NEWS visible after search', phone.locator('#newsPage').is_visible(), phone.locator('#newsPage').get_attribute('hidden'))
    phone.evaluate("window.OneTVPreview.setAdAvailable(true)")
    assert phone.locator('#adSlot').is_visible()
    phone.wait_for_timeout(450)
    print('NEWS ad visible', phone.locator('#newsPage').is_visible(), phone.locator('#newsPage').get_attribute('hidden'))
    phone.screenshot(path=str(root/'previews/OneTV_News_Ad_Visible.png'),full_page=True)
    phone.evaluate("window.OneTVPreview.navigate('youtube')")
    assert phone.locator('#adSlot').is_hidden()
    assert phone.locator('#youtubePage').is_visible()
    print('YOUTUBE ADS HIDDEN',phone.locator('#adSlot').is_hidden())
    tablet = browser.new_page(viewport={'width':860,'height':1100}, device_scale_factor=1.5)
    load(tablet)
    assert tablet.locator('#channelsGrid .channel-tile').count()==11
    tablet.screenshot(path=str(root/'previews/OneTV_Entertainment_Tablet.png'),full_page=True)
    tiny = browser.new_page(viewport={'width':320,'height':680}, device_scale_factor=1)
    load(tiny)
    assert tiny.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
    tiny.screenshot(path=str(root/'previews/OneTV_Entertainment_SmallPhone.png'),full_page=True)
    print('RESPONSIVE CHECKS PASSED')
    browser.close()
