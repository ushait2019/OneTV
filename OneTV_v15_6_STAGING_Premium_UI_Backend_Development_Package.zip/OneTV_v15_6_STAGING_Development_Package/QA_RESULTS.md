# OneTV v15.6 QA Results — local tests, 07 November 2026

- Worker `node --check`: PASS.
- D1 additive migration: PASS in a local SQLite in-memory database; 3 new tables and 2 indexes, no baseline table modifications.
- v15.5 multi-source safety: 49/49 PASS.
- v15.4 regression: 24/24 PASS.
- Issue 02 regression: 22/22 PASS.
- Issue 01 regression: 12/12 PASS.
- v15.5 staging one-shot safety: 10/10 PASS.
- New v15.6 directory integration using Node 22 SQLite: 25/25 PASS.
- Total backend tests: **142/142**.
- Premium browser UI QA: local staging-API mapping contract PASS; 390px mobile, 320px small phone and 860px tablet; channel category filter, Bangla publisher search, modal, bottom ad collapse/visible, YouTube ad-off placeholder; PASS.

**Boundaries**: Synthetic, local tests do not prove network availability, streaming/embedding rights, official YouTube mobile website WebView compatibility, Android UI integration, real provider scores, live channel auto-discovery or app-store approval. Neither worker nor database was deployed by this package.
