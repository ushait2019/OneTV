# OneTV v15.6 — Premium Directory, Staging Package
**USHA IT · 07 November 2026 · Development / QA build · NOT a released Android APK**

## What this ZIP actually contains

This package starts from the latest **locally available** `OneTV_v15_5_Staging_Internet_MultiSource.zip`. Its existing v15.5 Worker source and tests are preserved in `Backend_Staging/`. It adds an **additive** directory module to a new `OneTV_v15_6_STAGING_Premium_Directory.mjs` and matching `.txt` and `.js` copies. It also bundles the previously created responsive Entertainment + Newspaper HTML/CSS/JS UI prototype and visual references.

**The actual last-updated OneTV Android application project ZIP was not available in the accessible conversation or Library files at build time.** This is therefore **not** a modified Android Studio project, APK/AAB, or a finished migration of the current app's real navigation, toolbar, search, or ad SDK. Do not rename this ZIP to imply that it contains the Android app.

## New backend files

- `Backend_Staging/OneTV_v15_6_STAGING_Premium_Directory.mjs`: full copy-paste-ready Cloudflare Worker code based on v15.5, with additive routes.
- `Backend_Staging/OneTV_v15_6_STAGING_Premium_Directory.txt`: byte-identical copy for Cloudflare Dashboard Editor.
- `Backend_Staging/OneTV_v15_6_Directory_Migration.sql`: separate additive D1 schema. No existing tables are altered.
- `Backend_Staging/OneTV_v15_6_Directory_Integration_Tests.mjs`: 25 integration tests against real SQLite (via Node.js built-in `node:sqlite`) through a D1-style adapter.
- `Backend_Staging/OneTV_v15_5_*`, `Backend_Staging/OneTV_v15_4_*` and other existing files: original staging baseline and regression suites.
- `Backend_Staging/Test_Staging_Directory.ps1`: safe read-only check after deployment.
- `Backend_Staging/Migrate_Staging_Directory.ps1`: explicitly authorized, admin-protected schema setup; no secrets stored.

## New backend public API (D1-only, no remote provider calls)

- `GET /directory/channels` — only enabled authorized directory entries, ranked by featured, priority and popularity.
- `GET /directory/channels?category=sports` — filter by configured Entertainment category.
- `GET /directory/publishers` — Newspaper publisher directory only; does not copy headlines or articles.
- `GET /directory/search?section=entertainment&q=...` — search channel names and aliases, Bangla/English aware.
- `GET /directory/search?section=news&q=...` — search publisher names and aliases only.
- `GET /search?section=entertainment&q=...` and `?section=news` — optional section-specific behavior. The legacy `/search` without those values stays unchanged.

`/channels`, `/sports/*`, `/ads`, `/config`, the scheduled Worker jobs, refresh/cache timings and all previous routes remain unchanged by this patch.

### Admin API — existing ADMIN_TOKEN required

- `POST /admin/directory/migrate` — create new tables if absent; never seeds imaginary channels.
- `GET, POST /admin/directory/channels`
- `PATCH, DELETE /admin/directory/channels/{slug}`
- `GET, POST /admin/directory/publishers`
- `PATCH, DELETE /admin/directory/publishers/{slug}`
- `GET /admin/directory/audit` — recent create/update/delete events.

### Permissions and media safety

Every record uses its **official HTTPS URL**, supported locale and aliases, category, enabled state, featured status, priority, optional logo, requested opening mode, separate logo and WebView permission status/evidence/expiry.

- Defaults are safe: `enabled=false`, `logo_permission=unknown`, `webview_permission=unknown`. No data rows are automatically invented or seeded.
- Public response never returns a logo without verified permission evidence; expired rights hide the logo.
- Public response degrades in-app mode to **EXTERNAL** if WebView rights are unverified or expired. UI must still respect real site headers, restrictions, and allowed redirects.
- No video proxy, file download, scraping, media re-streaming, article republication or third-party asset mirroring.
- Records only point to official sites. Administrators must verify actual ownership, territory, platform policy and rights before enabling.
- YouTube mobile WebView **Option C** is not represented as already approved. The Android integration must pass compatibility, account sign-in, fullscreen, ad prohibition and store policy checks.

## Android integration checklist

See `ANDROID_INTEGRATION_GUIDE.md` for native integration boundaries and a locked-feature acceptance plan. This ZIP does **not** contain or modify a native Android Studio app project.

## UI preview

Open `Premium_UI_Prototype/index.html` in Chrome/Edge. It contains **fictional preview entries only**. Switch between Home/Sports/Entertainment/News; Entertainment uses horizontal in-content category chips and premium tiles; News is a publisher grid; Home and Sports are static protected-section notices, not replacements for the real OneTV implementation.

After staging deployment and migration, open `Premium_UI_Prototype/index.html?catalog=staging` to make the preview call ONLY the hard-coded staging backend's public directory endpoints. This displays actual authorized D1 entries (possibly empty) instead of fictional sample entries. If it cannot connect, it fails closed to empty grids rather than showing unverified sample brands. **It is a browser test, not Android app integration.**

The prototype's YouTube page is a safe placeholder — no actual YouTube player or mobile WebView has been implemented or policy-cleared. Do not ship the prototype as an Android application.

## Recommended safe deployment workflow

1. Keep `one-tv-backend` (Production) completely unchanged. Back up current `one-tv-backend-staging` code and `one-tv-staging-db` before testing.
2. Run local Node tests shown below. Review the code diff. Confirm staging `DB` binding and `ADMIN_TOKEN` remain correct.
3. Replace **only staging Worker** code with `OneTV_v15_6_STAGING_Premium_Directory.txt`. Do not add a Cron trigger and do not touch Production.
4. Run `Migrate_Staging_Directory.ps1` explicitly to create only the new tables, or execute the SQL against `one-tv-staging-db` after backing up the database (do **not** do both unless deliberately checking idempotency).
5. Run `Test_Staging_Directory.ps1` to verify D1-only public routes return empty responses until verified records are added.
6. Add one authorized official test channel/publisher through authenticated admin endpoints; never paste a real bearer token in screenshots or chats.
7. Obtain the real latest **Android app source ZIP** before implementing changes to its native Entertainment/News views, and regression test the locked app shell and Sports/Ads behavior.

## Local commands (PowerShell, Node 22 recommended)

```powershell
cd .\Backend_Staging
node --check .\OneTV_v15_6_STAGING_Premium_Directory.mjs
node --no-warnings .\OneTV_v15_6_Directory_Integration_Tests.mjs
node .\OneTV_v15_5_Internet_Source_Tests.mjs .\OneTV_v15_6_STAGING_Premium_Directory.txt
node .\OneTV_v15_4_Regression_Tests.mjs .\OneTV_v15_6_STAGING_Premium_Directory.txt
node .\OneTV_Issue02_Regression_Tests.mjs .\OneTV_v15_6_STAGING_Premium_Directory.txt
node .\OneTV_Issue01_Regression_Tests.mjs .\OneTV_v15_6_STAGING_Premium_Directory.txt
node .\OneTV_v15_5_STAGING_OneShot_Safety_Tests.mjs .\OneTV_v15_6_STAGING_Premium_Directory.txt
```

## Important uncompleted items

- No native Android source was available to merge. **No real OneTV APK/AAB was created**. Native WebView/YouTube behaviour, Back/fullscreen, existing search control styling, ad SDK behavior, responsive Android screens and store compliance remain to be implemented and tested from the Android source.
- Current staging DB has not been modified and code has **not been deployed** from this package.
- Dynamic authorized channel discovery, YouTube Data API auto-refresh, actual live video lookup, rights contracts and real catalog population are **not included**. PDF's directory/catalogue requirement is handled; no unlicensed streaming is invented.
- No rights can be inferred from an ordinary public URL; media and third-party logos stay disabled unless an administrator documents permission.
- The backend's legacy v15.5 experimental multi-sport feed code retains its staging-only restrictions and was not certified as a new licensed data provider.

## PDF acceptance coverage

See `COMPLIANCE_MATRIX.md` for the PDF's final revisions and exact implementation status. Preserve the existing OneTV Android source and normal app navigation when it becomes available; do not replace it with the preview mockup.

## Provenance

`Requirements_Reference/OneTV_Design_Implementation_Spec_2026-11-07.pdf` is the uploaded 27-page specification (unchanged copy). The latest 23–27 visual revision controls the content-area category chips and dynamic names; earlier contradictory drafts do not override it.
