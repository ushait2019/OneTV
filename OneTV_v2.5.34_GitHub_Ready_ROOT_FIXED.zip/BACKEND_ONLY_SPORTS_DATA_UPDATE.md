# OneTV — Backend-first scheduled sports synchronization

The Cloudflare Worker now fetches sports provider data only from the scheduled handler. Public sports pages, search results and match details read D1 snapshots. Android MainActivity/UI is unchanged.

Read `backend/ONETV_BACKEND_ONLY_ARCHITECTURE_GUIDE_BN.txt` for Bangla deployment details.

Key files:
- `backend/src/index.js`: complete Cloudflare Worker implementation
- `backend/migration-sports-backend-only.sql`: idempotent D1 migration
- `backend/wrangler.toml`: one-minute cron and conservative Cricbuzz budget defaults
- `backend/OneTV_BackendOnly_Deploy.ps1`: authenticated migration and Worker deployment
- `backend/OneTV_BackendOnly_Verify.ps1`: public read-only verification
- `backend/tests/sports-backend-only.test.mjs`: Node mock D1 integration tests

Initial snapshots are populated after Cloudflare Cron fires. Deploying source code without activating the Cron Trigger will not populate data. Providers can omit scorecard/commentary or block exhausted quotas; these values are not fabricated. This change applies specifically to sports provider APIs, not on-demand TV playback/channel source resolution.
