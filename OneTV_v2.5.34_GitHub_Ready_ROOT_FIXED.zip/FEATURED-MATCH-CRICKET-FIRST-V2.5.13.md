# OneTV v2.5.13: Cricket-first Featured Match

- Featured match priority: Live Cricket, Upcoming Cricket, Live Football, Upcoming Football, then other sports.
- The featured fixture is removed from Home Live Now / Upcoming listings when a stable match identity is available, preventing duplicate display.
- Existing UI layout, cards, navigation, backend endpoints, and ad placement are unchanged.
- Provider data remains authoritative. If no eligible verified match is returned, the neutral empty state is shown.

Build status: source patch only. Compile and device validation must be performed in Android Studio / GitHub Actions.
