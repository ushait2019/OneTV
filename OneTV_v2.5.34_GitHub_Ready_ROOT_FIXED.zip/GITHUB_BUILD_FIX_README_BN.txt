OneTV v2.5.34 - GitHub Actions Android Project Root FIX (2026-11-07)
============================================================================
WHY YOU GOT "ERROR: Android project root not found":
The original source archive contains its actual Android project in:
OneTV-Source/settings.gradle.kts + OneTV-Source/app/build.gradle.kts
A GitHub Actions command searching ONLY a different name such as "***-project"
will not find the project. "***" may be secret masking in GitHub logs.

FILES INCLUDED:
- OneTV_GitHub_Ready_ROOT.zip: Extract at repository ROOT (not as a single ZIP file)
- OneTV_Fixed_GitHub_Build.yml: replace repository .github/workflows/build.yml
- OneTV_Fixed_GitHub_Release.yml: optional; replace .github/workflows/release.yml

RECOMMENDED: GitHub repository > Add file > Upload files > upload the
EXTRACTED CONTENTS of OneTV_GitHub_Ready_ROOT.zip, preserving paths including
.github/workflows/build.yml (GitHub web uploader may hide dotfolders on some OSes;
use local Git if needed). The repository root should show:
settings.gradle.kts, build.gradle.kts, gradlew, gradle/, app/, .github/

ALTERNATIVE: keep the original OneTV source ZIP in repo, but copy
OneTV_Fixed_GitHub_Build.yml as .github/workflows/build.yml (replace the old
workflow). The new workflow discovers the Android project inside any ZIP.
The .github/workflows/build.yml file MUST itself be in the repo, outside ZIP.

Run from GitHub: Actions > OneTV Android Debug APK (Autodetect Source)
> Run workflow. Download APK from artifacts when build succeeds.

IMPORTANT:
1. Commit/remove the outdated workflow that contains the line
   PROJECT_DIR=$(find ***-project ...) ; otherwise running that workflow
   will still fail. Select the NEW workflow in GitHub Actions.
2. This fix addresses PROJECT DISCOVERY only, not unrelated Gradle,
   dependency, Java compilation or signing errors.
3. The Android application Java/Kotlin, XML, SDK configs and business logic
   are byte-for-byte preserved from the uploaded v2.5.34 source archive.
4. This is a BUILD artifact workflow, NOT a Cloudflare deployment.
5. ONETV_BACKEND_URL secret is optional for debug builds when using the
   existing source fallback; if present, it is supplied to Gradle.
6. Release artifacts are UNSIGNED unless you configure signing separately.

বাংলা: ফাইলটি GitHub Actions-এ project root না পাওয়ার ভুল সংশোধন করে।
ZIP-এর ভিতরে OneTV-Source folder আছে। নতুন workflow root, nested folder,
এবং ZIP—সব অবস্থায় Android Gradle project খুঁজে নেয়।
কোডের অন্য ফিচার বদলানো হয়নি।
