# OneTV ZIP-Based GitHub Actions Workflow

## Normal update process

1. Keep one source archive in the repository root named `OneTV_GitHub_Live_Development_Workflow.zip`.
2. For each new source update, replace that same ZIP file with the new complete archive. Do not upload the extracted source files individually.
3. Commit the ZIP replacement. The `OneTV ZIP Debug CI` workflow detects the changed ZIP, extracts the Android Gradle project from inside it, builds the Debug APK, and uploads the APK as a 14-day Actions artifact.
4. To remove the source from the repository, delete the single ZIP file.

The ZIP may contain the outer `onetv_master_package/OneTV-Source/` folder structure. The workflow locates the Android project by finding `settings.gradle.kts` and checking for `app/build.gradle.kts`.

## One-time repository setup

The workflow that runs on GitHub must exist in the repository at `.github/workflows/build.yml`; GitHub does not execute workflow files that are only stored inside an uploaded ZIP. Therefore, one time only, open the existing `.github/workflows/build.yml` in the GitHub repository, choose Edit, replace its contents with the ZIP-based `build.yml` included in this source archive, and commit the change. After that, normal source updates require replacing only the ZIP file.

Keep the repository private if it contains private project code or credentials. Store backend URLs and provider credentials in GitHub Actions Secrets, not in the ZIP.

## Build limitations

This workflow builds a Debug APK on GitHub-hosted Ubuntu. It does not install the APK on a USB-connected phone. Automatic USB installation requires a separately configured self-hosted Windows runner and the optional `device-deploy.yml` workflow. This is automated build/deploy, not hot reload. Native Android UI/code changes still require a new APK. Backend-served data and remote configuration can update without an APK only where the installed client already supports those controls.

The Release workflow remains manual-only. Configure signing secrets securely before any Play Store release.
