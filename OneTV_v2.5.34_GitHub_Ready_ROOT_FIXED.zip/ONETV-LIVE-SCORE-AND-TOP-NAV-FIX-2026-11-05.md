# OneTV update — 2026-11-05

- On Home, Sports, Entertainment and News, `updateTopNavigation()` now uses a flat,
  borderless, shadow-free 56dp row, with consistent Home-styled items. Existing child
  navigation and app sections are unchanged.
- Increased the Live Status Board padding to 13dp, minimum height to 54dp,
  and status text from 12.5sp to 13.5sp.
- Updated Worker SportsAPI cricket score mapping for side-specific inning runs,
  wickets, overs and run rate; strict match-pair/time cross-provider matching;
  latest feed/detail score alignment, and stale score retention guard.
- Source SportsAPI remains **OFF** and **unapproved**. No data is fabricated.
- No changes were made to the Control Centre binary or source.
- Offline Node.js backend tests and Go Control Centre tests passed.
- Android build/device and Cloudflare deployment were not performed.
