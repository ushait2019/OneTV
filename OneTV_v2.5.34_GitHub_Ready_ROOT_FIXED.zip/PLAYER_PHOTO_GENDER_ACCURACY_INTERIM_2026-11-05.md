# OneTV Player Photo / Avatar Interim Fix (v2.5.17)

Source: full Android project and Cloudflare Worker. No new provider is enabled.

**Priority:** verified HTTPS photo > explicitly sourced male/female avatar > neutral avatar.

Unknown/conflicting gender values are **not guessed**. Numeric gender codes are ignored.
Backend sets `gender`, `avatar_url`, and `onetv_gender_verified` in normalized player rows.
Squads, batting, bowling, current batters/bowlers, lineups, and nested team player groups are covered.
Missing provider player identities, images, scorecards or commentary cannot be fabricated.

Checks: Java source parse, Worker `node --check`, local avatar contract, D1 read and existing QA mapping tests.
Android APK compile and real-device tests were not possible in this environment.

This is an interim source release. The next Android package is intended to be the final build after complete QA.
