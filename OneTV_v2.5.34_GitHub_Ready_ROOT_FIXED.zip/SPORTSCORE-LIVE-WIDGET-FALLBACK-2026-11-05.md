OneTV Live Score — SPORTScore LIVE WIDGET FALLBACK — 05 November 2026

STATUS:
- Screenshot: Kathmandu Gurkhas vs Biratnagar Kings was LIVE but both teams showed Score unavailable.
- UI is able to render real provider scores; its scoreless screen does not prove actual match score is zero.
- Exact live Worker/D1 output cannot be verified from this environment.

NEW BACKEND CHANGE:
1. Only Cloudflare scheduled ingestion (Cron) may call upstream sports APIs.
2. When SportScore /api/v1/fixtures/ returns a LIVE cricket fixture with no/partial score,
   request its documented /api/widget/matches/ once within provider call limits.
3. Only merge widget scores into a fixture after both team names and the start timestamp
   match (max 120 minutes). Home/away swapped at the provider is aligned safely.
4. Add verified runs/wickets/overs where they are available; never invent missing values.
5. The fallback can improve scores ONLY if SportScore actually returns score data.
   It does not guarantee commentary, scorecard or every competition's live scoring.
6. SportsAPI.app stays OFF by default. No license rights were changed.
7. OneTV Android UI and Usha IT Application Control Centre are unchanged in this update.

DEPLOYMENT:
1. Back up the currently deployed Cloudflare Worker script.
2. Copy the code from OneTV_CLOUDFLARE_WORKER_SPORTSCORE_WIDGET_FIX_2026-11-05.js into your Worker,
   keeping the existing DB binding, Cron schedule and secrets. Deploy only when ready.
3. Allow the scheduled Cricket Live feed refresh to run, or queue it via the existing admin panel.
4. Read-only verification pages:
   https://one-tv-backend.ushait2019.workers.dev/sports/cache-status
   https://one-tv-backend.ushait2019.workers.dev/sports/cricket/live
   https://one-tv-backend.ushait2019.workers.dev/cricket/provider-status
5. In /sports/cricket/live, find Kathmandu Gurkhas vs Biratnagar Kings and inspect
   match.home.score, match.away.score, overs, wickets, dataSources and updatedAt.
6. If the score is still unavailable after a fresh Cron sync, verify whether SportScore
   actually supplies score data for this fixture. Do NOT enable a different provider
   without confirming its commercial/caching license.

LOCAL VALIDATION:
- node --check backend/src/index.js : pass
- backend/tests/sportscore-live-widget.test.mjs : pass
- backend/tests/sportsapi-cricket-safe-mapping.test.mjs : pass
- backend/tests/source-control.test.mjs : pass
- Android APK build, live Cloudflare deployment, live API response and D1 production
  were NOT tested here. No production settings were changed.
