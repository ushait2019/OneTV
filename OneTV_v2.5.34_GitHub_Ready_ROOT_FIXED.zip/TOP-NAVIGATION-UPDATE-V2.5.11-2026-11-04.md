# OneTV Top Navigation and Home Dashboard Update v2.5.12

- Moved the four primary destinations (Home, Sports, Entertainment, News) to a fixed top navigation row directly below the app header.
- Added clear icon-plus-label navigation items with a restrained selected-state surface and accent color.
- Removed the bottom navigation bar from the shell. The fixed footer ad area and USHA IT copyright remain at the bottom.
- Top navigation is visible on the four top-level destinations and hidden on child/detail screens to preserve content space and contextual back navigation.
- Removed duplicate category cards from Home; top navigation is the single entry point to those destinations.
- Refined Home hierarchy with a dedicated Featured Match heading, one verified featured match card, and concise Live Now, Upcoming Matches and Recent Results sections.
- Limited the initial Upcoming Matches preview to three cards for better scanability; full lists remain accessible through See All.
- All match content continues to come from configured backend providers. No sample or fabricated fixture data was added.
- Updated Android versionName to 2.5.12 and versionCode to 52.

Build verification: source edits and ZIP structure checked. Android compilation and device runtime validation have not yet been performed in this environment.
