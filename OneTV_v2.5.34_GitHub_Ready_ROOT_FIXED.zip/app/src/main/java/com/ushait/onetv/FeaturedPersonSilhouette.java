package com.ushait.onetv;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.ColorFilter;
import android.graphics.PixelFormat;

/** Team-neutral, fictional silhouette when a verified player photo is unavailable.
 * It is never represented as a real captain or given an invented player name. */
public final class FeaturedPersonSilhouette extends Drawable {
    private final Paint brush = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final boolean mirrored;
    private final int tint;
    public FeaturedPersonSilhouette(boolean mirrored, int tint) {
        this.mirrored = mirrored;
        this.tint = tint;
    }
    @Override public void draw(Canvas canvas) {
        int width = getBounds().width(), height = getBounds().height();
        if (width <= 0 || height <= 0) return;
        canvas.save();
        canvas.translate(getBounds().left, getBounds().top);
        float sx = width / 160f, sy = height / 215f;
        canvas.scale(sx,sy);
        if (mirrored) { canvas.translate(160,0); canvas.scale(-1,1); }
        brush.setShader(new LinearGradient(0,0,160,205,
                new int[]{Color.argb(105,76,145,194),Color.argb(15,19,59,98)},null,Shader.TileMode.CLAMP));
        canvas.drawOval(new RectF(-32,28,130,255),brush);
        brush.setShader(null);
        brush.setColor(Color.argb(210,18,43,73));
        Path torso=new Path();
        torso.moveTo(-26,217);torso.lineTo(-8,145);torso.quadTo(18,119,66,117);
        torso.quadTo(112,120,142,147);torso.lineTo(180,217);torso.close();
        canvas.drawPath(torso,brush);
        brush.setColor(Color.argb(255,37,72,109));
        canvas.drawRoundRect(new RectF(38,96,95,151),23,23,brush);
        brush.setColor(Color.argb(255,90,128,161));
        canvas.drawOval(new RectF(27,18,105,118),brush);
        brush.setColor(Color.argb(255,10,30,50));
        Path hair=new Path();hair.moveTo(28,71);hair.quadTo(22,15,65,17);
        hair.quadTo(118,14,104,70);hair.lineTo(95,48);hair.lineTo(39,49);hair.close();
        canvas.drawPath(hair,brush);
        // Jersey panel remains abstract; no invented team emblem or player identity.
        brush.setColor(Color.argb(220,Color.red(tint),Color.green(tint),Color.blue(tint)));
        Path jersey=new Path();jersey.moveTo(46,133);jersey.lineTo(85,133);
        jersey.lineTo(116,211);jersey.lineTo(12,211);jersey.close();canvas.drawPath(jersey,brush);
        brush.setColor(Color.argb(90,235,245,255));
        canvas.drawRoundRect(new RectF(38,150,93,154),2,2,brush);
        canvas.restore();
    }
    @Override public void setAlpha(int alpha) { brush.setAlpha(alpha);invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter filter) { brush.setColorFilter(filter);invalidateSelf(); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
