package com.ushait.onetv;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.SharedPreferences;
import android.os.Build;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.ui.PlayerView;
import androidx.core.app.NotificationCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Stack;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
public class MainActivity extends Activity {

    private String BACKEND_URL = "https://one-tv-backend.ushait2019.workers.dev";
    private static final String MATCH_PENDING_MESSAGE = "Waiting for the latest update";
    private int BG = Color.rgb(5, 10, 17);
    private int PANEL = Color.rgb(13, 25, 39);
    private int CARD = Color.rgb(20, 35, 51);
    private int CARD_2 = Color.rgb(24, 42, 61);
    private int BLUE = Color.rgb(28, 126, 245);
    private int CYAN = Color.rgb(0, 205, 190);
    private int PURPLE = Color.rgb(119, 52, 245);
    private int TEXT = Color.WHITE;
    private int MUTED = Color.rgb(174, 188, 203);
    private int GREEN = Color.rgb(0, 194, 142);
    private int RED = Color.rgb(244, 63, 81);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    // Isolated Home media/data requests: do not delay player, provider or ad network work.
    private final ExecutorService homeNetwork = Executors.newFixedThreadPool(5);
    private static final int HOME_BG = Color.rgb(5, 12, 25);
    private static final String HOME_CACHE_KEY = "onetv_verified_home_v1";
    private LinearLayout activeHomeHeroHost;
    private LinearLayout activeHomeDotsHost;
    private final ArrayList<JSONObject> featuredHomeMatches = new ArrayList<>();
    private final android.util.LruCache<String, android.graphics.Bitmap> homeBackdropCache =
            new android.util.LruCache<String, android.graphics.Bitmap>(8192) {
                @Override protected int sizeOf(String key, android.graphics.Bitmap value) {
                    return Math.max(1, value.getByteCount()/1024);
                }
            };
    private int homeFeaturedPosition = 0;
    private boolean homeFeaturedCached = false;
    private long homeFeaturedCachedAt = 0L;
    private volatile boolean homeHasConnection = true;
    private final Runnable homeFeaturedRotation = new Runnable() {
        @Override public void run() {
            if (!"home".equals(screen) || featuredHomeMatches.size() < 2 ||
                    activeHomeHeroHost == null || !hasWindowFocus()) return;
            homeFeaturedPosition = (homeFeaturedPosition + 1) % featuredHomeMatches.size();
            redrawHomeFeatured();
            handler.postDelayed(this, 6500L);
        }
    };
    private final Stack<String> history = new Stack<>();
    private final List<Channel> channels = new ArrayList<>();

    private LinearLayout root;
    private FrameLayout contentHost;
    private LinearLayout topModeRow;
    private TextView pageTitle;
    private TextView pageSubtitle;
    private TextView headerSlogan;
    private ImageView logoView;
    private LinearLayout adRow;
    private LinearLayout fixedBottom;
    private LinearLayout topNavigation;
    private View headerView;
    private TextView footer;
    private TextView statusText;
    private TextView notificationBadge;
    private ImageView headerSearch;
    private ImageView headerMenu;
    private ImageView headerNotification;
    private ImageView headerShare;
    private View menuScrim;
    private LinearLayout menuDrawer;
    private String menuOriginScreen = "home";
    private SharedPreferences prefs;
    private boolean volumePopupVisible = false;
    private android.widget.PopupWindow volumePopup;
    private long lastPlayerTapAt = 0L;
    private float lastPlayerTapX = 0f;
    private int notificationSequence = 1000;
    private int searchRequestSequence = 0;
    private Runnable pendingSearchRequest;
    private FrameLayout playerFrame;
    private TextView customPlayerControls;
    private final Handler playerUiHandler = new Handler(Looper.getMainLooper());
    private JSONObject adConfig;
    // The footer ad owns its reserved area ONLY while a real ad is loaded.
    // Backend platform configuration, fullscreen, and page suppression are separate gates.
    private AdView footerAdView;
    private boolean footerAdLoaded = false;
    private boolean footerAdPlatformEnabled = true;
    private boolean footerAdSuppressed = false;
    private final Runnable footerAdRetry = new Runnable() {
        @Override public void run() {
            if (!footerAdLoaded && footerAdPlatformEnabled && footerAdView != null
                    && !isFinishing() && !isDestroyed()) {
                footerAdView.loadAd(new AdRequest.Builder().build());
            }
        }
    };
    private JSONObject remoteAppConfig;
    private long sportsRefreshMs = 30000L;
    private long cricketDetailRefreshMs = 20000L;
    private long notificationsRefreshMs = 30000L;
    private String remoteLiveStatusLabel = "Live Now";
    private String remoteUpcomingStatusLabel = "Upcoming";
    private String remoteFinishedStatusLabel = "Finished";
    private String remoteLiveBadgeLabel = "LIVE NOW";
    // The sports page owns one featured fixture. Keep the original result set intact;
    // hiding the active featured fixture is a presentation-only operation.
    private JSONObject sportFeaturedMatch = null;
    private LinearLayout sportFeaturedHost = null;
    private int sportFeaturedGeneration = 0;
    private long lastSportFeaturedPollAt = 0L;

    private boolean remoteLiveScoreEnabled = true;
    private boolean remoteDataEnabled = true;
    private LinearLayout activeSportsPage;
    private boolean activeSportsHome = false;
    private final Runnable sportsRefreshTask = new Runnable() {
        @Override public void run() {
            if (activeSportsPage == null) return;
            if (activeSportsHome && "sportsHome".equals(screen)) {
                if (activeSportsHomeList != null) loadSportsHome(activeSportsHomeList);
                handler.postDelayed(this, sportsRefreshMs);
            } else if (!activeSportsHome && "sport".equals(screen)) {
                loadSportsFromBackend(selectedSport, matchMode, activeSportsPage);
                // Keep the FEATURED hero fresh too, not only the list underneath.
                // Limit 3 D1 reads to every 90 seconds to conserve battery/network.
                long now=android.os.SystemClock.elapsedRealtime();
                if(sportFeaturedHost!=null && now-lastSportFeaturedPollAt>=45000L){
                    lastSportFeaturedPollAt=now;
                    loadSportFeatured(sportFeaturedHost,selectedSport);
                }
                handler.postDelayed(this, sportsRefreshMs);
            }
        }
    };

    private ExoPlayer player;
    private PlayerView playerView;
    private boolean fullscreen = false;
    private ViewGroup playerOriginalParent;
    private int playerOriginalIndex = 0;

    private String screen = "home";
    private String selectedSport = "cricket";
    private String selectedEntertainment = "Explore";
    private String selectedNewsCategory = "All";
    private JSONObject lastOpenedNews;
    private LinearLayout activeSportListHost;
    private String selectedSportsDirectorySection="Teams";
    private String selectedSportsDirectorySport="cricket";
    private LinearLayout activeSportsHomeList;
    private String sportsHomeMode = "live";
    private boolean entertainmentContext = false;
    private String lastSearchQuery = "";
    private String matchMode = "live";
    private JSONObject selectedMatch;
    private String detailTab = "SCORECARD";
    private JSONArray remoteMatches;
    private JSONObject remoteMatchDetail;
    private JSONArray remoteContent;
    private FrameLayout matchHeroHost;
    private final Runnable matchDetailRefreshTask = new Runnable() {
        @Override public void run() {
            if (!"match".equals(screen) || selectedMatch == null) return;
            String sport = selectedMatch.optString("sport", selectedSport).toLowerCase(Locale.US);
            if (BACKEND_URL == null || BACKEND_URL.contains("REPLACE") || !remoteDataEnabled || !remoteLiveScoreEnabled) return;
            loadMatchDetail(selectedMatch, sport, activeMatchBodyHost);
        }
    };
    private FrameLayout activeMatchBodyHost;
    // Visible diagnostic only for the selected match; never substitute synthetic scores.
    private String matchDetailDataNotice = "";
    // Finished fixtures may publish the winner and margin a few minutes after
    // their final whistle. Recheck a finite number of times; no endless polling.
    private int finishedResultRetryCount = 0;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Kept in Gradle's resValue so -PbackendUrl still overrides the endpoint.
        // The fallback above is only for a missing resource during unusual imports.
        try {
            String configured = getString(R.string.onetv_backend_url).trim();
            if (!configured.isEmpty()) BACKEND_URL = configured.replaceAll("/+$", "");
        } catch (Exception ignored) { }
        prefs = getSharedPreferences("onetv_prefs", MODE_PRIVATE);
        OneTvReminderReceiver.restoreFutureReminders(this);
        setPalette(prefs.getBoolean("dark_theme", false));
        getWindow().setStatusBarColor(HOME_BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setNavigationBarDividerColor(BG);
        getWindow().getDecorView().setOnApplyWindowInsetsListener((v, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            int bottom = insets.getSystemWindowInsetBottom();
            if (root != null) root.setPadding(0, top, 0, bottom);
            return insets;
        });
        // The remote bootstrap begins while the motion is running, not after it.
        loadRemoteAppConfig();
        homeNetwork.execute(() -> {
            try {
                android.net.ConnectivityManager cm = (android.net.ConnectivityManager)
                        getSystemService(Context.CONNECTIVITY_SERVICE);
                if (cm != null && Build.VERSION.SDK_INT >= 23) {
                    android.net.Network n = cm.getActiveNetwork();
                    android.net.NetworkCapabilities caps = n == null ? null : cm.getNetworkCapabilities(n);
                    homeHasConnection = caps != null && caps.hasCapability(
                            android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET);
                }
            } catch (Exception ignored) { homeHasConnection = true; }
        });
        MobileAds.initialize(this, status -> {});
        createNotificationChannel();
        if (savedInstanceState != null && savedInstanceState.getBoolean("onetv_ready", false)) {
            startupCompleted = true;
            openAppAfterSplash();
        } else {
            showAnimatedSplash();
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        outState.putBoolean("onetv_ready", startupCompleted);
        super.onSaveInstanceState(outState);
    }

    private boolean startupCompleted = false;

    // A self-contained, ORIGINAL three-second OneTV sonic logo; no third-party recordings.
    private volatile boolean openingSoundCancelled = false;
    private volatile android.media.AudioTrack openingAudioTrack;
    private Thread openingAudioThread;

    private void startOpeningSound() {
        // Media volume, silent/vibrate and accessibility settings take precedence.
        if (prefs != null && !prefs.getBoolean("splash_music_enabled", true)) return;
        android.media.AudioManager audio =
                (android.media.AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (audio == null || audio.getRingerMode() != android.media.AudioManager.RINGER_MODE_NORMAL
                || audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) == 0
                || audio.isMusicActive()) return;
        openingSoundCancelled = false;
        openingAudioThread = new Thread(() -> {
            android.media.AudioTrack track = null;
            try {
                final int rate = 24000;
                final int samples = rate * 3;
                short[] pcm = new short[samples];
                // Eight gently plucked, uplifting notes over three airy chords.
                final double[] melody = {523.25, 659.25, 783.99, 880.00,
                        1046.50, 783.99, 659.25, 1046.50};
                final double[] starts = {0.12, 0.43, 0.76, 1.10, 1.49, 1.84, 2.13, 2.39};
                final double[] chords = {261.63, 349.23, 392.00};
                for (int i = 0; i < samples && !openingSoundCancelled; i++) {
                    double time = (double) i / rate;
                    double signal = 0;
                    for (int note = 0; note < melody.length; note++) {
                        double age = time - starts[note];
                        if (age < 0 || age >= 0.65) continue;
                        double env = Math.min(1.0, age / 0.018) * Math.exp(-4.8 * age);
                        signal += env * (0.66 * Math.sin(2 * Math.PI * melody[note] * age)
                                + 0.23 * Math.sin(2 * Math.PI * melody[note] * 2 * age)
                                + 0.11 * Math.sin(2 * Math.PI * melody[note] * 3 * age));
                    }
                    for (int n = 0; n < chords.length; n++) {
                        double at = n * 0.89 + 0.08;
                        double age = time - at;
                        if (age < 0 || age > 1.02) continue;
                        double env = Math.sin(Math.PI * Math.min(age / 1.02, 1.0));
                        signal += 0.13 * env * (Math.sin(2 * Math.PI * chords[n] * age)
                                + 0.38 * Math.sin(2 * Math.PI * 1.5 * chords[n] * age));
                    }
                    double fade = Math.min(1.0, time / 0.12)
                            * Math.min(1.0, Math.max(0, (3.0 - time) / 0.46));
                    pcm[i] = (short) (Math.max(-1, Math.min(1, signal * 0.20 * fade)) * 32767);
                }
                if (openingSoundCancelled) return;
                android.media.AudioAttributes attrs = new android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build();
                android.media.AudioFormat format = new android.media.AudioFormat.Builder()
                        .setSampleRate(rate)
                        .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO).build();
                track = new android.media.AudioTrack.Builder()
                        .setAudioAttributes(attrs).setAudioFormat(format)
                        .setTransferMode(android.media.AudioTrack.MODE_STATIC)
                        .setBufferSizeInBytes(samples * 2).build();
                openingAudioTrack = track;
                if (openingSoundCancelled) return;
                int written = track.write(pcm, 0, pcm.length);
                if (written > 0 && !openingSoundCancelled) {
                    track.setVolume(0.58f);
                    track.play();
                    // Keep the sound independent of UI frames, but stop immediately on leave.
                    for (int elapsed = 0; elapsed < 3100 && !openingSoundCancelled; elapsed += 50) {
                        try { Thread.sleep(50); } catch (InterruptedException interrupted) { break; }
                    }
                }
            } catch (Exception ignored) {
                // Missing/disabled audio hardware must NEVER block application startup.
            } finally {
                if (track != null) {
                    try { track.pause(); track.flush(); track.release(); } catch (Exception ignored) {}
                }
                if (openingAudioTrack == track) openingAudioTrack = null;
            }
        }, "OneTV-Opening-Sonic-Logo");
        openingAudioThread.setDaemon(true);
        openingAudioThread.start();
    }

    private void stopOpeningSound() {
        openingSoundCancelled = true;
        if (openingAudioThread != null) openingAudioThread.interrupt();
        android.media.AudioTrack track = openingAudioTrack;
        if (track != null) {
            try { track.pause(); } catch (Exception ignored) {}
        }
    }


    // One-shot identity transition. No fabricated progress or backend waiting.
    private void showAnimatedSplash() {
        final FrameLayout splash = new FrameLayout(this);
        splash.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(2, 8, 24), Color.rgb(7, 19, 47), Color.rgb(5, 8, 26)}));
        splash.setClipChildren(false);

        View blueSweep = splashLight(new int[]{Color.TRANSPARENT,
                Color.argb(102, 8, 101, 255), Color.argb(68, 54, 207, 255), Color.TRANSPARENT});
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, dp(96), Gravity.CENTER);
        splash.addView(blueSweep, bp);
        blueSweep.setRotation(-20f);
        blueSweep.setAlpha(0f);
        blueSweep.setTranslationX(-dp(200));

        View violetSweep = splashLight(new int[]{Color.TRANSPARENT,
                Color.argb(64, 237, 48, 172), Color.argb(105, 114, 50, 239), Color.TRANSPARENT});
        FrameLayout.LayoutParams vp = new FrameLayout.LayoutParams(-1, dp(98), Gravity.CENTER);
        splash.addView(violetSweep, vp);
        violetSweep.setRotation(24f);
        violetSweep.setAlpha(0f);
        violetSweep.setTranslationX(dp(190));

        View halo = new View(this);
        GradientDrawable haloRing = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.argb(13, 27, 126, 245), Color.argb(5, 144, 43, 224)});
        haloRing.setShape(GradientDrawable.OVAL);
        haloRing.setStroke(dp(2), Color.argb(67, 55, 152, 255));
        halo.setBackground(haloRing);
        int diameter = Math.min(268, Math.max(166,
                getResources().getConfiguration().screenWidthDp - 80));
        FrameLayout.LayoutParams haloLp = new FrameLayout.LayoutParams(dp(diameter),dp(diameter),Gravity.CENTER);
        splash.addView(halo,haloLp);
        halo.setScaleX(.58f); halo.setScaleY(.58f); halo.setAlpha(0f);

        // The EXISTING official combined OneTV asset is revealed in two moving halves;
        // it is never replaced with a fabricated brand mark or duplicate wordmark.
        LinearLayout identity = new LinearLayout(this);
        identity.setOrientation(LinearLayout.VERTICAL);
        identity.setGravity(Gravity.CENTER);
        final FrameLayout logoStage = new FrameLayout(this);
        int logoWidth = Math.min(255, Math.max(172,
                getResources().getConfiguration().screenWidthDp - 48));
        final ImageView leftHalf = new ImageView(this);
        final ImageView rightHalf = new ImageView(this);
        for (ImageView part : new ImageView[]{leftHalf,rightHalf}) {
            part.setImageResource(R.drawable.onetv_logo);
            part.setScaleType(ImageView.ScaleType.FIT_CENTER);
            logoStage.addView(part, new FrameLayout.LayoutParams(-1,-1));
        }
        logoStage.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,oright,obottom)->{
            int width = v.getWidth(), height = v.getHeight();
            if (width <= 0 || height <= 0) return;
            int cut = width / 2;
            leftHalf.setClipBounds(new android.graphics.Rect(0,0,cut,height));
            rightHalf.setClipBounds(new android.graphics.Rect(cut,0,width,height));
        });
        identity.addView(logoStage, new LinearLayout.LayoutParams(dp(logoWidth),dp(122)));
        TextView slogan = tv("All in One", 19, Color.WHITE, true);
        slogan.setGravity(Gravity.CENTER);
        slogan.setLetterSpacing(.06f);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1,-2);
        sl.topMargin = dp(0);
        identity.addView(slogan,sl);
        TextView accent = tv("STREAM  •  SPORTS  •  ENTERTAINMENT",9,
                Color.rgb(151,191,239),true);
        accent.setGravity(Gravity.CENTER);
        accent.setLetterSpacing(.10f);
        LinearLayout.LayoutParams ac = new LinearLayout.LayoutParams(-1,-2);
        ac.topMargin = dp(16);
        identity.addView(accent,ac);
        splash.addView(identity,new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER));

        // Owner/developer identity sits low, above Android's navigation/inset area.
        LinearLayout powered = new LinearLayout(this);
        powered.setOrientation(LinearLayout.VERTICAL);
        powered.setGravity(Gravity.CENTER);
        TextView poweredBy = tv("DEVELOPED & OWNED BY",9,Color.rgb(142,163,193),true);
        poweredBy.setLetterSpacing(.12f); poweredBy.setGravity(Gravity.CENTER);
        powered.addView(poweredBy);
        TextView owner = tv("USHA IT",17,Color.WHITE,true);
        owner.setLetterSpacing(.13f); owner.setGravity(Gravity.CENTER);
        owner.setPadding(0,dp(5),0,0);
        powered.addView(owner);
        FrameLayout.LayoutParams ownerLp = new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);
        // Raised about 0.8 inches (128dp) from the previous placement; keep
        // USHA IT comfortably above the Android gesture/navigation bar.
        ownerLp.bottomMargin=dp(Math.min(152, Math.max(36,
                getResources().getConfiguration().screenHeightDp / 2 - 145)));
        splash.addView(powered,ownerLp);
        setContentView(splash);

        boolean reduceMotion = false;
        try {
            reduceMotion = android.provider.Settings.Global.getFloat(getContentResolver(),
                    android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,1f) == 0f;
        } catch (Exception ignored) {}
        final long finishAt = reduceMotion ? 200L : 2750L;
        final long fadeTime = reduceMotion ? 0L : 250L;
        if (!reduceMotion) {
            leftHalf.setAlpha(0f); rightHalf.setAlpha(0f);
            leftHalf.setTranslationX(-dp(78)); rightHalf.setTranslationX(dp(78));
            leftHalf.setRotation(-6f); rightHalf.setRotation(6f);
            leftHalf.setScaleX(.88f); rightHalf.setScaleX(.88f);
            slogan.setAlpha(0f); slogan.setTranslationY(dp(35));
            accent.setAlpha(0f); accent.setTranslationY(dp(18));
            powered.setAlpha(0f); powered.setTranslationY(dp(12));
            halo.animate().scaleX(1.05f).scaleY(1.05f).alpha(.90f)
                    .setStartDelay(180).setDuration(1800).start();
            leftHalf.animate().alpha(1f).translationX(0).rotation(0).scaleX(1f)
                    .setStartDelay(160).setDuration(1570)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
            rightHalf.animate().alpha(1f).translationX(0).rotation(0).scaleX(1f)
                    .setStartDelay(360).setDuration(1450)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
            slogan.animate().alpha(1f).translationY(0)
                    .setStartDelay(1170).setDuration(720).start();
            accent.animate().alpha(.84f).translationY(0)
                    .setStartDelay(1560).setDuration(650).start();
            powered.animate().alpha(1f).translationY(0)
                    .setStartDelay(1980).setDuration(530).start();
            blueSweep.animate().alpha(.83f).translationX(dp(200))
                    .setStartDelay(210).setDuration(2080).start();
            violetSweep.animate().alpha(.65f).translationX(-dp(190))
                    .setStartDelay(300).setDuration(2180).start();
            startOpeningSound();
        }
        handler.postDelayed(()->{
            if (startupCompleted || isFinishing() || isDestroyed()) return;
            startupCompleted=true;
            if (fadeTime==0L) { stopOpeningSound(); openAppAfterSplash(); return; }
            splash.animate().alpha(0f).setDuration(fadeTime)
                    .withEndAction(()->{
                        stopOpeningSound();
                        if (!isFinishing() && !isDestroyed()) openAppAfterSplash();
                    }).start();
        },finishAt);
    }

    private View splashLight(int[] colors) {
        View view = new View(this);
        GradientDrawable glow = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors);
        glow.setCornerRadius(dp(70));
        view.setBackground(glow);
        return view;
    }

    private void openAppAfterSplash() {
        if (isFinishing() || isDestroyed()) return;
        buildShell();
        if (prefs.getBoolean("onetv_onboarding_complete", false)) showHome(false);
        else showOnboarding();
        loadChannels();
        loadAdConfig(); // Existing ad implementation intentionally unchanged.
        loadNotifications();
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        headerView = buildHeader();
        root.addView(headerView, new LinearLayout.LayoutParams(-1, dp(78)));
        topNavigation = buildTopNavigation();
        root.addView(topNavigation, new LinearLayout.LayoutParams(-1, dp(68)));

        contentHost = new FrameLayout(this);
        root.addView(contentHost, new LinearLayout.LayoutParams(-1, 0, 1));

        fixedBottom = new LinearLayout(this);
        fixedBottom.setOrientation(LinearLayout.VERTICAL);
        fixedBottom.setBackgroundColor(BG);

        adRow = buildAds();
        fixedBottom.addView(adRow, new LinearLayout.LayoutParams(-1, dp(84)));

        footer = tv("© 2026 USHA IT. All Rights Reserved.", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(dp(8), dp(4), dp(8), dp(5));
        fixedBottom.addView(footer, new LinearLayout.LayoutParams(-1, dp(38)));

        root.addView(fixedBottom, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        updateTopNavigation();
    }

    private LinearLayout buildTopNavigation() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(9), dp(3), dp(9), dp(3));
        // Keep a flat, borderless menu surface on every top-level page.
        // The parent background is applied by updateTopNavigation().
        nav.setBackgroundColor(BG);
        nav.setElevation(0);
        return nav;
    }

    private void updateTopNavigation() {
        if (topNavigation == null) return;
        final boolean home = "home".equals(screen);
        final boolean topLevel = home || "sportsHome".equals(screen)
                || "entertainment".equals(screen) || "news".equals(screen);

        if (root != null && contentHost != null && headerView != null) {
            // The navigation always belongs directly BELOW the app header and ABOVE
            // the scrollable content. In particular, Home has NO bottom menu.
            // Do not reparent or alter fixedBottom, adRow, or the copyright footer.
            final int contentIndex = root.indexOfChild(contentHost);
            if (contentIndex >= 0 && root.indexOfChild(topNavigation) != contentIndex - 1) {
                root.removeView(topNavigation);
                root.addView(topNavigation, root.indexOfChild(contentHost),
                        new LinearLayout.LayoutParams(-1, dp(56)));
            } else {
                ViewGroup.LayoutParams params = topNavigation.getLayoutParams();
                if (params != null && params.height != dp(56)) {
                    params.height = dp(56);
                    topNavigation.setLayoutParams(params);
                }
            }

            ViewGroup.LayoutParams headerParams = headerView.getLayoutParams();
            if (headerParams != null && headerParams.height != dp(home ? 64 : 78)) {
                headerParams.height = dp(home ? 64 : 78);
                headerView.setLayoutParams(headerParams);
            }
            root.setBackgroundColor(home ? HOME_BG : BG);
            headerView.setBackgroundColor(home ? HOME_BG
                    : (darkTheme() ? Color.rgb(4, 9, 15) : BG));
            getWindow().setStatusBarColor(home ? HOME_BG
                    : (darkTheme() ? Color.rgb(4, 9, 15) : BG));

            if (headerView instanceof LinearLayout) {
                LinearLayout header = (LinearLayout) headerView;
                if (header.getChildCount() >= 3) {
                    View brand = header.getChildAt(1);
                    View spacer = header.getChildAt(2);
                    // A FIXED-WIDTH brand next to the hamburger is left-aligned.
                    // Previously Home gave this brand weight=1, centering the logo.
                    LinearLayout.LayoutParams brandLp =
                            (LinearLayout.LayoutParams) brand.getLayoutParams();
                    int windowDp = Math.max(240, getResources().getConfiguration().screenWidthDp);
                    boolean compactHeader = windowDp < 330;
                    brandLp.width = dp(compactHeader ? 82 : (home ? 112 : 102));
                    brandLp.height = dp(home ? 56 : 60);
                    brandLp.weight = 0f;
                    brand.setLayoutParams(brandLp);
                    if (brand instanceof LinearLayout) {
                        LinearLayout column = (LinearLayout) brand;
                        column.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                        if (column.getChildCount() >= 2) {
                            View logoChild = column.getChildAt(0);
                            LinearLayout.LayoutParams logoLp =
                                    (LinearLayout.LayoutParams) logoChild.getLayoutParams();
                            logoLp.width = dp(compactHeader ? 80 : 96);
                            logoLp.height = dp(compactHeader ? 40 : 44);
                            logoChild.setLayoutParams(logoLp);
                            View sloganChild = column.getChildAt(1);
                            LinearLayout.LayoutParams sloganLp =
                                    (LinearLayout.LayoutParams) sloganChild.getLayoutParams();
                            sloganLp.width = dp(compactHeader ? 80 : 96);
                            sloganChild.setLayoutParams(sloganLp);
                        }
                    }
                    LinearLayout.LayoutParams spacerLp =
                            (LinearLayout.LayoutParams) spacer.getLayoutParams();
                    spacerLp.width = 0;
                    spacerLp.weight = 1f;
                    spacer.setLayoutParams(spacerLp);
                }
            }
            if (headerSearch != null) headerSearch.setBackgroundColor(Color.TRANSPARENT);
            boolean narrowHeader = getResources().getConfiguration().screenWidthDp < 330;
            if (headerMenu != null) {
                ViewGroup.LayoutParams p = headerMenu.getLayoutParams();
                if (p != null) { p.width = dp(narrowHeader ? 32 : 38); headerMenu.setLayoutParams(p); }
            }
            if (headerSearch != null) {
                ViewGroup.LayoutParams p = headerSearch.getLayoutParams();
                if (p != null) { p.width = dp(narrowHeader ? 32 : 38); headerSearch.setLayoutParams(p); }
            }
            if (headerNotification != null && headerNotification.getParent() instanceof ViewGroup) {
                ViewGroup frame = (ViewGroup) headerNotification.getParent();
                ViewGroup.LayoutParams p = frame.getLayoutParams();
                if (p != null) { p.width = dp(narrowHeader ? 34 : 40); frame.setLayoutParams(p); }
            }
            if (headerShare != null) {
                ViewGroup.LayoutParams p = headerShare.getLayoutParams();
                if (p != null) { p.width = dp(narrowHeader ? 32 : 40); headerShare.setLayoutParams(p); }
                headerShare.setPadding(dp(narrowHeader ? 6 : 9),dp(8),dp(narrowHeader ? 6 : 9),dp(8));
            }
        }

        configureMatchDetailHeader();
        topNavigation.setVisibility(topLevel ? View.VISIBLE : View.GONE);
        if (!topLevel) return;
        topNavigation.removeAllViews();
        // The same compact menu treatment as Home now applies to Sports,
        // Entertainment and News: no extra horizontal outlined/shadowed bar.
        int widthDp = Math.max(240, getResources().getConfiguration().screenWidthDp);
        topNavigation.setPadding(dp(widthDp < 330 ? 3 : 9), dp(3),
                dp(widthDp < 330 ? 3 : 9), dp(3));
        topNavigation.setBackgroundColor(home ? HOME_BG : BG);
        topNavigation.setElevation(0);
        addTopNavItem("Home", R.drawable.ic_home, home, v -> showHome(true));
        addTopNavItem("Sports", R.drawable.ic_sports, "sportsHome".equals(screen), v -> showSportsHome(true));
        addTopNavItem("Entertainment", R.drawable.ic_entertainment,
                "entertainment".equals(screen), v -> showEntertainment("Explore", true));
        addTopNavItem("News", R.drawable.ic_news, "news".equals(screen), v -> showNews(true));
    }

    private String installedAppVersionName() {
        try {
            String version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            if (version != null && !version.trim().isEmpty()) return version;
        } catch (Exception ignored) { }
        return "Unknown";
    }

    private void configureMatchDetailHeader() {
        if (!(headerView instanceof LinearLayout) || headerMenu == null
                || headerSlogan == null || logoView == null) return;
        LinearLayout header = (LinearLayout) headerView;
        if (header.getChildCount() < 3) return;
        View brand = header.getChildAt(1), spacer = header.getChildAt(2);
        LinearLayout.LayoutParams brandLp = (LinearLayout.LayoutParams) brand.getLayoutParams();
        LinearLayout.LayoutParams spacerLp = (LinearLayout.LayoutParams) spacer.getLayoutParams();
        boolean detail = "match".equals(screen) && selectedMatch != null;
        if (detail) {
            headerMenu.setImageDrawable(matchBackArrow());
            headerMenu.setOnClickListener(v -> onBackPressed());
            logoView.setVisibility(View.GONE);
            JSONObject a = team(selectedMatch,true), b = team(selectedMatch,false);
            String first = pickText(a,"short_name","shortName","abbreviation","code","name");
            String second = pickText(b,"short_name","shortName","abbreviation","code","name");
            String label = !first.isEmpty() && !second.isEmpty()
                    ? first + " vs " + second : "Match Details";
            headerSlogan.setText(label);
            headerSlogan.setTextSize(17);
            headerSlogan.setTypeface(android.graphics.Typeface.DEFAULT,
                    android.graphics.Typeface.BOLD);
            headerSlogan.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            headerSlogan.setEllipsize(android.text.TextUtils.TruncateAt.END);
            headerSlogan.setSingleLine(true);
            LinearLayout.LayoutParams subtitleLp =
                    (LinearLayout.LayoutParams) headerSlogan.getLayoutParams();
            subtitleLp.width = -1; subtitleLp.height = -2;
            headerSlogan.setLayoutParams(subtitleLp);
            brandLp.width=0;brandLp.weight=1f;
            spacerLp.width=0;spacerLp.weight=0f;
            brand.setLayoutParams(brandLp);spacer.setLayoutParams(spacerLp);
        } else {
            headerMenu.setImageResource(R.drawable.ic_menu);
            headerMenu.setOnClickListener(v -> showMenuPage(true));
            logoView.setVisibility(View.VISIBLE);
            headerSlogan.setText("All in One");
            headerSlogan.setTextSize(11);
            headerSlogan.setGravity(Gravity.CENTER);
            headerSlogan.setSingleLine(true);
            LinearLayout.LayoutParams subtitleLp =
                    (LinearLayout.LayoutParams) headerSlogan.getLayoutParams();
            subtitleLp.width = dp(getResources().getConfiguration().screenWidthDp<330?80:96);
            subtitleLp.height=dp(14);
            headerSlogan.setLayoutParams(subtitleLp);
            // Existing header sizing in updateTopNavigation() remains authoritative.
        }
    }

    private android.graphics.drawable.Drawable matchBackArrow() {
        return new android.graphics.drawable.Drawable() {
            private final android.graphics.Paint p = new android.graphics.Paint(
                    android.graphics.Paint.ANTI_ALIAS_FLAG);
            @Override public void draw(android.graphics.Canvas canvas) {
                android.graphics.Rect b = getBounds();
                float x=b.exactCenterX(),y=b.exactCenterY();
                p.setColor(Color.WHITE);p.setStyle(android.graphics.Paint.Style.STROKE);
                p.setStrokeWidth(dp(2));p.setStrokeCap(android.graphics.Paint.Cap.ROUND);
                p.setStrokeJoin(android.graphics.Paint.Join.ROUND);
                canvas.drawLine(x+dp(7),y,x-dp(7),y,p);
                canvas.drawLine(x-dp(7),y,x-dp(1),y-dp(7),p);
                canvas.drawLine(x-dp(7),y,x-dp(1),y+dp(7),p);
            }
            @Override public void setAlpha(int alpha) {}
            @Override public void setColorFilter(android.graphics.ColorFilter filter) {}
            @Override public int getOpacity() {
                return android.graphics.PixelFormat.TRANSLUCENT;
            }
        };
    }

    private void addTopNavItem(String label, int iconRes, boolean selected, View.OnClickListener click) {
        // Identical button treatment on all four top-level destinations.
        int windowDp = Math.max(240, getResources().getConfiguration().screenWidthDp);
        boolean compact = windowDp < 350;
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(compact ? 1 : 3), dp(3), dp(compact ? 1 : 3), dp(2));

        GradientDrawable surface;
        if (selected) {
            surface = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{Color.rgb(24, 107, 225), Color.rgb(6, 46, 114)});
            surface.setStroke(dp(1), Color.argb(188, 95, 176, 255));
            item.setElevation(dp(3));
        } else {
            surface = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{Color.argb(24, 52, 103, 167), Color.argb(8, 27, 49, 93)});
            surface.setStroke(dp(1), Color.argb(26, 103, 159, 236));
        }
        surface.setCornerRadius(dp(13));
        item.setBackground(new android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(Color.argb(57, 120, 196, 255)),
                surface, null));
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(selected ? Color.WHITE : Color.rgb(189, 212, 242));
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(
                dp(compact ? 18 : 20), dp(compact ? 18 : 20));
        iconLp.gravity = Gravity.CENTER_HORIZONTAL;
        item.addView(icon, iconLp);
        TextView title = tv(label, compact ? 8.3f : 9.3f,
                selected ? Color.WHITE : Color.rgb(186, 203, 226), selected);
        title.setGravity(Gravity.CENTER);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setIncludeFontPadding(false);
        title.setPadding(0, dp(3), 0, 0);
        if (Build.VERSION.SDK_INT >= 26) {
            title.setAutoSizeTextTypeUniformWithConfiguration(
                    8, 10, 1, android.util.TypedValue.COMPLEX_UNIT_SP);
        }
        item.addView(title, new LinearLayout.LayoutParams(-1, -2));
        // Preserve the Home-style subtle 2dp selected-item accent.
        View accent = new View(this);
        accent.setBackground(round(selected ? Color.rgb(110, 204, 255)
                : Color.TRANSPARENT, 2));
        LinearLayout.LayoutParams indicator = new LinearLayout.LayoutParams(dp(21), dp(2));
        indicator.gravity = Gravity.CENTER_HORIZONTAL;
        indicator.topMargin = dp(3);
        item.addView(accent, indicator);
        item.setContentDescription(label);
        item.setOnClickListener(click);
        item.setFocusable(true);
        item.setClickable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
        lp.setMargins(dp(compact ? 1 : 3), 0, dp(compact ? 1 : 3), 0);
        topNavigation.addView(item, lp);
    }

    private View buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(10), 0, dp(10), 0);
        header.setBackgroundColor(darkTheme() ? Color.rgb(4, 9, 15) : BG);

        headerMenu = headerIcon(R.drawable.ic_menu, "Menu");
        headerMenu.setOnClickListener(v -> showMenuPage(true));
        LinearLayout.LayoutParams menuLp = new LinearLayout.LayoutParams(dp(38), dp(40));
        menuLp.setMargins(0, 0, dp(5), 0);
        header.addView(headerMenu, menuLp);

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logoView = logo;
        logo.setImageResource(R.drawable.onetv_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_START);
        brand.addView(logo, new LinearLayout.LayoutParams(dp(96), dp(44)));
        headerSlogan = tv("All in One", 11, TEXT, true);
        headerSlogan.setGravity(Gravity.CENTER);
        headerSlogan.setSingleLine(true);
        headerSlogan.setPadding(0, 0, 0, 0);
        brand.addView(headerSlogan, new LinearLayout.LayoutParams(dp(96), dp(14)));
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(dp(102), dp(60));
        brandLp.setMargins(dp(1), 0, dp(3), 0);
        header.addView(brand, brandLp);

        Space spacer = new Space(this);
        header.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1));

        headerSearch = headerIcon(R.drawable.ic_search, "Search");
        headerSearch.setBackgroundColor(Color.TRANSPARENT);
        headerSearch.setPadding(dp(7), dp(7), dp(7), dp(7));
        headerSearch.setOnClickListener(v -> showSearch(true, "all"));
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(dp(38), dp(40));
        searchLp.setMargins(dp(3), 0, dp(6), 0);
        header.addView(headerSearch, searchLp);

        headerNotification = headerIcon(R.drawable.ic_notifications, "Notifications");
        headerNotification.setOnClickListener(v -> showNotifications(true));
        FrameLayout notification = new FrameLayout(this);
        notification.addView(headerNotification, new FrameLayout.LayoutParams(dp(40), dp(40)));
        notificationBadge = tv("", 7, Color.WHITE, true);
        notificationBadge.setGravity(Gravity.CENTER);
        notificationBadge.setBackground(round(RED, 7));
        notificationBadge.setVisibility(View.GONE);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(14), dp(14), Gravity.TOP | Gravity.END);
        bp.setMargins(0, 0, dp(1), 0);
        notification.addView(notificationBadge, bp);
        header.addView(notification, new LinearLayout.LayoutParams(dp(40), dp(40)));

        // Always-visible action: Search → Notifications → Share OneTV APK.
        headerShare = headerIcon(R.drawable.ic_share, "Share OneTV app installer");
        headerShare.setPadding(dp(9),dp(8),dp(9),dp(8));
        headerShare.setOnClickListener(v -> OneTvAppShare.shareInstalledApk(this, false));
        LinearLayout.LayoutParams shareLp = new LinearLayout.LayoutParams(dp(40),dp(40));
        shareLp.leftMargin = dp(3);
        header.addView(headerShare,shareLp);
        return header;
    }

    private ImageView headerIcon(int resId, String description) {
        ImageView icon = new ImageView(this);
        icon.setImageResource(resId);
        icon.setContentDescription(description);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        icon.setColorFilter(TEXT, android.graphics.PorterDuff.Mode.SRC_IN);
        icon.setPadding(dp(8), dp(8), dp(8), dp(8));
        return icon;
    }

    private LinearLayout buildAds() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(12), dp(6), dp(12), dp(6));
        row.setBackgroundColor(BG);
        row.setVisibility(View.GONE);
        // One global footer placement only. No parallel/duplicate ad containers.
        addAdSlot(row, "home_footer");
        return row;
    }

    private void addAdSlot(LinearLayout row, String placement) {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER);
        card.setBackgroundColor(Color.TRANSPARENT);
        AdView ad = new AdView(this);
        footerAdView = ad;
        ad.setBackgroundColor(Color.TRANSPARENT);
        ad.setAdSize(AdSize.BANNER);
        boolean isDebuggable = (getApplicationInfo().flags
                & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        String unit = isDebuggable ? "ca-app-pub-3940256099942544/6300978111" : "ca-app-pub-5981864080922785/5178976268";
        ad.setAdUnitId(unit);
        card.addView(ad, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1);
        p.setMargins(dp(3), 0, dp(3), 0);
        row.addView(card, p);
        ad.setAdListener(new com.google.android.gms.ads.AdListener() {
            @Override public void onAdLoaded() {
                runOnUiThread(() -> {
                    handler.removeCallbacks(footerAdRetry);
                    footerAdLoaded = true;
                    card.setVisibility(View.VISIBLE); // Recover after a previous load failure.
                    updateFooterAdVisibility();
                });
            }
            @Override public void onAdFailedToLoad(com.google.android.gms.ads.LoadAdError error) {
                runOnUiThread(() -> {
                    footerAdLoaded = false;
                    // Keep the inner AdView eligible for a later retry; the
                    // entire parent adRow is GONE, so it occupies zero space.
                    card.setVisibility(View.VISIBLE);
                    updateFooterAdVisibility();
                    handler.removeCallbacks(footerAdRetry);
                    // Retry without allocating a second AdView or leaving a blank slot.
                    if (footerAdPlatformEnabled && !isFinishing() && !isDestroyed()) {
                        handler.postDelayed(footerAdRetry, 90_000L);
                    }
                });
            }
        });
        ad.loadAd(new AdRequest.Builder().build());
    }

    private void showHome(boolean push) {
        stopMatchDetailAutoRefresh();
        stopSportsAutoRefresh();
        handler.removeCallbacks(homeFeaturedRotation);
        entertainmentContext = false;
        if (push) push("home");
        screen = "home";
        clearContent();
        buildHome();
        hideAds(false);
    }

    private void buildHome() {
        LinearLayout page = page();
        page.setBackgroundColor(HOME_BG);
        // Keep content centered and comfortably readable in tablet / split-screen windows.
        // All child cards remain match-parent inside a max-660dp reading column.
        int homeWindowDp = Math.max(240, getResources().getConfiguration().screenWidthDp);
        int homeGutterDp = Math.max(0, (homeWindowDp - 660) / 2);
        page.setPadding(dp(homeGutterDp), dp(5), dp(homeGutterDp), dp(20));

        // Hero deliberately begins immediately below the OneTV app bar.
        LinearLayout heroHost = new LinearLayout(this);
        heroHost.setOrientation(LinearLayout.VERTICAL);
        heroHost.setPadding(dp(14), dp(0), dp(14), dp(0));
        page.addView(heroHost);
        LinearLayout dotsHost = new LinearLayout(this);
        dotsHost.setGravity(Gravity.CENTER);
        // Center dots in the entire blank gap between Featured and the Sports card.
        // 3dp top + 26dp track + 3dp first-card margin = a symmetric 32dp gap.
        LinearLayout.LayoutParams dp0 = new LinearLayout.LayoutParams(-1, dp(26));
        dp0.topMargin = dp(3);
        dp0.bottomMargin = 0;
        page.addView(dotsHost, dp0);
        activeHomeHeroHost = heroHost;
        activeHomeDotsHost = dotsHost;
        heroHost.addView(homeHeroEmpty("Finding a featured match", "Checking verified matches…"));
        showHomeFromCache(heroHost, dotsHost);

        // Approved three full-width visual destinations (blue, violet, crimson).
        LinearLayout categories = new LinearLayout(this);
        categories.setOrientation(LinearLayout.VERTICAL);
        categories.setPadding(0, dp(0), 0, dp(13));
        categories.addView(homeCategoryCard(R.drawable.ic_sports, "Sports", "Live Matches & Scores",
                new int[]{Color.rgb(2,94,158), Color.rgb(7,40,89)}, v -> showSportsHome(true)));
        categories.addView(homeCategoryCard(R.drawable.ic_entertainment, "Entertainment", "Movies, Series & More",
                new int[]{Color.rgb(123,16,188), Color.rgb(50,14,92)}, v -> showEntertainment("Explore", true)));
        categories.addView(homeCategoryCard(R.drawable.ic_news, "News", "Breaking & Top Stories",
                new int[]{Color.rgb(189,15,63), Color.rgb(97,11,46)}, v -> showNews(true)));
        page.addView(categories);

        // Existing additional match-discovery features remain accessible on scroll.
        page.addView(premiumSectionHeader("Live Now", "See All", v -> {
            sportsHomeMode = "live";
            showSportsHome(true);
        }));
        LinearLayout live = homeMatchListContainer();
        page.addView(live);
        page.addView(premiumSectionHeader("Upcoming Matches", "See All", v -> {
            sportsHomeMode = "upcoming";
            showSportsHome(true);
        }));
        LinearLayout upcoming = homeMatchListContainer();
        page.addView(upcoming);
        page.addView(premiumSectionHeader("Recent Results", "See All", v -> {
            sportsHomeMode = "results";
            showSportsHome(true);
        }));
        LinearLayout recent = homeMatchListContainer();
        page.addView(recent);
        live.addView(homeSmallState("Loading verified scores…"));
        upcoming.addView(homeSmallState("Loading verified fixtures…"));
        recent.addView(homeSmallState("Loading verified results…"));

        addScroll(page);
        // Cache is painted again into the now-attached hosts before remote refresh.
        if (!showHomeFromCache(heroHost, dotsHost, live, upcoming, recent)) {
            heroHost.removeAllViews();
            heroHost.addView(homeHeroEmpty("Top Match", "Waiting for verified provider data"));
        }
        loadHomeDashboard(heroHost, dotsHost, live, upcoming, recent);
    }

    private LinearLayout homeMatchListContainer() {
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(14), 0, dp(14), dp(8));
        return list;
    }

    private View homeSmallState(String message) {
        TextView text = tv(message, 11, Color.rgb(154,179,203), false);
        text.setGravity(Gravity.CENTER_VERTICAL);
        text.setPadding(dp(15), dp(13), dp(15), dp(13));
        text.setBackground(round(Color.rgb(12, 28, 48), 12));
        return text;
    }

    private View homeHeroEmpty(String title, String subtitle) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER_VERTICAL);
        wrap.setPadding(dp(19), dp(20), dp(19), dp(20));
        wrap.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(11,37,70), Color.rgb(22,23,65), Color.rgb(7,24,44)}));
        wrap.setMinimumHeight(dp(170));
        TextView t = tv(title, 17, Color.WHITE, true);
        wrap.addView(t);
        TextView s = tv(subtitle, 11, Color.rgb(191,213,235), false);
        s.setPadding(0, dp(7), 0, 0);
        wrap.addView(s);
        return wrap;
    }

    private LinearLayout homeCategoryCard(int iconRes, String title, String subtitle,
                                          int[] colors, View.OnClickListener click) {
        int windowDp = Math.max(240, getResources().getConfiguration().screenWidthDp);
        boolean compact = windowDp < 350;
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(compact ? 10 : 14), dp(9), dp(compact ? 10 : 14), dp(9));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(dp(compact ? 10 : 14), dp(4), dp(compact ? 10 : 14), dp(5));
        card.setLayoutParams(cp);
        card.setMinimumHeight(dp(compact ? 68 : 74));
        GradientDrawable gradient = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors);
        gradient.setCornerRadius(dp(15));
        gradient.setStroke(dp(1), Color.argb(108, 164, 204, 255));
        card.setBackground(new android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(Color.argb(67,255,255,255)),
                gradient, null));
        card.setElevation(dp(3));

        FrameLayout iconBox = new FrameLayout(this);
        GradientDrawable inner = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.argb(95,255,255,255), Color.argb(21,255,255,255)});
        inner.setCornerRadius(dp(12));
        inner.setStroke(dp(1), Color.argb(53,255,255,255));
        iconBox.setBackground(inner);
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(Color.WHITE);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int glyph = compact ? 27 : 31;
        FrameLayout.LayoutParams iconPos = new FrameLayout.LayoutParams(dp(glyph),dp(glyph),Gravity.CENTER);
        iconBox.addView(icon, iconPos);
        int tileSize = compact ? 46 : 54;
        LinearLayout.LayoutParams boxPos = new LinearLayout.LayoutParams(dp(tileSize),dp(tileSize));
        boxPos.rightMargin = dp(compact ? 10 : 14);
        card.addView(iconBox, boxPos);

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = tv(title, compact ? 16.5f : 18f, Color.WHITE, true);
        heading.setMaxLines(2);
        heading.setEllipsize(android.text.TextUtils.TruncateAt.END);
        heading.setLineSpacing(0, 1.04f);
        TextView detail = tv(subtitle, compact ? 10.2f : 11f, Color.rgb(235,241,252), false);
        detail.setMaxLines(2);
        detail.setPadding(0, dp(4), 0, 0);
        labels.addView(heading);
        labels.addView(detail);
        card.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        TextView chevron = tv("›", compact ? 23 : 26, Color.argb(235,255,255,255), true);
        chevron.setGravity(Gravity.CENTER);
        chevron.setBackground(round(Color.argb(39,255,255,255),11));
        LinearLayout.LayoutParams chevronLp = new LinearLayout.LayoutParams(dp(compact ? 25 : 30),dp(32));
        chevronLp.leftMargin = dp(compact ? 3 : 8);
        card.addView(chevron, chevronLp);
        card.setOnClickListener(click);
        card.setFocusable(true);
        card.setContentDescription(title + ", " + subtitle);
        return card;
    }

    private LinearLayout premiumSectionHeader(String title, String action, View.OnClickListener click) {
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(18), dp(8), dp(18), dp(5));
        TextView t = tv(title, 18, TEXT, true);
        TextView a = tv(action, 10.5f, MUTED, true);
        a.setOnClickListener(click);
        head.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(a, new LinearLayout.LayoutParams(-2, -2));
        return head;
    }

    // OneTV Dynamic Venue Hero, v2.5.22.
    // Priority: fully verified, re-publishable match artwork. Otherwise use an
    // original in-app sport venue illustration. No arbitrary website scraping.
    private int heroArtworkFor(JSONObject match) {
        String sport=pickText(match,"sport","sportType").toLowerCase(Locale.US);
        if(sport.isEmpty())sport="home".equals(screen)?"cricket":selectedSport.toLowerCase(Locale.US);
        String identity=homeMatchIdentity(match);
        if(identity.isEmpty())identity=sport+"|"+canonicalMatchTitle(match);
        int variant=(identity.hashCode() & Integer.MAX_VALUE)%4;
        int[] group;
        switch(sport){
            case "football":group=new int[]{R.drawable.hero_football_0,R.drawable.hero_football_1,R.drawable.hero_football_2,R.drawable.hero_football_3};break;
            case "tennis":group=new int[]{R.drawable.hero_tennis_0,R.drawable.hero_tennis_1,R.drawable.hero_tennis_2,R.drawable.hero_tennis_3};break;
            case "basketball":group=new int[]{R.drawable.hero_basketball_0,R.drawable.hero_basketball_1,R.drawable.hero_basketball_2,R.drawable.hero_basketball_3};break;
            default:group=new int[]{R.drawable.hero_cricket_0,R.drawable.hero_cricket_1,R.drawable.hero_cricket_2,R.drawable.hero_cricket_3};break;
        }
        return group[variant];
    }

    private int heroAccentFor(JSONObject match) {
        String identity=homeMatchIdentity(match);
        if(identity.isEmpty())identity=canonicalMatchTitle(match);
        String sport=pickText(match,"sport").toLowerCase(Locale.US);
        int hash=identity.hashCode() & Integer.MAX_VALUE;
        float h="cricket".equals(sport)?195f:"football".equals(sport)?177f:
                "tennis".equals(sport)?224f:"basketball".equals(sport)?270f:208f;
        h=(h+(hash%27)-13+360)%360;
        return Color.HSVToColor(new float[]{h,.61f,.92f});
    }

    private String heroLicensedArtworkUrl(JSONObject match) {
        JSONObject media=match==null?null:match.optJSONObject("featured_media");
        if(media==null)media=match==null?null:match.optJSONObject("heroMedia");
        if(media==null)return "";
        // License metadata is required for third-party artwork. CC BY variants
        // are intentionally not supported here until visible credit is wired.
        String rights=pickText(media,"license","license_id","rights").trim().toLowerCase(Locale.US);
        boolean openLicense=("cc0".equals(rights)||"cc0-1.0".equals(rights)||
                "public-domain".equals(rights)||"public domain".equals(rights)||
                "onetv-original".equals(rights)||"cc-by-4.0".equals(rights)||
                "cc-by-3.0".equals(rights));
        if(!openLicense)return "";
        if(rights.startsWith("cc-by") && pickText(media,"credit","author").isEmpty())return "";
        if(!media.optBoolean("rights_verified",false)||!media.optBoolean("fixture_verified",false))return "";
        String matchedId=pickText(media,"fixture_id","match_id","matchId");
        String ourId=pickText(match,"id","match_id","matchId");
        if(matchedId.isEmpty()||ourId.isEmpty()||!matchedId.equals(ourId))return "";
        String url=pickText(media,"image_url","url","backdrop_url");
        return firstPartySportsMediaUrl(url);
    }

    private void addDynamicHeroBackdrop(FrameLayout hero,JSONObject match) {
        ImageView image=new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setImageResource(heroArtworkFor(match));
        hero.addView(image,new FrameLayout.LayoutParams(-1,-1));
        String verified=heroLicensedArtworkUrl(match);
        if(!verified.isEmpty()) loadFeaturedLicensedArtwork(image,verified);
    }

    private void loadFeaturedLicensedArtwork(ImageView view,String uri) {
        view.setTag(uri);
        android.graphics.Bitmap cached=homeBackdropCache.get(uri);
        if(cached!=null){view.setImageBitmap(cached);return;}
        homeNetwork.execute(()->{
            HttpURLConnection connection=null;
            try {
                connection=(HttpURLConnection)new URL(uri).openConnection();
                connection.setConnectTimeout(5000);connection.setReadTimeout(7000);
                connection.setInstanceFollowRedirects(false);
                if(connection.getResponseCode()!=200)return;
                String mime=connection.getContentType();
                if(mime==null||!mime.toLowerCase(Locale.US).startsWith("image/"))return;
                java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();
                try(InputStream input=connection.getInputStream()){
                    byte[] block=new byte[8192];int n;
                    while((n=input.read(block))>0){
                        if(bytes.size()+n>3_500_000)return;
                        bytes.write(block,0,n);
                    }
                }
                byte[] contents=bytes.toByteArray();
                android.graphics.BitmapFactory.Options options=new android.graphics.BitmapFactory.Options();
                options.inJustDecodeBounds=true;
                android.graphics.BitmapFactory.decodeByteArray(contents,0,contents.length,options);
                if(options.outWidth<400||options.outHeight<200)return;
                options.inSampleSize=Math.max(1,Math.max(options.outWidth/1100,options.outHeight/720));
                options.inJustDecodeBounds=false;
                final android.graphics.Bitmap bitmap=android.graphics.BitmapFactory.decodeByteArray(contents,0,contents.length,options);
                if(bitmap==null)return;
                homeBackdropCache.put(uri,bitmap);
                runOnUiThread(()->{
                    if(uri.equals(view.getTag())&&view.getParent()!=null)view.setImageBitmap(bitmap);
                });
            }catch(Exception ignored){} finally{if(connection!=null)connection.disconnect();}
        });
    }

    private TextView heroSmallBadge(String label,int color) {
        TextView badge=tv(label,9f,Color.WHITE,true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(9),dp(5),dp(9),dp(5));
        GradientDrawable plate=round(color,11);
        plate.setStroke(dp(1),Color.argb(48,255,255,255));
        badge.setBackground(plate);
        badge.setMaxLines(1);
        badge.setEllipsize(android.text.TextUtils.TruncateAt.END);
        return badge;
    }

    private View premiumMatchHero(JSONObject m) {
        int widthDp=getResources().getConfiguration().screenWidthDp;
        // Respect the existing 14dp page margins and support phones/tablets.
        int contentDp=Math.max(150,Math.min(760,widthDp-28));
        boolean compact=contentDp<345;
        int heightDp=compact?256:(contentDp<480?272:Math.min(338,Math.round(contentDp*.49f)));
        int portraitDp=Math.max(70,Math.min(225,Math.round(contentDp*(compact?.30f:.31f))));
        int portraitHeight=heightDp-(compact?66:64);
        // Sports Featured only: broadcast-size crests. The Home Featured sizing
        // stays unchanged. Reserve a guaranteed readable centre for team names.
        int crestEdgeReserveDp=contentDp<270?8:(compact?10:(contentDp<480?14:20));
        int minimumCentreDp=compact?108:132;
        int targetLogoDp=Math.round(contentDp*(compact?0.25f:0.255f));
        int logoFloorDp=contentDp<270?50:76;
        int logoCeilingDp=compact?84:(contentDp<480?104:(contentDp<680?122:138));
        int desiredLogoDp=Math.min(logoCeilingDp,Math.max(logoFloorDp,targetLogoDp));
        int safeLogoDp=Math.max(40,(contentDp-minimumCentreDp)/2-crestEdgeReserveDp-10);
        int logoDp=Math.min(desiredLogoDp,safeLogoDp);
        int accent=heroAccentFor(m);
        JSONObject home=team(m,true),away=team(m,false);
        JSONObject homeCaptain=explicitlyVerifiedCaptain(m,home,true);
        JSONObject awayCaptain=explicitlyVerifiedCaptain(m,away,false);
        String mode=pickText(m,"_listingMode","listingMode");
        String state=professionalSportsStatusLabel(m,mode);

        FrameLayout hero=new FrameLayout(this);
        GradientDrawable shape=round(Color.rgb(8,20,40),19);
        shape.setStroke(dp(1),Color.argb(118,124,167,206));
        hero.setBackground(shape);
        hero.setClipToOutline(true);
        hero.setElevation(dp(3));
        LinearLayout.LayoutParams heroParams=new LinearLayout.LayoutParams(
                widthDp>850?dp(contentDp):-1,dp(heightDp));
        heroParams.gravity=Gravity.CENTER_HORIZONTAL;
        hero.setLayoutParams(heroParams);
        addDynamicHeroBackdrop(hero,m);

        // Full-bleed cinematic shade: readable typography over bright stadiums.
        View darkening=new View(this);
        darkening.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.argb(85,5,11,26),Color.argb(146,3,10,28),Color.argb(216,3,10,23)}));
        hero.addView(darkening,new FrameLayout.LayoutParams(-1,-1));

        // Premium portraits are shown when team-bound player records exist.
        // Otherwise the banner keeps a clean stadium-first presentation.
        // Keep the central match names legible on compact split-screen windows.
        boolean showLeftPortrait=contentDp>=310 && !featuredVerifiedPhoto(homeCaptain).isEmpty();
        boolean showRightPortrait=contentDp>=310 && !featuredVerifiedPhoto(awayCaptain).isEmpty();
        if(showLeftPortrait){
            ImageView left=featuredSidePortrait(homeCaptain,false,true,accent);
            FrameLayout.LayoutParams leftLp=new FrameLayout.LayoutParams(dp(portraitDp),dp(portraitHeight),Gravity.LEFT|Gravity.BOTTOM);
            leftLp.bottomMargin=dp(41);hero.addView(left,leftLp);
        }
        if(showRightPortrait){
            ImageView right=featuredSidePortrait(awayCaptain,true,false,accent);
            FrameLayout.LayoutParams rightLp=new FrameLayout.LayoutParams(dp(portraitDp),dp(portraitHeight),Gravity.RIGHT|Gravity.BOTTOM);
            rightLp.bottomMargin=dp(41);hero.addView(right,rightLp);
        }

        View readable=new View(this);
        readable.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.argb(10,4,11,29),Color.argb(171,4,12,29),
                        Color.argb(190,4,12,29),Color.argb(10,4,11,29)}));
        hero.addView(readable,new FrameLayout.LayoutParams(-1,-1));

        // Keep BOTH crests near their respective OUTER edges. The previous
        // portraitDp-23 margin pushed both crests into team-name/VS territory.
        // Chest-height bottom anchors protect the faces in source portraits.
        int crestEdgeDp=crestEdgeReserveDp;
        int crestBottomDp=compact?68:74;
        FrameLayout.LayoutParams logoLeft=new FrameLayout.LayoutParams(dp(logoDp),dp(logoDp),Gravity.LEFT|Gravity.BOTTOM);
        logoLeft.leftMargin=dp(crestEdgeDp);logoLeft.bottomMargin=dp(crestBottomDp);
        hero.addView(featuredInnerLogo(home,logoDp,accent),logoLeft);
        FrameLayout.LayoutParams logoRight=new FrameLayout.LayoutParams(dp(logoDp),dp(logoDp),Gravity.RIGHT|Gravity.BOTTOM);
        logoRight.rightMargin=dp(crestEdgeDp);logoRight.bottomMargin=dp(crestBottomDp);
        hero.addView(featuredInnerLogo(away,logoDp,accent),logoRight);

        // Premium hero heading: competition alone on its own unobstructed row.
        // Actual match status stays in the dedicated metadata footer below.
        // Never paint a FEATURED badge over a team crest or licensed portrait.
        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(11),dp(10),dp(11),0);
        String league=pickText(m,"competition","league","tournament","competition_name");
        TextView competition=tv(league.isEmpty()?sportName(pickText(m,"sport")):league,
                compact?9.5f:11f,Color.WHITE,true);
        competition.setMaxLines(1);
        competition.setEllipsize(android.text.TextUtils.TruncateAt.END);
        top.addView(competition,new LinearLayout.LayoutParams(-1,-2));
        hero.addView(top,new FrameLayout.LayoutParams(-1,-2,Gravity.TOP));

        String roundText=pickText(m,"round","stage","matchTitle","format","match_format");
        if(!roundText.isEmpty()){
            TextView roundLabel=tv(roundText,compact?8.5f:10.3f,Color.rgb(215,230,252),true);
            roundLabel.setGravity(Gravity.CENTER);
            roundLabel.setMaxLines(1);roundLabel.setEllipsize(android.text.TextUtils.TruncateAt.END);
            roundLabel.setPadding(dp(11),dp(4),dp(11),dp(4));
            roundLabel.setBackground(round(Color.argb(138,5,24,55),12));
            FrameLayout.LayoutParams stageLp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);
            stageLp.topMargin=dp(compact?43:45);
            hero.addView(roundLabel,stageLp);
        }

        // Central typography stays within the gap between outer portraits.
        // Centre copy cannot enter either crest plate, including with verified portraits.
        int crestReserveDp=crestEdgeDp+logoDp+10;
        int playerReserveDp=(showLeftPortrait||showRightPortrait)?portraitDp+8:0;
        int sideReserveDp=Math.max(crestReserveDp,playerReserveDp);
        int centreWidth=Math.max(68,contentDp-2*sideReserveDp);
        LinearLayout centre=new LinearLayout(this);
        centre.setOrientation(LinearLayout.VERTICAL);
        centre.setGravity(Gravity.CENTER);
        TextView h=tv(pickText(home,"name","team_name","short_name"),compact?11f:13.2f,Color.WHITE,true);
        h.setGravity(Gravity.CENTER);h.setMaxLines(2);
        h.setEllipsize(android.text.TextUtils.TruncateAt.END);
        centre.addView(h,new LinearLayout.LayoutParams(-1,-2));
        String aScore=pickText(away,"score","points","total");
        String hScore=pickText(home,"score","points","total");
        boolean showScore=!"upcoming".equalsIgnoreCase(mode) && !hScore.isEmpty() && !aScore.isEmpty();
        TextView vs=tv(showScore?hScore+"  :  "+aScore:"VS",showScore?(compact?14.7f:18f):(compact?17.2f:19f),
                showScore?Color.rgb(164,225,255):Color.WHITE,true);
        vs.setGravity(Gravity.CENTER);vs.setPadding(0,dp(5),0,dp(5));
        centre.addView(vs,new LinearLayout.LayoutParams(-1,-2));
        TextView a=tv(pickText(away,"name","team_name","short_name"),compact?11f:13.2f,Color.WHITE,true);
        a.setGravity(Gravity.CENTER);a.setMaxLines(2);
        a.setEllipsize(android.text.TextUtils.TruncateAt.END);
        centre.addView(a,new LinearLayout.LayoutParams(-1,-2));
        FrameLayout.LayoutParams mid=new FrameLayout.LayoutParams(dp(centreWidth),-2,Gravity.CENTER);
        mid.topMargin=dp(17);hero.addView(centre,mid);

        // Contrast-backed metadata footer contains verified status/date/venue.
        LinearLayout bottom=new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(9),dp(5),dp(9),dp(8));
        bottom.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.argb(175,4,16,35),Color.argb(237,2,12,29)}));
        LinearLayout line=new LinearLayout(this);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setPadding(dp(6),0,dp(6),0);
        if(!state.isEmpty()){
            int stateColor=("Live Now".equalsIgnoreCase(state)||"Live".equalsIgnoreCase(state))?
                    Color.argb(224,18,145,114):Color.argb(205,35,70,109);
            TextView st=heroSmallBadge(state,stateColor);
            st.setMaxWidth(dp(Math.max(66,Math.min(160,contentDp/2))));
            line.addView(st,new LinearLayout.LayoutParams(-2,-2));
        }
        String schedule=formatMatchSchedule(pickText(m,"time","startsAt","starts_at","start_time","startTime"));
        if(!schedule.isEmpty()&&!"Time not confirmed".equals(schedule)){
            TextView date=tv(schedule,compact?8.5f:9.5f,Color.rgb(227,236,246),false);
            date.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
            date.setSingleLine(true);
            date.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams dpLine=new LinearLayout.LayoutParams(0,-2,1f);
            dpLine.leftMargin=dp(state.isEmpty()?0:7);
            line.addView(date,dpLine);
        }
        bottom.addView(line,new LinearLayout.LayoutParams(-1,dp(26)));
        String venue=pickText(m,"venue","venue_name","venueName","stadium","ground");
        if(!venue.isEmpty()){
            TextView place=tv("⌖  "+venue,compact?8.6f:9.5f,Color.rgb(190,211,234),false);
            place.setGravity(Gravity.CENTER);place.setSingleLine(true);
            place.setEllipsize(android.text.TextUtils.TruncateAt.END);
            bottom.addView(place,new LinearLayout.LayoutParams(-1,-2));
        }
        String creditLine=verifiedPhotoCreditLine(m);
        if(!creditLine.isEmpty()){
            TextView credit=tv(creditLine,8f,Color.rgb(178,201,229),false);
            credit.setSingleLine(true);
            credit.setEllipsize(android.text.TextUtils.TruncateAt.END);
            credit.setGravity(Gravity.CENTER);
            JSONArray creditItems=m.optJSONArray("verifiedMediaCredits");
            JSONObject firstCredit=creditItems==null?null:creditItems.optJSONObject(0);
            String creditUrl=pickText(firstCredit,"licenseUrl","url");
            if(isValidProviderImageUrl(creditUrl)){
                credit.setPaintFlags(credit.getPaintFlags()|android.graphics.Paint.UNDERLINE_TEXT_FLAG);
                credit.setContentDescription("Photo attribution and licence; open source");
                credit.setOnClickListener(v->openExternalSource(creditUrl));
            }
            bottom.addView(credit,new LinearLayout.LayoutParams(-1,-2));
        }
        hero.addView(bottom,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));
        hero.setFocusable(true);
        hero.setContentDescription("Featured "+canonicalMatchTitle(m)+
                (state.isEmpty()?"":", "+state));
        hero.setOnClickListener(v->{selectedMatch=m;showMatchDetail(true);});
        return hero;
    }

    private ImageView featuredSidePortrait(JSONObject captain,boolean mirror,boolean left,int accent) {
        ImageView image=new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        String name=captain==null?"":playerName(captain);
        image.setImageDrawable(premiumInitialsAvatar(name,accent,true));
        image.setAlpha(captain==null?0.92f:1f);
        image.setContentDescription(captain==null?"Premium fallback avatar":
                "Verified team captain "+name);
        String photo=featuredVerifiedPhoto(captain);
        if(!photo.isEmpty()) loadPlayerAvatar(image,photo,name);
        return image;
    }

    // Only featured + match-detail crests use this shape-free view. Ordinary
    // Live/Upcoming/Results listing identities intentionally remain unchanged.
    // identityView retains the original shaped initials monogram until an
    // approved logo image loads, then loadImage replaces it with a clean crest.
    private ImageView cleanHeroCrest(JSONObject team,int bitmapDp) {
        ImageView crest=identityView(team,bitmapDp);
        crest.setBackground(null);
        crest.setScaleType(ImageView.ScaleType.FIT_CENTER);
        crest.setClipToOutline(false);
        crest.setElevation(0f);
        crest.setPadding(0,0,0,0);
        return crest;
    }

    private View featuredInnerLogo(JSONObject side,int tileDp,int accent) {
        ImageView crest=cleanHeroCrest(side,tileDp);
        crest.setContentDescription(pickText(side,"name","team_name","short_name")+" team badge");
        return crest;
    }

    private JSONObject explicitlyVerifiedCaptain(JSONObject match, JSONObject side, boolean homeSide) {
        if(match==null||side==null)return null;
        String key=homeSide?"homeCaptain":"awayCaptain";
        JSONObject candidate=match.optJSONObject(key);
        if(candidate==null)candidate=side.optJSONObject("captain");
        if(candidate==null){
            JSONObject captains=match.optJSONObject("captains");
            if(captains!=null)candidate=captains.optJSONObject(homeSide?"home":"away");
        }
        // Only an explicit team-bound record can be displayed as captain.
        if(candidate==null||playerName(candidate).isEmpty())return null;
        String belongs=playerDirectField(candidate,"team_name","teamName","team");
        String sideName=pickText(side,"name","team_name","teamName");
        if(!belongs.isEmpty()&&!belongs.equalsIgnoreCase(sideName))return null;
        JSONObject nestedTeam=candidate.optJSONObject("team");
        if(nestedTeam!=null){
            String nestedName=pickText(nestedTeam,"name","team_name","teamName");
            if(!nestedName.isEmpty()&&!nestedName.equalsIgnoreCase(sideName))return null;
        }
        String verifiedTeamId=pickText(candidate,"team_id","teamId");
        if(verifiedTeamId.isEmpty()&&nestedTeam!=null)
            verifiedTeamId=pickText(nestedTeam,"id","team_id","teamId");
        String fixtureTeamId=pickText(side,"id","team_id","teamId");
        if(!verifiedTeamId.isEmpty()&&!fixtureTeamId.isEmpty()&&
                !verifiedTeamId.equalsIgnoreCase(fixtureTeamId))return null;
        return candidate;
    }

    private View featuredTeamColumn(JSONObject match,JSONObject side,boolean left){
        LinearLayout col=new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity((left?Gravity.START:Gravity.END)|Gravity.CENTER_VERTICAL);
        int screenDp=getResources().getConfiguration().screenWidthDp;
        col.addView(listingTeamIdentityRow(side,left,screenDp<360?44:55,
                screenDp<360?11.5f:13f),new LinearLayout.LayoutParams(-1,-2));
        String sport=pickText(match,"sport").toLowerCase(Locale.US);
        String score="cricket".equals(sport)?cricketDisplayScore(side):
                pickText(side,"score","points","total");
        String bucket=String.valueOf(match.opt("_listingMode"));
        if(!"upcoming".equalsIgnoreCase(bucket)&&!score.isEmpty()){
            TextView points=tv(score,screenDp<360?18f:21f,TEXT,true);
            points.setGravity(left?Gravity.LEFT:Gravity.RIGHT);
            points.setPadding(0,dp(5),0,0);
            col.addView(points,new LinearLayout.LayoutParams(-1,-2));
            if("cricket".equals(sport)){
                String overs=pickText(side,"overs","over");
                if(!overs.isEmpty()){
                    TextView sub=tv(overs.toLowerCase(Locale.US).contains("over")?overs:overs+" overs",
                            9.5f,MUTED,false);
                    sub.setGravity(left?Gravity.LEFT:Gravity.RIGHT);
                    col.addView(sub,new LinearLayout.LayoutParams(-1,-2));
                }
            }
        }
        JSONObject captain=explicitlyVerifiedCaptain(match,side,left);
        if(captain!=null){
            LinearLayout cap=new LinearLayout(this);
            cap.setGravity(Gravity.CENTER_VERTICAL);
            cap.setPadding(0,dp(9),0,0);
            ImageView portrait=new ImageView(this);
            portrait.setScaleType(ImageView.ScaleType.CENTER_CROP);
            portrait.setBackground(circleDrawable(CARD_2));
            portrait.setClipToOutline(true);
            String name=playerName(captain);
            portrait.setImageDrawable(playerIdentityFallback(captain));
            String photo=playerPhoto(captain);
            if(!photo.isEmpty())loadPlayerAvatar(portrait,photo,name);
            TextView description=tv("C  •  "+name,screenDp<360?8.5f:9.5f,MUTED,true);
            description.setMaxLines(2);
            description.setEllipsize(android.text.TextUtils.TruncateAt.END);
            if(left){
                cap.addView(portrait,new LinearLayout.LayoutParams(dp(30),dp(30)));
                description.setPadding(dp(6),0,0,0);
                cap.addView(description,new LinearLayout.LayoutParams(0,-2,1));
            }else{
                description.setGravity(Gravity.RIGHT);
                description.setPadding(0,0,dp(6),0);
                cap.addView(description,new LinearLayout.LayoutParams(0,-2,1));
                cap.addView(portrait,new LinearLayout.LayoutParams(dp(30),dp(30)));
            }
            col.addView(cap,new LinearLayout.LayoutParams(-1,-2));
        }
        return col;
    }

    // Stable identity is used only to keep the featured fixture out of the repeated Home lists.
    private String homeMatchIdentity(JSONObject match) {
        if (match == null) return "";
        String sport = pickText(match, "sport", "sportType").trim().toLowerCase(Locale.US);
        String id = pickText(match, "matchId", "match_id", "eventId", "event_id",
                "fixtureId", "fixture_id", "matchKey", "match_key", "id").trim();
        if (!id.isEmpty() && !"null".equalsIgnoreCase(id)) return sport + "|id|" + id.toLowerCase(Locale.US);
        JSONObject home = team(match, true);
        JSONObject away = team(match, false);
        String first = pickText(home, "name", "team_name", "short_name", "shortName", "teamName", "title").trim().toLowerCase(Locale.US);
        String second = pickText(away, "name", "team_name", "short_name", "shortName", "teamName", "title").trim().toLowerCase(Locale.US);
        if (first.isEmpty() || second.isEmpty()) return "";
        String a = first.compareTo(second) <= 0 ? first : second;
        String b = first.compareTo(second) <= 0 ? second : first;
        String competition = pickText(match, "competition", "league", "tournament", "competition_name", "league_name").trim().toLowerCase(Locale.US);
        String rawDate = pickText(match, "date", "matchDate", "match_date", "startDate", "start_date", "startsAt", "starts_at", "start_time", "startTime").trim();
        String date = rawDate.length() >= 10 ? rawDate.substring(0, 10) : rawDate;
        return sport + "|teams|" + a + "|" + b + "|" + competition + "|" + date;
    }

    // HOME ONLY: Verified World Cup fixtures across ANY sport have absolute priority.
    // Next: major competitions / high provider-rated events. Otherwise Cricket,
    // Football, Tennis, Basketball. Never apply this ranking to sport-only screens.
    private static final String[] HOME_SPORT_ORDER =
            new String[]{"cricket", "football", "tennis", "basketball"};

    private int homeSportRank(JSONObject match) {
        if (match == null) return HOME_SPORT_ORDER.length;
        String sport = match.optString("sport", match.optString("sportType", ""))
                .trim().toLowerCase(Locale.US);
        for (int i = 0; i < HOME_SPORT_ORDER.length; i++) {
            if (HOME_SPORT_ORDER[i].equals(sport)) return i;
        }
        return HOME_SPORT_ORDER.length;
    }

    private boolean belongsToRequestedSport(JSONObject match, String requested) {
        if (match == null) return false;
        String declared = match.optString("sport", match.optString("sportType", "")).trim();
        // A sport-specific endpoint is authoritative when a record lacks a sport label;
        // if the provider explicitly labels it differently, discard that record.
        if (declared.isEmpty() || requested.equalsIgnoreCase(declared)) return true;
        // Several football providers use "soccer" as the canonical sport name.
        return "football".equalsIgnoreCase(requested) && "soccer".equalsIgnoreCase(declared);
    }

    private int homeStatusRank(JSONObject match) {
        String status = normalizedMatchStatus(pickText(match,
                "status", "statusText", "state", "match_status", "matchStatus"));
        if ("LIVE".equals(status)) return 0;
        if ("UPCOMING".equals(status)) return 1;
        if ("FINISHED".equals(status)) return 2;
        return 3;
    }

    private String homeEventName(JSONObject match) {
        // Read only event/competition metadata, never a team's name or general
        // nested commentary, to prevent false World Cup classification.
        if (match == null) return "";
        StringBuilder names = new StringBuilder();
        String[] keys = {"competition", "competition_name", "competitionName",
                "league", "league_name", "leagueName", "tournament", "tournament_name",
                "tournamentName", "series", "series_name", "seriesName",
                "championship", "event_name", "eventName", "eventTitle"};
        for (JSONObject source : new JSONObject[]{match, match.optJSONObject("rawProviderData")}) {
            if (source == null) continue;
            for (String key : keys) {
                Object value = source.opt(key);
                if (value instanceof String) {
                    names.append(' ').append((String)value);
                } else if (value instanceof JSONObject) {
                    JSONObject event = (JSONObject)value;
                    names.append(' ').append(event.optString("name", ""));
                    names.append(' ').append(event.optString("title", ""));
                }
            }
        }
        return java.text.Normalizer.normalize(names.toString(),
                        java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+", "")
                .replace('_', ' ').replace('-', ' ').replaceAll("\\s+", " ")
                .toLowerCase(Locale.US).trim();
    }

    private double homePopularity(JSONObject match) {
        if (match == null) return 0;
        // No fabricated ranking: consider only values supplied by the provider.
        double result = match.optDouble("popularityScore", 0);
        if (result <= 0) result = match.optDouble("popularity_score", 0);
        if (result <= 0) result = match.optDouble("popularity", 0);
        return Double.isFinite(result) && result > 0 ? result : 0;
    }

    private boolean homeHighProviderRank(JSONObject match) {
        if (match == null) return false;
        for (String key : new String[]{"popularityRank", "popularity_rank", "globalRank", "global_rank"}) {
            int position = match.optInt(key, 0);
            if (position >= 1 && position <= 10) return true;
        }
        for (String key : new String[]{"importance", "importanceLevel", "eventTier", "event_tier"}) {
            String value = match.optString(key, "").trim().toLowerCase(Locale.US);
            if (value.equals("top") || value.equals("major") || value.equals("high")
                    || value.equals("premium") || value.equals("tier1") || value.equals("tier 1")) return true;
        }
        double popularity = homePopularity(match);
        // Support common normalized (0..1) and 0..100 provider scales.
        return popularity >= 0.90 && popularity <= 1.0
                || popularity >= 85.0 && popularity <= 100.0;
    }

    private int homeEventTier(JSONObject match) {
        String competition = homeEventName(match);
        // 0 is ABSOLUTE priority, even when this fixture is from Tennis or Basketball.
        if (competition.matches(".*\\bworld\\s*cup\\b.*")
                || competition.contains("worldcup")) return 0;
        // These are examples of major, provider-named events, not synthetic matches.
        // A genuinely high provider ranking can also promote another competition.
        String[] major = {"copa america", "uefa euro", "european championship",
                "champions league", "europa league", "olympic games", "olympics",
                "wimbledon", "roland garros", "french open", "australian open",
                "us open", "atp finals", "wta finals", "grand slam",
                "nba finals", "nba playoffs", "euroleague final four",
                "the ashes", "champions trophy", "asia cup", "indian premier league",
                "world championship"};
        for (String event : major) if (competition.contains(event)) return 1;
        return homeHighProviderRank(match) ? 1 : 2;
    }

    private int compareHomeMatches(JSONObject a, JSONObject b) {
        int aTier = homeEventTier(a), bTier = homeEventTier(b);
        int tier = Integer.compare(aTier, bTier);
        if (tier != 0) return tier;
        if (aTier <= 1) {
            // For World Cups and major events, important LIVE matches outrank upcoming.
            int state = Integer.compare(homeStatusRank(a), homeStatusRank(b));
            if (state != 0) return state;
            int score = Double.compare(homePopularity(b), homePopularity(a));
            if (score != 0) return score;
            return Integer.compare(homeSportRank(a), homeSportRank(b));
        }
        int sport = Integer.compare(homeSportRank(a), homeSportRank(b));
        if (sport != 0) return sport;
        int state = Integer.compare(homeStatusRank(a), homeStatusRank(b));
        if (state != 0) return state;
        return Double.compare(homePopularity(b), homePopularity(a));
    }

    private void sortHomeMatches(ArrayList<JSONObject> matches) {
        if (matches != null) matches.sort(this::compareHomeMatches);
    }

    private JSONObject chooseHomeFeaturedMatch(ArrayList<JSONObject> liveItems, ArrayList<JSONObject> upcomingItems) {
        ArrayList<JSONObject> eligible = new ArrayList<>(liveItems);
        eligible.addAll(upcomingItems);
        sortHomeMatches(eligible);
        return eligible.isEmpty() ? null : eligible.get(0);
    }

    private void removeFeaturedFromHomeList(ArrayList<JSONObject> matches, JSONObject featured) {
        if (featured == null || matches == null) return;
        String identity = homeMatchIdentity(featured);
        if (identity.isEmpty()) return;
        for (int i = matches.size() - 1; i >= 0; i--) {
            if (identity.equals(homeMatchIdentity(matches.get(i)))) matches.remove(i);
        }
    }

    private void loadHomeDashboard(LinearLayout hero, LinearLayout dots,
                                   LinearLayout live, LinearLayout upcoming, LinearLayout recent) {
        if (BACKEND_URL == null || BACKEND_URL.contains("REPLACE") || !remoteDataEnabled) {
            showHomeProviderError(hero, dots, live, upcoming, recent);
            return;
        }
        // Coordinated fetch: each sport is independent; slow provider does not block the others.
        homeNetwork.execute(() -> {
            ArrayList<JSONObject> liveItems = new ArrayList<>();
            ArrayList<JSONObject> upcomingItems = new ArrayList<>();
            ArrayList<JSONObject> recentItems = new ArrayList<>();
            ArrayList<java.util.concurrent.Future<JSONObject>> jobs = new ArrayList<>();
            for (String sport : new String[]{"cricket", "football", "tennis", "basketball"}) {
                jobs.add(homeNetwork.submit(() -> fetchHomeSport(sport)));
            }
            boolean anySuccessfulFetch = false;
            for (java.util.concurrent.Future<JSONObject> job : jobs) {
                try {
                    JSONObject group = job.get(25, java.util.concurrent.TimeUnit.SECONDS);
                    if (group == null) continue;
                    anySuccessfulFetch |= group.optBoolean("success", false);
                    appendHomeMatches(group.optJSONArray("live"), liveItems);
                    appendHomeMatches(group.optJSONArray("upcoming"), upcomingItems);
                    appendHomeMatches(group.optJSONArray("results"), recentItems);
                } catch (Exception ignored) { job.cancel(true); }
            }
            sortHomeMatches(liveItems);
            sortHomeMatches(upcomingItems);
            sortHomeMatches(recentItems);
            if (!anySuccessfulFetch) {
                runOnUiThread(() -> {
                    if ("home".equals(screen) && activeHomeHeroHost == hero) {
                        showHomeProviderError(hero, dots, live, upcoming, recent);
                    }
                });
                return;
            }
            final ArrayList<JSONObject> featured = chooseHomeCarouselItems(liveItems, upcomingItems);
            // Only the primary hero is suppressed from lists; secondary carousel
            // fixtures must remain discoverable and never trigger a false empty state.
            if (!featured.isEmpty() && homeEventTier(featured.get(0)) > 1) {
                // Ordinary fixtures are not duplicated, but World Cups and major
                // events MUST remain first in Home listings as well as Featured.
                removeFeaturedFromHomeList(liveItems, featured.get(0));
                removeFeaturedFromHomeList(upcomingItems, featured.get(0));
            }
            final long savedAt = System.currentTimeMillis();
            try {
                JSONObject cache = new JSONObject();
                cache.put("savedAt", savedAt);
                cache.put("featured", toHomeArray(featured));
                cache.put("live", toHomeArray(liveItems));
                cache.put("upcoming", toHomeArray(upcomingItems));
                cache.put("results", toHomeArray(recentItems));
                prefs.edit().putString(HOME_CACHE_KEY, cache.toString()).apply();
            } catch (Exception ignored) {}
            runOnUiThread(() -> {
                if (!"home".equals(screen) || activeHomeHeroHost != hero) return;
                installHomeCarousel(hero, dots, featured, false, savedAt);
                renderHomeLists(live, upcoming, recent, liveItems, upcomingItems, recentItems, false, savedAt);
            });
        });
    }

    private JSONObject fetchHomeSport(String sport) {
        JSONObject output = new JSONObject();
        JSONArray live = new JSONArray(), upcoming = new JSONArray(), results = new JSONArray();
        boolean success = false;
        for (String mode : new String[]{"live", "upcoming", "results"}) {
            // Results are requested for all four sports; unsupported provider
            // endpoints simply contribute no data (never synthetic scores).
            String endpoint = "/sports/" + sport + "/" + mode;
            try {
                JSONObject response;
                try {
                    response = new JSONObject(getUrl(BACKEND_URL + endpoint));
                } catch (Exception first) {
                    if (!"cricket".equals(sport)) throw first;
                    response = new JSONObject(getUrl(BACKEND_URL + "/cricket/" + mode));
                }
                JSONArray fetched = response.optJSONArray("matches");
                if (fetched == null) continue;
                success = true;
                for (int i=0; i<fetched.length(); i++) {
                    JSONObject match = fetched.optJSONObject(i);
                    if (!belongsToRequestedSport(match, sport)) continue;
                    String state = normalizedMatchStatus(pickText(match,
                            "status", "statusText", "state", "match_status", "matchStatus"));
                    if (("live".equals(mode) && !"LIVE".equals(state)) ||
                            ("upcoming".equals(mode) && !"UPCOMING".equals(state)) ||
                            ("results".equals(mode) && !"FINISHED".equals(state))) continue;
                    JSONObject homeTeam = team(match, true), awayTeam = team(match, false);
                    if (pickText(homeTeam,"name","team_name","short_name").isEmpty() ||
                            pickText(awayTeam,"name","team_name","short_name").isEmpty()) continue;
                    match.put("sport", sport);
                    match.put("_listingMode", mode);
                    if ("live".equals(mode)) live.put(match);
                    else if ("upcoming".equals(mode)) upcoming.put(match);
                    else results.put(match);
                }
            } catch (Exception ignored) { /* Do not invent matches on provider failure. */ }
        }
        try {
            output.put("success", success);
            output.put("live",live); output.put("upcoming",upcoming); output.put("results",results);
        } catch (Exception ignored) {}
        return output;
    }

    private void appendHomeMatches(JSONArray source, ArrayList<JSONObject> destination) {
        if (source == null) return;
        for (int i=0; i<source.length(); i++) {
            JSONObject match = source.optJSONObject(i);
            if (match != null) destination.add(match);
        }
    }

    private JSONArray toHomeArray(ArrayList<JSONObject> objects) {
        JSONArray output = new JSONArray();
        for (JSONObject item : objects) output.put(item);
        return output;
    }

    private ArrayList<JSONObject> chooseHomeCarouselItems(ArrayList<JSONObject> live,
                                                          ArrayList<JSONObject> upcoming) {
        ArrayList<JSONObject> candidates = new ArrayList<>(live);
        candidates.addAll(upcoming);
        sortHomeMatches(candidates); // World Cup first, regardless of sport, in Featured too.
        ArrayList<JSONObject> result = new ArrayList<>();
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        for (JSONObject match : candidates) {
            if (result.size() >= 4) break;
            if (homeSportRank(match) >= HOME_SPORT_ORDER.length) continue;
            String id = homeMatchIdentity(match);
            if (id.isEmpty() || !seen.add(id)) continue;
            result.add(match);
        }
        return result;
    }

    private boolean showHomeFromCache(LinearLayout hero, LinearLayout dots) {
        return showHomeFromCache(hero,dots,null,null,null);
    }

    private boolean showHomeFromCache(LinearLayout hero, LinearLayout dots,
                                      LinearLayout live, LinearLayout upcoming, LinearLayout recent) {
        try {
            String value = prefs.getString(HOME_CACHE_KEY, "");
            if (value.isEmpty()) return false;
            JSONObject data = new JSONObject(value);
            long savedAt = data.optLong("savedAt", 0L);
            if (savedAt <= 0 || System.currentTimeMillis() - savedAt > 48L*60*60*1000) return false;
            ArrayList<JSONObject> featured = new ArrayList<>();
            appendHomeMatches(data.optJSONArray("featured"),featured);
            sortHomeMatches(featured); // Old caches must obey the latest ranking too.
            installHomeCarousel(hero,dots,featured,true,savedAt);
            if (live != null) {
                ArrayList<JSONObject> l = new ArrayList<>(), u = new ArrayList<>(), r = new ArrayList<>();
                appendHomeMatches(data.optJSONArray("live"),l);
                appendHomeMatches(data.optJSONArray("upcoming"),u);
                appendHomeMatches(data.optJSONArray("results"),r);
                sortHomeMatches(l);
                sortHomeMatches(u);
                sortHomeMatches(r);
                renderHomeLists(live,upcoming,recent,l,u,r,true,savedAt);
            }
            return true;
        } catch (Exception ignored) { return false; }
    }

    private void showHomeProviderError(LinearLayout hero, LinearLayout dots,
                                       LinearLayout live, LinearLayout upcoming, LinearLayout recent) {
        // Keep valid cached provider records when the remote endpoint is unavailable.
        if (showHomeFromCache(hero,dots,live,upcoming,recent)) return;
        hero.removeAllViews(); dots.removeAllViews();
        hero.addView(homeHeroEmpty("Matches unavailable", "Unable to verify matches. Pull down to retry."));
        for (LinearLayout section : new LinearLayout[]{live,upcoming,recent}) {
            section.removeAllViews();
            section.addView(homeSmallState("Unable to load verified data. Pull down to retry."));
        }
    }

    private void renderHomeLists(LinearLayout live, LinearLayout upcoming, LinearLayout recent,
                                 ArrayList<JSONObject> ls, ArrayList<JSONObject> us,
                                 ArrayList<JSONObject> rs, boolean cached, long savedAt) {
        LinearLayout[] hosts={live,upcoming,recent};
        ArrayList<JSONObject>[] lists = new ArrayList[]{ls,us,rs};
        String[] empty={"No verified live matches", "No verified upcoming matches", "No verified recent results"};
        for (ArrayList<JSONObject> matches : lists) sortHomeMatches(matches);
        for(int j=0;j<hosts.length;j++) {
            LinearLayout host=hosts[j]; host.removeAllViews();
            if (cached) host.addView(homeSmallState("Cached • Last updated " + homeTimestamp(savedAt)));
            int count=Math.min(3,lists[j].size());
            for(int i=0;i<count;i++) {
                JSONObject m=lists[j].get(i);
                host.addView(cached ? homeCachedMatch(m) : sportsListCard(m, j==0), marginBottomParams(8));
            }
            if (count==0) host.addView(homeSmallState(empty[j]));
        }
    }

    private String homeTimestamp(long ms) {
        return new java.text.SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(new java.util.Date(ms));
    }

    private View homeCachedMatch(JSONObject m) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(14),dp(12),dp(14),dp(12));
        row.setBackground(round(Color.rgb(15,35,55),12));
        if ("results".equalsIgnoreCase(m.optString("_listingMode"))
                && "FINISHED".equals(normalizedMatchStatus(
                pickText(m,"status","statusText","state")))) {
            TextView finished = listingStatusBadge(remoteFinishedStatusLabel);
            LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-2,-2);
            statusLp.bottomMargin = dp(6);
            row.addView(finished,statusLp);
        }
        row.addView(tv(canonicalMatchTitle(m),14,Color.WHITE,true));
        String sub = pickText(m,"competition","league","tournament");
        if (!sub.isEmpty()) row.addView(tv(sub+" • Cached snapshot",10,Color.rgb(170,191,216),false));
        row.setOnClickListener(v -> { selectedMatch=homeNavigationMatch(m,true); showMatchDetail(true); });
        return row;
    }

    private void installHomeCarousel(LinearLayout hero, LinearLayout dots,
                                     ArrayList<JSONObject> matches, boolean cached, long savedAt) {
        featuredHomeMatches.clear();
        featuredHomeMatches.addAll(matches);
        homeFeaturedPosition = 0;
        homeFeaturedCached = cached;
        homeFeaturedCachedAt = savedAt;
        activeHomeHeroHost = hero;
        activeHomeDotsHost = dots;
        redrawHomeFeatured();
        handler.removeCallbacks(homeFeaturedRotation);
        if (matches.size() > 1) handler.postDelayed(homeFeaturedRotation,6500L);
    }

    private void redrawHomeFeatured() {
        LinearLayout hero = activeHomeHeroHost, dots=activeHomeDotsHost;
        if (hero == null || dots == null || !"home".equals(screen)) return;
        hero.removeAllViews(); dots.removeAllViews();
        if (featuredHomeMatches.isEmpty()) {
            hero.addView(homeHeroEmpty("No highlighted match", "No verified live or upcoming fixture is available."));
            return;
        }
        JSONObject match=featuredHomeMatches.get(homeFeaturedPosition);
        hero.addView(homeFeaturedBanner(match,homeFeaturedCached,homeFeaturedCachedAt));
        for (int i=0;i<featuredHomeMatches.size();i++) {
            final int position=i;
            FrameLayout tapArea = new FrameLayout(this);
            View dot=new View(this);
            GradientDrawable shape = new GradientDrawable();
            shape.setShape(GradientDrawable.OVAL);
            shape.setColor(i==homeFeaturedPosition ? Color.rgb(19,150,255) : Color.rgb(95,117,149));
            dot.setBackground(shape);
            tapArea.addView(dot,new FrameLayout.LayoutParams(dp(7),dp(7),Gravity.CENTER));
            // Full-height tap targets keep their centres aligned with the dot track.
            dots.addView(tapArea,new LinearLayout.LayoutParams(dp(30),dp(26)));
            tapArea.setClickable(true);
            tapArea.setContentDescription("Featured match "+(i+1)+" of "+featuredHomeMatches.size());
            tapArea.setOnClickListener(v -> {homeFeaturedPosition=position;redrawHomeFeatured();
                handler.removeCallbacks(homeFeaturedRotation);
                handler.postDelayed(homeFeaturedRotation,6500L);});
        }
    }

    private View homeFeaturedBanner(JSONObject match, boolean cached, long savedAt) {
        int windowDp = Math.max(240, getResources().getConfiguration().screenWidthDp);
        int gutterDp = Math.max(0, (windowDp - 660) / 2);
        int availableDp = Math.max(200, windowDp - 2 * gutterDp - 28);
        int heroHeightDp = Math.max(220, Math.min(292, Math.round(availableDp * .61f)));
        FrameLayout card = new FrameLayout(this);
        card.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(heroHeightDp)));
        GradientDrawable base = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(7,31,69),Color.rgb(33,20,89),Color.rgb(8,58,59)});
        base.setCornerRadius(dp(14));
        base.setStroke(dp(1),Color.argb(65,146,186,241));
        card.setBackground(base);
        card.setClipToOutline(true);
        // Match-keyed illustrated venue fallback, never a generic fixed image.
        ImageView generatedVenue = new ImageView(this);
        generatedVenue.setScaleType(ImageView.ScaleType.CENTER_CROP);
        generatedVenue.setImageResource(heroArtworkFor(match));
        card.addView(generatedVenue,new FrameLayout.LayoutParams(-1,-1));
        String artwork = heroLicensedArtworkUrl(match);
        if (!artwork.isEmpty()) {
            ImageView backdrop = new ImageView(this);
            backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
            card.addView(backdrop,new FrameLayout.LayoutParams(-1,-1));
            loadHomeArtwork(backdrop,artwork);
        }
        GradientDrawable scrim = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.argb(190,3,10,24),Color.argb(164,3,9,24),Color.argb(25,5,10,21)});
        View shade = new View(this);
        shade.setBackground(scrim);
        card.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        JSONObject home=team(match,true), away=team(match,false);
        JSONObject homeCaptain=explicitlyVerifiedCaptain(match,home,true);
        JSONObject awayCaptain=explicitlyVerifiedCaptain(match,away,false);
        int homeAccent=heroAccentFor(match);
        int homePortraitDp=Math.max(66,Math.min(98,Math.round(heroHeightDp*.42f)));
        // Start player bust below the upper crest row to avoid covering faces.
        int homePortraitHeight=Math.max(92,heroHeightDp-112);
        if(!featuredVerifiedPhoto(homeCaptain).isEmpty()){
            ImageView leftPortrait=featuredSidePortrait(homeCaptain,false,true,homeAccent);
            leftPortrait.setAlpha(0.97f);
            FrameLayout.LayoutParams leftLp=new FrameLayout.LayoutParams(dp(homePortraitDp),dp(homePortraitHeight),Gravity.LEFT|Gravity.BOTTOM);
            leftLp.leftMargin=dp(2);
            card.addView(leftPortrait,leftLp);
        }
        if(!featuredVerifiedPhoto(awayCaptain).isEmpty()){
            ImageView rightPortrait=featuredSidePortrait(awayCaptain,true,false,homeAccent);
            rightPortrait.setAlpha(0.97f);
            FrameLayout.LayoutParams rightLp=new FrameLayout.LayoutParams(dp(homePortraitDp),dp(homePortraitHeight),Gravity.RIGHT|Gravity.BOTTOM);
            rightLp.rightMargin=dp(2);
            card.addView(rightPortrait,rightLp);
        }
        // Two independently anchored club/country crests. Show them even when
        // a licensed match-specific venue image is available. Never place
        // the away crest beside the home crest at the top-right.
        // Broadcast-weight crests: they scale up without approaching the centre VS.
        int tileDp=availableDp<270?54:(availableDp<350?66:(availableDp<520?78:88));
        int crestInsetDp=availableDp<270?10:(availableDp<520?14:20);
        FrameLayout.LayoutParams homeCrest=new FrameLayout.LayoutParams(dp(tileDp),dp(tileDp),Gravity.LEFT|Gravity.TOP);
        homeCrest.leftMargin=dp(crestInsetDp);homeCrest.topMargin=dp(12);
        card.addView(featuredTeamLogoTile(home,tileDp),homeCrest);
        FrameLayout.LayoutParams awayCrest=new FrameLayout.LayoutParams(dp(tileDp),dp(tileDp),Gravity.RIGHT|Gravity.TOP);
        awayCrest.rightMargin=dp(crestInsetDp);awayCrest.topMargin=dp(12);
        card.addView(featuredTeamLogoTile(away,tileDp),awayCrest);
        TextView vs=tv("VS",15f,Color.rgb(237,245,255),true);
        vs.setGravity(Gravity.CENTER);
        vs.setBackground(round(Color.argb(95,5,22,48),12));
        FrameLayout.LayoutParams versusLp=new FrameLayout.LayoutParams(dp(44),dp(30),Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        versusLp.topMargin=dp(24);
        card.addView(vs,versusLp);

        // Dedicated text legibility layer: anchored below the crest row, so
        // team emblems stay visible even when the licensed photos appear.
        View bottomScrim=new View(this);
        bottomScrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.argb(0,2,10,24),Color.argb(181,2,10,24),Color.argb(237,2,10,24)}));
        FrameLayout.LayoutParams shadeParams=new FrameLayout.LayoutParams(-1,dp(Math.max(128,heroHeightDp-94)),Gravity.BOTTOM);
        card.addView(bottomScrim,shadeParams);

        LinearLayout text = new LinearLayout(this);
        text.setOrientation(LinearLayout.VERTICAL);
        text.setGravity(Gravity.BOTTOM|Gravity.LEFT);
        // Full-width bottom text strip, independent of the top crest row.
        // Constraining this to portrait width made long titles unreadable.
        text.setPadding(dp(15),dp(13),dp(15),dp(14));
        String status = normalizedMatchStatus(pickText(match,"status","statusText","state"));
        String actualStatus=professionalSportsStatusLabel(match,
                pickText(match,"_listingMode","listingMode"));
        boolean live = !cached && remoteLiveStatusLabel.equalsIgnoreCase(actualStatus);
        // Only the real match status is visible, never decorative FEATURED text.
        String headline=cached?"UPDATES DELAYED":
                (actualStatus.isEmpty()?"STATUS UNVERIFIED":actualStatus.toUpperCase(Locale.US));
        boolean isLiveStatus=!cached && remoteLiveStatusLabel.equalsIgnoreCase(actualStatus);
        int badgeColor=cached?Color.rgb(69,91,117):
                isLiveStatus?Color.rgb(11,117,93):
                "Upcoming".equalsIgnoreCase(actualStatus)?Color.rgb(27,86,145):
                Color.rgb(45,70,106);
        TextView badge = tv(headline,9,Color.WHITE,true);
        badge.setMaxWidth(dp(Math.max(100,availableDp-32)));
        badge.setSingleLine(true);
        badge.setEllipsize(android.text.TextUtils.TruncateAt.END);
        badge.setPadding(dp(8),dp(4),dp(8),dp(4));
        badge.setBackground(round(badgeColor,8));
        badge.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(-2,-2);
        badgeLp.bottomMargin=dp(7);
        text.addView(badge,badgeLp);
        TextView title=tv(canonicalMatchTitle(match),17,Color.WHITE,true);
        title.setMaxLines(2);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setShadowLayer(3f,1f,1f,Color.BLACK);
        text.addView(title,new LinearLayout.LayoutParams(-1,-2));
        String competition = pickText(match,"competition","league","tournament").trim();
        if (!competition.isEmpty()) {
            TextView league=tv(competition,10,Color.rgb(226,236,248),false);
            league.setSingleLine(true);
            league.setEllipsize(android.text.TextUtils.TruncateAt.END);
            league.setPadding(0,dp(4),0,0);
            text.addView(league,new LinearLayout.LayoutParams(-1,-2));
        }
        if (cached) {
            TextView ts=tv("Last updated "+homeTimestamp(savedAt),9,Color.rgb(191,212,236),false);
            ts.setPadding(0,dp(3),0,0);
            text.addView(ts);
        }
        TextView cta=tv(live ? "LIVE NOW  ❯" : "VIEW MATCH  ❯",11,Color.WHITE,true);
        cta.setGravity(Gravity.CENTER);
        cta.setPadding(dp(12),dp(6),dp(12),dp(6));
        cta.setBackground(round(live ? Color.rgb(218,17,46) : Color.rgb(23,105,202),8));
        LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-2,-2);
        clp.topMargin=dp(7);
        text.addView(cta,clp);
        String homePhotoCredit=verifiedPhotoCreditLine(match);
        if(!homePhotoCredit.isEmpty()){
            TextView credit=tv(homePhotoCredit,8f,Color.rgb(196,214,233),false);
            credit.setSingleLine(true);
            credit.setEllipsize(android.text.TextUtils.TruncateAt.END);
            credit.setPadding(0,dp(4),0,0);
            JSONArray creditItems=match.optJSONArray("verifiedMediaCredits");
            JSONObject firstCredit=creditItems==null?null:creditItems.optJSONObject(0);
            String creditUrl=pickText(firstCredit,"licenseUrl","url");
            if(isValidProviderImageUrl(creditUrl)){
                credit.setPaintFlags(credit.getPaintFlags()|android.graphics.Paint.UNDERLINE_TEXT_FLAG);
                credit.setContentDescription("Photo attribution and licence; open source");
                credit.setOnClickListener(v->openExternalSource(creditUrl));
            }
            text.addView(credit);
        }
        FrameLayout.LayoutParams content=new FrameLayout.LayoutParams(-1,-1,Gravity.BOTTOM|Gravity.LEFT);
        card.addView(text,content);
        View.OnClickListener open = v -> { selectedMatch=homeNavigationMatch(match,cached); showMatchDetail(true); };
        cta.setOnClickListener(open);
        card.setOnClickListener(open);
        card.setContentDescription("Featured " + canonicalMatchTitle(match));
        card.setFocusable(true);
        final float[] downX={0f}, downY={0f};
        card.setOnTouchListener((v,event)-> {
            if (event.getActionMasked()==MotionEvent.ACTION_DOWN) {
                downX[0]=event.getX(); downY[0]=event.getY(); return true;
            }
            if (event.getActionMasked()==MotionEvent.ACTION_UP) {
                float dx=event.getX()-downX[0], dy=event.getY()-downY[0];
                if (Math.abs(dx)>dp(46) && Math.abs(dx)>Math.abs(dy)*1.3f && featuredHomeMatches.size()>1) {
                    homeFeaturedPosition=(homeFeaturedPosition+(dx<0?1:featuredHomeMatches.size()-1))%featuredHomeMatches.size();
                    redrawHomeFeatured();
                    handler.removeCallbacks(homeFeaturedRotation);
                    handler.postDelayed(homeFeaturedRotation,6500L);
                } else if (Math.abs(dx)<dp(12) && Math.abs(dy)<dp(12)) v.performClick();
                return true;
            }
            if (event.getActionMasked()==MotionEvent.ACTION_MOVE) {
                float dx=event.getX()-downX[0],dy=event.getY()-downY[0];
                if (Math.abs(dy)>dp(12) && Math.abs(dy)>Math.abs(dx)) return false;
                return true;
            }
            return false;
        });
        return card;
    }

    private View featuredTeamLogoTile(JSONObject entity, int tileDp) {
        // No surrounding plate. 2dp padding on each edge preserves the exact
        // Home Featured crest footprint from v2.5.32 (tileDp - 4dp).
        ImageView logo=cleanHeroCrest(entity,tileDp-4);
        logo.setPadding(dp(2),dp(2),dp(2),dp(2));
        logo.setAlpha(1f);
        logo.setContentDescription(pickText(entity,"name","team_name","short_name"));
        return logo;
    }

    private JSONObject homeNavigationMatch(JSONObject match, boolean cached) {
        if (!cached) return match;
        // A cached match must never be presented as a current LIVE event during
        // the detail fetch. The canonical match ID is preserved for revalidation.
        try {
            JSONObject copy = new JSONObject(match.toString());
            copy.put("status", "STALE");
            copy.put("state", "STALE");
            copy.put("statusText", "STALE");
            return copy;
        } catch (Exception ignored) { return match; }
    }

    private String homeArtworkUrl(JSONObject m) {
        String[] fields={"featuredImage","featured_image","heroImage","hero_image",
                "bannerUrl","banner_url","backdropUrl","backdrop_url","coverUrl","cover_url",
                "imageUrl","image_url","thumbnailUrl","thumbnail_url"};
        for (String key:fields) {
            Object value=m.opt(key);
            if (value instanceof String && validHomeImageUrl((String)value)) return (String)value;
        }
        for (String parent:new String[]{"media","artwork","images"}) {
            JSONObject object=m.optJSONObject(parent);
            if (object==null) continue;
            for (String key:new String[]{"banner","backdrop","hero","url","image"}) {
                String value=object.optString(key, "");
                if (validHomeImageUrl(value)) return value;
            }
        }
        return "";
    }

    private boolean validHomeImageUrl(String value) {
        if (value==null || !value.startsWith("https://") || value.contains(" ")) return false;
        try {return new URL(value).getHost().contains(".");} catch(Exception ignored) {return false;}
    }

    private void loadHomeArtwork(ImageView target,String value) {
        android.graphics.Bitmap cached = homeBackdropCache.get(value);
        if (cached != null) { target.setImageBitmap(cached); return; }
        homeNetwork.execute(() -> {
            HttpURLConnection connection=null;
            try {
                connection=(HttpURLConnection)new URL(value).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(7000);
                connection.setInstanceFollowRedirects(true);
                if (connection.getResponseCode()!=200) return;
                String contentType=connection.getContentType();
                if (contentType==null || !contentType.toLowerCase(Locale.US).startsWith("image/")) return;
                java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();
                try (InputStream in=connection.getInputStream()) {
                    byte[] buffer=new byte[8192]; int read;
                    while ((read=in.read(buffer))!=-1) {
                        if (bytes.size()+read>5_000_000) return;
                        bytes.write(buffer,0,read);
                    }
                }
                byte[] raw=bytes.toByteArray();
                android.graphics.BitmapFactory.Options opt=new android.graphics.BitmapFactory.Options();
                opt.inJustDecodeBounds=true;
                android.graphics.BitmapFactory.decodeByteArray(raw,0,raw.length,opt);
                if (opt.outWidth<=0 || opt.outHeight<=0) return;
                opt.inSampleSize=Math.max(1,Math.max(opt.outWidth/1100,opt.outHeight/850));
                opt.inJustDecodeBounds=false;
                final android.graphics.Bitmap bmp=android.graphics.BitmapFactory.decodeByteArray(raw,0,raw.length,opt);
                if (bmp!=null) {
                    homeBackdropCache.put(value,bmp);
                    runOnUiThread(() -> {
                        if ("home".equals(screen) && target.getParent()!=null) target.setImageBitmap(bmp);
                    });
                }
            } catch (Exception ignored) {} finally {if(connection!=null)connection.disconnect();}
        });
    }

    private void loadHomeLive(LinearLayout container){
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE") || !remoteDataEnabled) return;
        network.execute(()->{
            ArrayList<JSONObject> all=new ArrayList<>();
            for(String sport:new String[]{"cricket","football","tennis","basketball"}){
                try{JSONObject r=new JSONObject(getUrl(BACKEND_URL+"/sports/"+sport+"/live"));JSONArray a=r.optJSONArray("matches");if(a!=null)for(int i=0;i<a.length();i++){JSONObject m=a.optJSONObject(i);if(m!=null){try{m.put("sport",sport);m.put("_listingMode","live");}catch(Exception ignored){}all.add(m);}}}catch(Exception ignored){}
            }
            sortHomeMatches(all);
            runOnUiThread(()->{container.removeAllViews(); for(JSONObject m:all)container.addView(sportsListCard(m,true),marginBottomParams(8));});
        });
    }

    private void loadSportsHome(LinearLayout list) {
        if(BACKEND_URL==null || BACKEND_URL.contains("REPLACE") || !remoteDataEnabled)return;
        String mode=sportsHomeMode;
        network.execute(()->{
            ArrayList<JSONObject> all=new ArrayList<>();
            boolean fetched=false;
            for(String sport:new String[]{"cricket","football","tennis","basketball"}) {
                try {
                    JSONObject response=new JSONObject(getUrl(BACKEND_URL+"/sports/"+sport+"/"+mode));
                    JSONArray matches=response.optJSONArray("matches");
                    if(matches==null)continue;
                    fetched=true;
                    for(int i=0;i<matches.length();i++){
                        JSONObject m=matches.optJSONObject(i);
                        if(!belongsToRequestedSport(m,sport))continue;
                        String status=normalizedMatchStatus(pickText(m,"status","statusText","state"));
                        if(("live".equals(mode)&&!"LIVE".equals(status)) ||
                                ("upcoming".equals(mode)&&!"UPCOMING".equals(status)) ||
                                ("results".equals(mode)&&!"FINISHED".equals(status)))continue;
                        m.put("sport",sport);m.put("_listingMode",mode);all.add(m);
                    }
                }catch(Exception ignored){}
            }
            all.sort((a, b) -> Double.compare(b.optDouble("popularityScore", 0),
                    a.optDouble("popularityScore", 0))); // Sports directory is NOT Home-ranked.
            final boolean found=fetched;
            runOnUiThread(()->{
                if(!"sportsHome".equals(screen) || !mode.equals(sportsHomeMode))return;
                list.removeAllViews();int count=Math.min(12,all.size());
                for(int i=0;i<count;i++)list.addView(sportsListCard(all.get(i),"live".equals(mode)),marginBottomParams(8));
                if(count==0)list.addView(emptyStateCard(found?"No verified "+mode+" matches":"Sports provider unavailable",
                        found?"Nothing matches this filter right now.":"No validated provider response was received."));
            });
        });
    }


    private void showSportsHome(boolean push) {
        stopMatchDetailAutoRefresh();
        entertainmentContext = false;
        stopSportsAutoRefresh();
        if (push) push("sportsHome");
        screen = "sportsHome";
        activeSportListHost = null;
        clearContent();
        LinearLayout page = page();
        page.addView(selectedSectionBar("Sports", false));
        page.addView(sportsProviderAttribution());
        LinearLayout grid = new LinearLayout(this);
        grid.setPadding(dp(12), 0, dp(12), dp(10));
        String[] names={"Cricket","Football","Tennis","Basketball"}; String[] icons={"🏏","⚽","🎾","🏀"};
        for(int i=0;i<names.length;i++){final String s=names[i].toLowerCase(Locale.US);LinearLayout c=featureTile(icons[i],names[i],i==0?CYAN:BLUE);c.setOnClickListener(v->showSports(s,true));grid.addView(c,featureTileParams());}
        page.addView(grid);
        LinearLayout homeTabs = new LinearLayout(this); homeTabs.setPadding(dp(12),dp(2),dp(12),dp(8));
        String[] homeModes={"LIVE","UPCOMING","RESULTS"};
        for(String hm:homeModes){
            FrameLayout b=sportsModeTab(hm,hm.equalsIgnoreCase(sportsHomeMode));
            b.setOnClickListener(v->{
                sportsHomeMode=hm.toLowerCase(Locale.US);
                updateSportsModeTabSelection(homeTabs,hm);
                if(activeSportsHomeList!=null){
                    activeSportsHomeList.removeAllViews();
                    activeSportsHomeList.addView(homeSmallState("Loading "+sportsHomeMode+" matches…"));
                    loadSportsHome(activeSportsHomeList);
                }
            });
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(50),1f);
            lp.setMargins(dp(4),0,dp(4),0);homeTabs.addView(b,lp);
        }
        page.addView(homeTabs);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(12),dp(2),dp(12),dp(18));
        page.addView(sectionLabel("Matches & Events","Verified live, upcoming and results across sports"));
        page.addView(list);
        activeSportsHomeList=list;
        activeSportsPage=page; activeSportsHome=true;
        addSportsRefreshScroll(page,()->loadSportsHome(list));
        scheduleSportsAutoRefresh(); loadSportsHome(list);
    }

    private void showSports(String sport, boolean push) {
        showSports(sport, push, "live");
    }

    private void showSports(String sport, boolean push, String initialMode) {
        stopMatchDetailAutoRefresh();
        entertainmentContext = false;
        stopSportsAutoRefresh();
        if (push) push("sport:" + sport);
        screen = "sport";
        selectedSport = sport;
        matchMode = initialMode == null ? "live" : initialMode.toLowerCase(Locale.US);
        remoteMatches = null;
        remoteMatchDetail = null;
        clearContent();
        LinearLayout page = page();
        page.addView(selectedSectionBar(sportName(sport), false));
        page.addView(sportsProviderAttribution());
        // Every sport has exactly one featured section and ONE set of state tabs.
        sportFeaturedMatch = null;
        sportFeaturedGeneration++;
        LinearLayout featuredHost = new LinearLayout(this);
        featuredHost.setOrientation(LinearLayout.VERTICAL);
        featuredHost.setPadding(dp(14),dp(4),dp(14),dp(7));
        featuredHost.addView(homeSmallState("Selecting a verified featured match…"));
        sportFeaturedHost = featuredHost;
        page.addView(featuredHost);
        // One compact discovery row near the top, rather than a large repeated
        // "More / Explore <sport>" menu at the bottom of every sport page.
        // This row never duplicates the LIVE / UPCOMING / RESULTS filter row.
        // Only functioning directories are surfaced; missing-data placeholders
        // (Rankings / H2H / Highlights / Draws) are not promoted as shortcuts.
        final String[] discoveryItems;
        switch (sport.toLowerCase(Locale.US)) {
            case "cricket":
                discoveryItems=new String[]{"Overview","Series","Teams","Players","Venues","Archive"};
                break;
            case "football":
                discoveryItems=new String[]{"Overview","Competitions","Teams","Players","Venues"};
                break;
            case "basketball":
                discoveryItems=new String[]{"Overview","Leagues","Teams","Players"};
                break;
            case "tennis":
                discoveryItems=new String[]{"Overview","Tournaments","Players"};
                break;
            default:
                discoveryItems=new String[]{"Overview"};
                break;
        }
        HorizontalScrollView navScroll=new HorizontalScrollView(this);
        navScroll.setHorizontalScrollBarEnabled(false);
        navScroll.setFillViewport(false);
        LinearLayout nav=new LinearLayout(this);
        nav.setPadding(dp(12),dp(2),dp(12),dp(7));
        for(String item:discoveryItems){
            TextView nb=tab(item,"Overview".equals(item));
            nb.setContentDescription(sportName(sport)+" "+item);
            nb.setOnClickListener(v->{
                if("Overview".equals(item))showSports(sport,false);
                else if("Archive".equals(item) && "cricket".equalsIgnoreCase(sport))showCricsheetHistory(true);
                else showSportsDirectory(sport,item,true);
            });
            int tabWidth="Overview".equals(item)?92:Math.max(82,item.length()*7+24);
            LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(dp(tabWidth),dp(42));
            np.setMargins(dp(4),0,dp(4),0);
            nav.addView(nb,np);
        }
        navScroll.addView(nav);
        page.addView(navScroll);
        // Removed legacy icon shortcuts that duplicated LIVE/UPCOMING/RESULTS.
        page.addView(modeTabs(page,sport,new String[]{"LIVE","UPCOMING","RESULTS"}));
        activeSportListHost=new LinearLayout(this);
        activeSportListHost.setOrientation(LinearLayout.VERTICAL);
        activeSportListHost.setPadding(dp(12),dp(2),dp(12),dp(18));
        page.addView(activeSportListHost);
        renderSportList(page,sport);
        activeSportsPage=page; activeSportsHome=false;
        addSportsRefreshScroll(page,()->loadSportsFromBackend(selectedSport,matchMode,page));
        scheduleSportsAutoRefresh(); loadSportsFromBackend(sport,matchMode,page);
        loadSportFeatured(featuredHost,sport);
    }

    // A provider ID may differ across feeds. Match ID is preferred, while a
    // fallback requires the same sport, exact unordered teams and near start time.
    private boolean isSameSportsFixture(JSONObject a, JSONObject b, String sport) {
        if(a==null||b==null)return false;
        String ai=pickText(a,"id","matchId","match_id","fixtureId","fixture_id");
        String bi=pickText(b,"id","matchId","match_id","fixtureId","fixture_id");
        if(!ai.isEmpty()&&!bi.isEmpty()&&ai.equalsIgnoreCase(bi))return true;
        String ah=pickText(team(a,true),"name","team_name").trim().toLowerCase(Locale.US);
        String aa=pickText(team(a,false),"name","team_name").trim().toLowerCase(Locale.US);
        String bh=pickText(team(b,true),"name","team_name").trim().toLowerCase(Locale.US);
        String ba=pickText(team(b,false),"name","team_name").trim().toLowerCase(Locale.US);
        if(ah.isEmpty()||aa.isEmpty()||bh.isEmpty()||ba.isEmpty())return false;
        if(!((ah.equals(bh)&&aa.equals(ba))||(ah.equals(ba)&&aa.equals(bh))))return false;
        long at=parseEventStartMillis(pickText(a,"time","startsAt","start_time","date"));
        long bt=parseEventStartMillis(pickText(b,"time","startsAt","start_time","date"));
        return at>0&&bt>0&&Math.abs(at-bt)<=90L*60L*1000L;
    }

    // Editorial selection, not an audience measurement. Top competitions and
    // verified live fixtures outrank minor games; never invent source popularity.
    private int sportsFeaturedRank(JSONObject m, String bucket, String sport) {
        if(m==null)return Integer.MIN_VALUE;
        String competition=pickText(m,"competition","league","tournament").toLowerCase(Locale.US);
        String teams=canonicalMatchTitle(m).toLowerCase(Locale.US);
        String format=pickText(m,"format","match_format").toLowerCase(Locale.US);
        int rank=0;
        if(competition.matches(".*(world cup|champions trophy|olympic|grand slam|wimbledon|roland garros|australian open|us open|fifa).*"))rank+=420;
        else if(competition.matches(".*(champions league|premier league|nba|euroleague|ipl|indian premier league|bbl|psl|asia cup|atp finals|wta finals).*"))rank+=280;
        else if(competition.matches(".*(international|test series|test match|odi series|t20i|atp|wta|grand prix).*"))rank+=165;
        if("cricket".equals(sport) && (format.contains("test")||competition.contains("test series")))rank+=110;
        if(teams.matches(".*(bangladesh|india|australia|england|pakistan|south africa|new zealand|west indies|sri lanka).*"))rank+=55;
        if("live".equals(bucket))rank+=155;
        else if("upcoming".equals(bucket))rank+=95;
        else rank+=15;
        if(m.optBoolean("_feedStale",false))rank-=180;
        String display=professionalSportsStatusLabel(m,bucket);
        if("Status Unverified".equals(display)||"Updates Delayed".equals(display))rank-=250;
        if("Stumps".equals(display)||"Innings Break".equals(display))rank-=35;
        long start=parseEventStartMillis(pickText(m,"time","startsAt","start_time","date"));
        if(start>0){
            long gap=Math.abs(System.currentTimeMillis()-start);
            if("upcoming".equals(bucket)&&start>System.currentTimeMillis()&&gap<86400000L)rank+=35;
            if("results".equals(bucket)&&gap>2*86400000L)rank-=160;
        }
        return rank;
    }

    private void loadSportFeatured(LinearLayout host, String sport) {
        if (BACKEND_URL == null || BACKEND_URL.contains("REPLACE") || !remoteDataEnabled) return;
        final int generation=sportFeaturedGeneration;
        network.execute(() -> {
            JSONObject best=null;
            int bestRank=Integer.MIN_VALUE;
            // D1-only endpoints: no upstream sports provider requests from Android.
            for(String bucket:new String[]{"live","upcoming","results"}){
                try {
                    String path="cricket".equals(sport)?"/cricket/"+bucket:
                        "/sports/"+sport+"/"+bucket;
                    JSONObject feed=new JSONObject(getUrl(BACKEND_URL+path));
                    JSONArray matches=feed.optJSONArray("matches");
                    if(matches==null)continue;
                    for(int i=0;i<matches.length();i++){
                        JSONObject m=matches.optJSONObject(i);
                        if(m==null||!belongsToRequestedSport(m,sport))continue;
                        String expected="live".equals(bucket)?"LIVE":
                            ("upcoming".equals(bucket)?"UPCOMING":"FINISHED");
                        if(!expected.equals(normalizedMatchStatus(pickText(m,"status","state","statusText"))))continue;
                        m.put("sport",sport);
                        m.put("_listingMode",bucket);
                        m.put("_feedStale",feed.optBoolean("stale",false));
                        int rank=sportsFeaturedRank(m,bucket,sport);
                        if(rank>bestRank){best=m;bestRank=rank;}
                    }
                }catch(Exception ignored){}
            }
            final JSONObject chosen=best;
            runOnUiThread(() -> {
                if(generation!=sportFeaturedGeneration||!"sport".equals(screen)||
                    !sport.equals(selectedSport)||host!=sportFeaturedHost||host.getParent()==null)return;
                sportFeaturedMatch=chosen;
                host.removeAllViews();
                if(chosen!=null)host.addView(premiumMatchHero(chosen));
                else host.addView(emptyStateCard("No highlighted match available",
                        "Waiting for a verified live, upcoming or recent fixture."));
                if(activeSportsPage!=null)renderSportList(activeSportsPage,sport);
            });
        });
    }

    private String professionalSportsStatusLabel(JSONObject m, String listingMode) {
        if(m==null)return "";
        String sport=pickText(m,"sport").toLowerCase(Locale.US);
        if(sport.isEmpty())sport=selectedSport.toLowerCase(Locale.US);
        String raw=(pickText(m,"statusText","status_text")+" "+
                pickText(m,"status","state")+" "+
                pickText(m,"phase","statusPhase","stateText","matchPhase","match_phase"))
                .toLowerCase(Locale.US).trim();
        String state=normalizedMatchStatus(pickText(m,"status","state","statusText"));
        if("FINISHED".equals(state)||"results".equalsIgnoreCase(listingMode)||"finished".equalsIgnoreCase(listingMode))return remoteFinishedStatusLabel;
        if("CANCELLED".equals(state))return "Cancelled";
        if("POSTPONED".equals(state))return "Postponed";
        if("ABANDONED".equals(state))return "Abandoned";
        if("UPCOMING".equals(state)||"upcoming".equalsIgnoreCase(listingMode))return remoteUpcomingStatusLabel;
        if("cricket".equals(sport)){
            if(raw.contains("stumps")||raw.contains("end of day")||raw.contains("close of play"))return "Stumps";
            if(raw.contains("innings break")||raw.contains("innings interval"))return "Innings Break";
            if(raw.matches(".*\\b(lunch|lunch break)\\b.*"))return "Lunch Break";
            if(raw.matches(".*\\b(tea|tea break)\\b.*"))return "Tea Break";
            if(raw.contains("drinks"))return "Drinks Break";
            if(raw.contains("bad light"))return "Bad Light";
            if(raw.contains("rain"))return "Rain Delay";
            if(raw.contains("suspend")||raw.contains("interrupt")||raw.contains("delay"))return "Play Suspended";
        } else {
            if(raw.contains("half time")||raw.equals("ht"))return "Half Time";
            if(raw.contains("suspend")||raw.contains("interrupt")||raw.contains("delay"))return "Suspended";
            if(raw.contains("break")||raw.contains("interval"))return "Interval";
        }
        if(m.optBoolean("_feedStale",false))return "Updates Delayed";
        // A stale generic LIVE state must never look like confirmed active play.
        // Test cricket can span five days; other sports have much shorter windows.
        long start=parseEventStartMillis(pickText(m,"time","startsAt","starts_at","start_time","date"));
        if(start>0 && System.currentTimeMillis()>start){
            long elapsed=System.currentTimeMillis()-start;
            long safeWindow;
            if("cricket".equals(sport)){
                String format=(pickText(m,"format","match_format")+" "+pickText(m,"competition")).toLowerCase(Locale.US);
                safeWindow=format.contains("test")?6L*86400000L:
                    (format.contains("odi")?18L*3600000L:10L*3600000L);
            }else if("tennis".equals(sport))safeWindow=14L*3600000L;
            else if("basketball".equals(sport))safeWindow=6L*3600000L;
            else safeWindow=5L*3600000L;
            if(elapsed>safeWindow)return "Status Unverified";
        }
        // Test cricket is played across multiple days. A generic LIVE status
        // alone is not evidence of active deliveries after day one.
        if("cricket".equals(sport) && "LIVE".equals(state) && start>0){
            String fmt=(pickText(m,"format","match_format")+" "+
                pickText(m,"competition")).toLowerCase(Locale.US);
            if(fmt.contains("test") && System.currentTimeMillis()-start>14L*3600000L)
                return "Match Ongoing";
        }
        return "LIVE".equals(state)||"live".equalsIgnoreCase(listingMode)?remoteLiveStatusLabel:"";
    }

    private String normalizedMatchStatus(String raw) {
        if (raw == null) return "";
        String s = raw.trim();
        if (s.isEmpty()) return "";
        String k = s.toLowerCase(Locale.US).replace("_", " ").replace("-", " ").replaceAll("\\s+", " ").trim();
        if (k.equals("live") || k.equals("live now") || k.equals("in play") || k.equals("inplay") || k.equals("playing") || k.equals("ongoing")
                || k.equals("started") || k.equals("in progress") || k.equals("1st innings") || k.equals("2nd innings") || k.equals("innings break")
                || k.equals("stumps") || k.equals("end of day") || k.equals("lunch") || k.equals("tea")) return "LIVE";
        if (k.equals("upcoming") || k.equals("scheduled") || k.equals("not started") || k.equals("fixture") || k.equals("pre match") || k.equals("preview")) return "UPCOMING";
        if (k.equals("finished") || k.equals("complete") || k.equals("completed") || k.equals("ended") || k.equals("match complete") || k.equals("match completed")) return "FINISHED";
        if (k.equals("postponed")) return "POSTPONED";
        if (k.equals("cancelled") || k.equals("canceled")) return "CANCELLED";
        if (k.equals("abandoned")) return "ABANDONED";
        // Provider-specific/unknown diagnostic states are never shown as user-facing match status.
        return "";
    }

    private void renderSportList(LinearLayout page, String sport) {
        if(activeSportListHost==null || !"sport".equals(screen))return;
        activeSportListHost.removeAllViews();
        if(remoteMatches==null){activeSportListHost.addView(homeSmallState("Loading verified matches…"));return;}
        int count=0;
        for(int i=0;i<remoteMatches.length();i++){
            JSONObject m=remoteMatches.optJSONObject(i);
            if(m==null)continue;
            if(isSameSportsFixture(m,sportFeaturedMatch,sport))continue;
            activeSportListHost.addView(sportsListCard(m,"live".equalsIgnoreCase(matchMode)),marginBottomParams(8));
            count++;
        }
        if(count==0){
            boolean featuredWasOnlyMatch=remoteMatches.length()==1 &&
                isSameSportsFixture(remoteMatches.optJSONObject(0),sportFeaturedMatch,sport);
            activeSportListHost.addView(featuredWasOnlyMatch
                ? homeSmallState("This match is shown above in Featured.")
                : emptyStateCard("No verified "+matchMode+" matches",
                    "The active provider has not supplied eligible "+sportName(sport)+" data."));
        }
    }


    private void openCricsheetLicence() {
        try {
            Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://cricsheet.org/licensing/"));
            startActivity(intent);
        }catch(Exception ignored){}
    }

    private void showCricsheetHistory(boolean pushHistory) {
        if(pushHistory)push("cricsheetArchive");
        screen="cricsheetArchive";selectedSport="cricket";clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar("Cricsheet Archive",false));
        page.addView(sectionLabel("Completed Cricket Matches","Archived ball-by-ball data, not live scores"));
        TextView credit=tv("Powered by SportScore & Cricsheet • Cricsheet historical data: ODC-BY 1.0",10,MUTED,false);
        credit.setGravity(Gravity.CENTER);
        credit.setPadding(dp(12),dp(7),dp(12),dp(7));
        credit.setOnClickListener(v->openCricsheetLicence());
        page.addView(credit);
        TextView licence=tv("Source: cricsheet.org • Dataset adapted for OneTV • Tap for licence and notices",10,BLUE,false);
        licence.setGravity(Gravity.CENTER);
        licence.setOnClickListener(v->openCricsheetLicence());
        page.addView(licence);
        LinearLayout rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);
        rows.setPadding(dp(12),dp(10),dp(12),dp(18));
        rows.addView(homeSmallState("Loading verified completed matches…"));
        page.addView(rows);addScroll(page);
        network.execute(()->{
            try{
                JSONObject response=new JSONObject(getUrl(BACKEND_URL+"/sports/cricket/history?limit=30"));
                JSONArray matches=response.optJSONArray("matches");
                runOnUiThread(()->{
                    if(!"cricsheetArchive".equals(screen))return;
                    rows.removeAllViews();
                    int count=0;
                    if(matches!=null)for(int i=0;i<matches.length();i++){
                        JSONObject m=matches.optJSONObject(i);
                        if(m==null||!m.optBoolean("archiveOnly",false))continue;
                        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);
                        c.setPadding(dp(14),dp(13),dp(14),dp(13));
                        c.setBackground(round(CARD,16));
                        c.addView(tv(canonicalMatchTitle(m),15,TEXT,true));
                        String date=pickText(m,"time","date","match_date");
                        c.addView(tv(formatMatchSchedule(date)+" • Completed",10,MUTED,false));
                        JSONObject h=team(m,true),a=team(m,false);
                        String scores=pickText(h,"name")+" "+pickText(h,"score")+"   •   "+
                            pickText(a,"name")+" "+pickText(a,"score");
                        c.addView(tv(scores,11,TEXT,true));
                        c.addView(tv("Cricsheet • ODC-BY 1.0 • Historical archive",9,BLUE,false));
                        c.setOnClickListener(v->{selectedMatch=m;showCricsheetArchiveDetail(m,true);});
                        rows.addView(c,marginBottomParams(9));count++;
                    }
                    if(count==0)rows.addView(emptyStateCard("No archived matches yet",
                        "Cricsheet is enabled, but the first archive sync has not completed."));
                });
            }catch(Exception ignored){runOnUiThread(()->{
                if("cricsheetArchive".equals(screen)){
                    rows.removeAllViews();rows.addView(emptyStateCard("Archive unavailable",
                        "Please check the Cricsheet backend health report."));
                }
            });}
        });
    }

    private void showCricsheetArchiveDetail(JSONObject match,boolean pushHistory){
        if(pushHistory)push("cricsheetArchiveDetail");
        screen="cricsheetArchiveDetail";clearContent();
        LinearLayout page=page();page.addView(selectedSectionBar("Completed Match",false));
        page.addView(sectionLabel(canonicalMatchTitle(match),"Cricsheet historical record"));
        page.addView(premiumMatchHero(match));
        String[] headings={"Batting","Bowling","Over summaries"};
        String[] keys={"batting","bowling","overs"};
        for(int ix=0;ix<keys.length;ix++){
            JSONArray array=match.optJSONArray(keys[ix]);
            if(array==null||array.length()==0)continue;
            page.addView(sectionLabel(headings[ix],"Derived from recorded deliveries"));
            for(int i=0;i<Math.min(array.length(),80);i++){
                JSONObject entry=array.optJSONObject(i);if(entry==null)continue;
                String info=entry.optString("name",entry.optString("player",entry.optString("team","")));
                String stat="batting".equals(keys[ix]) ?
                    "R "+entry.optString("runs","–")+"  B "+entry.optString("balls","–")+
                    "  SR "+entry.optString("strikeRate","–") :
                    "bowling".equals(keys[ix]) ?
                    "OV "+entry.optString("overs","–")+"  W "+entry.optString("wickets","–")+
                    "  ECO "+entry.optString("economy","–") :
                    "Runs "+entry.optString("runs","–")+"  W "+entry.optString("wickets","–");
                LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(14),dp(10),dp(14),dp(10));card.setBackground(round(CARD,12));
                card.addView(tv(info,12,TEXT,true));card.addView(tv(stat,11,MUTED,false));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
                lp.setMargins(dp(12),0,dp(12),dp(5));page.addView(card,lp);
            }
        }
        TextView credit=tv("Powered by SportScore & Cricsheet  •  Historical data: Cricsheet.org (ODC-BY 1.0). Adapted by OneTV. Tap for source and licence.",10,BLUE,false);
        credit.setGravity(Gravity.CENTER);credit.setPadding(dp(14),dp(10),dp(14),dp(14));
        credit.setOnClickListener(v->openCricsheetLicence());page.addView(credit);
        addScroll(page);
    }

    private void showSportsDirectory(String sport,String section,boolean push) {
        stopMatchDetailAutoRefresh();entertainmentContext=false;
        if(push)push("directory:"+sport+":"+section);
        selectedSportsDirectorySection=section;
        selectedSportsDirectorySport=sport;
        screen="directory";clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar(section,false));
        page.addView(sportsProviderAttribution());
        page.addView(sectionLabel(section,sportName(sport)+" • Provider-backed discovery"));
        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12),0,dp(12),dp(15));
        list.addView(homeSmallState("Loading eligible provider records…"));
        page.addView(list);addScroll(page);
        if("Standings".equals(section) || "Rankings".equals(section) || "Draws".equals(section)
                || "H2H".equals(section) || "Highlights".equals(section)){
            list.removeAllViews();
            list.addView(emptyStateCard(section+" unavailable",
                    "This section requires verified sport-specific provider data not yet exposed by the active backend."));
            return;
        }
        if(!remoteDataEnabled){
            list.removeAllViews();list.addView(emptyStateCard("Provider unavailable","Enable verified sports data to view this section."));
            return;
        }
        network.execute(()->{
            java.util.LinkedHashMap<String,JSONObject> entities=new java.util.LinkedHashMap<>();
            for(String mode:new String[]{"live","upcoming","results"}){
                try {
                    JSONObject result=new JSONObject(getUrl(BACKEND_URL+"/sports/"+sport+"/"+mode));
                    JSONArray matches=result.optJSONArray("matches");
                    if(matches==null)continue;
                    for(int i=0;i<matches.length();i++){
                        JSONObject match=matches.optJSONObject(i);
                        if(!belongsToRequestedSport(match,sport))continue;
                        if("Teams".equals(section)) {
                            for(JSONObject t:new JSONObject[]{team(match,true),team(match,false)}){
                                String name=pickText(t,"name","team_name","short_name");
                                if(!name.isEmpty())entities.put(name.toLowerCase(Locale.US),t);
                            }
                        } else if("Venues".equals(section)) {
                            String name=pickText(match,"venue","venueName","venue_name","stadium");
                            if(!name.isEmpty()){
                                JSONObject entry=new JSONObject();entry.put("name",name);
                                entities.put(name.toLowerCase(Locale.US),entry);
                            }
                        } else if("Players".equals(section)) {
                            JSONArray players=pickArray(rawProvider(match),"squads","players","lineups");
                            for(int k=0;k<players.length();k++){
                                JSONObject person=players.optJSONObject(k);
                                if(person==null)continue;
                                String name=pickText(person,"name","full_name","player_name");
                                if(!name.isEmpty())entities.put(name.toLowerCase(Locale.US),person);
                            }
                        } else {
                            String name=pickText(match,"competition","league","tournament");
                            if(!name.isEmpty()){
                                JSONObject entry=new JSONObject();entry.put("name",name);
                                entities.put(name.toLowerCase(Locale.US),entry);
                            }
                        }
                    }
                }catch(Exception ignored){}
            }
            runOnUiThread(()->{
                if(!"directory".equals(screen))return;
                list.removeAllViews();
                for(JSONObject entity:entities.values()){
                    String name=pickText(entity,"name","team_name","player_name");
                    if(name.isEmpty())continue;
                    LinearLayout row=new LinearLayout(this);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    row.setPadding(dp(12),dp(9),dp(12),dp(9));
                    row.setBackground(round(CARD,14));
                    int directoryIconDp=getResources().getConfiguration().screenWidthDp<340?44:52;
                    row.addView(identityView(entity,directoryIconDp),new LinearLayout.LayoutParams(dp(directoryIconDp),dp(directoryIconDp)));
                    TextView title=tv(name,13,TEXT,true);
                    title.setPadding(dp(10),0,0,0);
                    row.addView(title,new LinearLayout.LayoutParams(0,-2,1));
                    if("Teams".equals(section)){
                        String key=pickText(entity,"slug","id","name");
                        if(!key.isEmpty())row.setOnClickListener(v->showSportTeamDetail(sport,key,true));
                    }
                    list.addView(row,marginBottomParams(8));
                }
                if(entities.isEmpty())list.addView(emptyStateCard("No verified "+section.toLowerCase(Locale.US),
                        "The configured provider has not supplied eligible "+section.toLowerCase(Locale.US)+" records."));
            });
        });
    }


    private void loadSportsFromBackend(String sport, String mode, LinearLayout page) {
        if (BACKEND_URL == null || BACKEND_URL.contains("REPLACE") || !remoteDataEnabled) return;
        network.execute(() -> {
            try {
                String path = "cricket".equals(sport) ? "/cricket/" + mode : "/sports/" + sport + "/" + mode;
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + path));
                JSONArray fetchedMatches = root.optJSONArray("matches");
                if (fetchedMatches == null) fetchedMatches = new JSONArray();
                // Each sport-specific tab contains only provider-confirmed state.
                JSONArray verifiedMatches = new JSONArray();
                String expected = "live".equals(mode) ? "LIVE" :
                        ("upcoming".equals(mode) ? "UPCOMING" : "FINISHED");
                for (int index = 0; index < fetchedMatches.length(); index++) {
                    JSONObject match = fetchedMatches.optJSONObject(index);
                    if (match == null || !belongsToRequestedSport(match, sport)) continue;
                    String state = normalizedMatchStatus(pickText(match, "status", "statusText", "state", "match_status", "matchStatus"));
                    if (expected.equals(state)) verifiedMatches.put(match);
                }
                final JSONArray resultMatches = verifiedMatches;
                runOnUiThread(() -> {
                    if (!"sport".equals(screen) || !selectedSport.equals(sport) || !matchMode.equalsIgnoreCase(mode)) return;
                    for (int i = 0; i < resultMatches.length(); i++) {
                        JSONObject item = resultMatches.optJSONObject(i);
                        if (item != null) {
                            try {
                                if (!item.has("sport")) item.put("sport", sport);
                                item.put("_listingMode", mode);
                                item.put("_feedStale", root.optBoolean("stale",false));
                            } catch (Exception ignored) {}
                        }
                    }
                    remoteMatches = resultMatches;
                    renderSportList(page, sport);
                });
            } catch(Exception ignored) {
                runOnUiThread(()->{
                    if(!"sport".equals(screen) || !selectedSport.equals(sport) || !matchMode.equalsIgnoreCase(mode))return;
                    if(activeSportListHost!=null){
                        activeSportListHost.removeAllViews();
                        activeSportListHost.addView(emptyStateCard("Provider unavailable", "Unable to verify "+sportName(sport)+" matches. Pull down to retry."));
                    }
                });
            }
        });
    }

    private String formatMatchSchedule(String raw){
        if(raw==null || raw.trim().isEmpty())return "";
        String local=OneTvMatchTime.formattedLocal(raw);
        return local.isEmpty()?"Time not confirmed":local;
    }

    private String canonicalMatchTitle(JSONObject m){
        JSONObject h=team(m,true), a=team(m,false);
        String hn=pickText(h,"name","team_name","short_name").trim();
        String an=pickText(a,"name","team_name","short_name").trim();
        if(!hn.isEmpty() && !an.isEmpty() && !"TBD".equalsIgnoreCase(hn) && !"TBD".equalsIgnoreCase(an)) return hn+" vs "+an;
        String raw=pickText(m,"title","name").trim();
        return raw.isEmpty()?"Match":raw;
    }

    private View sportsListCard(JSONObject m, boolean live) {
        String sport = m.optString("sport", selectedSport).toLowerCase(Locale.US);
        if ("cricket".equals(sport)) {
            return cricketListCard(m, live);
        }

        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14),dp(12),dp(14),dp(12));
        card.setBackground(round(CARD,18));
        card.setElevation(dp(2));

        String competition=m.optString("competition","").trim();
        LinearLayout meta=new LinearLayout(this);
        meta.setGravity(Gravity.CENTER_VERTICAL);
        TextView comp=tv(competition.isEmpty()?sportName(sport):competition,10,MUTED,true);
        comp.setSingleLine(true); comp.setEllipsize(android.text.TextUtils.TruncateAt.END);
        meta.addView(comp,new LinearLayout.LayoutParams(0,-2,1));
        String status=normalizedMatchStatus(pickText(m,"status","statusText","state"));
        String listingMode=String.valueOf(m.opt("_listingMode")).toLowerCase(Locale.US);
        // Results are first-class match statuses, including all non-cricket listings.
        // Show Finished in a muted red pill like the blue Upcoming pill.
        String statusLabel=professionalSportsStatusLabel(m, listingMode);
        if(!statusLabel.isEmpty()){
            meta.addView(listingStatusBadge(statusLabel));
        }
        TextView fav = tv(isFavorite(m) ? "★" : "☆", 21, isFavorite(m) ? Color.rgb(255,196,55) : MUTED, true);
        fav.setGravity(Gravity.CENTER);
        fav.setContentDescription(isFavorite(m) ? "Remove from favorites" : "Add to favorites");
        fav.setOnClickListener(v -> {
            toggleFavorite(m);
            boolean now = isFavorite(m);
            fav.setText(now ? "★" : "☆");
            fav.setTextColor(now ? Color.rgb(255,196,55) : MUTED);
        });
        meta.addView(fav, new LinearLayout.LayoutParams(dp(38), dp(36)));
        card.addView(meta);

        String title=canonicalMatchTitle(m);
        TextView titleView=tv(title,14,TEXT,true);
        titleView.setSingleLine(true); titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleView.setPadding(0,dp(5),0,0);
        card.addView(titleView);

        String rawTime=pickText(m,"time","startsAt","starts_at","start_time","startTime");
        String schedule=formatMatchSchedule(rawTime);
        if(!schedule.isEmpty()){
            String scheduleLabel=remoteLiveStatusLabel.equalsIgnoreCase(statusLabel)
                    ? remoteLiveStatusLabel+" • "+schedule:schedule;
            TextView tt=tv(scheduleLabel,9,MUTED,false);
            tt.setPadding(0,dp(2),0,0);
            card.addView(tt);
        }

        LinearLayout teams=new LinearLayout(this);
        teams.setGravity(Gravity.CENTER_VERTICAL);
        teams.setPadding(0,dp(9),0,dp(6));
        JSONObject home=team(m,true), away=team(m,false);
        teams.addView(matchTeam(home,true),weighted());
        LinearLayout vsWrap=new LinearLayout(this); vsWrap.setGravity(Gravity.CENTER); vsWrap.setOrientation(LinearLayout.VERTICAL);
        TextView vs=tv("VS",13.5f,MUTED,true); vs.setGravity(Gravity.CENTER); vs.setPadding(dp(8),dp(7),dp(8),dp(7)); vs.setBackground(round(CARD_2,16));
        vsWrap.addView(vs);
        teams.addView(vsWrap,new LinearLayout.LayoutParams(
                dp(getResources().getConfiguration().screenWidthDp < 340 ? 39 : 58),-2));
        teams.addView(matchTeam(away,false),weighted());
        card.addView(teams);

        String venue=m.optString("venue","").trim();
        if(!venue.isEmpty()){
            TextView v=tv("⌖  "+venue,9,MUTED,false); v.setSingleLine(true); v.setEllipsize(android.text.TextUtils.TruncateAt.END); card.addView(v);
        }
        card.setOnClickListener(v->{selectedMatch=m;showMatchDetail(true);});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,dp(10)); card.setLayoutParams(p);
        return card;
    }

    private View cricketListCard(JSONObject m, boolean liveHint) {
        final String mode = matchMode == null ? "" : matchMode.toLowerCase(Locale.US);
        final String normalizedStatus = normalizedMatchStatus(pickText(m,"status","statusText","state"));
        final String listingMode = String.valueOf(m.opt("_listingMode")).toLowerCase(Locale.US);
        // The requested listing is authoritative. A provider may return a stale
        // status label, but it must never make an Upcoming/Results card render as Live.
        final boolean hasListingMode = !listingMode.isEmpty();
        final boolean isLive = hasListingMode
                ? "live".equals(listingMode)
                : ("live".equals(mode) || "LIVE".equalsIgnoreCase(normalizedStatus));
        final boolean isFinished = hasListingMode
                ? ("results".equals(listingMode) || "finished".equals(listingMode))
                : ("results".equals(mode) || "FINISHED".equalsIgnoreCase(normalizedStatus)
                || "COMPLETED".equalsIgnoreCase(normalizedStatus) || "FINAL".equalsIgnoreCase(normalizedStatus));

        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16),dp(13),dp(16),dp(13));
        card.setBackground(round(CARD,16));
        card.setElevation(dp(1));

        // Cricket title block:
        // 1) tournament logo/monogram + tournament title
        // 2) italic match title
        // 3) schedule/date
        String competition=pickText(m,"competition","league","tournament","competition_name","league_name","tournament_name").trim();
        String competitionLogo=pickText(m,
                "competitionLogo","competition_logo","competitionLogoUrl","competition_logo_url",
                "competition_image","competitionImage","competition_image_url","competitionImageUrl",
                "leagueLogo","league_logo","leagueLogoUrl","league_logo_url",
                "league_image","leagueImage","league_image_url","leagueImageUrl",
                "tournamentLogo","tournament_logo","tournamentLogoUrl","tournament_logo_url",
                "tournament_image","tournamentImage","tournament_image_url","tournamentImageUrl").trim();

        LinearLayout tournamentRow=new LinearLayout(this);
        tournamentRow.setOrientation(LinearLayout.HORIZONTAL);
        tournamentRow.setGravity(Gravity.CENTER_VERTICAL);

        ImageView tournamentIdentity=new ImageView(this);
        tournamentIdentity.setScaleType(ImageView.ScaleType.FIT_CENTER);
        tournamentIdentity.setPadding(0,0,0,0);
        String tournamentFallbackName=competition.isEmpty()?"Cricket":competition;
        tournamentIdentity.setImageDrawable(teamMonogramDrawable(tournamentFallbackName));
        if(!competitionLogo.isEmpty()) loadImage(tournamentIdentity,competitionLogo,26);
        tournamentRow.addView(tournamentIdentity,new LinearLayout.LayoutParams(dp(26),dp(26)));

        TextView tournamentTitle=tv(competition.isEmpty()?"Cricket":competition,15.5f,TEXT,true);
        tournamentTitle.setMaxLines(2);
        tournamentTitle.setEllipsize(null);
        tournamentTitle.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        tournamentTitle.setIncludeFontPadding(false);
        tournamentTitle.setPadding(dp(8),0,0,0);
        tournamentRow.addView(tournamentTitle,new LinearLayout.LayoutParams(0,-2,1));
        String cardListingMode=String.valueOf(m.opt("_listingMode")).toLowerCase(Locale.US);
        boolean resultsListing="results".equals(cardListingMode) || "finished".equals(cardListingMode);
        String statusLabel=professionalSportsStatusLabel(m, cardListingMode);
        if(!statusLabel.isEmpty()) tournamentRow.addView(listingStatusBadge(statusLabel));
        TextView fav = tv(isFavorite(m) ? "★" : "☆", 22, isFavorite(m) ? Color.rgb(255,196,55) : MUTED, true);
        fav.setGravity(Gravity.CENTER);
        fav.setContentDescription(isFavorite(m) ? "Remove from favorites" : "Add to favorites");
        fav.setOnClickListener(v -> {
            toggleFavorite(m);
            boolean now = isFavorite(m);
            fav.setText(now ? "★" : "☆");
            fav.setTextColor(now ? Color.rgb(255,196,55) : MUTED);
            fav.setContentDescription(now ? "Remove from favorites" : "Add to favorites");
        });
        tournamentRow.addView(fav, new LinearLayout.LayoutParams(dp(38), dp(36)));
        card.addView(tournamentRow);

        String round=pickText(m,"round","round_name","roundName","roundInfo","round_info","stage","stage_name","stageName",
                "match_number","matchNumber","match_no","matchNo","match_round","matchRound","fixture_round","fixtureRound",
                "game_round","gameRound","matchday","match_day","matchday_name","matchdayName","round_display","roundDisplay",
                "fixture_number","fixtureNumber","event_round","eventRound").trim();
        String format=pickText(m,"format","match_format","matchFormat","match_type","matchType","game_type","gameType","type",
                "competition_format","competitionFormat","format_name","formatName","match_kind","matchKind","game_format","gameFormat",
                "format_short","formatShort","format_display","formatDisplay","match_type_name","matchTypeName").trim();
        if(format.isEmpty()) format=extractCricketFormat(competition);
        String venue=pickText(m,"venue","venue_name","venueName","stadium","ground","ground_name","groundName","venue_title","venueTitle",
                "location","location_name","locationName","venue_display","venueDisplay","stadium_name","stadiumName").trim();
        String providerMatchTitle=pickText(m,"match_title","matchTitle","match_name","matchName","fixture_title","fixtureTitle",
                "match_title_text","matchTitleText","fixture_name","fixtureName").trim();
        String matchTitle=cricketMatchTitle(round,format,venue,providerMatchTitle);
        if(!matchTitle.isEmpty()){
            TextView mt=tv(matchTitle,11.5f,TEXT,false);
            mt.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.ITALIC));
            mt.setMaxLines(2);
            mt.setEllipsize(null);
            mt.setIncludeFontPadding(false);
            mt.setPadding(0,dp(5),0,0);
            card.addView(mt);
        }

        String rawTime=pickText(m,"time","startsAt","starts_at","start_time","startTime","datetime","date").trim();
        String schedule=formatMatchSchedule(rawTime);
        if(!schedule.isEmpty()){
            TextView st=tv(schedule,11.5f,MUTED,false);
            st.setIncludeFontPadding(false);
            st.setPadding(0,dp(3),0,dp(9));
            card.addView(st);
        }

        View divider=new View(this);
        divider.setBackgroundColor(Color.argb(darkTheme()?38:28,255,255,255));
        card.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));

        // Team identities are always horizontal: logo + left-aligned team name.
        // Live/results add score and overs beneath the team identity.
        LinearLayout matchup=new LinearLayout(this);
        matchup.setGravity(Gravity.CENTER_VERTICAL);
        matchup.setPadding(0,dp(12),0,dp(8));

        JSONObject home=team(m,true), away=team(m,false);
        matchup.addView(cricketTeamColumn(home, isLive || isFinished, true),new LinearLayout.LayoutParams(0,-2,1));

        LinearLayout centre=new LinearLayout(this);
        centre.setOrientation(LinearLayout.VERTICAL);
        centre.setGravity(Gravity.CENTER);
        String centreText="VS";
        TextView marker=tv(centreText, 13f, MUTED, true);
        marker.setGravity(Gravity.CENTER);
        marker.setPadding(dp(8),dp(6),dp(8),dp(6));
        marker.setBackground(round(CARD_2,14));
        centre.addView(marker);
        matchup.addView(centre,new LinearLayout.LayoutParams(
                dp(getResources().getConfiguration().screenWidthDp < 340 ? 39 : 52),-2));
        matchup.addView(cricketTeamColumn(away, isLive || isFinished, false),new LinearLayout.LayoutParams(0,-2,1));
        card.addView(matchup);

        String result=pickText(m,"result","result_text","resultText","outcome","winner_text").trim();
        if(isFinished && !result.isEmpty() && !isGenericCricketStatus(result)){
            TextView r=tv(result,11.5f,Color.rgb(224,92,92),true);
            r.setGravity(Gravity.CENTER);
            r.setIncludeFontPadding(false);
            r.setPadding(0,dp(7),0,dp(2));
            View d2=new View(this);
            d2.setBackgroundColor(Color.argb(darkTheme()?38:28,255,255,255));
            card.addView(d2,new LinearLayout.LayoutParams(-1,dp(1)));
            card.addView(r);
        } else if(isLive){
            String liveInfo=pickText(m,"live_info","liveInfo","result","result_text","resultText","statusText").trim();
            if(!liveInfo.isEmpty() && !isGenericCricketStatus(liveInfo) && !"LIVE".equalsIgnoreCase(liveInfo)){
                TextView li=tv(liveInfo,10.5f,MUTED,false);
                li.setGravity(Gravity.CENTER);
                li.setIncludeFontPadding(false);
                li.setPadding(0,dp(6),0,0);
                card.addView(li);
            }
        }

        card.setOnClickListener(v->{selectedMatch=m;showMatchDetail(true);});
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);
        cp.setMargins(0,0,0,dp(12));
        card.setLayoutParams(cp);
        return card;
    }

    private String extractCricketFormat(String competition){
        String c=competition==null?"":competition.trim();
        if(c.isEmpty()) return "";
        String u=c.toUpperCase(Locale.US);
        if(u.matches(".*\\bT20I\\b.*")) return "T20I";
        if(u.matches(".*\\bT20\\b.*")) return "T20";
        if(u.matches(".*\\bODI\\b.*")) return "ODI";
        if(u.matches(".*\\bTEST\\b.*")) return "Test";
        if(u.matches(".*\\bT10\\b.*")) return "T10";
        if(u.matches(".*\\bTHE HUNDRED\\b.*") || u.matches(".*\\bHUNDRED\\b.*")) return "The Hundred";
        return "";
    }

    private String cricketMatchTitle(String round, String format, String venue, String providerTitle){
        String r=round==null?"":round.trim();
        String f=format==null?"":format.trim();
        String v=venue==null?"":venue.trim();
        String p=providerTitle==null?"":providerTitle.trim();

        // Prefer explicit round/stage data. If the provider gives a round such as
        // "5th" and a format such as "T20I", present them as "5th T20I".
        String lead=r;
        if(!lead.isEmpty() && !f.isEmpty() && !lead.toLowerCase(Locale.US).contains(f.toLowerCase(Locale.US))){
            lead=lead+" "+f;
        } else if(lead.isEmpty()){
            lead=f;
        }

        // Some providers expose the complete match-title phrase instead of round/format.
        // Use it only when structured round/format data is unavailable.
        if(lead.isEmpty() && !p.isEmpty()){
            // Use an explicit provider match title only when no structured
            // round/format field is available.
            lead=p;
        }

        if(lead.isEmpty()) return v;
        if(v.isEmpty()) return lead;
        if(lead.toLowerCase(Locale.US).contains(v.toLowerCase(Locale.US))) return lead;
        return lead+" - "+v;
    }


    private String cricketDisplayScore(JSONObject t){
        String score=pickText(t,"score_text","scoreText","display_score","displayScore","score","runs","points","total").trim();
        String wickets=pickText(t,"wickets","wicket").trim();

        if(score.isEmpty()){
            String runs=pickText(t,"runs","run","total","points").trim();
            if(!runs.isEmpty()) score=runs;
        }
        if(!score.isEmpty() && !wickets.isEmpty()
                && !score.contains("-") && !score.contains("/")
                && !score.matches(".*\\b\\d+\\s*w\\b.*")){
            score=score+"-"+wickets;
        }

        if(score.matches(".*\\([^)]*\\).*")) {
            int idx=score.indexOf('(');
            if(idx>0) score=score.substring(0,idx).trim();
        }
        return score;
    }

    private String cricketScheduleLine(String round, String schedule){
        String r=round==null?"":round.trim();
        String s=schedule==null?"":schedule.trim();
        if(!r.isEmpty() && !s.isEmpty()) return r+" • "+s;
        if(!r.isEmpty()) return r;
        return s;
    }

    // One symmetric name/logo layout for EVERY sport's match listings:
    // Home/Upcoming/Results, Cricket, Football, Basketball and Tennis.
    // On the right the name and logo are both anchored to the RIGHT edge;
    // the name is right-aligned and can wrap to two lines. Its width is
    // strictly the space remaining before the fixed centre VS column.
    private LinearLayout listingTeamIdentityRow(JSONObject team, boolean left, int logoDp, float fontSp) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        row.setClipChildren(true);
        row.setClipToPadding(true);
        row.setMinimumWidth(0);

        String teamName = pickText(team,
                "name", "team_name", "short_name", "shortName", "teamName").trim();
        int availableWidthDp = Math.max(240,getResources().getConfiguration().screenWidthDp);
        boolean narrow = availableWidthDp < 360;
        // Estimate half-row budget after card paddings and centre VS: the badge
        // may grow only while retaining at least ~50dp for a two-line team name.
        int halfColumnDp=Math.max(87,(availableWidthDp-(availableWidthDp<340?93:116))/2);
        int desiredLogoDp=availableWidthDp<300?35:(availableWidthDp<360?43:
                (availableWidthDp<420?49:(availableWidthDp<620?54:60)));
        int actualLogoDp=Math.max(32,Math.min(desiredLogoDp,Math.min(logoDp+16,halfColumnDp-55)));
        int gapDp = narrow ? 6 : 8;
        ImageView badge = identityView(team, actualLogoDp);
        badge.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams badgeLp =
                new LinearLayout.LayoutParams(dp(actualLogoDp), dp(actualLogoDp));
        badgeLp.gravity = Gravity.CENTER_VERTICAL;

        TextView name = tv(teamName, narrow ? Math.min(fontSp, 12.4f) :
                (availableWidthDp<400?Math.min(fontSp,13.7f):fontSp), TEXT, true);
        name.setSingleLine(false);
        name.setMaxLines(2);
        name.setHorizontallyScrolling(false);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        name.setGravity((left ? Gravity.LEFT : Gravity.RIGHT) | Gravity.CENTER_VERTICAL);
        name.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY);
        name.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        name.setIncludeFontPadding(false);
        name.setMinWidth(0);
        name.setPadding(0, 0, 0, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            name.setBreakStrategy(android.graphics.text.LineBreaker.BREAK_STRATEGY_HIGH_QUALITY);
        }
        if (Build.VERSION.SDK_INT >= 23) {
            name.setHyphenationFrequency(android.text.Layout.HYPHENATION_FREQUENCY_NONE);
        }

        // Critical: name is a DIRECT weighted child, never WRAP_CONTENT inside
        // a FrameLayout. That old arrangement let long away-team names occupy
        // the centre VS space or start too far towards the middle.
        LinearLayout.LayoutParams nameLp =
                new LinearLayout.LayoutParams(0, -2, 1f);
        if (left) {
            nameLp.setMargins(dp(gapDp), 0, 0, 0);
            row.addView(badge, badgeLp);
            row.addView(name, nameLp);
        } else {
            nameLp.setMargins(0, 0, dp(gapDp), 0);
            row.addView(name, nameLp);
            row.addView(badge, badgeLp);
        }
        // Respond to the actual allocated row width (not just display size).
        // Leave text at least 38dp before the crest; dynamically shrink ONLY when
        // this specific parent layout is narrower than the design budget.
        final int preferredLogoDp=actualLogoDp;
        row.addOnLayoutChangeListener((v,leftPx,topPx,rightPx,bottomPx,oldLeft,oldTop,oldRight,oldBottom)->{
            float density=getResources().getDisplayMetrics().density;
            int measuredDp=Math.round((rightPx-leftPx)/Math.max(.1f,density));
            if(measuredDp<=0)return;
            int minimumTextDp=Math.max(38,Math.min(76,Math.round(measuredDp*.45f)));
            int safeDp=Math.max(22,measuredDp-minimumTextDp-gapDp);
            int targetDp=Math.min(preferredLogoDp,safeDp);
            if(badgeLp.width!=dp(targetDp)){
                badgeLp.width=dp(targetDp);
                badgeLp.height=dp(targetDp);
                badge.setLayoutParams(badgeLp);
            }
        });
        row.setContentDescription(teamName);
        return row;
    }

    private View cricketTeamColumn(JSONObject t, boolean showScore, boolean left) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity((left ? Gravity.LEFT : Gravity.RIGHT) | Gravity.CENTER_VERTICAL);
        col.addView(listingTeamIdentityRow(t,left,52,14.5f),
                new LinearLayout.LayoutParams(-1,-2));
        if (showScore) {
            String score = cricketDisplayScore(t);
            String overs = pickText(t,"overs","over","overs_text","oversText","over_text","overText").trim();
            if (!score.isEmpty()) {
                TextView sc = tv(score,18,TEXT,true);
                sc.setGravity(left ? Gravity.LEFT : Gravity.RIGHT);
                sc.setIncludeFontPadding(false);
                sc.setPadding(0,dp(3),0,0);
                col.addView(sc,new LinearLayout.LayoutParams(-1,-2));
            }
            if (!overs.isEmpty()) {
                String ov = overs.toLowerCase(Locale.US).contains("over") ? overs : overs+" Over";
                TextView ot = tv(ov,10.5f,MUTED,false);
                ot.setGravity(left ? Gravity.LEFT : Gravity.RIGHT);
                ot.setIncludeFontPadding(false);
                ot.setPadding(0,dp(1),0,0);
                col.addView(ot,new LinearLayout.LayoutParams(-1,-2));
            }
        }
        return col;
    }

    private boolean isGenericCricketStatus(String value){
        String s=value==null?"":value.trim().toLowerCase(Locale.US).replace("_"," ");
        return s.isEmpty() || s.equals("finished") || s.equals("complete") || s.equals("completed") || s.equals("ended") || s.equals("final") || s.equals("live") || s.equals("in play") || s.equals("inplay") || s.equals("upcoming") || s.equals("scheduled");
    }

    private View matchTeam(JSONObject t, boolean left) {
        // Football, basketball, tennis and featured cards share exactly the
        // same symmetric 7dp logo gap and two-line, side-aligned name layout.
        return listingTeamIdentityRow(t,left,52,13.7f);
    }

    private void showMatchDetail(boolean push) {
        entertainmentContext=false;
        if (push) push("match");
        screen="match";
        clearContent();
        if (selectedMatch==null) { showSports(selectedSport,false); return; }
        JSONObject match=selectedMatch;
        matchDetailDataNotice = "";
        finishedResultRetryCount = 0;
        String sport=match.optString("sport",selectedSport).toLowerCase(Locale.US);
        String state=normalizedMatchStatus(pickText(match,"status","statusText","state"));
        detailTab="LIVE".equals(state) ? "LIVE" : "OVERVIEW";
        configureMatchDetailHeader();
        rememberOpenedItem("Match",canonicalMatchTitle(match),homeMatchIdentity(match));

        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.rgb(4,12,28));
        int widthDp=getResources().getConfiguration().screenWidthDp;
        int gutterDp=Math.max(0,(widthDp-720)/2);
        page.setPadding(dp(12+gutterDp),dp(7),dp(12+gutterDp),dp(22));

        String[] tabs;
        if ("cricket".equals(sport)) {
            tabs=new String[]{"Live","Scorecard","Commentary","Squads","Overview",
                    "Overs","Highlights","Series"};
        } else if ("football".equals(sport)) {
            tabs=new String[]{"Live","Stats","Lineups","Timeline","Overview","Standings","H2H"};
        } else if ("basketball".equals(sport)) {
            tabs=new String[]{"Live","Box Score","Play-by-play","Lineups","Overview","Team Stats","Standings"};
        } else {
            tabs=new String[]{"Live","Scoreboard","Point-by-point","Stats","Overview","H2H","Draw"};
        }
        HorizontalScrollView tabScroll=new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabScroll.setFillViewport(false);
        LinearLayout tabRow=new LinearLayout(this);
        tabRow.setGravity(Gravity.CENTER_VERTICAL);
        tabRow.setPadding(dp(1),dp(5),dp(1),dp(12));

        final FrameLayout bodyHost=new FrameLayout(this);
        activeMatchBodyHost=bodyHost;
        for (String title : tabs) {
            final String tabKey=title.toUpperCase(Locale.US);
            TextView button=tv(title,12.3f,Color.rgb(193,213,240),true);
            button.setGravity(Gravity.CENTER);
            button.setSingleLine(true);
            button.setPadding(dp(14),0,dp(14),0);
            LinearLayout.LayoutParams tLp=new LinearLayout.LayoutParams(-2,dp(40));
            tLp.setMargins(dp(3),0,dp(3),0);
            tabRow.addView(button,tLp);
            setPremiumMatchTab(button,tabKey.equals(detailTab));
            button.setOnClickListener(v -> {
                detailTab=tabKey;
                for (int i=0;i<tabRow.getChildCount();i++) {
                    View child=tabRow.getChildAt(i);
                    if (child instanceof TextView) {
                        TextView t=(TextView) child;
                        setPremiumMatchTab(t,t.getText().toString().equalsIgnoreCase(detailTab));
                    }
                }
                renderMatchBody(bodyHost,selectedMatch!=null?selectedMatch:match,sport);
            });
        }
        tabScroll.addView(tabRow,new HorizontalScrollView.LayoutParams(-2,-2));
        page.addView(tabScroll,new LinearLayout.LayoutParams(-1,-2));

        matchHeroHost=new FrameLayout(this);
        matchHeroHost.addView(matchHero(match),new FrameLayout.LayoutParams(-1,-2));
        LinearLayout.LayoutParams heroLp=new LinearLayout.LayoutParams(-1,-2);
        heroLp.bottomMargin=dp(13);
        page.addView(matchHeroHost,heroLp);
        if ("UPCOMING".equals(state)) {
            TextView reminder=tv("Set Match Reminder",11,TEXT,true);
            reminder.setGravity(Gravity.CENTER);
            reminder.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_reminder_clock,0,0,0);
            reminder.setCompoundDrawablePadding(dp(8));
            reminder.setBackground(round(Color.rgb(19,45,78),14));
            reminder.setOnClickListener(v->saveReminder(selectedMatch!=null?selectedMatch:match));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(43));
            p.bottomMargin=dp(10);
            page.addView(reminder,p);
        }
        page.addView(bodyHost,new LinearLayout.LayoutParams(-1,-2));
        page.addView(sportsProviderAttribution());
        View verifiedMediaCredits=verifiedMediaCreditsPanel(match);
        if(verifiedMediaCredits!=null)page.addView(verifiedMediaCredits);

        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setBackgroundColor(Color.rgb(4,12,28));
        scroll.addView(page,new ScrollView.LayoutParams(-1,-2));
        SwipeRefreshLayout swipe=new SwipeRefreshLayout(this);
        swipe.setColorSchemeColors(BLUE);
        swipe.setOnRefreshListener(()->{
            JSONObject current=selectedMatch;
            if (current!=null) loadMatchDetail(current,sport,bodyHost);
            handler.postDelayed(()->swipe.setRefreshing(false),900L);
        });
        swipe.addView(scroll,new SwipeRefreshLayout.LayoutParams(-1,-1));
        contentHost.addView(swipe,new FrameLayout.LayoutParams(-1,-1));
        renderMatchBody(bodyHost,match,sport);
        loadMatchDetail(match,sport,bodyHost);
        scheduleMatchDetailAutoRefresh(bodyHost,sport);
    }


    private View verifiedMediaCreditsPanel(JSONObject match){
        JSONArray credits=match==null?null:match.optJSONArray("verifiedMediaCredits");
        if(credits==null||credits.length()==0)return null;
        LinearLayout panel=new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12),dp(9),dp(12),dp(12));
        panel.setBackground(round(CARD,13));
        panel.addView(tv("VERIFIED PHOTO CREDITS",10,CYAN,true));
        for(int i=0;i<Math.min(6,credits.length());i++){
            JSONObject source=credits.optJSONObject(i);if(source==null)continue;
            String person=pickText(source,"name");
            String author=pickText(source,"credit","author");
            String licence=pickText(source,"license");
            String link=pickText(source,"url");
            String credit="Photo: "+person+" • "+author+" • "+licence+" • Wikimedia Commons";
            TextView line=tv(credit,9.6f,MUTED,false);
            line.setMaxLines(3);
            line.setPadding(0,dp(6),0,0);
            if(link.startsWith("https://commons.wikimedia.org/wiki/File:")){
                line.setTextColor(BLUE);
                line.setOnClickListener(v->openExternalSource(link));
                line.setContentDescription("Open Wikimedia Commons licence and creator details for "+person);
            }
            panel.addView(line);
        }
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.topMargin=dp(10);
        panel.setLayoutParams(lp);
        return panel;
    }

    private void setPremiumMatchTab(TextView tab,boolean active) {
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                active ? new int[]{Color.rgb(29,122,250),Color.rgb(19,72,199)}
                        : new int[]{Color.rgb(19,37,67),Color.rgb(12,25,48)});
        bg.setCornerRadius(dp(22));
        bg.setStroke(dp(1),active ? Color.argb(180,87,182,255)
                : Color.argb(60,119,157,209));
        tab.setBackground(new android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(Color.argb(60,112,178,255)),bg,null));
        tab.setTextColor(active?Color.WHITE:Color.rgb(189,211,240));
        tab.setElevation(dp(active?3:0));
    }

    private void loadMatchDetail(JSONObject summary, String sport, FrameLayout host) {
        if (!remoteDataEnabled || BACKEND_URL == null || BACKEND_URL.contains("REPLACE")) {
            matchDetailDataNotice = MATCH_PENDING_MESSAGE;
            renderMatchBody(host, summary, sport);
            return;
        }
        final String id = strictMatchField(summary,"id","providerMatchId","matchId",
                "match_id","eventId","event_id","fixtureId","fixture_id");
        if (id.isEmpty()) {
            matchDetailDataNotice = MATCH_PENDING_MESSAGE;
            renderMatchBody(host, summary, sport);
            return;
        }
        network.execute(() -> {
            try {
                String encoded = Uri.encode(id);
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/sports/" + sport + "/match/" + encoded, 25000));
                JSONObject detail = root.optJSONObject("match");
                if (detail == null) throw new IllegalStateException("Provider returned no match object");
                detail.put("provider", root.optString("provider", "SportScore"));
                runOnUiThread(() -> {
                    if(!"match".equals(screen) || selectedMatch != summary) return;
                    matchDetailDataNotice = "";
                    final boolean detailAvailable = root.optBoolean("detailAvailable",
                            detail.optBoolean("detailAvailable", true));
                    if (!detailAvailable && "LIVE".equals(normalizedMatchStatus(
                            pickText(detail,"status","statusText","state")))
                            && !hasVerifiedCricketScore(detail)) {
                        matchDetailDataNotice = MATCH_PENDING_MESSAGE;
                    }
                    try {
                        // Preserve list-level provider fields if the detail endpoint
                        // omits them. Never invent values.
                        JSONObject summaryHome = summary.optJSONObject("home");
                        JSONObject summaryAway = summary.optJSONObject("away");
                        JSONObject detailHome = detail.optJSONObject("home");
                        JSONObject detailAway = detail.optJSONObject("away");
                        if (detailHome == null && summaryHome != null) { detailHome = new JSONObject(); detail.put("home", detailHome); }
                        if (detailAway == null && summaryAway != null) { detailAway = new JSONObject(); detail.put("away", detailAway); }
                        mergeMissingTeamFields(detailHome, summaryHome);
                        mergeMissingTeamFields(detailAway, summaryAway);
                        for (String key : new String[]{"competition","competitionLogo","round","format","matchTitle","venue","time","startsAt","result"}) {
                            if (pickText(detail,key).isEmpty()) {
                                String value = pickText(summary,key);
                                if (!value.isEmpty()) detail.put(key,value);
                            }
                        }
                        if (pickText(detail,"status","statusText","state").isEmpty()) {
                            String summaryStatus = pickText(summary,"status","statusText","state");
                            if (!summaryStatus.isEmpty()) detail.put("status", summaryStatus);
                        }
                        selectedMatch = detail;
                    } catch(Exception ignored) {}
                    configureMatchDetailHeader();
                    if (matchHeroHost != null) {
                        matchHeroHost.removeAllViews();
                        matchHeroHost.addView(matchHero(detail),new FrameLayout.LayoutParams(-1,-2));
                    }
                    // The live scoring board is rendered inside the match hero,
                    // so refreshing the provider detail updates it in place with the hero.
                    // Keep a clear distinction between present metadata and absent score feeds.
                    if ("cricket".equals(sport)
                            && !hasVerifiedCricketScore(detail)
                            && "LIVE".equals(normalizedMatchStatus(
                            pickText(detail,"status","statusText","state")))) {
                        matchDetailDataNotice = MATCH_PENDING_MESSAGE;
                    }
                    renderMatchBody(host, detail, sport);
                    scheduleMatchDetailAutoRefresh(host, sport);
                });
            } catch(Exception error) {
                android.util.Log.w("OneTV-Match", "Unable to load verified details for " + sport
                        + " match ID " + id + ": " + error.getClass().getSimpleName());
                runOnUiThread(() -> {
                    if ("match".equals(screen) && selectedMatch == summary) {
                        String state=normalizedMatchStatus(
                                pickText(summary,"status","statusText","state"));
                        matchDetailDataNotice="LIVE".equals(state)?MATCH_PENDING_MESSAGE:"";
                        renderMatchBody(host, summary, sport);
                        scheduleMatchDetailAutoRefresh(host, sport);
                    }
                });
            }
        });
    }

    private String listingStatusLabel(String normalizedStatus, String listingMode, boolean resultsPage) {
        if ("results".equalsIgnoreCase(listingMode) || "finished".equalsIgnoreCase(listingMode) || resultsPage) {
            return remoteFinishedStatusLabel;
        }
        if ("live".equalsIgnoreCase(listingMode) || "LIVE".equalsIgnoreCase(normalizedStatus)) return remoteLiveStatusLabel;
        if ("upcoming".equalsIgnoreCase(listingMode) || "UPCOMING".equalsIgnoreCase(normalizedStatus)) return remoteUpcomingStatusLabel;
        if ("FINISHED".equalsIgnoreCase(normalizedStatus)) return remoteFinishedStatusLabel;
        if ("POSTPONED".equalsIgnoreCase(normalizedStatus)) return "Postponed";
        if ("CANCELLED".equalsIgnoreCase(normalizedStatus)) return "Cancelled";
        return "";
    }

    private TextView listingStatusBadge(String label) {
        boolean live = remoteLiveStatusLabel.equalsIgnoreCase(label);
        boolean upcoming = remoteUpcomingStatusLabel.equalsIgnoreCase(label);
        boolean finished = remoteFinishedStatusLabel.equalsIgnoreCase(label);
        boolean paused = "Stumps".equals(label)||label.endsWith("Break")||"Half Time".equals(label)
                ||"Interval".equals(label)||"Rain Delay".equals(label)||"Bad Light".equals(label)
                ||"Play Suspended".equals(label)||"Suspended".equals(label);
        boolean unverified="Status Unverified".equals(label)||"Updates Delayed".equals(label)
                ||"Match Ongoing".equals(label);
        // Live = green/white, Upcoming keeps the existing blue treatment,
        // Finished = red/white.
        int textColor = finished ? Color.rgb(255, 125, 143)
                : (live ? TEXT : (paused ? Color.rgb(251, 203, 114) : (unverified ? MUTED : (upcoming ? BLUE : MUTED))));
        // Keep Finished's red translucent fill as subtle as the blue Upcoming pill.
        int background = live ? Color.argb(34, 0, 194, 142)
                : (paused ? Color.argb(40, 231, 170, 53)
                : (unverified ? Color.argb(36, 152, 165, 184)
                : (finished ? Color.argb(34, 244, 63, 81) : Color.argb(34, 28, 126, 245))));
        TextView badge=tv(label,9.5f,textColor,true);
        badge.setGravity(Gravity.CENTER);
        badge.setSingleLine(true);
        badge.setPadding(dp(11),dp(6),dp(11),dp(6));
        badge.setMinWidth(dp(live || finished ? 78 : 70));
        badge.setBackground(round(background,16));
        return badge;
    }

    private void scheduleMatchDetailAutoRefresh(FrameLayout host, String sport) {
        stopMatchDetailAutoRefresh();
        if (!"match".equals(screen) || host == null) return;
        activeMatchBodyHost = host;
        long delay = cricketDetailRefreshMs;
        String status = normalizedMatchStatus(pickText(selectedMatch,"status","statusText","state","match_status","matchStatus"));
        if ("CANCELLED".equals(status) || "ABANDONED".equals(status)) return;
        if ("FINISHED".equals(status)) {
            // A completed fixture can initially have only "Match finished".
            // Fetch up to six further D1 snapshots while the winning result
            // settles, then stop. Reminders are intentionally untouched.
            if(!verifiedFinishedMessage(selectedMatch).isEmpty() || finishedResultRetryCount>=6)return;
            finishedResultRetryCount++;
            delay=Math.max(60000L,cricketDetailRefreshMs);
        }
        handler.postDelayed(matchDetailRefreshTask, delay);
    }

    private void stopMatchDetailAutoRefresh() {
        handler.removeCallbacks(matchDetailRefreshTask);
    }

    private void mergeMissingTeamFields(JSONObject target, JSONObject source) {
        if (target == null || source == null) return;
        for (String key : new String[]{"name","slug","id","score","runs","wickets","overs","logo","flag","countryCode","country_code"}) {
            if (emptyMatchValue(pickText(target,key))) {
                String value = pickText(source,key);
                if (!emptyMatchValue(value)) try { target.put(key,value); } catch(Exception ignored) {}
            }
        }
    }

    private String providerStatusText(JSONObject m,String sport){
        String rawStatus=pickText(m,"status","statusText","state","match_status","matchStatus");
        String status=normalizedMatchStatus(rawStatus);
        ArrayList<String> details=new ArrayList<>();
        if("cricket".equals(sport)){
            addIfPresent(details,"Innings",pickText(m,"innings","currentInnings"));
            addIfPresent(details,"Target",pickText(m,"target"));
            addIfPresent(details,"Required",pickText(m,"runsRequired","requiredRuns"));
            addIfPresent(details,"RRR",pickText(m,"requiredRunRate","rrr"));
        } else if("football".equals(sport)){
            addIfPresent(details,"Clock",pickText(m,"clock","matchClock","minute"));
            addIfPresent(details,"Goals",pickText(m,"goals"));
            addIfPresent(details,"Cards",pickText(m,"cards"));
            addIfPresent(details,"VAR",pickText(m,"var"));
        } else if("basketball".equals(sport)){
            addIfPresent(details,"Period",pickText(m,"period","quarter"));
            addIfPresent(details,"Clock",pickText(m,"clock","gameClock"));
            addIfPresent(details,"Fouls",pickText(m,"fouls","teamFouls"));
            addIfPresent(details,"Timeouts",pickText(m,"timeouts"));
        } else {
            addIfPresent(details,"Set",pickText(m,"set","currentSet"));
            addIfPresent(details,"Game",pickText(m,"game","currentGame"));
            addIfPresent(details,"Server",pickText(m,"server"));
            addIfPresent(details,"Break",pickText(m,"breakPoint","break"));
        }
        if(status.isEmpty() && details.isEmpty()) return "";
        if(details.isEmpty()) return status;
        return status.isEmpty()?android.text.TextUtils.join(" • ",details):status+" • "+android.text.TextUtils.join(" • ",details);
    }

    private void addIfPresent(ArrayList<String> list,String label,String value){
        if(value!=null && !value.trim().isEmpty()) list.add(label+" "+value.trim());
    }

    private View cricketLiveScoreBoard(JSONObject m) {
        if (m == null) return null;
        String status = normalizedMatchStatus(pickText(m,"status","statusText","state","match_status","matchStatus"));
        String result = pickText(m,"result","result_text","resultText","outcome","winner_text","winnerText","winner");
        String display = "";

        if ("LIVE".equals(status)) {
            String phase=professionalSportsStatusLabel(m, String.valueOf(m.opt("_listingMode")));
            if (!remoteLiveStatusLabel.equalsIgnoreCase(phase) && !phase.isEmpty())
                display=phase+" • Latest verified score will appear when available";
            else display=latestCricketLiveStatus(m);
            if (display.isEmpty()) display = "Updating live score • Please wait…";
        } else if ("FINISHED".equals(status)) {
            display = result.trim();
            if (display.isEmpty()) {
                String winner = pickText(m,"winner","winner_name","winnerName","winning_team","winningTeam","winner_text","winnerText");
                display = winner.isEmpty() ? "Match finished" : winner;
            }
        } else if ("UPCOMING".equals(status)) {
            return null;
        } else {
            return null;
        }

        TextView board = tv(display, 10.8f, TEXT, true);
        board.setGravity(Gravity.CENTER);
        board.setMaxLines(2);
        board.setEllipsize(android.text.TextUtils.TruncateAt.END);
        board.setIncludeFontPadding(false);
        board.setPadding(dp(16), dp(12), dp(16), dp(12));
        // A restrained premium green, used as the live scoring surface itself.
        int bg = "FINISHED".equals(status)
                ? Color.argb(46, 244, 63, 81)
                : Color.rgb(20, 122, 82);
        board.setBackground(round(bg, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.setMargins(dp(0), dp(8), dp(0), dp(0));
        board.setLayoutParams(lp);
        return board;
    }

    private String latestCricketLiveStatus(JSONObject m) {
        JSONObject raw = rawProvider(m);
        JSONArray a = pickArray(raw,"commentary","ball_by_ball","ballByBall","commentaries","commentary_feed","commentaryFeed");
        if (a.length() == 0) return "";

        JSONObject latest = null;
        double latestOrder = -1;
        int latestIndex = -1;
        String latestText = "";
        for (int i=0; i<a.length(); i++) {
            JSONObject x=a.optJSONObject(i);
            if(x==null) continue;
            String text=commentaryText(x);
            if(text.isEmpty()) continue;
            double order=commentaryDeliveryOrder(x);
            if(latest==null || order>latestOrder || (order<0 && latestOrder<0 && i>latestIndex)) {
                latest=x;
                latestOrder=order;
                latestIndex=i;
                latestText=text;
            }
        }
        if(latest==null) return "";

        String event=cricketEventBadge(latest, latestText);
        if(!event.isEmpty()) return event + "  •  " + latestText;
        return latestText;
    }

    private String commentaryText(JSONObject x) {
        return pickText(x,"text","commentary","comment","commText","comm_text","commtext","description","event","eventType","message","title","summary").trim();
    }

    private double commentaryDeliveryOrder(JSONObject x) {
        String over=pickText(x,"over","over_number","overNumber","over_num","overNum");
        String ball=pickText(x,"ball","ball_number","ballNumber","delivery","delivery_number","deliveryNumber");
        try {
            double o=Double.parseDouble(over.replaceAll("[^0-9.]",""));
            double b=0;
            if(!ball.isEmpty()) b=Double.parseDouble(ball.replaceAll("[^0-9.]",""));
            return o*100+b;
        } catch(Exception ignored) {
            String ts=pickText(x,"timestamp","timeStamp","commTimestamp","commentaryTimestamp","createdAt","created_at","timestamp_ms");
            try {
                if(ts.matches("\\d+")) return Double.parseDouble(ts);
                String iso = ts.trim().replace("Z", "+0000");
                if (iso.matches(".*[+-]\\d{2}:\\d{2}$")) {
                    iso = iso.substring(0, iso.length()-6) + iso.substring(iso.length()-5).replace(":", "");
                }
                java.text.SimpleDateFormat isoParser = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US);
                return isoParser.parse(iso).getTime();
            } catch(Exception ignoredTs) { return -1; }
        }
    }

    private String cricketEventBadge(JSONObject x, String text) {
        String t=(text==null?"":text).toLowerCase(Locale.US);
        String dismissal=pickText(x,"wicket_type","dismissal","dismissal_text","dismissalText","out_reason","outReason","how_out","howOut").toLowerCase(Locale.US);
        if (t.contains("bowled") || dismissal.contains("bowled")) return "BOWLED";
        if (t.contains("lbw") || dismissal.contains("lbw")) return "LBW";
        if (t.contains("caught") || dismissal.contains("caught")) return "CAUGHT";
        if (t.contains("run out") || dismissal.contains("run out")) return "RUN OUT";
        if (t.contains("stumped") || dismissal.contains("stumped")) return "STUMPED";
        if (t.contains("hit wicket") || dismissal.contains("hit wicket")) return "HIT WICKET";
        boolean wicket=boolLike(x,"isWicket","is_wicket","wicket") || !dismissal.isEmpty()
                || t.contains("wicket");
        if(wicket) return "WICKET";
        boolean six=boolLike(x,"isSix","is_six","six") || t.matches(".*\\b6\\b.*") || t.contains("six");
        if(six) return "SIX";
        boolean four=boolLike(x,"isFour","is_four","four") || t.matches(".*\\b4\\b.*") || t.contains("four");
        if(four) return "FOUR";
        if(t.contains("no ball") || t.contains("noball")) return "NO BALL";
        if(t.contains("wide")) return "WIDE";
        if(t.contains("leg bye") || t.contains("leg-bye")) return "LEG BYE";
        if(t.contains("player") && (t.contains("enter") || t.contains("comes in") || t.contains("coming in"))) return "PLAYER IN";
        if(t.contains("break") || t.contains("interval") || t.contains("drinks") || t.contains("lunch") || t.contains("tea")) return "BREAK";
        String runs=pickText(x,"runs","run","bat_runs","batRuns","total_runs","totalRuns","totalRunsValue","score");
        if("1".equals(runs)) return "1 RUN";
        if("2".equals(runs)) return "2 RUNS";
        if("3".equals(runs)) return "3 RUNS";
        if("0".equals(runs) || t.contains("dot ball") || t.contains("no run")) return "DOT BALL";
        return "";
    }

    private View matchHero(JSONObject m) {
        String sport=m.optString("sport",selectedSport).toLowerCase(Locale.US);
        String status=normalizedMatchStatus(pickText(m,"status","statusText","state","match_status"));
        JSONObject home=team(m,true),away=team(m,false);
        FrameLayout surface=new FrameLayout(this);
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(13,39,80),Color.rgb(18,28,70),Color.rgb(37,18,64)});
        bg.setCornerRadius(dp(21));
        bg.setStroke(dp(1),Color.argb(112,90,151,240));
        surface.setBackground(bg);
        surface.setClipToOutline(true);
        // Creative V-shaped light plates are decorative, intentionally barely visible.
        View plate=new View(this);
        GradientDrawable decor=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.argb(17,37,149,255),Color.argb(11,205,49,245)});
        decor.setCornerRadius(dp(50));
        plate.setBackground(decor);
        plate.setRotation(-28f);
        FrameLayout.LayoutParams plateLp=new FrameLayout.LayoutParams(dp(170),dp(225),
                Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        plateLp.topMargin=-dp(27);
        surface.addView(plate,plateLp);
        LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14),dp(18),dp(14),dp(24));
        LinearLayout head=new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        String competition=pickText(m,"competition","league","tournament",
                "competition_name","league_name");
        TextView league=tv(competition.isEmpty()?sportName(sport):competition,11,
                Color.rgb(196,217,242),true);
        league.setMaxLines(2); league.setEllipsize(android.text.TextUtils.TruncateAt.END);
        head.addView(league,new LinearLayout.LayoutParams(0,-2,1));
        String presentationStatus=professionalSportsStatusLabel(m, String.valueOf(m.opt("_listingMode")));
        if (!presentationStatus.isEmpty()) head.addView(listingStatusBadge(presentationStatus));
        content.addView(head);

        LinearLayout teams=new LinearLayout(this);
        teams.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        teams.setPadding(0,dp(21),0,dp(14));
        teams.addView(heroTeam(m,home,true,sport),new LinearLayout.LayoutParams(0,-2,1));
        TextView center=tv("VS",15f,Color.rgb(220,233,250),true);
        center.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams centerLp=new LinearLayout.LayoutParams(dp(38),dp(60));
        teams.addView(center,centerLp);
        teams.addView(heroTeam(m,away,false,sport),new LinearLayout.LayoutParams(0,-2,1));
        content.addView(teams);
        if ("cricket".equals(sport)) {
            String target=strictMatchField(m,"target","targetScore","target_score");
            if(target.matches("[0-9]+")) {
                TextView chase=tv("Target  "+target,11.5f,Color.rgb(188,213,246),true);
                chase.setGravity(Gravity.CENTER);
                chase.setPadding(0,dp(5),0,0);
                content.addView(chase);
            }
        }

        String update=matchRealtimeUpdate(m,sport);
        if (!update.isEmpty()) {
            LinearLayout statusPill=new LinearLayout(this);
            statusPill.setGravity(Gravity.CENTER);
            // Larger touch-free read area: slightly taller live update board.
            statusPill.setPadding(dp(13),dp(13),dp(13),dp(13));
            statusPill.setMinimumHeight(dp(54));
            GradientDrawable pill=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Color.argb(125,9,70,139),Color.argb(100,89,31,127)});
            pill.setCornerRadius(dp(22));
            pill.setStroke(dp(1),Color.argb(122,62,169,252));
            statusPill.setBackground(pill);
            // Show ONLY the verified update: no duplicate "LIVE UPDATE"/"LIVE" prefix.
            // The update alone may wrap to a second line; all other labels stay compact.
            TextView text=tv(update,13.5f,Color.WHITE,true);
            text.setGravity(Gravity.CENTER);
            text.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            text.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            text.setSingleLine(false);
            text.setMaxLines(2);
            text.setEllipsize(android.text.TextUtils.TruncateAt.END);
            text.setLineSpacing(dp(2),1.0f);
            statusPill.addView(text,new LinearLayout.LayoutParams(-1,-2));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
            p.topMargin=dp(10);
            content.addView(statusPill,p);
        }
        // Upcoming-only real countdown, independent of the reminder feature.
        // Unknown, stale or timezone-ambiguous schedule values are never guessed.
        if("UPCOMING".equals(status)) addVerifiedKickoffCountdown(content,m);
        surface.addView(content,new FrameLayout.LayoutParams(-1,-2));
        surface.setMinimumHeight(dp(246));
        surface.setContentDescription(canonicalMatchTitle(m));
        return surface;
    }

    private void addVerifiedKickoffCountdown(LinearLayout parent, JSONObject match) {
        final long startAt=verifiedUpcomingKickoff(match);
        if(startAt<=System.currentTimeMillis())return;
        final TextView countdown=tv("",11.7f,Color.rgb(190,224,255),true);
        countdown.setGravity(Gravity.CENTER);
        countdown.setSingleLine(true);
        countdown.setEllipsize(android.text.TextUtils.TruncateAt.END);
        countdown.setContentDescription("Time remaining until scheduled match kickoff");
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.topMargin=dp(8);
        parent.addView(countdown,lp);
        // Bind ticking to the actual view lifecycle. It is stopped as soon
        // as Match Detail re-renders, preventing leaked timers and old labels.
        final Runnable[] update=new Runnable[1];
        update[0]=()->{
            if(!countdown.isAttachedToWindow()||!"match".equals(screen))return;
            long millis=startAt-System.currentTimeMillis();
            if(millis<=0L){
                countdown.setText("Kickoff time reached • Awaiting verified live status");
                return;
            }
            long minutes=(millis+59999L)/60000L;
            long days=minutes/(24L*60L);
            long hours=(minutes%(24L*60L))/60L;
            long remain=minutes%60L;
            String value=days>0L ? days+"d "+hours+"h "+remain+"m" :
                    hours>0L ? hours+"h "+remain+"m" : remain+"m";
            countdown.setText("STARTS IN  "+value);
            handler.postDelayed(update[0],30000L);
        };
        countdown.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){
            @Override public void onViewAttachedToWindow(View v){
                handler.removeCallbacks(update[0]);
                handler.post(update[0]);
            }
            @Override public void onViewDetachedFromWindow(View v){
                handler.removeCallbacks(update[0]);
            }
        });
    }

    private LinearLayout heroTeam(JSONObject match, JSONObject t,boolean left,String sport) {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.TOP|(left?Gravity.START:Gravity.END));
        int screenDp=getResources().getConfiguration().screenWidthDp;
        int tile=screenDp<350?62:(screenDp<410?74:(screenDp<620?84:94));
        // Match Detail uses the same shape-free crest as Featured. Keep the
        // original 2dp inset/visible footprint; the monogram's own background
        // remains visible only when no verified crest has been loaded.
        ImageView logo=cleanHeroCrest(t,tile-4);
        logo.setPadding(dp(2),dp(2),dp(2),dp(2));
        LinearLayout.LayoutParams logoLp=new LinearLayout.LayoutParams(dp(tile),dp(tile));
        logoLp.gravity=left?Gravity.START:Gravity.END;
        box.addView(logo,logoLp);
        String name=pickText(t,"short_name","shortName","abbreviation","name","team_name");
        TextView label=tv(name,screenDp<360?12f:13.5f,Color.WHITE,true);
        label.setGravity(left?Gravity.LEFT:Gravity.RIGHT);
        label.setMaxLines(2);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        label.setPadding(0,dp(9),0,0);
        box.addView(label,new LinearLayout.LayoutParams(-1,-2));
        String score="cricket".equalsIgnoreCase(sport)
                ? verifiedCricketTeamScore(match,left)
                : validMatchValue(pickText(t,"score","points","total"));
        if (!score.isEmpty()) {
            TextView figure=tv(score,screenDp<350?22f:27f,Color.WHITE,true);
            figure.setGravity(left?Gravity.LEFT:Gravity.RIGHT);
            figure.setMaxLines(1);
            figure.setEllipsize(android.text.TextUtils.TruncateAt.END);
            figure.setPadding(0,dp(7),0,0);
            box.addView(figure,new LinearLayout.LayoutParams(-1,-2));
        } else if ("cricket".equalsIgnoreCase(sport)) {
            String state=normalizedMatchStatus(pickText(match,"status","statusText","state"));
            String message="UPCOMING".equals(state)?"Not started":"Score unavailable";
            TextView missing=tv(message,11,Color.rgb(169,195,226),false);
            missing.setGravity(left?Gravity.LEFT:Gravity.RIGHT);
            missing.setMaxLines(1);
            missing.setPadding(0,dp(9),0,0);
            box.addView(missing,new LinearLayout.LayoutParams(-1,-2));
        }
        String overs="cricket".equalsIgnoreCase(sport)
                ? verifiedCricketTeamOvers(match,left)
                : validMatchValue(pickText(t,"overs","oversText","overs_text"));
        if (!overs.isEmpty()) {
            TextView line=tv(overs.toLowerCase(Locale.US).contains("ov")
                    ? overs : overs+" ov",11.5f,Color.rgb(185,210,242),false);
            line.setGravity(left?Gravity.LEFT:Gravity.RIGHT);
            box.addView(line,new LinearLayout.LayoutParams(-1,-2));
        }
        return box;
    }

    // Match-specific score lookup. Every value below is from THIS match's
    // direct team object or explicitly paired innings; never use a generic
    // deep "score" lookup that might pick the other team or an old delivery.
    private boolean emptyMatchValue(String input) {
        if (input==null) return true;
        String value=input.trim().toLowerCase(Locale.US);
        return value.isEmpty() || value.equals("-") || value.equals("—")
                || value.equals("--") || value.equals("null") || value.equals("n/a")
                || value.equals("na") || value.equals("undefined") || value.equals("pending")
                || value.equals("not available");
    }

    private String validMatchValue(String input) {
        return emptyMatchValue(input)?"":input.trim();
    }

    private String teamScoreFromNode(Object node) {
        if (node instanceof String || node instanceof Number) {
            String score=validMatchValue(String.valueOf(node));
            // An actual cricket score contains digits; never present prose as a score.
            return score.matches(".*\\d.*") && score.length()<=40 ? score : "";
        }
        if (!(node instanceof JSONObject)) return "";
        JSONObject o=(JSONObject)node;
        String wickets=validMatchValue(o.optString("wickets",o.optString("wicket","")));
        for (String key:new String[]{"score_text","scoreText","display_score","displayScore","score"}) {
            String text=teamScoreFromNode(o.opt(key));
            if(!text.isEmpty()) {
                // If the provider supplied the wicket count separately, combine
                // those two actual values, never fabricate a wicket count.
                if(text.matches("\\d+") && wickets.matches("\\d+"))
                    return text+"/"+wickets;
                return text;
            }
        }
        String runs=validMatchValue(o.optString("runs",o.optString("run",
                o.optString("total", ""))));
        if(runs.matches("\\d+"))return wickets.matches("\\d+") ? runs+"/"+wickets : runs;
        // Cricbuzz has innings scores nested under inngs1/inngs2, not score.
        for(String key:new String[]{"inngs2","innings2","inngs1","innings1",
                "inning2","inning1","currentInnings","current_innings"}) {
            String nested=teamScoreFromNode(o.opt(key));
            if(!nested.isEmpty())return nested;
        }
        return "";
    }

    private String teamOversFromNode(JSONObject node) {
        if(node==null)return "";
        for(String key:new String[]{"overs","overs_text","oversText","over","overText"}) {
            String value=validMatchValue(node.optString(key,""));
            if(!value.isEmpty())return value;
        }
        for(String key:new String[]{"inngs2","innings2","inngs1","innings1",
                "inning2","inning1"}) {
            String value=teamOversFromNode(node.optJSONObject(key));
            if(!value.isEmpty())return value;
        }
        return "";
    }

    private JSONObject providerCricketScoreObject(JSONObject match,boolean home) {
        JSONObject raw=match==null?null:match.optJSONObject("rawProviderData");
        JSONObject[] sources={match,raw,
                raw==null?null:raw.optJSONObject("matchInfo"),
                raw==null?null:raw.optJSONObject("match"),
                raw==null?null:raw.optJSONObject("matchScore"),
                raw==null?null:raw.optJSONObject("data")};
        String key=home?"team1Score":"team2Score";
        for(JSONObject source:sources) {
            if(source==null)continue;
            JSONObject scores=source.optJSONObject(key);
            if(scores!=null)return scores;
        }
        return null;
    }

    private String verifiedCricketTeamScore(JSONObject match,boolean home) {
        if(match==null)return "";
        JSONObject team=team(match,home);
        String result=teamScoreFromNode(team);
        if(!result.isEmpty())return result;
        String[] flat=home ? new String[]{"home_score","homeScore","team1_score","team1ScoreText"}
                : new String[]{"away_score","awayScore","team2_score","team2ScoreText"};
        JSONObject raw=match.optJSONObject("rawProviderData");
        for(JSONObject src:new JSONObject[]{match,raw}) {
            if(src==null)continue;
            for(String key:flat) {
                result=teamScoreFromNode(src.opt(key));
                if(!result.isEmpty())return result;
            }
        }
        result=teamScoreFromNode(providerCricketScoreObject(match,home));
        if(!result.isEmpty())return result;
        // Innings arrays can be used only when their explicit team ID/name matches.
        JSONArray innings=match.optJSONArray("innings");
        if(innings==null && raw!=null)innings=raw.optJSONArray("innings");
        if(innings!=null) {
            String wanted=validMatchValue(team.optString("name",""))
                    .replaceAll("[^A-Za-z0-9]", "").toLowerCase(Locale.US);
            String wantedId=validMatchValue(team.optString("id",""));
            for(int i=innings.length()-1;i>=0;i--) {
                JSONObject entry=innings.optJSONObject(i);
                if(entry==null)continue;
                String owner=validMatchValue(entry.optString("team_name",
                        entry.optString("teamName",entry.optString("team",""))))
                        .replaceAll("[^A-Za-z0-9]", "").toLowerCase(Locale.US);
                String ownerId=validMatchValue(entry.optString("team_id",entry.optString("teamId","")));
                if ((!wanted.isEmpty() && wanted.equals(owner))
                        || (!wantedId.isEmpty() && wantedId.equals(ownerId))) {
                    result=teamScoreFromNode(entry);
                    if(!result.isEmpty())return result;
                }
            }
        }
        return "";
    }

    private String verifiedCricketTeamOvers(JSONObject match,boolean home) {
        if(match==null)return "";
        String value=teamOversFromNode(team(match,home));
        if(!value.isEmpty())return value;
        JSONObject raw=match.optJSONObject("rawProviderData");
        String key=home?"home_overs":"away_overs";
        for(JSONObject src:new JSONObject[]{match,raw}) {
            if(src!=null) {
                value=validMatchValue(src.optString(key,""));
                if(!value.isEmpty())return value;
            }
        }
        return teamOversFromNode(providerCricketScoreObject(match,home));
    }

    private boolean hasVerifiedCricketScore(JSONObject match) {
        return !verifiedCricketTeamScore(match,true).isEmpty()
                || !verifiedCricketTeamScore(match,false).isEmpty();
    }

    // Read specific LIVE fields only from this match, never from unrelated nested
    // participants or cached events. Text is constructed solely from provider values.
    private String strictMatchField(JSONObject m,String... keys) {
        if(m==null)return "";
        JSONObject raw=m.optJSONObject("rawProviderData");
        JSONObject[] sources={m,m.optJSONObject("live"),m.optJSONObject("match"),
                raw,raw==null?null:raw.optJSONObject("live"),
                raw==null?null:raw.optJSONObject("match")};
        for (JSONObject source:sources) {
            if(source==null)continue;
            for(String key:keys){
                Object value=source.opt(key);
                if(value instanceof String || value instanceof Number){
                    String str=String.valueOf(value).trim();
                    if(!str.isEmpty() && !"null".equalsIgnoreCase(str))return str;
                }
            }
        }
        return "";
    }

    private String verifiedFinishedMessage(JSONObject match) {
        for(String key:new String[]{"resultMessage","result","resultText","result_text",
                "scoreboardMessage","outcome","winner_text"}) {
            String value=validMatchValue(strictMatchField(match,key));
            if(value.isEmpty() || value.matches("(?i)^(match finished|match complete|finished|completed|final|ended|result pending)$"))continue;
            // The server verifies winner identity and margin; client never guesses
            // the winner from scores. Respect verified draw/tie/no-result messages.
            if(value.length()<=180)return value;
        }
        return "";
    }

    private String matchRealtimeUpdate(JSONObject match,String sport) {
        String status=normalizedMatchStatus(pickText(match,"status","statusText","state","match_status"));
        if ("FINISHED".equals(status)) {
            // Provider-backed result first; do not let a stale generic scoreboard
            // placeholder hide a newer verified winner + margin.
            String result=verifiedFinishedMessage(match);
            return result.isEmpty()?"Match finished":result;
        }
        if("UPCOMING".equals(status)) {
            String rawTime=strictMatchField(match,"time","startsAt","starts_at",
                    "startTime","start_time","scheduledAt","scheduled_at","dateTime");
            String when=OneTvMatchTime.formattedLocal(rawTime);
            String where=validMatchValue(strictMatchField(match,
                    "venue","venueName","venue_name","ground","stadium"));
            if(!when.isEmpty() && !where.isEmpty()) return when+" at "+where;
            if(!when.isEmpty()) return when;
            if(!where.isEmpty()) return "Venue • "+where+" • Time to be confirmed";
            return "Match schedule to be confirmed";
        }
        if(!"LIVE".equals(status))return "";
        if("cricket".equalsIgnoreCase(sport)) {
            String runs=validMatchValue(strictMatchField(match,"runsRequired","runs_required","requiredRuns","required_runs",
                    "runsToWin","runs_to_win","runsNeeded","runs_needed"));
            String balls=validMatchValue(strictMatchField(match,"ballsRemaining","balls_remaining","remainingBalls","remaining_balls",
                    "ballsToGo","balls_to_go","deliveriesRemaining","deliveries_remaining"));
            String rate=validMatchValue(strictMatchField(match,"requiredRunRate","required_run_rate","rrr"));
            if(runs.matches("\\d+") && balls.matches("\\d+")) {
                String batting=strictMatchField(match,"battingTeamName","batting_team_name","currentBattingTeamName");
                String line=(batting.isEmpty()?"Batting team needs ":batting+" need ")
                        +runs+" runs in "+balls+" balls";
                return rate.isEmpty()?line:line+" • Req RR "+rate;
            }
            String latest=latestCricketLiveStatus(match);
            if(!latest.isEmpty())return "Latest • "+latest;
            // Fallback to the score of THIS exact fixture, never an older match.
            String homeScore=verifiedCricketTeamScore(match,true);
            String awayScore=verifiedCricketTeamScore(match,false);
            if(!homeScore.isEmpty() || !awayScore.isEmpty()){
                String homeName=pickText(team(match,true),"short_name","name");
                String awayName=pickText(team(match,false),"short_name","name");
                StringBuilder board=new StringBuilder();
                if(!homeScore.isEmpty())board.append(homeName).append(" ").append(homeScore);
                if(!awayScore.isEmpty()){
                    if(board.length()>0)board.append("  •  ");
                    board.append(awayName).append(" ").append(awayScore);
                }
                return board.toString();
            }
            String score=validMatchValue(strictMatchField(match,
                    "live_info","liveInfo","scoreUpdate","score_update"));
            if (!score.isEmpty()) return score;
            // Fixture providers (including SportScore) can report a real
            // innings/match phase such as "1st innings (away)" even when no
            // ball-by-ball events or numeric score are supplied. Show that
            // verified phase in the hero status board, independently of score.
            String phase=validMatchValue(strictMatchField(match,
                    "statusText","status_text","stateText","state_text",
                    "matchStatusText","match_status_text"));
            if (phase.isEmpty() || isGenericCricketStatus(phase)) {
                String resultPhase=validMatchValue(strictMatchField(match,
                        "result","resultText","result_text"));
                if (!resultPhase.isEmpty() && !isGenericCricketStatus(resultPhase))
                    phase=resultPhase;
            }
            if (!phase.isEmpty() && !isGenericCricketStatus(phase)) return phase;
            return MATCH_PENDING_MESSAGE;
        }
        String live=providerStatusText(match,sport);
        if("LIVE".equalsIgnoreCase(live))return MATCH_PENDING_MESSAGE;
        if(live.startsWith("LIVE • "))live=live.substring(7);
        return live.isEmpty()?MATCH_PENDING_MESSAGE:live;
    }

    private String matchMetaText(String sport, JSONObject m) {
        ArrayList<String> parts = new ArrayList<>();
        String date = pickText(m, "date", "startTime", "start_time", "scheduledAt", "scheduled_at");
        String venue = pickText(m, "venue", "venueName");
        String format = pickText(m, "format", "round", "stage", "competitionRound");
        String referee = pickText(m, "referee", "official", "officials");
        if(!date.isEmpty()) parts.add(date);
        if(!venue.isEmpty()) parts.add(venue);
        if(!format.isEmpty()) parts.add(format);
        if("football".equals(sport) && !referee.isEmpty()) parts.add("Referee " + referee);
        return parts.isEmpty() ? "" : android.text.TextUtils.join("  •  ", parts);
    }

    private void renderMatchBody(FrameLayout host, JSONObject m, String sport) {
        if(host==null || m==null)return;
        host.removeAllViews();
        LinearLayout body=new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(0,dp(2),0,dp(16));
        if(!matchDetailDataNotice.isEmpty()
                && !MATCH_PENDING_MESSAGE.equals(matchDetailDataNotice)
                && !MATCH_PENDING_MESSAGE.equals(matchRealtimeUpdate(m,sport))) {
            TextView notice=tv(matchDetailDataNotice,11.2f,Color.rgb(193,214,238),false);
            notice.setPadding(dp(12),dp(12),dp(12),dp(12));
            notice.setBackground(round(Color.rgb(16,34,56),13));
            LinearLayout.LayoutParams nLp=new LinearLayout.LayoutParams(-1,-2);
            nLp.bottomMargin=dp(10);
            body.addView(notice,nLp);
        }
        String active=detailTab;
        if("cricket".equals(sport))renderProviderCricket(body,m,active);
        else if("football".equals(sport))renderProviderFootball(body,m,active);
        else if("basketball".equals(sport))renderProviderBasketball(body,m,active);
        else renderProviderTennis(body,m,active);
        host.addView(body,new FrameLayout.LayoutParams(-1,-2));
    }

    private JSONObject rawProvider(JSONObject m){
        if(m==null)return new JSONObject();
        JSONObject raw=m.optJSONObject("rawProviderData");
        if(raw==null)return m;
        try{
            JSONObject merged=new JSONObject(raw.toString());
            JSONArray names=m.names();
            if(names!=null)for(int i=0;i<names.length();i++){
                String k=names.optString(i);
                if(!"rawProviderData".equals(k) && !merged.has(k)) merged.put(k,m.opt(k));
            }
            return merged;
        }catch(Exception ignored){return m;}
    }

    // Provider payloads are not guaranteed to use one fixed nesting level.
    // Match detail data may arrive directly, under data/match/result, or inside
    // a provider-specific container. These helpers deliberately search the
    // existing payload without inventing or merging values from another match.
    private Object findDeep(JSONObject root, String[] keys, int depth){
        if(root==null || depth<0) return null;
        for(String k:keys){
            Object v=root.opt(k);
            if(v!=null && !(v instanceof JSONObject && ((JSONObject)v).length()==0) && !(v instanceof JSONArray && ((JSONArray)v).length()==0)) return v;
        }
        if(depth==0) return null;
        JSONArray names=root.names();
        if(names!=null){
            for(int i=0;i<names.length();i++){
                Object v=root.opt(names.optString(i));
                if(v instanceof JSONObject){
                    Object found=findDeep((JSONObject)v,keys,depth-1);
                    if(found!=null) return found;
                }else if(v instanceof JSONArray){
                    JSONArray a=(JSONArray)v;
                    for(int j=0;j<a.length();j++){
                        Object item=a.opt(j);
                        if(item instanceof JSONObject){
                            Object found=findDeep((JSONObject)item,keys,depth-1);
                            if(found!=null) return found;
                        }
                    }
                }
            }
        }
        return null;
    }

    private String pickText(JSONObject o,String... keys){
        if(o==null) return "";
        for(String k:keys){
            Object v=o.opt(k);
            if(v!=null && !(v instanceof JSONObject) && !(v instanceof JSONArray) && !String.valueOf(v).trim().isEmpty()) return String.valueOf(v);
        }
        Object found=findDeep(o,keys,5);
        if(found!=null && !(found instanceof JSONObject) && !(found instanceof JSONArray) && !String.valueOf(found).trim().isEmpty()) return String.valueOf(found);
        return "";
    }

    private JSONArray pickArray(JSONObject o,String... keys){
        if(o==null) return new JSONArray();
        for(String k:keys){
            JSONArray a=o.optJSONArray(k);
            if(a!=null && a.length()>0) return a;
            JSONObject container=o.optJSONObject(k);
            if(container!=null){
                for(String ck:new String[]{"items","data","results","list","entries","records","rows","values","events"}){
                    JSONArray ca=container.optJSONArray(ck);
                    if(ca!=null && ca.length()>0) return ca;
                }
            }
        }
        Object found=findDeep(o,keys,5);
        if(found instanceof JSONArray && ((JSONArray)found).length()>0) return (JSONArray)found;
        if(found instanceof JSONObject){
            JSONObject x=(JSONObject)found;
            for(String ck:new String[]{"items","data","results","list","entries","records","rows","values","events"}){
                JSONArray ca=x.optJSONArray(ck);
                if(ca!=null && ca.length()>0) return ca;
            }
        }
        return new JSONArray();
    }

    private JSONObject pickObject(JSONObject o,String... keys){
        if(o==null) return new JSONObject();
        for(String k:keys){JSONObject x=o.optJSONObject(k);if(x!=null)return x;}
        Object found=findDeep(o,keys,5);
        return found instanceof JSONObject ? (JSONObject)found : new JSONObject();
    }
    private void providerUnavailable(LinearLayout b,String title){ /* unavailable provider fields are intentionally omitted */ }
    private void providerTeamHeader(LinearLayout b,JSONObject m){
        JSONObject h=team(m,true),a=team(m,false);
        String homeName=pickText(h,"name","team_name","short_name");
        String awayName=pickText(a,"name","team_name","short_name");
        String homeScore=pickText(h,"score","runs","points","total");
        String awayScore=pickText(a,"score","runs","points","total");
        if(homeName.isEmpty()) homeName=pickText(m,"home_name","homeTeamName");
        if(awayName.isEmpty()) awayName=pickText(m,"away_name","awayTeamName");
        if(homeScore.isEmpty()) homeScore=pickText(m,"home_score","homeScore");
        if(awayScore.isEmpty()) awayScore=pickText(m,"away_score","awayScore");
        if(!homeName.isEmpty()||!awayName.isEmpty()||!homeScore.isEmpty()||!awayScore.isEmpty()){
            b.addView(scoreboardCard(homeName,homeScore,normalizedMatchStatus(pickText(m,"status","statusText","state","match_status","matchStatus")),awayName+(awayScore.isEmpty()?"":"  "+awayScore)));
        }
    }
    private void addMatchInfo(LinearLayout b, JSONObject m){
        JSONObject raw=rawProvider(m);
        ArrayList<String[]> info=new ArrayList<>();
        String series=pickText(m,"series","series_name","seriesName","tournament","competition");
        String date=pickText(m,"date","match_date","matchDate","scheduledAt","scheduled_at","start_date","startDate");
        String time=pickText(m,"time","match_time","matchTime","start_time","startTime","startsAt","starts_at");
        String venue=pickText(m,"venue","venue_name","venueName","ground","stadium");
        String city=pickText(m,"city","venue_city","venueCity");
        String country=pickText(m,"country","venue_country","venueCountry");
        String format=pickText(m,"format","match_format","matchFormat","round","stage","competitionRound");
        String toss=pickText(m,"toss","toss_result","tossResult");
        String result=pickText(m,"result","match_result","matchResult","outcome");
        String status=normalizedMatchStatus(pickText(m,"status","statusText","state","match_status","matchStatus"));
        String officials=pickText(m,"officials","umpires","umpire","referee");

        if(series.isEmpty()) series=pickText(raw,"series","series_name","seriesName","tournament","competition");
        if(date.isEmpty()) date=pickText(raw,"date","match_date","matchDate","scheduledAt","scheduled_at","start_date","startDate");
        if(time.isEmpty()) time=pickText(raw,"time","match_time","matchTime","start_time","startTime","startsAt","starts_at");
        if(venue.isEmpty()) venue=pickText(raw,"venue","venue_name","venueName","ground","stadium");
        if(city.isEmpty()) city=pickText(raw,"city","venue_city","venueCity");
        if(country.isEmpty()) country=pickText(raw,"country","venue_country","venueCountry");
        if(format.isEmpty()) format=pickText(raw,"format","match_format","matchFormat","round","stage","competitionRound");
        if(toss.isEmpty()) toss=pickText(raw,"toss","toss_result","tossResult");
        if(result.isEmpty()) result=pickText(raw,"result","match_result","matchResult","outcome");
        if(status.isEmpty()) status=normalizedMatchStatus(pickText(raw,"status","statusText","state","match_status","matchStatus"));
        if(officials.isEmpty()) officials=pickText(raw,"officials","umpires","umpire","referee");

        if(!series.isEmpty()) info.add(new String[]{"Series",series});
        if(!date.isEmpty()) info.add(new String[]{"Date",date});
        if(!time.isEmpty()) info.add(new String[]{"Time",formatMatchSchedule(time)});
        if(!venue.isEmpty()) info.add(new String[]{"Venue",venue});
        String location=city;
        if(!country.isEmpty()) location=location.isEmpty()?country:location+", "+country;
        if(!location.isEmpty()) info.add(new String[]{"Location",location});
        if(!format.isEmpty()) info.add(new String[]{"Format",format});
        if(!toss.isEmpty()) info.add(new String[]{"Toss",toss});
        if(!result.isEmpty()) info.add(new String[]{"Result",result});
        if(!status.isEmpty()) info.add(new String[]{"Status",status});
        if(!officials.isEmpty()) info.add(new String[]{"Officials",officials});
        if(info.isEmpty()) return;

        b.addView(sectionLabel("Match Information","Verified provider fields only"));
        for(String[] item:info){
            View row=detailRow(item[0],item[1]);
            row.setLayoutParams(marginBottomParams(5));
            b.addView(row);
        }
    }

    private void renderProviderCricket(LinearLayout b,JSONObject m,String tab){
        JSONObject raw=rawProvider(m);
        if(!"LIVE".equals(tab))
            b.addView(sectionLabel("Cricket Match Centre",m.optString("competition","")));
        if("OVERVIEW".equals(tab)){
            providerTeamHeader(b,m);
            addCricketOverviewState(b,m,raw);
            addMatchInfo(b,m);
            return;
        }
        if("LIVE".equals(tab)){
            renderMatchCommentaryPreview(b,raw);
            renderCricketLiveBoard(b,m,raw);
            return;
        }
        if("SCORECARD".equals(tab)){
            renderCricketScorecard(b,m,raw);
            return;
        }
        if("SQUADS".equals(tab)){
            renderProviderPeople(b,pickArray(raw,"squads","squad","playing_xi","playingXI","playing_xi_players","team_players","lineups"),"Squads");
            return;
        }
        if("OVERS".equals(tab)){
            JSONArray overs=pickArray(raw,"overs","over_by_over","overByOver","over_summary","overSummary");
            renderCricketOvers(b,overs);
            return;
        }
        if("COMMENTARY".equals(tab)){
            JSONArray commentary=pickArray(raw,"commentary","ball_by_ball","ballByBall","commentaries","commentary_feed","commentaryFeed");
            renderProviderEvents(b,commentary,"Commentary");
            return;
        }
        if("HIGHLIGHTS".equals(tab)){
            JSONArray highlights=pickArray(raw,"highlights","highlight","key_events","keyEvents");
            renderProviderEvents(b,highlights,"Highlights");
            return;
        }
        if("SERIES".equals(tab)){
            renderCricketSeries(b,m,raw);
            return;
        }
        providerUnavailable(b,tab);
    }

    private void renderCricketScorecard(LinearLayout b, JSONObject m, JSONObject raw) {
        b.addView(sectionLabel("Scorecard", "Batting • Bowling • Extras • Fall of Wickets • Partnerships"));
        JSONArray innings=pickArray(raw,"innings","innings_summary","inningsSummary");
        if(innings.length()>0){
            for(int i=0;i<innings.length();i++){
                JSONObject inn=innings.optJSONObject(i);
                if(inn!=null) renderCricketInningsScorecard(b,inn,i+1,m,raw);
            }
            return;
        }

        // Some providers expose scorecard sections at the match root instead of
        // nesting them under innings. Keep the same professional section order.
        renderCricketSectionArray(b,"Batting",collectFeatureArray(raw,"batting","batting_scorecard","battingScorecard"),true);
        renderCricketSectionArray(b,"Bowling",collectFeatureArray(raw,"bowling","bowling_scorecard","bowlingScorecard"),false);
        renderExtrasSection(b,collectFeatureArray(raw,"extras"));
        renderFowSection(b,collectFeatureArray(raw,"fall_of_wickets","fallOfWickets","fow"));
        renderPartnershipSection(b,collectFeatureArray(raw,"partnerships","partnership"));
        if(!hasCricketScorecardData(raw)){
            JSONObject home=team(m,true), away=team(m,false);
            String hs=pickText(home,"score","runs","points","total","score_text","scoreText");
            String as=pickText(away,"score","runs","points","total","score_text","scoreText");
            if(!hs.isEmpty()||!as.isEmpty()) b.addView(scoreboardCard(pickText(home,"name","team_name","short_name"),hs,"",pickText(away,"name","team_name","short_name")+(as.isEmpty()?"":"  "+as)));
        }
    }

    private void renderCricketInningsScorecard(LinearLayout b, JSONObject inn, int number, JSONObject match, JSONObject raw){
        String teamName=pickText(inn,"team","team_name","teamName","batting_team","battingTeam","name");
        String score=pickText(inn,"score","score_text","scoreText","total");
        String overs=pickText(inn,"overs","over","overs_text","oversText");
        String wickets=pickText(inn,"wickets","wicket");
        String subtitle=teamName;
        if(score.isEmpty()) score=pickText(inn,"runs");
        if(!score.isEmpty()) subtitle+=(subtitle.isEmpty()?"":"  ")+score+(overs.isEmpty()?"":" ("+overs+" Ov)");
        if(!wickets.isEmpty() && !score.contains("/")) subtitle+=(score.isEmpty()?"":"  ")+"/"+wickets;
        if(subtitle.isEmpty()) subtitle="Innings "+number;
        b.addView(sectionLabel("Innings "+number,subtitle));
        renderCricketSectionArray(b,"Batting",collectFeatureArray(inn,"batting","batting_scorecard","battingScorecard","batters","batsmen"),true);
        renderCricketSectionArray(b,"Bowling",collectFeatureArray(inn,"bowling","bowling_scorecard","bowlingScorecard","bowlers"),false);
        renderExtrasSection(b,collectFeatureArray(inn,"extras"));
        renderFowSection(b,collectFeatureArray(inn,"fall_of_wickets","fallOfWickets","fow"));
        renderPartnershipSection(b,collectFeatureArray(inn,"partnerships","partnership"));
    }

    private JSONArray collectFeatureArray(JSONObject root,String... keys){
        JSONArray out=new JSONArray();
        collectFeatureArrayRecursive(root,out,keys,0);
        return out;
    }

    private void collectFeatureArrayRecursive(Object node,JSONArray out,String[] keys,int depth){
        if(node==null||depth>7)return;
        if(node instanceof JSONArray){
            JSONArray a=(JSONArray)node;
            for(int i=0;i<a.length();i++)collectFeatureArrayRecursive(a.opt(i),out,keys,depth+1);
            return;
        }
        if(!(node instanceof JSONObject))return;
        JSONObject o=(JSONObject)node;
        for(String key:keys){
            JSONArray a=o.optJSONArray(key);
            if(a!=null&&a.length()>0){
                for(int i=0;i<a.length();i++)putUniqueFeature(out,a.opt(i));
            }else{
                JSONObject obj=o.optJSONObject(key);
                if(obj!=null){
                    JSONArray nested=objectArray(obj);
                    for(int i=0;i<nested.length();i++)putUniqueFeature(out,nested.opt(i));
                }
            }
        }
        JSONArray names=o.names();
        if(names!=null)for(int i=0;i<names.length();i++){
            Object v=o.opt(names.optString(i));
            if(v instanceof JSONObject||v instanceof JSONArray)collectFeatureArrayRecursive(v,out,keys,depth+1);
        }
    }

    private void putUniqueFeature(JSONArray out,Object value){
        if(value==null)return;
        String sig=String.valueOf(value);
        for(int i=0;i<out.length();i++)if(sig.equals(String.valueOf(out.opt(i))))return;
        out.put(value);
    }

    private JSONArray objectArray(JSONObject o){
        JSONArray out=new JSONArray();
        for(String k:new String[]{"items","data","results","list","entries","records","rows","values"}){
            JSONArray a=o.optJSONArray(k); if(a!=null&&a.length()>0)return a;
        }
        return out;
    }

    private boolean hasCricketScorecardData(JSONObject raw){
        return collectFeatureArray(raw,"batting","batting_scorecard","battingScorecard","batters","batsmen").length()>0
                || collectFeatureArray(raw,"bowling","bowling_scorecard","bowlingScorecard","bowlers").length()>0
                || collectFeatureArray(raw,"extras").length()>0
                || collectFeatureArray(raw,"fall_of_wickets","fallOfWickets","fow").length()>0
                || collectFeatureArray(raw,"partnerships","partnership").length()>0;
    }

    // Player photo and gender: read only THIS player record or its explicit
    // nested player object. A generic recursive lookup can borrow another
    // athlete's gender or picture from a team/scorecard wrapper.
    private String playerDirectField(JSONObject object,String... aliases){
        if(object==null)return "";
        for(String key:aliases){
            Object value=object.opt(key);
            if(value instanceof String || value instanceof Number){
                String text=String.valueOf(value).trim();
                if(!text.isEmpty()&&!"null".equalsIgnoreCase(text))return text;
            }
        }
        return "";
    }

    private JSONObject nestedPlayer(JSONObject x){
        if(x==null)return null;
        for(String key:new String[]{"player","athlete","person"}){
            JSONObject value=x.optJSONObject(key);
            if(value!=null)return value;
        }
        return null;
    }

    private String playerName(JSONObject x){
        String name=playerDirectField(x,"name","player_name","playerName","full_name","fullName",
                "batName","bowlName","batter","batsman","bowler");
        if(name.isEmpty())name=playerDirectField(nestedPlayer(x),"name","player_name","playerName","full_name","fullName");
        return name;
    }


    // First-party media delivery. Source photography is fetched, licensed and
    // cached in Cloudflare R2 by Cron. Android NEVER fetches Wikimedia/other
    // sports image providers directly or sends a user IP to those sources.
    private String firstPartySportsMediaUrl(String raw){
        String value=raw==null?"":raw.trim();
        if(value.isEmpty())return "";
        if(value.startsWith("/sports/verified-media/")){
            if(!value.matches("/sports/verified-media/(?:players|venues|teams)/[a-f0-9]{64}\\.(?:jpg|png|webp)"))return "";
            return BACKEND_URL.replaceAll("/+$","")+value;
        }
        try{
            android.net.Uri uri=android.net.Uri.parse(value);
            android.net.Uri own=android.net.Uri.parse(BACKEND_URL);
            if(!"https".equalsIgnoreCase(uri.getScheme()) || uri.getUserInfo()!=null ||
                    !own.getHost().equalsIgnoreCase(uri.getHost()) ||
                    !uri.getPath().matches("/sports/verified-media/(?:players|venues|teams)/[a-f0-9]{64}\\.(?:jpg|png|webp)"))return "";
            return value;
        }catch(Exception ignored){return "";}
    }

    private String featuredVerifiedPhoto(JSONObject captain){
        if(captain==null || !captain.optBoolean("photo_verified",false))return "";
        String raw=pickText(captain,"avatar_url","photo_url","image_url");
        return firstPartySportsMediaUrl(raw);
    }

    private String verifiedPhotoCreditLine(JSONObject match){
        JSONArray credits=match==null?null:match.optJSONArray("verifiedMediaCredits");
        if(credits==null||credits.length()==0)return "";
        StringBuilder text=new StringBuilder();
        for(int i=0;i<Math.min(2,credits.length());i++){
            JSONObject x=credits.optJSONObject(i);if(x==null)continue;
            String author=pickText(x,"credit","author");
            String licence=pickText(x,"license");
            if(text.length()>0)text.append(" & ");
            text.append(author.isEmpty()?"Wikimedia Commons":author);
            if(!licence.isEmpty())text.append(" ("+licence+")");
        }
        return text.length()>0?"Photo: "+text:"";
    }

    private String playerPhoto(JSONObject x){
        String[] keys={"avatar_url","avatarUrl","image_url","imageUrl","photo_url","photoUrl",
                "headshot_url","headshotUrl","profile_image","profileImage","player_image","playerImage",
                "profile_photo","profilePhoto","avatar","photo","headshot","image"};
        for(JSONObject row:new JSONObject[]{x,nestedPlayer(x)}){
            if(row==null)continue;
            for(String key:keys){
                String candidate=playerDirectField(row,key);
                String verified=firstPartySportsMediaUrl(candidate);
                if(!verified.isEmpty())return verified;
            }
        }
        return "";
    }

    private String verifiedPlayerGender(JSONObject x){
        // Backend's verification marker prevents inferring gender from conflicting
        // raw provider fields after the backend explicitly rejected them.
        if(x!=null && x.has("onetv_gender_verified")){
            return x.optBoolean("onetv_gender_verified",false)
                    ? normalizePlayerGender(playerDirectField(x,"gender")) : "";
        }
        // Treat missing, unrecognised, or contradictory provider values as unknown.
        // Numeric codes are intentionally excluded: they vary between providers.
        String verified="";
        String[] keys={"gender","sex","player_gender","playerGender","gender_type","genderType",
                "gender_code","genderCode"};
        for(JSONObject row:new JSONObject[]{x,nestedPlayer(x)}){
            if(row==null)continue;
            for(String key:keys){
                String value=playerDirectField(row,key);
                if(value.isEmpty())continue;
                String parsed=normalizePlayerGender(value);
                if(parsed.isEmpty())return "";
                if(!verified.isEmpty()&&!verified.equals(parsed))return "";
                verified=parsed;
            }
        }
        return verified;
    }

    private android.graphics.drawable.Drawable playerIdentityFallback(JSONObject x){
        return playerGenderAvatar(playerName(x),verifiedPlayerGender(x));
    }

    private void renderCricketSectionArray(LinearLayout b,String title,JSONArray a,boolean batting){
        if(a==null||a.length()==0)return;
        b.addView(sectionLabel(title,batting?"R  B  4s  6s  SR":"O  M  R  W  ECO"));
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);
            if(x==null){b.addView(eventRow(String.valueOf(a.opt(i)),i));continue;}
            String name=playerName(x);
            if(name.isEmpty())continue; // Do not invent player identities from generic stats.
            String status=playerDirectField(x,"status","dismissal","dismissal_text","dismissalText","out_reason","outReason","how_out","howOut");
            String avatar=playerPhoto(x);
            String gender=verifiedPlayerGender(x);
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),dp(9),dp(10),dp(9));row.setBackground(round(CARD,12));
            if(!avatar.isEmpty()||!name.isEmpty()){
                ImageView im=new ImageView(this);
                im.setScaleType(ImageView.ScaleType.CENTER_CROP);
                im.setBackground(circleDrawable(CARD_2));
                im.setClipToOutline(true);
                im.setImageDrawable(playerGenderAvatar(name,gender));
                if(!avatar.isEmpty()) loadPlayerAvatar(im,avatar,name);
                row.addView(im,new LinearLayout.LayoutParams(dp(34),dp(34)));
            }
            LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(8),0,dp(6),0);
            TextView nm=tv(name,11.5f,TEXT,true);nm.setMaxLines(2);info.addView(nm);
            if(!status.isEmpty()) {TextView st=tv(status,8.5f,MUTED,false);st.setMaxLines(2);info.addView(st);}
            row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            String[] vals=batting?new String[]{pickText(x,"runs","run","r"),pickText(x,"balls","ball","b"),pickText(x,"fours","four","4s"),pickText(x,"sixes","six","6s"),pickText(x,"strike_rate","strikeRate","sr")}:
                    new String[]{pickText(x,"overs","over","o"),pickText(x,"maidens","maiden","m"),pickText(x,"runs","run","r"),pickText(x,"wickets","wicket","w"),pickText(x,"economy","economy_rate","economyRate","eco")};
            LinearLayout stats=new LinearLayout(this);stats.setGravity(Gravity.CENTER_VERTICAL);stats.setPadding(dp(4),0,0,0);
            for(String v:vals){TextView z=tv(v.isEmpty()?"-":v,10.5f,TEXT,true);z.setGravity(Gravity.CENTER);stats.addView(z,new LinearLayout.LayoutParams(dp(38),-2));}
            row.addView(stats);
            b.addView(row,new LinearLayout.LayoutParams(-1,-2));
            Space gap=new Space(this);b.addView(gap,new LinearLayout.LayoutParams(1,dp(5)));
        }
    }

    private void renderExtrasSection(LinearLayout b,JSONArray a){
        if(a==null||a.length()==0)return;
        b.addView(sectionLabel("Extras","Byes • Leg byes • Wides • No balls • Penalty"));
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);
            if(x==null){b.addView(eventRow(String.valueOf(a.opt(i)),i));continue;}
            String text=pickText(x,"summary","description","text","total","value");
            if(text.isEmpty()){
                ArrayList<String> parts=new ArrayList<>();
                for(String[] f:new String[][]{{"b","Byes"},{"lb","Leg byes"},{"w","Wides"},{"nb","No balls"},{"p","Penalty"},{"total","Total"}}){String v=pickText(x,f[0],f[1],f[1].toLowerCase(Locale.US));if(!v.isEmpty())parts.add(f[1]+" "+v);}
                text=android.text.TextUtils.join("  •  ",parts);
            }
            if(!text.isEmpty())b.addView(detailRow("Extras",text));
        }
    }

    private void renderFowSection(LinearLayout b,JSONArray a){
        if(a==null||a.length()==0)return;
        b.addView(sectionLabel("Fall of Wickets","Wicket • Score • Over"));
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i); if(x==null){b.addView(eventRow(String.valueOf(a.opt(i)),i));continue;}
            String player=pickText(x,"player","player_name","playerName","batter","batsman","name");
            String score=pickText(x,"score","team_score","teamScore","runs","total");
            String over=pickText(x,"over","overs","ball","delivery");
            String text=(player.isEmpty()?"Wicket "+(i+1):player)+(score.isEmpty()?"":"  •  "+score)+(over.isEmpty()?"":"  •  "+over);
            b.addView(detailRow(""+(i+1),text));
        }
    }

    private void renderPartnershipSection(LinearLayout b,JSONArray a){
        if(a==null||a.length()==0)return;
        b.addView(sectionLabel("Partnerships","Runs • Balls • Batters"));
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i); if(x==null){b.addView(eventRow(String.valueOf(a.opt(i)),i));continue;}
            String p1=pickText(x,"player1","player_1","batter1","batter_1","first_player","firstPlayer");
            String p2=pickText(x,"player2","player_2","batter2","batter_2","second_player","secondPlayer");
            if(p1.isEmpty()||p2.isEmpty()){
                JSONArray players=x.optJSONArray("players"); if(players!=null&&players.length()>0){p1=pickText(players.optJSONObject(0),"name","player_name");if(players.length()>1)p2=pickText(players.optJSONObject(1),"name","player_name");}
            }
            String runs=pickText(x,"runs","partnership_runs","partnershipRuns","total");
            String balls=pickText(x,"balls","partnership_balls","partnershipBalls");
            String text=(p1.isEmpty()?"Batter 1":p1)+"  +  "+(p2.isEmpty()?"Batter 2":p2);
            String meta=(runs.isEmpty()?"":runs+" runs")+(balls.isEmpty()?"":"  •  "+balls+" balls");
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(10),dp(9),dp(10),dp(9));row.setBackground(round(CARD,12));row.addView(tv(text,11,TEXT,true));if(!meta.isEmpty())row.addView(tv(meta,9,MUTED,false));b.addView(row,new LinearLayout.LayoutParams(-1,-2));Space gap=new Space(this);b.addView(gap,new LinearLayout.LayoutParams(1,dp(5)));
        }
    }

    private void addCricketOverviewState(LinearLayout b,JSONObject m,JSONObject raw){
        ArrayList<String[]> stats=new ArrayList<>();
        // Strict root-level fields only. A generic deep search can accidentally
        // select the other team, an old innings, or the delivery's runs.
        String score=validMatchValue(strictMatchField(m,"current_score","currentScore",
                "innings_score","inningsScore"));
        String currentWickets=validMatchValue(strictMatchField(m,"current_wickets","currentWickets"));
        if(score.matches("\\d+") && currentWickets.matches("\\d+"))
            score=score+"/"+currentWickets;
        String overs=validMatchValue(strictMatchField(m,"current_over","currentOver"));
        String target=validMatchValue(strictMatchField(m,"target","target_score","targetScore"));
        String required=validMatchValue(strictMatchField(m,"runs_required","runsRequired",
                "required_runs","requiredRuns"));
        String crr=validMatchValue(strictMatchField(m,"crr","current_run_rate","currentRunRate"));
        String rrr=validMatchValue(strictMatchField(m,"rrr","required_run_rate","requiredRunRate"));
        if(!score.isEmpty())stats.add(new String[]{"Score",score,""});
        if(!overs.isEmpty())stats.add(new String[]{"Overs",overs,""});
        if(!target.isEmpty())stats.add(new String[]{"Target",target,""});
        if(!required.isEmpty())stats.add(new String[]{"Required",required,""});
        if(!crr.isEmpty())stats.add(new String[]{"CRR",crr,""});
        if(!rrr.isEmpty())stats.add(new String[]{"RRR",rrr,""});
        if(!stats.isEmpty())addStatGrid(b,stats.toArray(new String[0][]));
    }

    private void renderCurrentBatters(LinearLayout b,JSONObject raw){
        JSONArray a=pickArray(raw,"current_batters","currentBatters");
        if(a.length()==0)return;
        renderCricketSectionArray(b,"Current Batters",a,true);
    }

    private void renderCurrentBowler(LinearLayout b,JSONObject raw){
        JSONArray a=pickArray(raw,"current_bowler","currentBowler");
        if(a.length()==0){JSONObject o=pickObject(raw,"current_bowler","currentBowler");if(o.length()>0){a=new JSONArray();a.put(o);}}
        if(a.length()==0)return;
        renderCricketSectionArray(b,"Current Bowler",a,false);
    }

    private void renderCricketLiveBoard(LinearLayout b, JSONObject m, JSONObject raw) {
        // The large premium hero ABOVE the tabs body is the ONE canonical
        // scoreboard. Do not draw a duplicate card that repeats names/scores.
        addCricketOverviewState(b,m,raw);
        renderCurrentBatters(b,raw);
        renderCurrentBowler(b,raw);
        JSONArray overs=pickArray(raw,"overs","over_by_over","overByOver",
                "over_summary","overSummary");
        if(overs.length()>0)renderCricketOvers(b,overs);
        if (!hasVerifiedCricketScore(m)
                && emptyMatchValue(strictMatchField(m,"current_score","currentScore"))
                && matchDetailDataNotice.isEmpty()
                && !MATCH_PENDING_MESSAGE.equals(matchRealtimeUpdate(m,"cricket"))) {
            // Display a single friendly waiting state; no fake score or
            // duplicate technical error panel below the real scoreboard.
            b.addView(homeSmallState(MATCH_PENDING_MESSAGE));
        }
    }

    private LinearLayout liveScoreTeam(String name,String score,JSONObject team){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);
        int miniLogoDp=getResources().getConfiguration().screenWidthDp<340?44:52;
        ImageView symbol=identityView(team,miniLogoDp);
        LinearLayout.LayoutParams symbolLp=new LinearLayout.LayoutParams(dp(miniLogoDp),dp(miniLogoDp));
        symbolLp.gravity=Gravity.CENTER_HORIZONTAL;
        box.addView(symbol,symbolLp);
        TextView teamName=tv(name.isEmpty()?"Team":name,11.5f,TEXT,true);
        teamName.setMaxLines(2);
        teamName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        teamName.setGravity(Gravity.CENTER);
        box.addView(teamName,new LinearLayout.LayoutParams(-1,-2));
        if(!score.isEmpty())box.addView(tv(score,17,TEXT,true));
        String overs=pickText(team,"overs","over","overs_text","oversText","over_text","overText");
        if(!overs.isEmpty())box.addView(tv(overs.toLowerCase(Locale.US).contains("over")?overs:overs+" Ov",8.5f,MUTED,false));
        return box;
    }

    private void renderMatchCommentaryPreview(LinearLayout parent,JSONObject raw) {
        JSONArray deliveries=pickArray(raw,"commentary","ball_by_ball","ballByBall",
                "commentaries","commentary_feed","commentaryFeed");
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(13),dp(13),dp(13),dp(12));
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(13,33,65),Color.rgb(20,28,64),Color.rgb(31,22,65)});
        bg.setCornerRadius(dp(20));
        bg.setStroke(dp(1),Color.argb(91,85,143,228));
        card.setBackground(bg);
        TextView header=tv("Live Commentary",17,Color.WHITE,true);
        LinearLayout.LayoutParams hl=new LinearLayout.LayoutParams(-1,-2);
        hl.bottomMargin=dp(10);
        card.addView(header,hl);
        java.util.ArrayList<JSONObject> valid=new java.util.ArrayList<>();
        for(int i=0;i<deliveries.length();i++){
            JSONObject event=deliveries.optJSONObject(i);
            if(event!=null&&!commentaryText(event).isEmpty())valid.add(event);
        }
        // Ordered event times/sequence when supplied. With no sequence, retain
        // original provider order; no invented over numbers or commentary.
        if(!valid.isEmpty()){
            boolean hasOrder=true;
            for(JSONObject event:valid){
                if(commentaryDeliveryOrder(event)<0){hasOrder=false;break;}
            }
            if(hasOrder)valid.sort((a,b)->Double.compare(
                    commentaryDeliveryOrder(b),commentaryDeliveryOrder(a)));
            else java.util.Collections.reverse(valid);
        }
        int shown=0;
        for(JSONObject event:valid){
            if(shown>=4)break;
            String content=commentaryText(event);
            if(content.isEmpty())continue;
            String over=strictMatchField(event,"over","over_number","overNumber");
            String ball=strictMatchField(event,"ball","ball_number","ballNumber");
            String label=over.isEmpty()?"•":(ball.isEmpty()?over:over+"."+ball);
            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(4),dp(10),dp(4),dp(10));
            TextView delivery=tv(label,11.5f,Color.WHITE,true);
            delivery.setGravity(Gravity.CENTER_VERTICAL);
            row.addView(delivery,new LinearLayout.LayoutParams(dp(49),-2));
            String eventTag=cricketEventBadge(event,content);
            String runs=strictMatchField(event,"runs","run","bat_runs","batRuns");
            String bubble="WICKET".equals(eventTag)?"W":
                    ("FOUR".equals(eventTag)?"4":("SIX".equals(eventTag)?"6":
                            (runs.matches("[0-9]+")?runs:"•")));
            int bubbleColor="WICKET".equals(eventTag)?Color.rgb(184,48,78):
                    ("4".equals(bubble)||"6".equals(bubble)
                            ?Color.rgb(8,166,122):Color.rgb(51,75,111));
            TextView impact=tv(bubble,12,Color.WHITE,true);
            impact.setGravity(Gravity.CENTER);
            impact.setBackground(round(bubbleColor,16));
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(30),dp(30));
            ip.rightMargin=dp(11);
            row.addView(impact,ip);
            TextView description=tv(content,11.5f,Color.rgb(232,241,255),false);
            description.setMaxLines(3);
            description.setEllipsize(android.text.TextUtils.TruncateAt.END);
            row.addView(description,new LinearLayout.LayoutParams(0,-2,1));
            card.addView(row);
            shown++;
            if(shown<valid.size() && shown<4){
                View divider=new View(this);
                divider.setBackgroundColor(Color.argb(47,153,189,242));
                card.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
            }
        }
        if(shown==0){
            TextView empty=tv("No verified ball-by-ball commentary available yet.",
                    11,Color.rgb(166,187,217),false);
            empty.setPadding(dp(4),dp(8),dp(4),dp(8));
            card.addView(empty);
        }
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.bottomMargin=dp(12);
        parent.addView(card,p);
    }

    private void renderCricketCommentary(LinearLayout b,JSONArray a){
        if(a==null||a.length()==0)return;
        b.addView(sectionLabel("Ball-by-Ball Commentary","Latest delivery first when supplied by the provider"));
        int shown=0;
        for(int i=a.length()-1;i>=0 && shown<80;i--){
            JSONObject x=a.optJSONObject(i);
            if(x==null){String raw=String.valueOf(a.opt(i));if(!raw.trim().isEmpty())b.addView(eventRow(raw,shown++));continue;}
            String over=pickText(x,"over","over_number","overNumber","over_num","overNum");
            String ball=pickText(x,"ball","ball_number","ballNumber","delivery","delivery_number","deliveryNumber");
            String batsman=pickText(x,"batsman","batter","batter_name","batsman_name","striker","striker_name");
            String bowler=pickText(x,"bowler","bowler_name","bowlerName");
            String runs=pickText(x,"runs","run","bat_runs","batRuns","total_runs","totalRuns","totalRunsValue","score");
            String extras=pickText(x,"extras","extra","extra_runs","extraRuns");
            String text=pickText(x,"text","commentary","comment","commText","comm_text","commtext","description","event","eventType","message","title","summary");
            boolean four=boolLike(x,"isFour","is_four","four") || "4".equals(runs);
            boolean six=boolLike(x,"isSix","is_six","six") || "6".equals(runs);
            boolean wicket=boolLike(x,"isWicket","is_wicket","wicket") || !pickText(x,"wicket_type","dismissal","dismissal_text","outcome").isEmpty();
            if(text.isEmpty()){
                StringBuilder sb=new StringBuilder();
                if(!batsman.isEmpty())sb.append(batsman);
                if(!bowler.isEmpty()){if(sb.length()>0)sb.append(" • ");sb.append("vs ").append(bowler);}
                if(!runs.isEmpty()){if(sb.length()>0)sb.append(" • ");sb.append(runs).append(" run").append("6".equals(runs)||"4".equals(runs)?"s":"");}
                if(!extras.isEmpty()){if(sb.length()>0)sb.append(" • ");sb.append(extras);}
                text=sb.toString();
            }
            if(text.isEmpty())text=flattenProviderObject(x);
            if(text.isEmpty())continue;
            LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(9),dp(9),dp(9),dp(9));row.setBackground(round(CARD,12));
            String overLabel=over.isEmpty()?"":(ball.isEmpty()?over:over+"."+ball);
            TextView ov=tv(overLabel.isEmpty()?"•":overLabel,9,MUTED,true);ov.setGravity(Gravity.CENTER);row.addView(ov,new LinearLayout.LayoutParams(dp(44),dp(34)));
            TextView desc=tv(text,10.5f,TEXT,false);desc.setMaxLines(4);desc.setEllipsize(android.text.TextUtils.TruncateAt.END);desc.setPadding(dp(7),0,dp(7),0);row.addView(desc,new LinearLayout.LayoutParams(0,-2,1));
            String badgeText=wicket?"WICKET":(six?"6":(four?"4":(!runs.isEmpty()?runs:"")));
            if(!badgeText.isEmpty()){TextView badge=tv(badgeText,9,wicket?RED:(four||six?TEXT:CYAN),true);badge.setGravity(Gravity.CENTER);badge.setPadding(dp(7),dp(5),dp(7),dp(5));badge.setBackground(round(wicket?Color.argb(45,244,63,81):(four||six?Color.argb(38,28,126,245):Color.argb(30,0,205,190)),12));row.addView(badge,new LinearLayout.LayoutParams(-2,dp(30)));}
            b.addView(row,marginBottomParams(5));
            shown++;
        }
    }

    private boolean boolLike(JSONObject o,String...keys){
        for(String k:keys){Object v=o.opt(k);if(v instanceof Boolean && (Boolean)v)return true;String s=String.valueOf(v==null?"":v).trim().toLowerCase(Locale.US);if("true".equals(s)||"yes".equals(s)||"1".equals(s))return true;}
        return false;
    }

    private void renderCricketOvers(LinearLayout b,JSONArray a){
        if(a==null||a.length()==0)return;
        b.addView(sectionLabel("Overs","Over-by-over breakdown"));
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);if(x==null){b.addView(eventRow(String.valueOf(a.opt(i)),i));continue;}
            String over=pickText(x,"over","over_number","overNumber","number");
            String runs=pickText(x,"runs","score","total");
            String bowler=pickText(x,"bowler","bowler_name","bowlerName");
            String deliveries=pickText(x,"deliveries","balls","events");
            String title=(over.isEmpty()?"Over "+(i+1):"Over "+over)+(runs.isEmpty()?"":"  •  "+runs+" runs")+(bowler.isEmpty()?"":"  •  "+bowler);
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(10),dp(9),dp(10),dp(9));row.setBackground(round(CARD,12));row.addView(tv(title,11,TEXT,true));String details=deliveries.isEmpty()?flattenProviderObject(x):deliveries;if(!details.isEmpty()&&!details.equals(title))row.addView(tv(details,9,MUTED,false));b.addView(row,new LinearLayout.LayoutParams(-1,-2));Space gap=new Space(this);b.addView(gap,new LinearLayout.LayoutParams(1,dp(5)));
        }
    }

    private void renderCricketSeries(LinearLayout b,JSONObject m,JSONObject raw){
        JSONObject series=pickObject(raw,"series","series_data","seriesData","seriesDetails");
        String name=pickText(raw,"series","series_name","seriesName","tournament","competition");
        if(name.isEmpty())name=pickText(m,"competition");
        if(!name.isEmpty())b.addView(statCard("Series",name,""));
        if(series.length()>0){
            JSONArray matches=pickArray(series,"matches","fixtures","games","results");
            if(matches.length()>0){renderProviderEvents(b,matches,"Series matches");}
            String detail=flattenProviderObject(series);if(!detail.isEmpty()&&!detail.equals(name))b.addView(eventRow(detail,1));
        }
    }

    private void renderProviderFootball(LinearLayout b,JSONObject m,String tab){JSONObject raw=rawProvider(m);b.addView(sectionLabel("Football Match Centre",m.optString("competition","")));if("OVERVIEW".equals(tab)||"LIVE".equals(tab)){providerTeamHeader(b,m);renderProviderMetrics(b,raw,new String[]{"possession","shots","shots_on_target","corners","fouls","offsides","passes","pass_accuracy","tackles","saves","xg"},"Match statistics");renderProviderEvents(b,pickArray(raw,"timeline","events","goals","cards","substitutions"),"Timeline");return;}if("STATS".equals(tab)){renderProviderMetrics(b,raw,new String[]{"possession","shots","shots_on_target","corners","fouls","offsides","passes","pass_accuracy","tackles","saves","xg"},"Statistics");return;}if("LINEUPS".equals(tab)){renderProviderPeople(b,pickArray(raw,"lineups","players","formations"),"Lineups");return;}if("TIMELINE".equals(tab)){renderProviderEvents(b,pickArray(raw,"timeline","events","goals","cards","substitutions"),"Timeline");return;}if("STANDINGS".equals(tab)){renderProviderTables(b,raw,new String[]{"standings","table"},"Standings");return;}renderProviderTables(b,raw,new String[]{"h2h","head_to_head","recent_meetings"},"Head to Head");}
    private void renderProviderBasketball(LinearLayout b,JSONObject m,String tab){JSONObject raw=rawProvider(m);b.addView(sectionLabel("Basketball Match Centre",m.optString("competition","")));if("OVERVIEW".equals(tab)||"LIVE".equals(tab)){providerTeamHeader(b,m);renderProviderMetrics(b,raw,new String[]{"quarter","quarters","game_clock","possession","team_fouls","timeouts","points","fg_percentage","three_point_percentage","free_throw_percentage","rebounds","assists","turnovers"},"Game state");renderProviderEvents(b,pickArray(raw,"play_by_play","playByPlay","events","timeline"),"Play-by-play");return;}if("BOX SCORE".equals(tab)){renderProviderTables(b,raw,new String[]{"box_score","boxScore","players"},"Box Score");return;}if("PLAY-BY-PLAY".equals(tab)){renderProviderEvents(b,pickArray(raw,"play_by_play","playByPlay","events","timeline"),"Play-by-play");return;}if("LINEUPS".equals(tab)){renderProviderPeople(b,pickArray(raw,"lineups","players"),"Lineups");return;}if("TEAM STATS".equals(tab)){renderProviderMetrics(b,raw,new String[]{"fg_percentage","three_point_percentage","free_throw_percentage","rebounds","offensive_rebounds","assists","turnovers","steals","blocks","team_fouls"},"Team statistics");return;}renderProviderTables(b,raw,new String[]{"standings","table"},"Standings");}
    private void renderProviderTennis(LinearLayout b,JSONObject m,String tab){JSONObject raw=rawProvider(m);b.addView(sectionLabel("Tennis Match Centre",m.optString("competition","")));if("OVERVIEW".equals(tab)||"LIVE".equals(tab)){providerTeamHeader(b,m);renderProviderMetrics(b,raw,new String[]{"set","sets","game","games","point","server","break_point","tiebreak","aces","double_faults","first_serve_percentage","first_serve_points_won","second_serve_points_won"},"Match state");renderProviderEvents(b,pickArray(raw,"point_by_point","pointByPoint","points","events"),"Point-by-point");return;}if("SCOREBOARD".equals(tab)){renderProviderTables(b,raw,new String[]{"scoreboard","sets","score"},"Scoreboard");return;}if("POINT-BY-POINT".equals(tab)){renderProviderEvents(b,pickArray(raw,"point_by_point","pointByPoint","points","events"),"Point-by-point");return;}if("STATS".equals(tab)){renderProviderMetrics(b,raw,new String[]{"aces","double_faults","first_serve_percentage","first_serve_points_won","second_serve_points_won","break_points","winners","unforced_errors","net_points","rally_length","serve_speed"},"Tennis statistics");return;}if("H2H".equals(tab)){renderProviderTables(b,raw,new String[]{"h2h","head_to_head","recent_meetings"},"Head to Head");return;}renderProviderTables(b,raw,new String[]{"draw","bracket"},"Draw");}
    private void renderProviderMetrics(LinearLayout b,JSONObject raw,String[] keys,String title){ArrayList<String[]> a=new ArrayList<>();for(String k:keys){String v=pickText(raw,k);if(!v.isEmpty())a.add(new String[]{prettyKey(k),v,""});}if(a.isEmpty()){providerUnavailable(b,title);return;}for(int i=0;i<a.size();i+=3){int end=Math.min(i+3,a.size());addStatGrid(b,a.subList(i,end).toArray(new String[0][]));}}
    private String prettyKey(String k){String x=k.replace('_',' ');return x.length()==0?x:x.substring(0,1).toUpperCase(Locale.US)+x.substring(1);}
    private void addProviderEvents(LinearLayout b, JSONArray a, String title) {
        renderProviderEvents(b, a, title);
    }
    private void renderProviderEvents(LinearLayout b,JSONArray a,String title){
        if(a==null||a.length()==0)return;
        ArrayList<String> rows=new ArrayList<>();
        for(int i=0;i<a.length();i++){
            Object v=a.opt(i);
            String text=v instanceof JSONObject?flattenProviderObject((JSONObject)v):String.valueOf(v);
            if(!text.isEmpty())rows.add(text);
        }
        if(rows.isEmpty())return;
        b.addView(sectionLabel(title,""));
        for(String text:rows)b.addView(eventRow(text,1));
    }
    private void renderProviderPeople(LinearLayout b,JSONArray a,String title){
        if(a==null||a.length()==0)return;
        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        appendProviderPlayerRows(list,a,0);
        if(list.getChildCount()==0)return;
        b.addView(sectionLabel(title,""));
        b.addView(list);
    }

    private void appendProviderPlayerRows(LinearLayout parent,JSONArray rows,int depth){
        if(rows==null||depth>5)return;
        for(int i=0;i<rows.length()&&i<150;i++){
            JSONObject x=rows.optJSONObject(i);
            if(x==null)continue;
            JSONArray children=null;
            for(String key:new String[]{"players","squad","roster","lineup","lineups","playing_xi",
                    "playingXI","playingXIPlayers","members","athletes"}){
                children=x.optJSONArray(key);
                if(children!=null&&children.length()>0)break;
                children=null;
            }
            if(children!=null){
                JSONObject t=x.optJSONObject("team");
                String group=playerDirectField(t,"name","teamName","team_name");
                if(group.isEmpty())group=playerDirectField(x,"team_name","teamName");
                if(group.isEmpty()&&x.opt("name") instanceof String)group=x.optString("name");
                if(!group.isEmpty())parent.addView(sectionLabel(group,""));
                appendProviderPlayerRows(parent,children,depth+1);
                continue;
            }
            String name=playerName(x);
            if(name.isEmpty())continue;
            String role=playerDirectField(x,"role","position","type","status");
            if(role.isEmpty())role=playerDirectField(nestedPlayer(x),"role","position");
            parent.addView(playerRow(playerPhoto(x),name,role,verifiedPlayerGender(x)),marginBottomParams(5));
        }
    }
    private void renderProviderTables(LinearLayout b,JSONObject raw,String[] keys,String title){
        JSONArray a=pickArray(raw,keys);
        if(a!=null&&a.length()>0){
            b.addView(sectionLabel(title,""));
            for(int i=0;i<a.length();i++){
                Object v=a.opt(i);
                String text=v instanceof JSONObject?flattenProviderObject((JSONObject)v):String.valueOf(v);
                if(!text.isEmpty())b.addView(eventRow(text,1));
            }
            return;
        }
        JSONObject o=pickObject(raw,keys);
        String text=flattenProviderObject(o);
        if(!text.isEmpty()){b.addView(sectionLabel(title,""));b.addView(eventRow(text,1));}
    }

    private String flattenProviderObject(JSONObject o){
        if(o==null)return "";
        StringBuilder b=new StringBuilder();
        appendFlatFields(b,o,0);
        return b.toString();
    }

    private void appendFlatFields(StringBuilder out,JSONObject o,int depth){
        if(o==null||depth>2)return;
        JSONArray names=o.names();
        if(names==null)return;
        for(int i=0;i<names.length();i++){
            String k=names.optString(i);
            Object v=o.opt(k);
            if(v==null)continue;
            if(v instanceof JSONObject){
                appendFlatFields(out,(JSONObject)v,depth+1);
                continue;
            }
            if(v instanceof JSONArray){
                JSONArray a=(JSONArray)v;
                for(int j=0;j<a.length() && j<4;j++){
                    Object item=a.opt(j);
                    if(item instanceof JSONObject) appendFlatFields(out,(JSONObject)item,depth+1);
                    else if(item!=null) appendFlatValue(out,k,String.valueOf(item));
                }
                continue;
            }
            String value=String.valueOf(v).trim();
            if(value.isEmpty() || "null".equalsIgnoreCase(value))continue;
            if(value.startsWith("http://")||value.startsWith("https://"))continue;
            appendFlatValue(out,k,value);
        }
    }

    private void appendFlatValue(StringBuilder out,String key,String value){
        if(out.length()>0)out.append(" • ");
        out.append(prettyKey(key)).append(": ").append(value);
    }

    private void addStatGrid(LinearLayout body,String[][] stats) {
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        for(String[] s:stats){
            LinearLayout c=new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setGravity(Gravity.CENTER);
            c.setPadding(dp(7),dp(8),dp(7),dp(8));
            c.setBackground(round(CARD,11));
            c.addView(tv(s[0],9,MUTED,true));
            c.addView(tv(s[1],14,TEXT,true));
            c.addView(tv(s[2],8.5f,MUTED,false));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(72),1);
            cp.setMargins(dp(2),0,dp(2),0);
            row.addView(c,cp);
        }
        body.addView(row,marginBottomParams(8));
    }

    private View statPairCard(String title,String value,String sub) {
        return statCard(title,value,sub);
    }

    private LinearLayout scoreboardCard(String teamName,String score,String state,String sub) {
        LinearLayout c=new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(13),dp(11),dp(13),dp(11));
        c.setBackground(round(CARD,14));
        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(tv(teamName,11,MUTED,true),new LinearLayout.LayoutParams(0,-2,1));
        top.addView(tv(state,10,CYAN,true));
        c.addView(top);
        c.addView(tv(score,25,TEXT,true));
        c.addView(tv(sub,9,MUTED,false));
        c.setLayoutParams(marginBottomParams(8));
        return c;
    }

    private LinearLayout playerRow(String avatarUrl,String name,String role,String gender) {
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(10),dp(12),dp(10));row.setBackground(round(CARD,14));
        ImageView avatar=new ImageView(this);avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);avatar.setBackground(circleDrawable(CARD_2));avatar.setClipToOutline(true);
        String normalizedGender=normalizePlayerGender(gender);
        // Always paint a deterministic fallback first. If the provider image loads successfully,
        // loadPlayerAvatar() replaces it. If the URL is invalid or unavailable, the fallback remains visible.
        avatar.setImageDrawable(playerGenderAvatar(name,normalizedGender));
        if(isValidProviderImageUrl(avatarUrl)) loadPlayerAvatar(avatar,avatarUrl.trim(),name);
        row.addView(avatar,new LinearLayout.LayoutParams(dp(50),dp(50)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(12),0,0,0);
        info.addView(tv(name,12.5f,TEXT,true)); if(role!=null&&!role.trim().isEmpty())info.addView(tv(role,9.5f,MUTED,false));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        return row;
    }

    private String normalizePlayerGender(String value){
        String g=value==null?"":value.trim().toLowerCase(Locale.US);
        if(g.equals("m")||g.equals("male")||g.equals("man")||g.equals("men"))return "male";
        if(g.equals("f")||g.equals("female")||g.equals("woman")||g.equals("women"))return "female";
        return ""; // Never guess gender using name, image, or numeric API codes.
    }

    private android.graphics.drawable.Drawable playerGenderAvatar(String name,String gender){
        final String verified=normalizePlayerGender(gender);
        int accent="female".equals(verified)?Color.rgb(137,92,221):
                "male".equals(verified)?Color.rgb(34,146,255):Color.rgb(46,172,191);
        return premiumInitialsAvatar(name,accent,true);
    }

    private android.graphics.drawable.Drawable premiumInitialsAvatar(String name,int accent,boolean ring){
        int size=160;
        android.graphics.Bitmap bitmap=android.graphics.Bitmap.createBitmap(size,size,android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas canvas=new android.graphics.Canvas(bitmap);
        android.graphics.Paint fill=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        fill.setColor(Color.rgb(14,28,52));
        canvas.drawCircle(size/2f,size/2f,74,fill);
        android.graphics.Paint glow=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        glow.setColor(Color.argb(154,Color.red(accent),Color.green(accent),Color.blue(accent)));
        canvas.drawCircle(size/2f,size/2f,61,glow);
        if(ring){
            android.graphics.Paint edge=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            edge.setStyle(android.graphics.Paint.Style.STROKE);
            edge.setStrokeWidth(4f);
            edge.setColor(Color.argb(105,255,255,255));
            canvas.drawCircle(size/2f,size/2f,73,edge);
        }
        String initials="";
        if(name!=null){
            for(String part:name.trim().split("\\s+")){
                if(!part.isEmpty())initials+=part.substring(0,1).toUpperCase(Locale.US);
                if(initials.length()>=2)break;
            }
        }
        if(initials.isEmpty())initials="•";
        android.graphics.Paint textPaint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextAlign(android.graphics.Paint.Align.CENTER);
        textPaint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        textPaint.setTextSize(initials.length()>1?52:60);
        android.graphics.Paint.FontMetrics fm=textPaint.getFontMetrics();
        float y=size/2f-(fm.ascent+fm.descent)/2f;
        canvas.drawText(initials,size/2f,y,textPaint);
        return new android.graphics.drawable.BitmapDrawable(getResources(),bitmap);
    }

    private ImageView identityView(JSONObject entity,int sizeDp){
        ImageView image=new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setPadding(dp(1),dp(1),dp(1),dp(1));
        image.setBackgroundColor(Color.TRANSPARENT);
        // Do not clip non-circular team crests or rectangular national flags.
        image.setClipToOutline(false);
        String logo=pickText(entity,"logo","logo_url","image","image_url","badge","crest","team_logo","teamLogo","logoUrl","logoURL");
        String flag=pickText(entity,"flag","country_flag","countryCode","country_code","countryCode2","country_iso","countryIso","iso2");
        if(flag.isEmpty()){
            JSONObject country=pickObject(entity,"country","nation","nationality");
            flag=pickText(country,"code","iso2","countryCode","country_code","flag");
        }
        String name=pickText(entity,"name","team_name","short_name","shortName","teamName","player_name","full_name");
        if(flag.isEmpty())flag=nationalFlagIso(name);
        // Initial/monogram is the deterministic default. A provider asset replaces it only
        // after a valid provider image/flag is actually available. This prevents blank identities.
        image.setImageDrawable(teamMonogramDrawable(name));
        logo=firstPartySportsMediaUrl(logo);
        if(!logo.isEmpty()){
            image.setBackgroundColor(Color.TRANSPARENT);
            image.setClipToOutline(false);
            loadImage(image,logo,sizeDp);
        } else if(!flag.isEmpty() && !"_".equals(flag.trim())) {
            String f=flag.trim();
            if(f.length()==2 && f.matches("[A-Za-z]{2}")) f=countryFlagEmoji(f);
            image.setImageDrawable(flagDrawable(f,Math.max(18,sizeDp/2)));
        }
        image.setContentDescription(name);
        return image;
    }


    private String nationalFlagIso(String name){
        String key=(name==null?"":name.trim().toLowerCase(Locale.US));
        key=key.replaceAll("(?i) +(u-?19|u 19|under-?19|under 19|women|men|national cricket team)$","").trim();
        switch(key){
            case "bangladesh":return "BD";
            case "india":return "IN";
            case "pakistan":return "PK";
            case "australia":return "AU";
            case "england":return "GB";
            case "new zealand":return "NZ";
            case "sri lanka":return "LK";
            case "south africa":return "ZA";
            case "nepal":return "NP";
            case "afghanistan":return "AF";
            case "zimbabwe":return "ZW";
            case "ireland":return "IE";
            case "united states":case "usa":return "US";
            case "canada":return "CA";
            case "netherlands":return "NL";
            case "scotland":return "GB";
            case "uae":case "united arab emirates":return "AE";
            case "oman":return "OM";
            case "namibia":return "NA";
            case "uganda":return "UG";
            default:return "";
        }
    }

    private android.graphics.drawable.Drawable flagDrawable(String text,int sp){
        int w=150,h=96;
        android.graphics.Bitmap bm=android.graphics.Bitmap.createBitmap(w,h,android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c=new android.graphics.Canvas(bm);
        android.graphics.Paint bg=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        bg.setColor(Color.argb(24,255,255,255));
        c.drawRoundRect(2,2,w-2,h-2,10,10,bg);
        android.graphics.Paint p=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE); p.setTextSize(sp*2.0f); p.setTextAlign(android.graphics.Paint.Align.CENTER);
        p.setTypeface(android.graphics.Typeface.DEFAULT);
        android.graphics.Paint.FontMetrics fm=p.getFontMetrics();
        float y=h/2f-(fm.ascent+fm.descent)/2f;
        c.drawText(text,w/2f,y,p);
        return new android.graphics.drawable.BitmapDrawable(getResources(),bm);
    }

    private android.graphics.drawable.Drawable teamMonogramDrawable(String name){
        String[] parts=String.valueOf(name==null?"":name).trim().split("\\s+");
        String mon="";
        for(String part:parts){ if(!part.isEmpty()){ mon+=part.substring(0,1).toUpperCase(Locale.US); if(mon.length()>=2) break; }}
        if(mon.isEmpty()) mon="?";
        int size=120;
        android.graphics.Bitmap bm=android.graphics.Bitmap.createBitmap(size,size,android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c=new android.graphics.Canvas(bm);
        android.graphics.Paint bg=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG); bg.setColor(CARD_2); c.drawCircle(60,60,56,bg);
        android.graphics.Paint p=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG); p.setColor(TEXT); p.setTextSize(42); p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); p.setTextAlign(android.graphics.Paint.Align.CENTER);
        android.graphics.Paint.FontMetrics fm=p.getFontMetrics(); float y=60-(fm.ascent+fm.descent)/2; c.drawText(mon,60,y,p);
        return new android.graphics.drawable.BitmapDrawable(getResources(),bm);
    }

    private android.graphics.drawable.Drawable textDrawable(String text,int sp,int color,boolean bold){
        android.graphics.Bitmap bm=android.graphics.Bitmap.createBitmap(120,120,android.graphics.Bitmap.Config.ARGB_8888);android.graphics.Canvas c=new android.graphics.Canvas(bm);
        android.graphics.Paint p=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);p.setColor(Color.argb(38,255,255,255));c.drawCircle(60,60,58,p);p.setColor(color);p.setTextSize(sp*2.1f);p.setTypeface(bold?android.graphics.Typeface.DEFAULT_BOLD:android.graphics.Typeface.DEFAULT);p.setTextAlign(android.graphics.Paint.Align.CENTER);android.graphics.Paint.FontMetrics fm=p.getFontMetrics();float y=60-(fm.ascent+fm.descent)/2;c.drawText(text,60,y,p);return new android.graphics.drawable.BitmapDrawable(getResources(),bm);
    }

    private String countryFlagEmoji(String code){String c=code.toUpperCase(Locale.US); if(c.length()!=2)return c; return new String(Character.toChars(0x1F1E6+c.charAt(0)-'A'))+new String(Character.toChars(0x1F1E6+c.charAt(1)-'A'));}

    private void loadImage(ImageView target,String imageUrl,int sizeDp){
        String safeUrl=firstPartySportsMediaUrl(imageUrl);
        if(safeUrl.isEmpty())return;
        network.execute(()->{
            android.graphics.Bitmap bitmap=null;
            HttpURLConnection c=null;
            try{
                URL u=new URL(safeUrl);
                c=(HttpURLConnection)u.openConnection();
                c.setConnectTimeout(5000);
                c.setReadTimeout(7000);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent","ONE-TV/2.4");
                c.connect();
                if(c.getResponseCode()>=200&&c.getResponseCode()<300){
                    try(InputStream in=c.getInputStream()){bitmap=android.graphics.BitmapFactory.decodeStream(in);}
                }
            }catch(Exception ignored){}finally{if(c!=null)c.disconnect();}
            if(bitmap==null) return;
            final android.graphics.Bitmap source=bitmap;
            final int canvasPx=Math.max(1,dp(sizeDp));
            final int maxPx=Math.max(1,Math.round(canvasPx*0.95f));
            // Normalize the ACTUAL visible artwork (trim transparent margins), not
            // just provider image dimensions. This keeps flag/logo sizes balanced.
            android.graphics.Rect visible=logoVisibleBounds(source);
            final float scale=Math.min((float)maxPx/Math.max(1,visible.width()),
                    (float)maxPx/Math.max(1,visible.height()));
            final int dw=Math.max(1,Math.round(visible.width()*scale));
            final int dh=Math.max(1,Math.round(visible.height()*scale));
            final android.graphics.Bitmap normalized=android.graphics.Bitmap.createBitmap(canvasPx,canvasPx,android.graphics.Bitmap.Config.ARGB_8888);
            android.graphics.Canvas canvas=new android.graphics.Canvas(normalized);
            android.graphics.Paint paint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG|android.graphics.Paint.FILTER_BITMAP_FLAG);
            float left=(canvasPx-dw)/2f, top=(canvasPx-dh)/2f;
            canvas.drawBitmap(source,visible,new android.graphics.RectF(left,top,left+dw,top+dh),paint);
            runOnUiThread(()->{target.setImageBitmap(normalized);target.setBackgroundColor(Color.TRANSPARENT);target.setClipToOutline(false);});
        });
    }

    private android.graphics.Rect logoVisibleBounds(android.graphics.Bitmap image) {
        int width=image.getWidth(),height=image.getHeight();
        if(width<=1||height<=1)return new android.graphics.Rect(0,0,width,height);
        int step=Math.max(1,Math.max(width,height)/350);
        int minX=width,minY=height,maxX=-1,maxY=-1;
        // A PNG may have an alpha channel even when every pixel is opaque.
        // Detect truly transparent corners instead of trusting hasAlpha().
        boolean transparentEdge=false;
        if(image.hasAlpha()){
            int[] edge={image.getPixel(0,0),image.getPixel(width-1,0),
                    image.getPixel(0,height-1),image.getPixel(width-1,height-1)};
            for(int c:edge)if(Color.alpha(c)<230){transparentEdge=true;break;}
        }
        if(transparentEdge){
            for(int y=0;y<height;y+=step){
                for(int x=0;x<width;x+=step){
                    if((image.getPixel(x,y)>>>24)>30){
                        minX=Math.min(minX,x);minY=Math.min(minY,y);
                        maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);
                    }
                }
            }
        } else {
            // Many source PNGs bake a large off-white border into the pixels.
            // Only crop this when image is near-square and 4 corners are uniform
            // off-white. Landscape national flags must preserve their field.
            float aspect=(float)width/height;
            if(aspect<.84f||aspect>1.18f)return new android.graphics.Rect(0,0,width,height);
            int[] corners={image.getPixel(0,0),image.getPixel(width-1,0),
                    image.getPixel(0,height-1),image.getPixel(width-1,height-1)};
            for(int c:corners){
                if(Color.red(c)<236||Color.green(c)<236||Color.blue(c)<236)
                    return new android.graphics.Rect(0,0,width,height);
            }
            for(int y=0;y<height;y+=step){
                for(int x=0;x<width;x+=step){
                    int c=image.getPixel(x,y);
                    // White/off-white background is ignored; coloured/outlined
                    // artwork and dark text remain as visible emblem bounds.
                    if(Color.red(c)<225||Color.green(c)<225||Color.blue(c)<225){
                        minX=Math.min(minX,x);minY=Math.min(minY,y);
                        maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);
                    }
                }
            }
            // Do not crop away a genuine white border when the marks already
            // occupy almost the whole frame.
            if(maxX>=minX && maxY>=minY &&
                    (minX<width*.055f||minY<height*.055f||
                     maxX>width*.945f||maxY>height*.945f))
                return new android.graphics.Rect(0,0,width,height);
        }
        if(maxX<minX||maxY<minY)return new android.graphics.Rect(0,0,width,height);
        int padding=Math.max(1,Math.round(Math.min(width,height)*.035f));
        return new android.graphics.Rect(Math.max(0,minX-padding),Math.max(0,minY-padding),
                Math.min(width,maxX+padding+step+1),Math.min(height,maxY+padding+step+1));
    }

    private GradientDrawable circleDrawable(int color){
        GradientDrawable d=new GradientDrawable(); d.setShape(GradientDrawable.OVAL); d.setColor(color); return d;
    }

    private GradientDrawable searchButtonBackground(){
        GradientDrawable d=new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(Color.argb(darkTheme()?34:22,255,255,255));
        d.setStroke(dp(1), Color.argb(darkTheme()?70:48,255,255,255));
        return d;
    }

    private android.graphics.drawable.Drawable initialsAvatar(String name){
        int size=96;
        android.graphics.Bitmap bm=android.graphics.Bitmap.createBitmap(size,size,android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas canvas=new android.graphics.Canvas(bm);
        android.graphics.Paint bgPaint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        bgPaint.setColor(BLUE); canvas.drawCircle(size/2f,size/2f,size/2f,bgPaint);
        String initials="";
        if(name!=null){String[] parts=name.trim().split("\\s+");for(String part:parts){if(!part.isEmpty()) initials+=part.substring(0,1).toUpperCase(Locale.US);if(initials.length()>=2)break;}}
        if(initials.isEmpty()) initials="•";
        android.graphics.Paint textPaint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.WHITE); textPaint.setTextSize(34); textPaint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); textPaint.setTextAlign(android.graphics.Paint.Align.CENTER);
        android.graphics.Paint.FontMetrics fm=textPaint.getFontMetrics();
        float y=size/2f-(fm.ascent+fm.descent)/2f; canvas.drawText(initials,size/2f,y,textPaint);
        return new android.graphics.drawable.BitmapDrawable(getResources(),bm);
    }

    private void loadPlayerAvatar(ImageView target,String imageUrl,String playerName){
        String safeUrl=firstPartySportsMediaUrl(imageUrl);
        if(safeUrl.isEmpty())return;
        target.setTag(safeUrl);
        network.execute(()->{
            android.graphics.Bitmap bitmap=null;
            HttpURLConnection c=null;
            try{
                URL u=new URL(safeUrl); c=(HttpURLConnection)u.openConnection();
                c.setConnectTimeout(5000); c.setReadTimeout(7000); c.setInstanceFollowRedirects(false);
                c.setRequestProperty("Accept","image/jpeg,image/png,image/webp");
                c.setRequestProperty("User-Agent","ONE-TV/2.2"); c.connect();
                if(c.getResponseCode()>=200 && c.getResponseCode()<300){
                    try(InputStream in=c.getInputStream()){bitmap=android.graphics.BitmapFactory.decodeStream(in);}
                }
            }catch(Exception ignored){} finally {if(c!=null)c.disconnect();}
            android.graphics.Bitmap result=bitmap;
            if(result!=null) runOnUiThread(()->{
                if(safeUrl.equals(target.getTag()) && target.getParent()!=null){
                    target.setImageBitmap(result);target.setBackground(circleDrawable(Color.TRANSPARENT));
                }
            });
        });
    }

    private void showNews(boolean push) {
        stopMatchDetailAutoRefresh();stopSportsAutoRefresh();entertainmentContext=false;
        if(push)push("news");
        screen="news";clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar("News",false));
        TextView intro=tv("Breaking • National • International",10.5f,MUTED,false);
        intro.setPadding(dp(18),0,dp(18),dp(9));page.addView(intro);
        HorizontalScrollView scroll=new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs=new LinearLayout(this);
        tabs.setPadding(dp(10),0,dp(10),dp(8));
        for(String category:new String[]{"All","Breaking","Bangladesh","World","Business","Technology","Sports","Entertainment"}) {
            TextView t=tab(category,selectedNewsCategory.equals(category));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(category.length()>11?112:95),dp(37));
            p.setMargins(dp(3),0,dp(3),0);tabs.addView(t,p);
            t.setOnClickListener(v->{selectedNewsCategory=category;showNews(false);});
        }
        scroll.addView(tabs);page.addView(scroll);
        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12),0,dp(12),dp(18));
        page.addView(list);addScroll(page);
        list.addView(homeSmallState("Loading verified news…"));
        loadNews(list);
    }

    private void loadNews(LinearLayout list) {
        if(BACKEND_URL==null || BACKEND_URL.contains("REPLACE") || !remoteDataEnabled){
            list.removeAllViews();list.addView(emptyStateCard("News unavailable","Connect a verified news backend."));return;
        }
        final String currentCategory=selectedNewsCategory;
        network.execute(()->{
            try {
                JSONObject response=new JSONObject(getUrl(BACKEND_URL+"/news?limit=50"));
                JSONArray a=response.optJSONArray("items");
                runOnUiThread(()->{
                    if(!"news".equals(screen) || !currentCategory.equals(selectedNewsCategory))return;
                    list.removeAllViews();int count=0;
                    if(a!=null)for(int i=0;i<a.length();i++){
                        JSONObject item=a.optJSONObject(i);
                        if(item==null || !newsMatchesCategory(item,currentCategory))continue;
                        list.addView(newsCard(item),marginBottomParams(9));count++;
                    }
                    if(count==0)list.addView(emptyStateCard("No verified articles", "No eligible "+currentCategory.toLowerCase(Locale.US)+" stories are available."));
                });
            }catch(Exception e){runOnUiThread(()->{
                if(!"news".equals(screen))return;
                list.removeAllViews();list.addView(emptyStateCard("News unavailable","Retry after connectivity is restored."));
            });}
        });
    }


    private View newsCard(JSONObject x) {
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(15),dp(13),dp(15),dp(13)); card.setBackground(round(CARD,17));
        LinearLayout meta=new LinearLayout(this); meta.setGravity(Gravity.CENTER_VERTICAL);
        TextView cat=tv(x.optString("category","News"),9.5f,CYAN,true); meta.addView(cat,new LinearLayout.LayoutParams(0,-2,1));
        String source=x.optString("source_name",""); if(!source.isEmpty())meta.addView(tv(source,8.5f,MUTED,false)); card.addView(meta);
        String imageUrl=x.optString("image_url", "");
        if (isValidProviderImageUrl(imageUrl)) {
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackground(round(CARD_2, 10));
            LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(-1, dp(154));
            imageParams.topMargin = dp(8);
            card.addView(image, imageParams);
            loadProviderPhoto(image, imageUrl);
        }
        TextView h=tv(x.optString("headline","News"),15.5f,TEXT,true);h.setPadding(0,dp(6),0,dp(4));h.setMaxLines(3);card.addView(h);
        String summary=x.optString("summary","");if(!summary.isEmpty()){TextView sm=tv(summary,10.5f,MUTED,false);sm.setMaxLines(4);card.addView(sm);}
        String published=x.optString("published_at","");if(!published.isEmpty()){TextView p=tv("Published • "+formatNewsTime(published),8.5f,MUTED,false);p.setPadding(0,dp(7),0,0);card.addView(p);}
        card.setOnClickListener(v->openNewsDetail(x)); return card;
    }

    private String formatNewsTime(String raw){try{java.text.SimpleDateFormat in=new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX",Locale.US);java.util.Date d=in.parse(raw);if(d!=null){java.text.SimpleDateFormat out=new java.text.SimpleDateFormat("d MMM • h:mm a",Locale.US);out.setTimeZone(java.util.TimeZone.getDefault());return out.format(d);}}catch(Exception ignored){}return raw.replace('T',' ');}

    private void openNewsDetail(JSONObject x){
        if(x==null)return; lastOpenedNews=x; rememberOpenedItem("News",x.optString("headline",""), x.optString("id","")); push("newsDetail:"+x.optString("id","")); screen="newsDetail"; clearContent(); LinearLayout page=page(); page.addView(selectedSectionBar("News",false));
        TextView cat=tv(x.optString("category","News"),10,CYAN,true);cat.setPadding(dp(18),dp(5),dp(18),dp(4));page.addView(cat);
        String articleImage=x.optString("image_url", "");
        if (isValidProviderImageUrl(articleImage)) {
            ImageView photo=new ImageView(this); photo.setScaleType(ImageView.ScaleType.CENTER_CROP); photo.setBackground(round(CARD_2,12));
            LinearLayout.LayoutParams photoParams=new LinearLayout.LayoutParams(-1,dp(210)); photoParams.setMargins(dp(14),dp(4),dp(14),dp(10));
            page.addView(photo,photoParams); loadProviderPhoto(photo,articleImage);
        }
        TextView h=tv(x.optString("headline","News"),22,TEXT,true);h.setPadding(dp(18),dp(3),dp(18),dp(8));page.addView(h);
        TextView src=tv("Source: "+x.optString("source_name",""),9,MUTED,false);src.setPadding(dp(18),0,dp(18),dp(10));page.addView(src);
        TextView body=tv(x.optString("body",x.optString("summary","")),11.5f,TEXT,false);body.setLineSpacing(dp(3),1.0f);body.setPadding(dp(18),0,dp(18),dp(10));page.addView(body);
        TextView sourceUrl=tv("Original source: "+x.optString("source_url",""),8.5f,MUTED,false);sourceUrl.setPadding(dp(18),dp(7),dp(18),dp(14));sourceUrl.setMaxLines(2);sourceUrl.setEllipsize(android.text.TextUtils.TruncateAt.END);page.addView(sourceUrl);
        final String canonical=x.optString("source_url", "");
        if(isValidProviderImageUrl(canonical))page.addView(menuAction("↗","Read at source","Open the original publisher",v->openExternalSource(canonical)));
        addScroll(page);
    }

    private void showEntertainment(String category, boolean push) {
        entertainmentContext = true;
        if(push) push("ent:" + category);
        if(!"Explore".equals(category) && !"Entertainment".equals(category) && !"Photos".equals(category)) {
            showEntertainmentCollection(category,false);
            return;
        }
        screen="entertainment";
        selectedEntertainment="Explore";
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar("Entertainment",true));
        TextView subtitle=tv("Movies • TV & Series • Music • More",10,MUTED,false);
        subtitle.setPadding(dp(18),0,0,dp(10));page.addView(subtitle);
        String[] labels={"Movies","TV & Series","Music","Celebrity","Trending","Live Events"};
        String[] icons={"◉","▣","♫","★","✦","◌"};
        int[][] gradients={
                {Color.rgb(0,70,149),Color.rgb(23,18,80)},
                {Color.rgb(48,31,174),Color.rgb(17,38,87)},
                {Color.rgb(123,17,122),Color.rgb(43,23,91)},
                {Color.rgb(99,20,78),Color.rgb(34,13,72)},
                {Color.rgb(149,40,55),Color.rgb(68,20,70)},
                {Color.rgb(12,67,106),Color.rgb(22,30,90)}
        };
        for(int row=0;row<2;row++) {
            LinearLayout columns=new LinearLayout(this);
            columns.setPadding(dp(10),dp(2),dp(10),dp(5));
            for(int col=0;col<3;col++) {
                final int index=row*3+col;
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(87),1);
                lp.setMargins(dp(4),0,dp(4),0);
                columns.addView(entertainmentTile(icons[index],labels[index],gradients[index],
                        v->showEntertainmentCollection(labels[index],true)),lp);
            }
            page.addView(columns);
        }
        page.addView(sectionLabel("Photo Stories","Verified artwork from licensed providers"));
        LinearLayout photoEntry=menuAction("▣","Photo Stories","Browse authorized editorial photos",
                v->showEntertainmentPhotos(true));
        page.addView(photoEntry);
        page.addView(sectionLabel("Popular on OneTV","Based on available rights-cleared provider content"));
        LinearLayout trending=new LinearLayout(this);
        trending.setOrientation(LinearLayout.VERTICAL);
        trending.setPadding(dp(12),0,dp(12),dp(15));
        trending.addView(homeSmallState("Checking provider content…"));
        page.addView(trending);
        addScroll(page);
        loadEntertainmentTrending(trending);
    }


    /** Photo-only discovery. Images are shown only when the licensed news provider supplies a real image URL. */
    private void buildPhotoFront(LinearLayout page) {
        page.addView(sectionLabel("Photo Stories", "Provider-sourced editorial photography"));
        TextView note = tv("Only source-linked images are displayed. Unavailable images are omitted, never substituted.", 9.5f, MUTED, false);
        note.setPadding(dp(16), 0, dp(16), dp(10));
        page.addView(note);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), 0, dp(12), dp(18));
        page.addView(list);
        addScroll(page);
        if (BACKEND_URL == null || BACKEND_URL.contains("REPLACE") || !remoteDataEnabled) {
            list.addView(emptyStateCard("Photo stories unavailable", "Connect the licensed content provider to load real editorial images."));
            return;
        }
        network.execute(() -> {
            try {
                JSONObject response = new JSONObject(getUrl(BACKEND_URL + "/media?type=photo&limit=40"));
                JSONArray items = response.optJSONArray("items");
                runOnUiThread(() -> {
                    list.removeAllViews();
                    int shown = 0;
                    if (items != null) for (int i = 0; i < items.length(); i++) {
                        JSONObject item = items.optJSONObject(i);
                        if (item == null || !isValidProviderImageUrl(item.optString("media_url", ""))) continue;
                        list.addView(authorizedMediaPhotoCard(item), marginBottomParams(10));
                        shown++;
                    }
                    if (shown == 0) list.addView(emptyStateCard("No verified photos available", "The configured provider has not supplied publishable images for current stories."));
                });
            } catch (Exception e) {
                runOnUiThread(() -> { list.removeAllViews(); list.addView(emptyStateCard("Photo stories unavailable", "The content provider could not be reached.")); });
            }
        });
    }

    private View authorizedMediaPhotoCard(JSONObject item) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(12));
        card.setBackground(round(CARD, 16));
        ImageView photo = new ImageView(this);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photo.setBackground(round(CARD_2, 12));
        card.addView(photo, new LinearLayout.LayoutParams(-1, dp(178)));
        loadProviderPhoto(photo, item.optString("media_url", ""));
        TextView category = tv(item.optString("category", "Photo Story"), 9.5f, CYAN, true);
        category.setPadding(dp(2), dp(9), dp(2), dp(2));
        card.addView(category);
        TextView headline = tv(item.optString("title", ""), 15.5f, TEXT, true);
        headline.setPadding(dp(2), dp(2), dp(2), dp(4));
        card.addView(headline);
        String source = item.optString("source_name", "");
        if (!source.isEmpty()) card.addView(tv("Source: " + source, 8.5f, MUTED, false));
        String description = item.optString("description", "");
        if (!description.isEmpty()) card.addView(tv(description, 10f, MUTED, false));
        return card;
    }

    private boolean isValidProviderImageUrl(String value) {
        try {
            Uri uri = Uri.parse(value == null ? "" : value.trim());
            return "https".equalsIgnoreCase(uri.getScheme())
                    && !android.text.TextUtils.isEmpty(uri.getHost())
                    && android.text.TextUtils.isEmpty(uri.getUserInfo());
        } catch (Exception ignored) { return false; }
    }

    private View photoStoryCard(JSONObject item) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(12));
        card.setBackground(round(CARD, 16));
        ImageView photo = new ImageView(this);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photo.setBackground(round(CARD_2, 12));
        card.addView(photo, new LinearLayout.LayoutParams(-1, dp(178)));
        loadProviderPhoto(photo, item.optString("image_url", ""));
        TextView category = tv(item.optString("category", "Photo Story"), 9.5f, CYAN, true);
        category.setPadding(dp(2), dp(9), dp(2), dp(2));
        card.addView(category);
        TextView headline = tv(item.optString("headline", ""), 15.5f, TEXT, true);
        headline.setPadding(dp(2), dp(2), dp(2), dp(4));
        card.addView(headline);
        String source = item.optString("source_name", "");
        if (!source.isEmpty()) card.addView(tv("Photo source: " + source, 8.5f, MUTED, false));
        card.setOnClickListener(v -> openNewsDetail(item));
        return card;
    }

    private void loadProviderPhoto(ImageView target, String imageUrl) {
        if (!isValidProviderImageUrl(imageUrl)) return;
        network.execute(() -> {
            android.graphics.Bitmap bitmap = null;
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(imageUrl).openConnection();
                connection.setConnectTimeout(6000);
                connection.setReadTimeout(8000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("Accept", "image/*");
                connection.setRequestProperty("User-Agent", "OneTV/2.5.7");
                connection.connect();
                String type = connection.getContentType();
                if (connection.getResponseCode() >= 200 && connection.getResponseCode() < 300 && type != null && type.toLowerCase(Locale.US).startsWith("image/")) {
                    try (InputStream input = connection.getInputStream()) { bitmap = android.graphics.BitmapFactory.decodeStream(input); }
                }
            } catch (Exception ignored) { } finally { if (connection != null) connection.disconnect(); }
            android.graphics.Bitmap result = bitmap;
            if (result != null) runOnUiThread(() -> target.setImageBitmap(result));
        });
    }

    private void buildTvFront(LinearLayout page) {
        page.addView(sectionLabel("TV Channels", "Live channels"));
        LinearLayout list=new LinearLayout(this);
        list.setPadding(dp(12),0,dp(12),dp(12));
        list.setOrientation(LinearLayout.VERTICAL);
        if(!channels.isEmpty()){
            for(Channel c:channels){
                LinearLayout row=channelListRow(c);
                row.setOnClickListener(v->openChannel(c));
                list.addView(row, marginBottomParams(7));
            }
        }
        page.addView(list);
        addScroll(page);
    }

    private LinearLayout channelListRow(Channel c){
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(13),dp(10),dp(13),dp(10));
        row.setBackground(round(CARD,14));
        TextView icon=tv("📺",22,TEXT,false);
        row.addView(icon,new LinearLayout.LayoutParams(dp(46),dp(46)));
        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
        info.addView(tv(c.name,14,TEXT,true));
        String state=c.connected?"CONNECTED":"COMING SOON";
        info.addView(tv((c.program==null||c.program.isEmpty()?c.category:c.program)+" • "+state,10,c.connected?GREEN:MUTED,false));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(tv("›",24,MUTED,false));
        return row;
    }

    private void openChannel(Channel c){
        showSimple("Video sections unavailable", "OneTV is currently configured for sports data, news and provider-sourced photo content. Video playback sections have been removed from this app build.");
    }

    private void showComingSoon(Channel c){
        push("comingSoon"); clearContent(); screen="comingSoon";
        LinearLayout page=page();
        page.addView(selectedSectionBar(c.name,true));
        page.addView(sectionLabel("Coming soon","This channel is being prepared for playback."));
        page.addView(statCard("Channel status","COMING SOON", "Playback will be available when the channel is connected."));
        page.addView(detailRow("Category", c.category));
        page.addView(detailRow("Country", c.country));
        addScroll(page);
    }

    private void buildMediaFront(LinearLayout page,String type) {
        page.addView(sectionLabel(type,"Entertainment"));
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(12),0,dp(12),dp(18));
        boolean found=false;
        for(Channel c:channels){ if(type.equalsIgnoreCase(c.category)){ LinearLayout row=channelListRow(c); row.setOnClickListener(v->openChannel(c)); list.addView(row,marginBottomParams(7)); found=true; } }
        page.addView(list); addScroll(page);
    }

    private LinearLayout heroBanner(String title,String sub,String action,int accent) {
        LinearLayout h=new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);
        h.setPadding(dp(16),dp(15),dp(16),dp(15));
        h.setBackground(round(Color.rgb(24,34,55),17));
        TextView a=tv(title,19,TEXT,true);
        TextView b=tv(sub,11,MUTED,false);
        Button c=smallButton(action,accent);
        h.addView(a);h.addView(b);h.addView(c,new LinearLayout.LayoutParams(-2,dp(36)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(12),dp(8),dp(12),dp(10));h.setLayoutParams(p);
        return h;
    }

    private FrameLayout buildPlayerFrame(boolean live) {
        FrameLayout frame=new FrameLayout(this);
        frame.setBackgroundColor(Color.BLACK);
        playerFrame=frame;

        playerView=new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerShowTimeoutMs(3500);
        playerView.setControllerHideOnTouch(false);
        playerView.setControllerAutoShow(true);
        playerView.setShowRewindButton(false);
        playerView.setShowFastForwardButton(false);
        playerView.setShowPreviousButton(false);
        playerView.setShowNextButton(false);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        frame.addView(playerView,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout overlay=new LinearLayout(this);
        overlay.setGravity(Gravity.CENTER_VERTICAL);
        overlay.setPadding(dp(8),dp(8),dp(8),dp(8));
        overlay.setBackgroundColor(Color.argb(92,0,0,0));

        TextView play=playerButton("▶");
        TextView speed=playerButton("1x");
        TextView quality=playerButton("Auto");
        TextView volume=playerButton("🔊");
        TextView full=playerButton("⛶");
        overlay.addView(play,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(speed,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(quality,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(volume,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(full,new LinearLayout.LayoutParams(0,dp(44),1));
        FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(-1,dp(60),Gravity.BOTTOM);
        frame.addView(overlay,op);

        final float[] speedValue={1f};
        final boolean[] muted={false};
        final long[] lastTap={0L};
        final float[] tapX={0f};

        play.setOnClickListener(v->{
            if(player!=null){
                if(player.isPlaying()){player.pause();play.setText("▶");}
                else{player.play();play.setText("Ⅱ");}
            }
            showPlayerControls(overlay);
        });
        speed.setOnClickListener(v->{
            speedValue[0]+=0.25f; if(speedValue[0]>2f)speedValue[0]=0.75f;
            if(player!=null)player.setPlaybackParameters(new PlaybackParameters(speedValue[0]));
            speed.setText(String.format(Locale.US,"%.2gx",speedValue[0])); showPlayerControls(overlay);
        });
        quality.setOnClickListener(v->{
            quality.setText("Auto");
            android.widget.Toast.makeText(this, "Only source-provided quality levels can be selected", android.widget.Toast.LENGTH_SHORT).show();
            showPlayerControls(overlay);
        });
        volume.setOnClickListener(v->{
            if(muted[0]){
                muted[0]=false; if(player!=null)player.setVolume(1f); volume.setText("🔊");
                showVolumeSlider(frame, volume, player); return;
            }
            if(volumePopupVisible){
                muted[0]=true; if(player!=null)player.setVolume(0f); volume.setText("🔇"); hideVolumeSlider();
            }else{
                showVolumeSlider(frame, volume, player);
            }
            showPlayerControls(overlay);
        });
        full.setOnClickListener(v->{toggleFullscreen();showPlayerControls(overlay);});

        playerView.setOnTouchListener((v,event)->{
            if(event.getAction()==MotionEvent.ACTION_UP){
                long now=System.currentTimeMillis();
                float x=event.getX();
                if(now-lastTap[0] < 320){
                    if(x < playerView.getWidth()/2f) seekBy(-10000); else seekBy(10000);
                    lastTap[0]=0L;
                }else{
                    lastTap[0]=now; tapX[0]=x;
                    showPlayerControls(overlay);
                }
            }
            return false;
        });
        if(!live) overlay.setVisibility(View.GONE);
        return frame;
    }

    private void showVolumeSlider(FrameLayout anchor, TextView icon, ExoPlayer exo){
        hideVolumeSlider();
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(10),dp(8),dp(10),dp(8)); box.setGravity(Gravity.CENTER_VERTICAL);
        box.setBackground(round(darkTheme() ? Color.rgb(24,34,48) : CARD_2,14));
        SeekBar bar=new SeekBar(this); bar.setMax(100); bar.setProgress(exo==null?100:(int)(exo.getVolume()*100f));
        box.addView(bar,new LinearLayout.LayoutParams(dp(150),dp(42)));
        volumePopup=new android.widget.PopupWindow(box,dp(170),dp(58),true);
        volumePopup.setBackgroundDrawable(round(darkTheme() ? Color.rgb(24,34,48) : CARD_2,14)); volumePopup.setOutsideTouchable(true);
        volumePopup.setOnDismissListener(()->volumePopupVisible=false);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean from){if(from && exo!=null)exo.setVolume(p/100f); icon.setText(p==0?"🔇":"🔊");}
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
        });
        volumePopup.showAtLocation(anchor,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL,0,dp(74)); volumePopupVisible=true;
    }

    private void hideVolumeSlider(){if(volumePopup!=null){volumePopup.dismiss();volumePopup=null;} volumePopupVisible=false;}

    private TextView playerButton(String label) {
        TextView b=tv(label,11,TEXT,true);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        return b;
    }

    private void showPlayerControls(View overlay) {
        if(overlay==null)return;
        overlay.setVisibility(View.VISIBLE);
        playerUiHandler.removeCallbacksAndMessages(null);
        playerUiHandler.postDelayed(()->overlay.setVisibility(View.GONE),3500);
    }

    private void seekBy(long delta) {
        if(player==null)return;
        long pos=Math.max(0,player.getCurrentPosition()+delta);
        long duration=player.getDuration();
        if(duration>0)pos=Math.min(pos,duration);
        player.seekTo(pos);
    }

    private void playFirstChannel() {
        for(Channel c:channels){ if(c.connected && c.url!=null && !c.url.isEmpty()){ playChannel(c); return; } }
        if(!channels.isEmpty()) showComingSoon(channels.get(0));
        else showSimple("Live TV","No channel is configured. Add an authorized source from the backend.");
    }

    private void playChannel(Channel c) {
        push("player"); screen="player"; clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar(c.name,true));
        FrameLayout frame=buildPlayerFrame(true);
        page.addView(frame,new LinearLayout.LayoutParams(-1,dp(260)));
        addScroll(page);
        if(player!=null)player.release();
        player=new ExoPlayer.Builder(this).build(); playerView.setPlayer(player);
        try{player.setMediaItem(MediaItem.fromUri(Uri.parse(c.url)));player.prepare();player.play();}catch(Exception ignored){}
    }

    private void loadRemoteAppConfig() {
        if (BACKEND_URL == null || BACKEND_URL.contains("REPLACE")) return;
        network.execute(() -> {
            try {
                JSONObject root = new JSONObject(getUrl(BACKEND_URL + "/config"));
                JSONObject cfg = root.optJSONObject("config");
                if (cfg == null) return;
                remoteAppConfig = cfg;
                sportsRefreshMs = Math.max(5000L, cfg.optLong("sports_refresh_ms", sportsRefreshMs));
                cricketDetailRefreshMs = Math.max(5000L, cfg.optLong("cricket_detail_refresh_ms", cricketDetailRefreshMs));
                notificationsRefreshMs = Math.max(5000L, cfg.optLong("notifications_refresh_ms", notificationsRefreshMs));
                remoteLiveStatusLabel = cfg.optString("status_live", remoteLiveStatusLabel);
                remoteUpcomingStatusLabel = cfg.optString("status_upcoming", remoteUpcomingStatusLabel);
                remoteFinishedStatusLabel = cfg.optString("status_finished", remoteFinishedStatusLabel);
                remoteLiveBadgeLabel = cfg.optString("status_live_badge", remoteLiveBadgeLabel);
                remoteLiveScoreEnabled = cfg.optBoolean("live_score_refresh_enabled", true);
                remoteDataEnabled = cfg.optBoolean("remote_data_enabled", true);
            } catch (Exception ignored) {}
        });
    }

    private String remoteStatusLabel(String normalized) {
        if ("LIVE".equalsIgnoreCase(normalized)) return remoteLiveStatusLabel;
        if ("UPCOMING".equalsIgnoreCase(normalized)) return remoteUpcomingStatusLabel;
        if ("FINISHED".equalsIgnoreCase(normalized)) return remoteFinishedStatusLabel;
        return normalized == null ? "" : normalized;
    }

    private void loadChannels() {
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")) return;
        network.execute(()->{
            try{
                JSONObject root=new JSONObject(getUrl(BACKEND_URL+"/channels")); JSONArray arr=root.optJSONArray("channels");
                if(arr==null)return; List<Channel> temp=new ArrayList<>();
                for(int i=0;i<arr.length();i++){ JSONObject o=arr.optJSONObject(i); if(o==null)continue;
                    String url=o.optString("url",o.optString("streamUrl",o.optString("sourceUrl","")));
                    boolean connected=o.optBoolean("connected",!url.isEmpty());
                    temp.add(new Channel(o.optInt("id",0),o.optString("name","Channel"),url,o.optString("program",o.optString("programName","")),o.optString("category","TV"),o.optString("country","International"),connected));
                }
                runOnUiThread(()->{channels.clear();channels.addAll(temp); /* Channel refresh does not replace the active Entertainment navigation. */});
            }catch(Exception ignored){}
        });
    }

    private void loadAdConfig() {
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")) return;
        network.execute(()->{
            try {
                JSONObject cfg=new JSONObject(getUrl(BACKEND_URL+"/ads"));
                adConfig=cfg;
                JSONArray active=cfg.optJSONArray("activePlatforms");
                boolean admobActive=false;
                if(active!=null) for(int i=0;i<active.length();i++){ JSONObject a=active.optJSONObject(i); if(a!=null && "admob".equalsIgnoreCase(a.optString("platform_key"))){ admobActive=true; break; } }
                final boolean enabled=admobActive;
                runOnUiThread(() -> {
                    footerAdPlatformEnabled = enabled;
                    if (!enabled) handler.removeCallbacks(footerAdRetry);
                    updateFooterAdVisibility(); // Never show an empty 84dp slot.
                });
            } catch(Exception ignored) {}
        });
    }

    private void showMenuPage(boolean push) {
        entertainmentContext = false;
        stopMatchDetailAutoRefresh();
        stopSportsAutoRefresh();
        if (push) push("menu");
        menuOriginScreen = screen == null ? "home" : screen;
        screen = "menu";
        // The Home bottom bar must not remain interactive beneath the menu overlay.
        if (topNavigation != null) topNavigation.setVisibility(View.GONE);
        if (menuScrim != null || menuDrawer != null) closeMenuDrawer(false);
        if (headerView != null) headerView.setVisibility(View.GONE);
        if (fixedBottom != null) fixedBottom.setVisibility(View.GONE);
        contentHost.removeAllViews();

        FrameLayout overlay = new FrameLayout(this);
        menuScrim = new View(this);
        menuScrim.setBackgroundColor(Color.argb(165, 0, 0, 0));
        menuScrim.setOnClickListener(v -> closeMenuDrawer(true));
        overlay.addView(menuScrim, new FrameLayout.LayoutParams(-1, -1));

        menuDrawer = new LinearLayout(this);
        menuDrawer.setOrientation(LinearLayout.VERTICAL);
        menuDrawer.setPadding(dp(18), dp(16), dp(16), dp(10));
        menuDrawer.setElevation(dp(14));
        menuDrawer.setBackground(menuDrawerBackground());
        FrameLayout.LayoutParams drawerLp = new FrameLayout.LayoutParams(
                (int)(getResources().getDisplayMetrics().widthPixels * 0.82f), -1);
        drawerLp.gravity = Gravity.LEFT;
        overlay.addView(menuDrawer, drawerLp);
        buildPremiumMenuDrawer(menuDrawer);
        contentHost.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
    }

    private GradientDrawable menuDrawerBackground() {
        int[] colors = darkTheme()
                ? new int[]{Color.rgb(8,8,31), Color.rgb(7,13,30), Color.rgb(18,5,31)}
                : new int[]{Color.rgb(31,31,32), Color.rgb(40,40,42), Color.rgb(35,29,40)};
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        g.setCornerRadius(dp(2));
        return g;
    }

    private void buildPremiumMenuDrawer(LinearLayout drawer) {
        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        brandRow.setPadding(dp(2), dp(2), 0, dp(12));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.onetv_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        brandRow.addView(logo, new LinearLayout.LayoutParams(dp(88), dp(62)));

        LinearLayout brandText = new LinearLayout(this);
        brandText.setOrientation(LinearLayout.VERTICAL);
        brandText.setPadding(dp(8), 0, 0, 0);
        TextView title = tv("One TV", 25, TEXT, true);
        title.setIncludeFontPadding(false);
        brandText.addView(title);
        TextView tagline = tv("Sports • Entertainment • News", 10.5f, MUTED, false);
        tagline.setPadding(0, dp(3), 0, 0);
        brandText.addView(tagline);
        brandRow.addView(brandText, new LinearLayout.LayoutParams(0, -2, 1));

        ImageView close = headerIcon(R.drawable.ic_close, "Close menu");
        close.setColorFilter(TEXT, android.graphics.PorterDuff.Mode.SRC_IN);
        close.setPadding(dp(7), dp(7), dp(7), dp(7));
        close.setOnClickListener(v -> closeMenuDrawer(true));
        brandRow.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));
        drawer.addView(brandRow);

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        boolean menuHome = "home".equals(menuOriginScreen);
        boolean menuSports = "sportsHome".equals(menuOriginScreen) || "sport".equals(menuOriginScreen) || "match".equals(menuOriginScreen) || menuOriginScreen.startsWith("sport:");
        boolean menuEntertainment = menuOriginScreen.startsWith("ent:") || "entertainment".equals(menuOriginScreen);
        boolean menuNews = "news".equals(menuOriginScreen) || "newsDetail".equals(menuOriginScreen);

        body.addView(drawerMenuItem(R.drawable.ic_home, "Home", menuHome, null, v -> closeMenuAndOpen(() -> showHome(false))));
        body.addView(drawerMenuItem(R.drawable.ic_sports, "Sports", menuSports, "⌄", v -> closeMenuAndOpen(() -> showSportsHome(false))));
        body.addView(drawerMenuItem(R.drawable.ic_entertainment, "Entertainment", menuEntertainment, null, v -> closeMenuAndOpen(() -> showEntertainment("Explore", false))));
        body.addView(drawerMenuItem(R.drawable.ic_news, "News", menuNews, null, v -> closeMenuAndOpen(() -> showNews(false))));
        body.addView(drawerDivider());
        body.addView(drawerMenuItem(R.drawable.ic_schedule, "Schedule", false, null, v -> closeMenuAndOpen(() -> showSports("cricket", false, "upcoming"))));
        body.addView(drawerMenuItem(R.drawable.ic_favorite, "Favorites", false, null, v -> closeMenuAndOpen(() -> showFavorites(false))));
        body.addView(drawerMenuItem(R.drawable.ic_schedule, "Reminders", false, null, v -> closeMenuAndOpen(() -> showReminders(false))));
        body.addView(drawerMenuItem(R.drawable.ic_info, "Account", false, null, v -> closeMenuAndOpen(() -> showUserAccount(false))));
        body.addView(drawerMenuItem(R.drawable.ic_help, "History", false, null, v -> closeMenuAndOpen(() -> showHistory(false))));
        body.addView(drawerMenuItem(R.drawable.ic_info, "Downloads", false, null, v -> closeMenuAndOpen(() -> showDownloads(false))));
        body.addView(drawerMenuItem(R.drawable.ic_notifications, "Notifications", false, null, v -> closeMenuAndOpen(() -> showNotifications(false))));
        body.addView(drawerMenuItem(R.drawable.ic_share, "Share OneTV", false, null, v -> {
            closeMenuDrawer(true);
            OneTvAppShare.shareInstalledApk(this, false);
        }));
        body.addView(drawerDivider());
        body.addView(drawerMenuItem(R.drawable.ic_settings, "Settings", false, null, v -> closeMenuAndOpen(() -> showSettings(false))));
        body.addView(drawerMenuItem(R.drawable.ic_help, "Help & Support", false, null, v -> closeMenuAndOpen(() -> showSupport(false))));
        body.addView(drawerMenuItem(R.drawable.ic_info, "About One TV", false, null, v -> closeMenuAndOpen(() -> showAboutOneTv(true))));

        scrollView.addView(body, new ScrollView.LayoutParams(-1, -2));
        drawer.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private View drawerDivider() {
        View line = new View(this);
        line.setBackgroundColor(Color.argb(55, 150, 160, 210));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(dp(12), dp(8), dp(12), dp(8));
        line.setLayoutParams(lp);
        return line;
    }

    private LinearLayout drawerMenuItem(int iconRes, String title, boolean active, String trailing, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), 0, dp(10), 0);
        row.setMinimumHeight(dp(58));
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(click);
        if (active) {
            GradientDrawable selected = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Color.rgb(220,22,61), Color.rgb(65,15,76)});
            selected.setCornerRadius(dp(15));
            row.setBackground(selected);
        } else row.setBackgroundColor(Color.TRANSPARENT);

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        icon.setColorFilter(TEXT, android.graphics.PorterDuff.Mode.SRC_IN);
        row.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(44)));

        TextView label = tv(title, 15.5f, TEXT, active);
        label.setGravity(Gravity.CENTER_VERTICAL);
        label.setIncludeFontPadding(false);
        row.addView(label, new LinearLayout.LayoutParams(0, -1, 1));

        if (trailing != null) {
            TextView chevron = tv(trailing, 24, MUTED, false);
            chevron.setGravity(Gravity.CENTER);
            row.addView(chevron, new LinearLayout.LayoutParams(dp(36), -1));
        }
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(58));
        rp.setMargins(0, dp(2), 0, dp(2));
        row.setLayoutParams(rp);
        return row;
    }

    private void closeMenuAndOpen(Runnable action) {
        closeMenuDrawer(false);
        action.run();
    }

    private void closeMenuDrawer(boolean restorePrevious) {
        menuScrim = null;
        menuDrawer = null;
        if (contentHost != null) contentHost.removeAllViews();
        if (headerView != null) headerView.setVisibility(View.VISIBLE);
        if (fixedBottom != null) fixedBottom.setVisibility(View.VISIBLE);
        updateFooterAdVisibility();
        if (restorePrevious) {
            if (!history.empty()) {
                String prev = history.pop();
                if ("home".equals(prev)) showHome(false);
                else if ("sportsHome".equals(prev)) showSportsHome(false);
                else if ("news".equals(prev)) showNews(false);
                else if (prev.startsWith("sport:")) showSports(prev.substring(6), false);
                else if (prev.startsWith("ent:")) showEntertainment(prev.substring(4), false);
                else if ("notifications".equals(prev)) showNotifications(false);
                else if ("favorites".equals(prev)) showFavorites(false);
                else if ("support".equals(prev)) showSupport(false);
                else if ("about".equals(prev)) showAboutOneTv(false);
                else if ("privacy".equals(prev)) showPrivacyPolicy(false);
                else if ("terms".equals(prev)) showTermsOfUse(false);
                else if ("licenses".equals(prev)) showLicenses(false);
                else if ("settings".equals(prev)) showSettings(false);
                else if ("playback".equals(prev)) showPlaybackSettings(false);
                else showHome(false);
            } else showHome(false);
        }
    }

    private void showSupport(boolean push) {
        entertainmentContext = false;
        if (push) push("support");
        screen = "support";
        clearContent();
        LinearLayout page = page();
        page.addView(selectedSectionBar("Help & Support", false));
        page.addView(sectionLabel("Help & Support", "Get help with playback, data and app issues"));
        page.addView(menuAction("◌", "Report a Problem", "Review the issue details before contacting support",
                v -> showSimple("Report a Problem", "Include the screen, match or channel affected and the exact error message when reporting a problem.")));
        page.addView(menuAction("?", "FAQ", "Common questions about ONE TV",
                v -> showSimple("FAQ", "Refresh the current page and retry a verified source when a stream or score is unavailable.")));
        page.addView(menuAction("ⓘ", "App Information", "ONE TV by USHA IT",
                v -> showAboutOneTv(true)));
        addScroll(page);
    }

    private void showFavorites(boolean push) {
        entertainmentContext = false;
        if (push) push("favorites");
        screen = "favorites";
        clearContent();
        LinearLayout page = page();
        page.addView(selectedSectionBar("Favorites", false));
        page.addView(sectionLabel("Favorites", "Your saved matches"));
        JSONArray saved = getFavoriteMatches();
        if (saved.length() == 0) page.addView(emptyStateCard("No favorites yet", "Open a verified match and tap the star icon to save it."));
        else {
            LinearLayout list = new LinearLayout(this);
            list.setOrientation(LinearLayout.VERTICAL);
            list.setPadding(dp(12), dp(4), dp(12), dp(18));
            for (int i = 0; i < saved.length(); i++) {
                JSONObject m = saved.optJSONObject(i);
                if (m != null) list.addView(sportsListCard(m, false));
            }
            page.addView(list);
        }
        addScroll(page);
    }

    private String favoriteKey(JSONObject m) {
        String id = pickText(m, "id", "providerMatchId", "matchId", "eventId");
        return id.isEmpty() ? canonicalMatchTitle(m) : id;
    }

    private JSONArray getFavoriteMatches() {
        JSONArray out = new JSONArray();
        String raw = prefs == null ? "[]" : prefs.getString("favorite_matches", "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject m = a.optJSONObject(i);
                if (m != null) out.put(m);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private boolean isFavorite(JSONObject m) {
        String key = favoriteKey(m);
        JSONArray a = getFavoriteMatches();
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x != null && key.equals(favoriteKey(x))) return true;
        }
        return false;
    }

    private void toggleFavorite(JSONObject m) {
        if (prefs == null || m == null) return;
        JSONArray a = getFavoriteMatches();
        String key = favoriteKey(m);
        JSONArray out = new JSONArray();
        boolean removed = false;
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x == null) continue;
            if (key.equals(favoriteKey(x))) removed = true;
            else out.put(x);
        }
        if (!removed) out.put(m);
        prefs.edit().putString("favorite_matches", out.toString()).apply();
    }

    private void showSettings(boolean push){
        entertainmentContext=false;
        if(push)push("settings");screen="settings";clearContent();
        LinearLayout page=page();page.addView(selectedSectionBar("Settings",false));
        page.addView(sectionLabel("Settings","Playback, data and accessibility"));
        page.addView(menuAction("◉","Account","Guest and personal controls",v->showUserAccount(true)));
        page.addView(menuAction("🔔","Notifications","Match and content preferences",v->showNotificationSettings(true)));
        page.addView(playbackSettingsRow());
        page.addView(menuAction("◈","Data Saver","Cache and network refresh",v->showDataSaver(true)));
        page.addView(themeSettingRow());
        page.addView(menuAction("文","Language","Supported interface translations",v->showLanguage(true)));
        page.addView(menuAction("⊙","Privacy","Data use and app controls",v->showPrivacyPolicy(true)));
        page.addView(menuAction("↗","Share OneTV APK","Share the installed app through Android",v->OneTvAppShare.shareInstalledApk(this,false)));
        page.addView(menuAction("▣","Share compatible ZIP","If a messenger blocks APK files; recipient extracts before installing",v->OneTvAppShare.shareInstalledApk(this,true)));
        page.addView(menuAction("ⓘ","About OneTV","Version, licenses and credits",v->showAboutOneTv(true)));
        addScroll(page);
    }


    private LinearLayout themeSettingRow() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(10), dp(12), dp(10));
        row.setBackground(round(CARD, 16));

        TextView ico = tv("◐", 21, TEXT, false);
        ico.setGravity(Gravity.CENTER);
        row.addView(ico, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.addView(tv("Theme", 14, TEXT, true));
        info.addView(tv("Choose your viewing theme", 10, MUTED, false));
        row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));

        TextView value = tv(darkTheme() ? "Dark" : "Default", 12, TEXT, true);
        value.setGravity(Gravity.CENTER);
        value.setPadding(dp(14), 0, dp(8), 0);
        value.setCompoundDrawablesWithIntrinsicBounds(0,0,android.R.drawable.arrow_down_float,0);
        value.setCompoundDrawablePadding(dp(5));
        value.setBackground(round(CARD_2, 13));
        value.setMinimumWidth(dp(108));
        value.setContentDescription("Theme selector");
        value.setOnClickListener(v -> showThemePopup(value));
        row.addView(value, new LinearLayout.LayoutParams(dp(118), dp(42)));

        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.setMargins(dp(12),0,dp(12),dp(8));
        row.setLayoutParams(rp);
        return row;
    }

    private void showThemePopup(TextView anchor){
        final android.widget.PopupWindow popup = new android.widget.PopupWindow(this);
        LinearLayout menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setPadding(dp(6),dp(6),dp(6),dp(6));
        menu.setBackground(round(PANEL,16));
        String[] options={"Default","Dark"};
        for(String option:options){
            TextView item=tv(option,12,TEXT,true);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(14),0,dp(14),0);
            item.setBackground(round(option.equals(anchor.getText().toString())?CARD_2:PANEL,11));
            item.setOnClickListener(v->{
                boolean dark="Dark".equals(((TextView)v).getText().toString());
                prefs.edit().putBoolean("dark_theme",dark).apply();
                popup.dismiss();
                setPalette(dark);
                showSettings(false);
            });
            menu.addView(item,new LinearLayout.LayoutParams(dp(136),dp(44)));
        }
        popup.setContentView(menu);
        popup.setWidth(dp(148));
        popup.setHeight(dp(104));
        popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(true);
        popup.setFocusable(true);
        popup.setElevation(dp(8));
        popup.showAsDropDown(anchor, -dp(18), dp(6));
    }

    private LinearLayout playbackSettingsRow() {
        LinearLayout row = menuAction("▶", "Playback", "Player behavior and quality", v -> {});
        row.setOnClickListener(v -> showPlaybackSettings(true));
        return row;
    }

    private void showPlaybackSettings(boolean push) {
        entertainmentContext = false;
        if(push) push("playback"); screen="playback"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar("Playback",false));
        page.addView(sectionLabel("Playback","Controls used when a channel or video is opened"));
        page.addView(menuAction("▶","Autoplay","Start connected playback automatically",v->showSimple("Autoplay","Autoplay is used for connected sources only.")));
        page.addView(menuAction("HD","Quality","Use the highest quality supplied by the source",v->showSimple("Quality","Quality choices are available in the player when the source provides multiple variants.")));
        page.addView(menuAction("🔊","Volume","Open the volume slider from the player",v->showSimple("Volume","Tap the volume icon to open the slider. Tap it again to mute or unmute.")));
        page.addView(menuAction("⛶","Fullscreen","Use landscape/fullscreen playback when supported",v->showSimple("Fullscreen","Fullscreen is available from the player controls.")));
        addScroll(page);
    }

    private boolean darkTheme(){ return prefs != null && prefs.getBoolean("dark_theme", false); }

    private void setPalette(boolean dark){
        if(dark){
            // Dark: keep the existing cool, slightly lighter content surfaces.
            BG=Color.rgb(5,10,17); PANEL=Color.rgb(13,25,39); CARD=Color.rgb(20,35,51); CARD_2=Color.rgb(24,42,61); BLUE=Color.rgb(28,126,245); CYAN=Color.rgb(0,205,190); PURPLE=Color.rgb(119,52,245); TEXT=Color.WHITE; MUTED=Color.rgb(174,188,203); GREEN=Color.rgb(0,194,142); RED=Color.rgb(244,63,81);
        }else{
            // Default: premium charcoal presentation instead of the previous pale/light palette.
            BG=Color.rgb(34,34,34); PANEL=Color.rgb(40,40,43); CARD=Color.rgb(47,47,51); CARD_2=Color.rgb(56,56,61); BLUE=Color.rgb(91,140,255); CYAN=Color.rgb(66,214,197); PURPLE=Color.rgb(155,108,255); TEXT=Color.rgb(245,245,247); MUTED=Color.rgb(181,184,193); GREEN=Color.rgb(57,217,138); RED=Color.rgb(255,77,103);
        }
        if(root!=null) root.setBackgroundColor(BG);
        if(fixedBottom!=null) fixedBottom.setBackgroundColor(BG);
        if(adRow!=null){
            adRow.setBackgroundColor(BG);
            for(int i=0;i<adRow.getChildCount();i++) adRow.getChildAt(i).setBackground(round(PANEL,12));
        }
        if(footer!=null) footer.setTextColor(MUTED);
        if(headerView!=null) headerView.setBackgroundColor(dark?Color.rgb(4,9,15):BG);
        if(headerSlogan!=null) headerSlogan.setTextColor(TEXT);
        if(headerMenu!=null) headerMenu.setColorFilter(TEXT, android.graphics.PorterDuff.Mode.SRC_IN);
        if(headerSearch!=null){ headerSearch.setBackground(circleDrawable(dark?CARD:CARD_2)); headerSearch.setColorFilter(TEXT, android.graphics.PorterDuff.Mode.SRC_IN); }
        if(headerNotification!=null) headerNotification.setColorFilter(TEXT, android.graphics.PorterDuff.Mode.SRC_IN);
        if(getWindow()!=null){
            // Both palettes are intentionally dark-premium, so keep system-bar icons light.
            getWindow().setStatusBarColor(dark?Color.rgb(4,9,15):BG);
            getWindow().setNavigationBarColor(dark?Color.BLACK:BG);
            int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    private void showNotifications(boolean push) {
        entertainmentContext = false;
        if(push) push("notifications"); screen="notifications"; clearContent();
        if(notificationBadge!=null) notificationBadge.setVisibility(View.GONE);
        LinearLayout page=page(); page.addView(selectedSectionBar("Notifications",false));
        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(18),dp(8),dp(18),dp(18));
        page.addView(list);
        addScroll(page);
        loadNotificationsInto(list);
    }

    private void loadNotifications(){
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")) return;
        network.execute(()->{try{JSONObject r=new JSONObject(getUrl(BACKEND_URL+"/notifications")); int count=r.optInt("unreadCount",0); runOnUiThread(()->{if(notificationBadge!=null){notificationBadge.setText(count>0?String.valueOf(Math.min(count,99)):"");notificationBadge.setVisibility(count>0?View.VISIBLE:View.GONE);}}); if(count>0) postLocalNotification(r.optJSONArray("items"));}catch(Exception ignored){}});
        handler.postDelayed(this::loadNotifications,notificationsRefreshMs);
    }

    private void loadNotificationsInto(LinearLayout list){
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")) return;
        network.execute(()->{
            try{
                JSONObject r=new JSONObject(getUrl(BACKEND_URL+"/notifications"));
                JSONArray items=r.optJSONArray("items");
                runOnUiThread(()->{
                    list.removeAllViews();
                    if(items==null||items.length()==0){
                        list.addView(emptyStateCard("No notifications","New alerts will appear here when they arrive."));
                        return;
                    }
                    for(int i=0;i<items.length();i++){
                        JSONObject n=items.optJSONObject(i);
                        if(n==null) continue;
                        final JSONObject notice=n;
                        boolean hasTarget=!n.optString("sport","").trim().isEmpty()
                                && !n.optString("matchId",n.optString("providerMatchId","")).trim().isEmpty();
                        View.OnClickListener click=hasTarget
                                ? v->{ try { openNotificationTarget(notice); } catch (Exception ignored) { showNotifications(false); } }
                                : null;
                        list.addView(notificationCard(n.optString("icon","ℹ"),n.optString("title","ONE TV"),
                                n.optString("body",n.optString("html","")),click));
                    }
                });
            }catch(Exception ignored){ runOnUiThread(list::removeAllViews); }
        });
    }

    private void openNotificationTarget(JSONObject n){
        if(n==null){ showNotifications(false); return; }
        String sport=n.optString("sport","").trim().toLowerCase(Locale.US);
        String id=n.optString("matchId",n.optString("providerMatchId","")).trim();
        if(sport.isEmpty() || id.isEmpty() || BACKEND_URL==null || BACKEND_URL.contains("REPLACE")){ showNotifications(false); return; }
        try{
            JSONObject target=new JSONObject();
            target.put("id",id); target.put("sport",sport);
            target.put("title",n.optString("title","Match Centre"));
            target.put("status",n.optString("status",""));
            JSONObject home=n.optJSONObject("home"); JSONObject away=n.optJSONObject("away");
            if(home!=null)target.put("home",home); if(away!=null)target.put("away",away);
            selectedMatch=target;
        }catch(Exception ignored){ showNotifications(false); return; }
        try { showMatchDetail(true); } catch(Exception ignored) { showNotifications(false); }
    }

    private void postLocalNotification(JSONArray items){
        if(items==null||items.length()==0)return; JSONObject n=items.optJSONObject(0); if(n==null)return;
        String key=n.optString("id",n.optString("title","")); String last=prefs.getString("last_notice_key",""); if(key.equals(last))return; prefs.edit().putString("last_notice_key",key).apply();
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); if(nm==null)return;
        Intent i=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(this,"onetv_updates").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(n.optString("title","ONE TV")).setContentText(n.optString("body",n.optString("html",""))).setAutoCancel(true).setContentIntent(pi);
        if(Build.VERSION.SDK_INT<33 || checkSelfPermission("android.permission.POST_NOTIFICATIONS")==android.content.pm.PackageManager.PERMISSION_GRANTED)
            nm.notify(++notificationSequence,b.build());
    }

    private void createNotificationChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); if(nm!=null)nm.createNotificationChannel(new NotificationChannel("onetv_updates","ONE TV Updates",NotificationManager.IMPORTANCE_DEFAULT));}}
    private void requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},901); else showSimple("Notifications","Notifications are enabled for this Android version.");}

    private LinearLayout notificationCard(String icon,String title,String sub,View.OnClickListener click) {
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14),dp(12),dp(14),dp(12));
        row.setBackground(round(CARD,16));
        if(click!=null){
            row.setClickable(true);
            row.setOnClickListener(click);
        }
        row.addView(tv(icon,20,TEXT,false),new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout info=new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.addView(tv(title,14,TEXT,true));
        if(sub!=null && !sub.trim().isEmpty()) info.addView(tv(sub,10,MUTED,false));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        if(click!=null) row.addView(tv("›",22,MUTED,false));
        row.setLayoutParams(marginBottomParams(8));
        return row;
    }

    private LinearLayout emptyStateCard(String title,String subtitle){
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(18),dp(22),dp(18),dp(22));
        card.setBackground(round(CARD,16));
        card.addView(tv(title,15,TEXT,true));
        card.addView(tv(subtitle,10,MUTED,false));
        return card;
    }

    private void showAppearance(boolean push){ showSettings(push); }

    private void showSearch(boolean push,String scope) { showSearch(push,scope,""); }

    private void showSearch(boolean push,String scope,String initialQuery) {
        entertainmentContext = false;
        if(push) push("search"); screen="search"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar("Search",false));

        LinearLayout searchWrap=new LinearLayout(this);
        searchWrap.setGravity(Gravity.CENTER_VERTICAL);
        searchWrap.setPadding(dp(14),0,dp(7),0);
        GradientDrawable searchBg=round(CARD,15);
        searchBg.setStroke(dp(1),Color.argb(darkTheme()?48:30,255,255,255));
        searchWrap.setBackground(searchBg);

        EditText input=new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setHint("Search OneTV");
        input.setContentDescription("Search matches, teams, players and news");
        input.setTextSize(14f);
        input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        input.setPadding(0,0,dp(6),0);
        input.setBackgroundColor(Color.TRANSPARENT);
        searchWrap.addView(input,new LinearLayout.LayoutParams(0,dp(46),1));
        ImageButton searchButton=new ImageButton(this);
        searchButton.setImageResource(R.drawable.ic_search);
        searchButton.setColorFilter(TEXT,android.graphics.PorterDuff.Mode.SRC_IN);
        searchButton.setScaleType(ImageView.ScaleType.CENTER);
        searchButton.setPadding(dp(6),dp(6),dp(6),dp(6));
        searchButton.setBackgroundColor(Color.TRANSPARENT);
        searchButton.setContentDescription("Search");
        searchWrap.addView(searchButton,new LinearLayout.LayoutParams(dp(40),dp(40)));

        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(48));
        ip.setMargins(dp(14),dp(5),dp(14),dp(10));
        page.addView(searchWrap,ip);

        LinearLayout results=new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        results.setPadding(dp(14),0,dp(14),dp(18));
        page.addView(results,new LinearLayout.LayoutParams(-1,-2));

        if(initialQuery!=null && !initialQuery.trim().isEmpty()){
            input.setText(initialQuery.trim());
            input.setSelection(input.length());
            loadSearchResults(results,input.getText().toString());
        }

        input.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence c,int st,int count,int after){}
            public void onTextChanged(CharSequence c,int st,int before,int count){
                if(pendingSearchRequest!=null)handler.removeCallbacks(pendingSearchRequest);
                final String typed=c.toString().trim();
                ++searchRequestSequence;
                if(typed.isEmpty()){loadSearchResults(results,"");return;}
                results.removeAllViews();
                if(typed.codePointCount(0,typed.length())<2)return;
                pendingSearchRequest=()->{
                    if("search".equals(screen))loadSearchResults(results,typed);
                };
                handler.postDelayed(pendingSearchRequest,480L);
            }
            public void afterTextChanged(Editable e){}
        });
        searchButton.setOnClickListener(v->{
            if(pendingSearchRequest!=null)handler.removeCallbacks(pendingSearchRequest);
            loadSearchResults(results,input.getText().toString()); ((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0); });
        input.setOnEditorActionListener((v,action,event)->{
            if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){
                if(pendingSearchRequest!=null)handler.removeCallbacks(pendingSearchRequest);
                loadSearchResults(results,input.getText().toString());
                ((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(input.getWindowToken(),0);
                return true;
            }
            return false;
        });

        addScroll(page);

    }

    private void loadSearchResults(LinearLayout results,String query){
        String q=query==null?"":query.trim();
        lastSearchQuery=q;
        final int requestId=++searchRequestSequence;
        results.removeAllViews();
        if(q.isEmpty()) return;
        results.addView(homeSmallState("Searching…"));
        if(BACKEND_URL==null||BACKEND_URL.contains("REPLACE")){
            results.addView(emptyStateCard("Search unavailable","Please try again shortly."));
            return;
        }
        network.execute(()->{
            try{
                JSONObject r=new JSONObject(getUrl(BACKEND_URL+"/search?q="+Uri.encode(q)));
                JSONArray items=r.optJSONArray("items");
                runOnUiThread(()->{
                    if(requestId!=searchRequestSequence) return;
                    results.removeAllViews();
                    if(items==null||items.length()==0){
                        results.addView(emptyStateCard("No results found","Try a different name or keyword."));
                        return;
                    }
                    for(int i=0;i<items.length();i++){
                        JSONObject item=items.optJSONObject(i);
                        if(item==null) continue;
                        String sub=item.optString("subtitle","");
                        if("match".equals(item.optString("kind",""))){
                            String schedule=formatMatchSchedule(item.optString("time",item.optString("startsAt","")));
                            if(!schedule.isEmpty()) sub=(sub.isEmpty()?"":sub+" • ")+schedule;
                        }
                        results.addView(searchResult(item.optString("icon","•"),
                                item.optString("title",item.optString("name","")),
                                sub,
                                v->openSearchItem(item)));
                    }
                });
            }catch(Exception e){
                runOnUiThread(()->{
                    if(requestId!=searchRequestSequence) return;
                    results.removeAllViews();
                    results.addView(emptyStateCard("Search unavailable","Please try again in a moment."));
                });
            }
        });
    }

    private void openSearchItem(JSONObject item){
        if(item==null)return;
        String kind=item.optString("kind","");
        if("match".equals(kind)){
            String targetSport=item.optString("sport","").toLowerCase(Locale.US);
            if(targetSport.equals("cricket")||targetSport.equals("football")||
                    targetSport.equals("tennis")||targetSport.equals("basketball"))selectedSport=targetSport;
            selectedMatch=item;
            showMatchDetail(true);
        } else if("article".equals(kind)){
            openNewsDetail(item);
        } else if("media".equals(kind)){
            showEntertainmentItem(item,true);
        } else if("channel".equals(kind)){
            showSimple("Video unavailable", "Only licensed, validated sources may be played in OneTV.");
        } else {
            showContentDetail(item.optString("title","Content"),item.optString("subtitle","Entertainment"),true);
        }
    }

    private LinearLayout searchResult(String icon,String title,String sub,View.OnClickListener click) {
        LinearLayout r=contentRow(title,sub);
        r.setOnClickListener(click);
        return r;
    }

    private void showContentDetail(String title,String type,boolean push) {
        entertainmentContext = "entertainment".equalsIgnoreCase(type);
        if(push) push("content:"+title); screen="content"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar(title,false));
        page.addView(sectionLabel(type,"Entertainment"));
        page.addView(sectionLabel("Content",type));
        page.addView(statCard("Playback","Coming soon","Playback will be available when this content is connected."));
        addScroll(page);
    }

    private void showSimple(String title,String subtitle) {
        if (title != null && title.toLowerCase(Locale.US).contains("about")) { showAboutOneTv(true); return; }
        clearContent();
        screen="simple";
        LinearLayout page=page();
        page.addView(selectedSectionBar(title,false));
        page.addView(sectionLabel(title,subtitle));
        addScroll(page);
    }

    private void showAboutOneTv(boolean pushHistory) {
        if (pushHistory) push("about");
        entertainmentContext=false; screen="about"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar("About OneTV",false));
        LinearLayout identity=new LinearLayout(this); identity.setOrientation(LinearLayout.VERTICAL);
        identity.setGravity(Gravity.CENTER); identity.setPadding(dp(20),dp(24),dp(20),dp(20));
        identity.setBackground(round(PANEL,20));
        ImageView oneLogo=new ImageView(this); oneLogo.setImageResource(R.drawable.onetv_logo);
        oneLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        identity.addView(oneLogo,new LinearLayout.LayoutParams(dp(150),dp(82)));
        identity.addView(tv("OneTV - All in One",18,TEXT,true));
        identity.addView(tv("Version "+installedAppVersionName(),12,MUTED,false));
        View gap=new View(this); identity.addView(gap,new LinearLayout.LayoutParams(1,dp(18)));
        TextView developed=tv("Developed and owned by",12,MUTED,false); identity.addView(developed);
        ImageView ushaLogo=new ImageView(this); ushaLogo.setImageResource(R.drawable.usha_it_full_logo_white);
        ushaLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams ulp=new LinearLayout.LayoutParams(dp(190),dp(62)); ulp.setMargins(0,dp(5),0,dp(5)); identity.addView(ushaLogo,ulp);
        identity.addView(tv("© 2026 USHA IT. All Rights Reserved.",11,MUTED,false));
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2); ip.setMargins(dp(14),dp(12),dp(14),dp(12)); page.addView(identity,ip);
        page.addView(menuAction("▤","Privacy Policy","How OneTV handles information and permissions",v->showPrivacyPolicy(true)));
        page.addView(menuAction("§","Terms of Use","Rules and conditions for using OneTV",v->showTermsOfUse(true)));
        page.addView(menuAction("©","Licenses & Attributions","Third-party services, data and media credits",v->showLicenses(true)));
        addScroll(page);
    }

    private void legalSection(LinearLayout page,String heading,String body) {
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15),dp(13),dp(15),dp(13)); card.setBackground(round(CARD,14));
        TextView h=tv(heading,14,TEXT,true); h.setPadding(0,0,0,dp(7)); card.addView(h);
        TextView b=tv(body,12,MUTED,false); b.setLineSpacing(dp(3),1f); card.addView(b);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(dp(12),dp(4),dp(12),dp(5)); page.addView(card,lp);
    }

    private void showPrivacyPolicy(boolean pushHistory) {
        if(pushHistory) push("privacy"); entertainmentContext=false; screen="privacy"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar("Privacy Policy",false));
        page.addView(sectionLabel("Privacy Policy","OneTV • USHA IT • Effective 3 November 2026"));
        legalSection(page,"1. Who we are","OneTV is a sports, entertainment and news application developed and owned by USHA IT (\"USHA IT\", \"we\", \"us\" or \"our\"). This policy explains how information may be handled when you use the app and its connected services.");
        legalSection(page,"2. Guest use and account information","Basic browsing is designed to work without requiring an account. Favorites, reminders, preferences and viewing history may be stored locally on your device. If optional account or synchronization features are enabled in a future release, only information needed to provide that feature and information you choose to submit will be processed under the applicable in-app flow.");
        legalSection(page,"3. Information processed","Depending on the features you use, the app and its service providers may process app settings, saved-item identifiers, reminder preferences, content and playback requests, device/app version, network address, timestamps, crash or diagnostic details, and security/rate-limit signals. We do not ask for contacts, microphone, camera or precise location for ordinary browsing. Android notification permission is requested only for notifications where required.");
        legalSection(page,"4. Sports, news and entertainment providers","OneTV requests data and media metadata from configured third-party providers, such as sports-data, news, catalogue, streaming and image services. Those providers may receive technical request information under their own privacy policies. OneTV preserves source attribution where required. Provider availability and data coverage may vary.");
        legalSection(page,"5. Advertising","The app may display advertising in its dedicated bottom/footer advertising area. Advertising partners may use device identifiers, cookies or similar technologies, where supported and permitted by Android and applicable law, to deliver, measure or limit advertising. Ad availability and partner behavior are governed by the relevant partner policies. OneTV does not intentionally place a second floating or player-covering ad container.");
        legalSection(page,"6. Storage, cache and retention","The app may cache provider responses and permitted media metadata to improve performance and reduce repeated requests. Local favorites, reminders, preferences and history remain on the device until cleared or the app data is removed, unless an enabled sync feature states otherwise. Server logs and operational records are retained only as reasonably needed for service operation, security, troubleshooting and legal obligations.");
        legalSection(page,"7. Why information is used","Information is used to operate the app, return requested content, maintain saved preferences, schedule reminders, protect services against abuse, diagnose errors, measure service reliability, manage advertising and comply with legal obligations. We do not sell personal information as a standalone product.");
        legalSection(page,"8. Sharing and service providers","Information may be processed by hosting, database, content, sports-data, news, streaming, analytics or advertising providers that support OneTV. It may also be disclosed where required by law, to protect users or the service, or as part of a business transfer subject to applicable law. Provider credentials and private API keys are kept server-side and are not intended to be exposed in the app.");
        legalSection(page,"9. Children","OneTV is a general-audience service and is not designed to knowingly collect personal information from children. A parent or guardian who believes a child has submitted personal information may contact us through the app's Help & Support section so the matter can be reviewed.");
        legalSection(page,"10. Security and international processing","We use reasonable technical and organizational safeguards appropriate to the service, including encrypted transport where supported, access controls and server-side secret storage. No internet transmission or storage system can be guaranteed completely secure. Providers may process information in countries other than your own.");
        legalSection(page,"11. Your choices and controls","You can manage Android notification permission in device settings, clear app storage/cache through Android settings, and remove locally saved favorites or history where those controls are available. You may stop using the app at any time. Requests about information processed by OneTV can be submitted through Help & Support.");
        legalSection(page,"12. Third-party links and policies","Content may identify or link to third-party sources. Their services are not controlled by USHA IT. Review their privacy notices and terms before using them. A source's presence in OneTV does not mean USHA IT owns that source or its content.");
        legalSection(page,"13. Changes to this policy","We may update this policy when the app, providers or applicable requirements change. The revised policy will be published in the app with an updated effective date. Continued use after an update means the updated notice is available to you; it does not remove rights provided by applicable law.");
        legalSection(page,"14. Contact","For privacy questions or requests, use Help & Support in OneTV and select Report a Problem or the available contact route. Please include \"Privacy Request\" in the message. Do not include passwords, payment credentials or API keys.");
        legalSection(page,"Developer and owner","USHA IT • © 2026 USHA IT. All Rights Reserved.");
        addScroll(page);
    }

    private void showTermsOfUse(boolean pushHistory) {
        if(pushHistory) push("terms"); entertainmentContext=false; screen="terms"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar("Terms of Use",false));
        page.addView(sectionLabel("Terms of Use","OneTV • USHA IT • Effective 3 November 2026"));
        legalSection(page,"1. Agreement","These Terms govern your access to and use of OneTV, developed and owned by USHA IT. By accessing or using the app, you agree to these Terms. If you do not agree, stop using the app.");
        legalSection(page,"2. Service description","OneTV provides interfaces for sports information, live scores, schedules, commentary, news, entertainment catalogues and, where a valid authorized source is available, in-app audio/video playback. Features and regional availability may change as providers and technical capabilities change.");
        legalSection(page,"3. Eligibility and permitted use","Use OneTV only where you are legally permitted to do so. You must comply with applicable laws, these Terms and the rules of each connected provider. You may use the app for personal, lawful, non-commercial viewing and information unless USHA IT expressly authorizes another use in writing.");
        legalSection(page,"4. Accounts and device data","Basic browsing may be available as a guest. If optional account features are introduced or enabled, provide accurate information, protect your credentials and use sign-out controls on shared devices. You are responsible for activity performed through your account or device, subject to applicable law.");
        legalSection(page,"5. Content, data and accuracy","Scores, fixtures, commentary, news, schedules, images, programme details and other metadata are supplied by third-party sources and may be delayed, incomplete, corrected or unavailable. OneTV displays provider-backed information and does not guarantee uninterrupted availability or absolute accuracy. Official competition and broadcaster sources should be consulted for authoritative decisions.");
        legalSection(page,"6. Streaming and media rights","Playback is provided only when a valid source is configured and its use is permitted. Content may be subject to copyright, broadcast rights, territorial limits, subscription requirements, DRM, expiry and provider conditions. You must not bypass DRM, access controls, geographic restrictions or technical protections, and must not record, redistribute, rebroadcast, download or commercially exploit content unless the rights holder expressly permits it.");
        legalSection(page,"7. Acceptable use","You must not misuse the service, interfere with its operation, probe or attack its infrastructure, scrape or automate requests in a harmful way, reverse engineer except where law permits, upload malicious material, impersonate another person, infringe intellectual property, or attempt to access private APIs, credentials or administrative systems.");
        legalSection(page,"8. Intellectual property and attribution","The OneTV name, app design, software and USHA IT branding are owned by or licensed to USHA IT. Third-party names, logos, data, artwork and media remain the property of their respective owners. Provider attribution and notices must not be removed or misrepresented. No ownership of third-party content is transferred to you.");
        legalSection(page,"9. Advertising","Advertisements may appear only in the app's designated advertising placement and are supplied by advertising partners. Interaction with an advertisement, offer or advertiser is between you and the relevant third party. USHA IT does not endorse an advertiser merely by displaying an eligible advertisement.");
        legalSection(page,"10. Third-party services","OneTV may rely on external data, hosting, streaming, news, catalogue and advertising services. Those services may have separate terms, privacy notices, fees or eligibility rules. USHA IT is not responsible for services it does not operate, subject to rights and responsibilities that cannot be excluded by law.");
        legalSection(page,"11. Availability and changes","We may update, suspend or discontinue features, sources or parts of the service for maintenance, provider changes, security, legal compliance or operational reasons. We will not promise that every event, channel, video, region or provider will always be available. Cached data may be marked stale when a provider is unavailable.");
        legalSection(page,"12. Disclaimers","To the extent permitted by applicable law, OneTV is provided on an \"as available\" basis. We do not warrant uninterrupted access, error-free operation, provider accuracy, availability of a particular stream, or suitability for a particular purpose. Nothing in these Terms excludes a guarantee or right that cannot legally be excluded.");
        legalSection(page,"13. Limitation of liability","To the maximum extent permitted by applicable law, USHA IT will not be liable for indirect, incidental, special or consequential loss arising from third-party provider outages, inaccurate or delayed feeds, network failures, device incompatibility or unavailable media. These Terms do not limit liability where such limitation is prohibited by law, including applicable consumer rights.");
        legalSection(page,"14. Suspension and termination","We may restrict access where reasonably necessary to protect the service, comply with law, respond to abuse or enforce these Terms. You may stop using OneTV at any time and uninstall it through your device settings.");
        legalSection(page,"15. Changes to these Terms","We may revise these Terms as the service evolves. The current version and effective date will be shown in the app. Material changes will be presented through an appropriate in-app notice where reasonably practicable.");
        legalSection(page,"16. Governing law and mandatory rights","These Terms are subject to applicable laws. Any governing-law or dispute-resolution provision will operate only to the extent permitted by the law applicable to you. Nothing here removes mandatory consumer or statutory rights.");
        legalSection(page,"17. Contact","For questions about these Terms, use OneTV's Help & Support section and submit a report mentioning \"Terms of Use\". Do not send passwords, payment details or private API credentials.");
        legalSection(page,"Developer and owner","USHA IT • © 2026 USHA IT. All Rights Reserved.");
        addScroll(page);
    }

    private void showLicenses(boolean pushHistory) {
        if(pushHistory) push("licenses"); entertainmentContext=false; screen="licenses"; clearContent();
        LinearLayout page=page(); page.addView(selectedSectionBar("Licenses & Attributions",false));
        page.addView(sectionLabel("Third-party acknowledgements","Ownership remains with each respective provider."));
        legalSection(page,"Data and media providers","Sports data, news metadata, entertainment catalogues, images, logos and video streams may be supplied by third-party providers. Attribution and permitted-use notices are displayed or maintained according to each provider's requirements. Availability depends on active, authorized integrations.");
        legalSection(page,"SportScore & Cricsheet","Live fixtures and scores: SportScore (subject to provider terms). Historical completed-cricket records, when imported: Cricsheet.org, ODC-BY 1.0 (https://cricsheet.org/licensing/). Statistics are transformed by OneTV; Cricsheet does not endorse OneTV.");
        legalSection(page,"Software components","OneTV uses third-party Android libraries and services. Their respective copyright and license terms remain applicable. A complete component/license inventory should be generated from the release dependency manifest before public distribution.");
        legalSection(page,"USHA IT","OneTV is developed and owned by USHA IT. © 2026 USHA IT. All Rights Reserved.");
        addScroll(page);
    }

    private void clearContent() {
        hideVolumeSlider();
        if(contentHost!=null)contentHost.removeAllViews();
        if(statusText!=null)statusText=null;
        updateTopNavigation();
    }

    private LinearLayout page() {
        LinearLayout p=new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundColor(BG);
        return p;
    }

    private void scheduleSportsAutoRefresh() {
        handler.removeCallbacks(sportsRefreshTask);
        handler.postDelayed(sportsRefreshTask, sportsRefreshMs);
    }

    private void stopSportsAutoRefresh() {
        handler.removeCallbacks(sportsRefreshTask);
        activeSportsPage = null;
    }

    private void addSportsRefreshScroll(LinearLayout page, Runnable refreshAction) {
        contentHost.removeAllViews();
        SwipeRefreshLayout swipe = new SwipeRefreshLayout(this);
        swipe.setColorSchemeColors(BLUE);
        swipe.setOnRefreshListener(() -> {
            refreshAction.run();
            handler.postDelayed(() -> swipe.setRefreshing(false), 700);
        });
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));
        swipe.addView(scroll, new SwipeRefreshLayout.LayoutParams(-1, -1));
        contentHost.addView(swipe, new FrameLayout.LayoutParams(-1, -1));
    }

    private void addScroll(LinearLayout page) {
        contentHost.removeAllViews();
        page.setPadding(page.getPaddingLeft(),page.getPaddingTop(),page.getPaddingRight(),dp(14));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));

        // Global pull-to-refresh is enabled throughout ONE TV except the Entertainment sector.
        // Sports pages use their dedicated refresh wrapper, while this wrapper covers Home and
        // all other non-entertainment scrollable screens.
        if (!entertainmentContext) {
            SwipeRefreshLayout swipe = new SwipeRefreshLayout(this);
            swipe.setColorSchemeColors(BLUE);
            swipe.setOnRefreshListener(() -> {
                refreshCurrentNonEntertainmentScreen();
                handler.postDelayed(() -> swipe.setRefreshing(false), 700);
            });
            swipe.addView(scroll, new SwipeRefreshLayout.LayoutParams(-1, -1));
            contentHost.addView(swipe, new FrameLayout.LayoutParams(-1, -1));
        } else {
            contentHost.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        }
    }

    private void refreshCurrentNonEntertainmentScreen() {
        if (entertainmentContext) return;
        if ("home".equals(screen)) {
            showHome(false);
        } else if ("news".equals(screen)) {
            showNews(false);
        } else if ("notifications".equals(screen)) {
            showNotifications(false);
        } else if ("settings".equals(screen)) {
            showSettings(false);
        } else if ("playback".equals(screen)) {
            showPlaybackSettings(false);
        } else if ("search".equals(screen)) {
            showSearch(false, "", lastSearchQuery);
        } else if ("match".equals(screen)) {
            showMatchDetail(false);
        } else if ("menu".equals(screen)) {
            showMenuPage(false);
        } else if ("favorites".equals(screen)) {
            showFavorites(false);
        } else if ("support".equals(screen)) {
            showSupport(false);
        }
    }

    private LinearLayout modeRow() {
        LinearLayout row=new LinearLayout(this);
        row.setPadding(dp(10),dp(5),dp(10),dp(5));
        TextView s=modeButton("SPORTS",BLUE); s.setOnClickListener(v->showSportsHome(true));
        TextView e=modeButton("PHOTOS",PURPLE); e.setOnClickListener(v->showEntertainment("Explore",true));
        TextView n=modeButton("NEWS",GREEN); n.setOnClickListener(v->showNews(true));
        TextView[] buttons={s,e,n};
        for(TextView b:buttons){LinearLayout.LayoutParams lp=weighted();lp.height=dp(46);lp.setMargins(dp(4),0,dp(4),0);row.addView(b,lp);}
        return row;
    }

    private TextView sportsProviderAttribution() {
        TextView t=tv("Powered by SportScore",9,MUTED,false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0,dp(2),0,dp(4));
        t.setContentDescription("Sports data provider attribution");
        return t;
    }

    private View selectedSectionBar(String name, boolean entertainment) {
        LinearLayout bar=new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(18),dp(7),dp(18),dp(4));
        boolean sportsSection = !entertainment && (
                "Cricket".equalsIgnoreCase(name) || "Football".equalsIgnoreCase(name)
                        || "Basketball".equalsIgnoreCase(name) || "Tennis".equalsIgnoreCase(name)
                        || "Series".equalsIgnoreCase(name) || "Teams".equalsIgnoreCase(name)
                        || "Players".equalsIgnoreCase(name) || "Venues".equalsIgnoreCase(name)
                        || "Competitions".equalsIgnoreCase(name) || "Leagues".equalsIgnoreCase(name)
                        || "Standings".equalsIgnoreCase(name) || "H2H".equalsIgnoreCase(name)
                        || "Tournaments".equalsIgnoreCase(name) || "Rankings".equalsIgnoreCase(name)
                        || "Draws".equalsIgnoreCase(name) || "Highlights".equalsIgnoreCase(name));
        if(sportsSection){
            TextView icon=tv(sportGlyph(name),22,TEXT,false);
            icon.setGravity(Gravity.CENTER);
            bar.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(44)));
        } else if(entertainment){
            TextView icon=tv("▣",20,TEXT,false);
            icon.setGravity(Gravity.CENTER);
            bar.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(44)));
        }
        TextView title=tv(name,20,TEXT,true);
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title,new LinearLayout.LayoutParams(0,dp(44),1));
        return bar;
    }

    private String sportGlyph(String name){
        if(name==null)return "◈";
        if(name.equalsIgnoreCase("Cricket"))return "◉";
        if(name.equalsIgnoreCase("Football"))return "●";
        if(name.equalsIgnoreCase("Basketball"))return "◌";
        if(name.equalsIgnoreCase("Tennis"))return "◍";
        return "◇";
    }

    // OneTV final responsive filter tabs: centre ICON + GAP + LABEL as a single
    // group. A TextView compound drawable is anchored at the edge, while the
    // text is centred independently; that was the original misalignment.
    // This component is shared by Sports Home and all four sport front pages.
    private FrameLayout sportsModeTab(String mode, boolean selected) {
        final String name = "live".equalsIgnoreCase(mode) ? "Live" :
                "upcoming".equalsIgnoreCase(mode) ? "Upcoming" : "Results";
        final int iconRes = "live".equalsIgnoreCase(mode) ? R.drawable.ic_score_live :
                "upcoming".equalsIgnoreCase(mode) ? R.drawable.ic_score_upcoming :
                        R.drawable.ic_score_results;
        final int windowDp = getResources().getConfiguration().screenWidthDp;
        final int iconDp = 20;
        final int gapDp = 6; // Exactly the same for Live / Upcoming / Results.
        final float labelSp = windowDp <= 320 ? 12.5f :
                windowDp < 360 ? 13.0f : 13.7f;
        final int foreground = selected ? TEXT : MUTED;

        FrameLayout button = new FrameLayout(this);
        button.setBackground(round(selected ? BLUE : CARD, 15));
        button.setClipChildren(true);
        button.setClipToPadding(true);
        button.setMinimumWidth(0);
        button.setTag(mode.toLowerCase(Locale.US));
        button.setSelected(selected);
        button.setContentDescription(name + " matches");
        button.setFocusable(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.HORIZONTAL);
        content.setGravity(Gravity.CENTER_VERTICAL);
        content.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        content.setClipChildren(true);
        content.setClipToPadding(true);

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(foreground);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        content.addView(icon, new LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)));

        TextView label = tv(name, labelSp, foreground, true);
        label.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        label.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY);
        label.setSingleLine(true);
        label.setIncludeFontPadding(false);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        label.setMinWidth(0);
        label.setPadding(0, 0, 0, 0);
        LinearLayout.LayoutParams labelParams =
                new LinearLayout.LayoutParams(-2, -2);
        labelParams.leftMargin = dp(gapDp);
        content.addView(label, labelParams);

        // WRAP_CONTENT content sits at the exact visual centre of the button.
        FrameLayout.LayoutParams groupParams =
                new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
        button.addView(content, groupParams);

        // Limit the text based on the *measured* button, not screen width.
        // Large accessibility fonts and split-screen cannot push one label
        // into the adjacent filter button; only the label may ellipsize.
        button.addOnLayoutChangeListener((view, left, top, right, bottom,
                                          oldLeft, oldTop, oldRight, oldBottom) -> {
            int labelMax = Math.max(dp(20), right - left - dp(iconDp + gapDp + 8));
            if (label.getMaxWidth() != labelMax) label.setMaxWidth(labelMax);
        });
        return button;
    }

    private void updateSportsModeTabSelection(LinearLayout tabs, String selected) {
        for (int i = 0; i < tabs.getChildCount(); i++) {
            View button = tabs.getChildAt(i);
            if (!(button instanceof FrameLayout)) continue;
            boolean active = selected.equalsIgnoreCase(String.valueOf(button.getTag()));
            button.setBackground(round(active ? BLUE : CARD, 15));
            button.setSelected(active);
            if (((FrameLayout) button).getChildCount() < 1) continue;
            View child = ((FrameLayout) button).getChildAt(0);
            if (!(child instanceof LinearLayout)) continue;
            LinearLayout contents = (LinearLayout) child;
            if (contents.getChildCount() < 2) continue;
            if (contents.getChildAt(0) instanceof ImageView)
                ((ImageView) contents.getChildAt(0)).setColorFilter(active ? TEXT : MUTED);
            if (contents.getChildAt(1) instanceof TextView)
                ((TextView) contents.getChildAt(1)).setTextColor(active ? TEXT : MUTED);
        }
    }

    private LinearLayout modeTabs(LinearLayout page, String sport, String[] modes) {
        LinearLayout row = new LinearLayout(this);
        row.setPadding(dp(10), dp(4), dp(10), dp(8));
        for (String mode : modes) {
            FrameLayout button = sportsModeTab(mode, mode.equalsIgnoreCase(matchMode));
            button.setOnClickListener(v -> {
                matchMode = mode.toLowerCase(Locale.US);
                remoteMatches = null;
                updateSportsModeTabSelection(row, mode);
                renderSportList(page, sport);
                activeSportsPage = page;
                activeSportsHome = false;
                loadSportsFromBackend(sport, matchMode, page);
                scheduleSportsAutoRefresh();
            });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(50), 1f);
            params.setMargins(dp(4), 0, dp(4), 0);
            row.addView(button, params);
        }
        return row;
    }

    private View sectionLabel(String title, String sub) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(18), dp(8), dp(18), dp(6));
        TextView t = tv(title, 18, TEXT, true);
        TextView s = tv(sub, 10, MUTED, false);
        wrap.addView(t);
        if (sub != null && !sub.isEmpty()) wrap.addView(s);
        return wrap;
    }

    private TextView modeButton(String label,int accent) {
        TextView b=tv(label,14,TEXT,true);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setBackground(round(CARD,18));
        b.setPadding(0,0,0,0);
        return b;
    }

    private LinearLayout featureTile(String icon,String name,int accent) {
        LinearLayout c=new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setMinimumHeight(dp(62));
        c.setPadding(dp(1),dp(2),dp(1),dp(2));
        c.setBackground(round(CARD_2,12));
        TextView i=tv(icon,20,TEXT,false);
        i.setGravity(Gravity.CENTER);
        TextView n=tv(name,10.5f,TEXT,true);
        n.setGravity(Gravity.CENTER);
        n.setSingleLine(true);
        n.setEllipsize(android.text.TextUtils.TruncateAt.END);
        c.addView(i,new LinearLayout.LayoutParams(-1,dp(29)));
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(16));
        np.setMargins(dp(1),dp(1),dp(1),0);
        c.addView(n,np);
        LinearLayout.LayoutParams p=weighted();
        p.setMargins(dp(5),0,dp(5),0);
        c.setLayoutParams(p);
        return c;
    }

    private LinearLayout.LayoutParams featureTileParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(62), 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        return p;
    }

    private LinearLayout homeSearchBox() {
        LinearLayout wrap=new LinearLayout(this);
        wrap.setGravity(Gravity.CENTER_VERTICAL);
        wrap.setPadding(dp(14),0,dp(8),0);
        GradientDrawable bg=round(CARD,15);
        bg.setStroke(dp(1),Color.argb(darkTheme()?42:28,255,255,255));
        wrap.setBackground(bg);

        EditText input=new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setHint("Search OneTV");
        input.setContentDescription("Search matches, teams, players and news");
        input.setTextSize(14f);
        input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        input.setPadding(0,0,dp(6),0);
        input.setBackgroundColor(Color.TRANSPARENT);
        wrap.addView(input,new LinearLayout.LayoutParams(0,dp(46),1));

        ImageButton button=new ImageButton(this);
        button.setImageResource(R.drawable.ic_search);
        button.setColorFilter(TEXT,android.graphics.PorterDuff.Mode.SRC_IN);
        button.setScaleType(ImageView.ScaleType.CENTER);
        button.setPadding(dp(7),dp(7),dp(7),dp(7));
        button.setBackgroundColor(Color.TRANSPARENT);
        button.setContentDescription("Search");
        wrap.addView(button,new LinearLayout.LayoutParams(dp(38),dp(38)));

        View.OnClickListener go=v->{
            String q=input.getText().toString().trim();
            showSearch(true,"all",q);
        };
        button.setOnClickListener(go);
        input.setOnEditorActionListener((v,action,event)->{
            if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){go.onClick(v);return true;}
            return false;
        });

        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));
        lp.setMargins(dp(14),dp(2),dp(14),dp(8));
        wrap.setLayoutParams(lp);
        return wrap;
    }

    private LinearLayout scoreTeam(String flag,String name,String score) {
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setGravity(Gravity.CENTER);
        b.addView(tv(flag,18,TEXT,false));
        b.addView(tv(name,14,TEXT,true));
        b.addView(tv(score,14,TEXT,true));
        return b;
    }

    private LinearLayout channelTile(String name) {
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);
        c.setPadding(dp(4),dp(8),dp(4),dp(8));c.setBackground(round(CARD,10));
        TextView icon=tv("▣",22,BLUE,true);icon.setGravity(Gravity.CENTER);
        TextView n=tv(name,9,TEXT,true);n.setGravity(Gravity.CENTER);n.setMaxLines(2);
        c.addView(icon,new LinearLayout.LayoutParams(-1,dp(32)));c.addView(n);
        return c;
    }

    private LinearLayout menuAction(String icon, String title, String subtitle, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(13), dp(12), dp(13), dp(12));
        row.setBackground(round(CARD, 14));
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(click);
        TextView ico = tv(icon, 22, TEXT, false);
        ico.setGravity(Gravity.CENTER);
        row.addView(ico, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(4), 0, dp(6), 0);
        TextView t = tv(title, 14, TEXT, true);
        t.setMaxLines(2);
        TextView st = tv(subtitle, 10, MUTED, false);
        st.setMaxLines(2);
        info.addView(t);
        info.addView(st);
        row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        TextView arrow = tv("›", 24, MUTED, false);
        arrow.setGravity(Gravity.CENTER);
        row.addView(arrow, new LinearLayout.LayoutParams(dp(30), dp(48)));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.setMargins(dp(12), 0, dp(12), dp(8));
        row.setLayoutParams(rp);
        return row;
    }

    private LinearLayout contentRow(String title,String type) {
        LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(12),dp(9),dp(12),dp(9));r.setBackground(round(CARD,12));
        TextView icon=tv(type.equals("News")?"▤":"▶",20,TEXT,false);r.addView(icon,new LinearLayout.LayoutParams(dp(45),dp(45)));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.addView(tv(title,13,TEXT,true));info.addView(tv(type+" • ONE TV",10,MUTED,false));
        r.addView(info,new LinearLayout.LayoutParams(0,-2,1));r.addView(tv("›",24,MUTED,false));
        return r;
    }

    private TextView tab(String label,boolean active) {
        TextView b=tv(label,12.5f,active?TEXT:MUTED,true);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setMinWidth(dp(78));
        b.setBackground(round(active?BLUE:CARD,18));
        b.setPadding(dp(10),0,dp(10),0);
        return b;
    }

    private Button smallButton(String label,int color) {
        Button b=new Button(this);b.setText(label);b.setTextSize(10);b.setTextColor(TEXT);b.setAllCaps(false);b.setMinHeight(0);b.setMinWidth(0);b.setPadding(dp(12),0,dp(12),0);b.setBackground(round(color,18));return b;
    }

    private TextView eventRow(String value,int n) {
        TextView t=tv(value,12,TEXT,false);t.setPadding(dp(12),dp(11),dp(12),dp(11));t.setBackground(round(CARD,12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(6));t.setLayoutParams(p);return t;
    }

    private View statCard(String title,String value,String sub) {
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(13),dp(10),dp(13),dp(10));r.setBackground(round(CARD,12));
        r.addView(tv(title,10,MUTED,true));r.addView(tv(value,16,TEXT,true));r.addView(tv(sub,10,MUTED,false));return r;
    }

    private LinearLayout tableBox() {
        LinearLayout t=new LinearLayout(this);t.setOrientation(LinearLayout.VERTICAL);t.setBackground(round(CARD,12));return t;
    }

    private LinearLayout tableRow(String[] values,boolean header) {
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(6),dp(6),dp(6),dp(6));
        for(int i=0;i<values.length;i++){TextView v=tv(values[i],header?8.5f:9.5f,header?MUTED:TEXT,header);v.setGravity(i==0?Gravity.LEFT:Gravity.CENTER);row.addView(v,new LinearLayout.LayoutParams(0,dp(32),i==0?2.3f:1));}
        row.setBackgroundColor(header?Color.rgb(25,45,59):Color.TRANSPARENT);return row;
    }

    private LinearLayout detailRow(String left,String right) {
        LinearLayout r=new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(12),dp(9),dp(12),dp(9));
        r.setBackground(round(CARD,10));
        TextView l=tv(left,11.5f,TEXT,true);
        l.setSingleLine(true);
        l.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView rr=tv(right,11.5f,MUTED,false);
        rr.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        rr.setMaxLines(3);
        rr.setEllipsize(android.text.TextUtils.TruncateAt.END);
        r.addView(l,new LinearLayout.LayoutParams(0,-2,0.34f));
        r.addView(rr,new LinearLayout.LayoutParams(0,-2,0.66f));
        return r;
    }

    private LinearLayout.LayoutParams marginBottomParams(int dp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, this.dp(dp));
        return p;
    }

    private LinearLayout.LayoutParams weighted() { return new LinearLayout.LayoutParams(0, -2, 1); }

    private JSONObject team(JSONObject m, boolean home) {
        String side = home ? "home" : "away";
        JSONObject t = m.optJSONObject(side);
        if(t == null) t = m.optJSONObject(side + "Team");
        if(t == null) t = m.optJSONObject(home ? "home_team" : "away_team");
        if(t != null) return t;
        JSONArray teams = m.optJSONArray("teams");
        if(teams != null && teams.length() >= 2) {
            JSONObject x = teams.optJSONObject(home ? 0 : 1);
            if(x != null) return x;
        }
        JSONObject raw = rawProvider(m);
        t = raw.optJSONObject(side);
        if(t == null) t = raw.optJSONObject(home ? "home_team" : "away_team");
        if(t != null) return t;
        JSONArray participants = raw.optJSONArray("participants");
        if(participants != null && participants.length() >= 2) {
            JSONObject x = participants.optJSONObject(home ? 0 : 1);
            if(x != null) return x;
        }
        return new JSONObject();
    }

    private String sportName(String s) {
        if(s==null)return "Sports";
        if("football".equalsIgnoreCase(s)||"soccer".equalsIgnoreCase(s))return "Football";
        if("basketball".equalsIgnoreCase(s))return "Basketball";
        if("tennis".equalsIgnoreCase(s))return "Tennis";
        if("baseball".equalsIgnoreCase(s))return "Baseball";
        return "Cricket";
    }

    private void push(String state) {
        if(screen==null || screen.equals(state) || "onboarding".equals(screen))return;
        String from=screen;
        if("sport".equals(from))from="sport:"+selectedSport;
        else if("entertainment".equals(from))from="ent:Explore";
        else if("entCollection".equals(from))from="entCollection";
        else if("directory".equals(from))from="directory:"+selectedSportsDirectorySport+":"+selectedSportsDirectorySection;
        history.push(from);
    }


    @Override public void onBackPressed() {
        if("onboarding".equals(screen)){finishOnboarding();return;}
        if(fullscreen){exitFullscreen();return;}
        if("menu".equals(screen) && menuDrawer != null){
            closeMenuDrawer(true);
            return;
        }
        if(!history.empty()){
            String prev=history.pop();
            if("home".equals(prev))showHome(false);
            else if("sportsHome".equals(prev))showSportsHome(false);
            else if("news".equals(prev))showNews(false);
            else if("newsDetail".equals(prev) && lastOpenedNews!=null)openNewsDetail(lastOpenedNews);
            else if("entertainment".equals(prev))showEntertainment("Explore",false);
            else if("entCollection".equals(prev))showEntertainmentCollection(selectedEntertainment,false);
            else if("photos".equals(prev))showEntertainmentPhotos(false);
            else if("entItem".equals(prev))showEntertainmentCollection(selectedEntertainment,false);
            else if("account".equals(prev))showUserAccount(false);
            else if("history".equals(prev))showHistory(false);
            else if("reminders".equals(prev))showReminders(false);
            else if("downloads".equals(prev))showDownloads(false);
            else if("dataSaver".equals(prev))showDataSaver(false);
            else if("language".equals(prev))showLanguage(false);
            else if("notificationSettings".equals(prev))showNotificationSettings(false);
            else if("onboarding".equals(prev))finishOnboarding();
            else if(prev.startsWith("sport:"))showSports(prev.substring(6),false);
            else if(prev.startsWith("ent:"))showEntertainment(prev.substring(4),false);
            else if("match".equals(prev)&&selectedMatch!=null)showMatchDetail(false);
            else if("cricsheetArchive".equals(prev))showCricsheetHistory(false);
            else if("cricsheetArchiveDetail".equals(prev)&&selectedMatch!=null)
                showCricsheetArchiveDetail(selectedMatch,false);
            else if("notifications".equals(prev))showNotifications(false);
            else if("favorites".equals(prev))showFavorites(false);
            else if("support".equals(prev))showSupport(false);
            else if("about".equals(prev))showAboutOneTv(false);
            else if("privacy".equals(prev))showPrivacyPolicy(false);
            else if("terms".equals(prev))showTermsOfUse(false);
            else if("licenses".equals(prev))showLicenses(false);
            else if("appearance".equals(prev))showSettings(false);
            else if("settings".equals(prev))showSettings(false);
            else if("playback".equals(prev))showSettings(false);
            else if("comingSoon".equals(prev))showHome(false);
            else if("search".equals(prev))showSearch(false,"all");
            else if(prev.startsWith("content:"))showContentDetail(prev.substring(8),"Entertainment",false);
            else if(prev.startsWith("team:"))showSportsDirectory(selectedSportsDirectorySport,"Teams",false);
            else if("teamDetail".equals(prev))showSportsDirectory(selectedSportsDirectorySport,"Teams",false);
            else if(prev.startsWith("directory:")){
                String[] parts=prev.split(":",3);
                if(parts.length==3)showSportsDirectory(parts[1],parts[2],false); else showSportsHome(false);
            }
            else showHome(false);
        }else super.onBackPressed();
    }

    private void exitFullscreen() {
        if(fullscreen) toggleFullscreen();
    }

    private void toggleFullscreen() {
        if (playerFrame == null) return;
        ViewGroup decor = (ViewGroup) getWindow().getDecorView();
        if (!fullscreen) {
            playerOriginalParent = (ViewGroup) playerFrame.getParent();
            playerOriginalIndex = playerOriginalParent == null ? 0 : playerOriginalParent.indexOfChild(playerFrame);
            if (playerOriginalParent != null) playerOriginalParent.removeView(playerFrame);
            decor.addView(playerFrame, new ViewGroup.LayoutParams(-1, -1));
            playerFrame.setVisibility(View.VISIBLE);
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            if (adRow != null) adRow.setVisibility(View.GONE);
            if (footer != null) footer.setVisibility(View.GONE);
            fullscreen = true;
        } else {
            decor.removeView(playerFrame);
            if (playerOriginalParent != null) {
                playerOriginalParent.addView(playerFrame, Math.min(playerOriginalIndex, playerOriginalParent.getChildCount()),
                        new LinearLayout.LayoutParams(-1, dp(260)));
            }
            getWindow().getDecorView().setSystemUiVisibility(0);
            if (footer != null) footer.setVisibility(View.VISIBLE);
            fullscreen = false;
            updateFooterAdVisibility();
        }
    }

    private void updateFooterAdVisibility() {
        if (adRow == null) return;
        // GONE removes the full 84dp ad slot from LinearLayout measurement;
        // contentHost's weight=1 automatically reclaims the released pixels.
        boolean visible = footerAdLoaded && footerAdPlatformEnabled
                && !footerAdSuppressed && !fullscreen;
        adRow.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    private void hideAds(boolean hide) {
        footerAdSuppressed = hide;
        updateFooterAdVisibility();
        if (footer != null) footer.setVisibility(hide ? View.GONE : View.VISIBLE);
    }


    private TextView tv(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(android.graphics.Typeface.DEFAULT,bold?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL);t.setIncludeFontPadding(false);return t;}

    private GradientDrawable round(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}

    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}

    private LinearLayout.LayoutParams weightedLp(){return new LinearLayout.LayoutParams(0,-2,1);}

    private JSONObject getJson(String url){try{return new JSONObject(getUrl(url));}catch(Exception e){return new JSONObject();}}

    private String getUrl(String address)throws Exception{
        return getUrl(address, 10000);
    }

    private String getUrl(String address,int readTimeoutMs)throws Exception{
        HttpURLConnection c=null;
        try{
            URL u=new URL(address);c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(8000);c.setReadTimeout(readTimeoutMs);c.setRequestMethod("GET");
            int code=c.getResponseCode();
            InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
            if(in==null)throw new Exception("HTTP "+code);
            BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder sb=new StringBuilder();String line;
            while((line=r.readLine())!=null)sb.append(line);
            return sb.toString();
        }finally{if(c!=null)c.disconnect();}
    }

    private static class Channel {
        int id; String name,url,program,category,country; boolean connected;
        Channel(int i,String n,String u,String p,String cat,String ctry,boolean ok){id=i;name=n;url=u;program=p;category=cat;country=ctry;connected=ok;}
    }

    @Override protected void onResume(){
        super.onResume();
        if (!footerAdLoaded && footerAdView != null && footerAdPlatformEnabled) {
            handler.removeCallbacks(footerAdRetry);
            handler.postDelayed(footerAdRetry,90_000L);
        }
        if(activeSportsPage!=null && ("sportsHome".equals(screen) || "sport".equals(screen))) scheduleSportsAutoRefresh();
        if ("home".equals(screen) && featuredHomeMatches.size()>1 && startupCompleted) {
            handler.removeCallbacks(homeFeaturedRotation);
            handler.postDelayed(homeFeaturedRotation,6500L);
        }
    }

    @Override protected void onPause(){
        stopOpeningSound();
        handler.removeCallbacks(footerAdRetry);
        handler.removeCallbacks(sportsRefreshTask);
        handler.removeCallbacks(homeFeaturedRotation);
        super.onPause();
    }

    @Override protected void onDestroy(){
        stopOpeningSound();
        handler.removeCallbacksAndMessages(null);
        playerUiHandler.removeCallbacksAndMessages(null);
        network.shutdownNow();
        homeNetwork.shutdownNow();
        if(player!=null){player.release();player=null;}
        if(footerAdView!=null){footerAdView.destroy();footerAdView=null;}
        super.onDestroy();
    }

    private void showOnboarding() {
        screen="onboarding";
        clearContent();
        if(headerView!=null)headerView.setVisibility(View.GONE);
        if(topNavigation!=null)topNavigation.setVisibility(View.GONE);
        if(fixedBottom!=null)fixedBottom.setVisibility(View.GONE);
        LinearLayout page=page();
        page.setBackgroundColor(Color.rgb(4,10,26));
        page.setPadding(dp(20), dp(30), dp(20), dp(24));
        Space topSpace=new Space(this);
        page.addView(topSpace, new LinearLayout.LayoutParams(-1, 0, 1));
        ImageView brand=new ImageView(this);
        brand.setImageResource(R.drawable.onetv_logo);
        brand.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams brandLp=new LinearLayout.LayoutParams(-1, dp(130));
        page.addView(brand,brandLp);
        TextView title=tv("Watch Live Sports, Movies, TV & Latest News",24,TEXT,true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(dp(8),dp(25),dp(8),dp(10));
        page.addView(title);
        TextView copy=tv("Explore real match scores, licensed entertainment and trusted news in one app.",12,MUTED,false);
        copy.setGravity(Gravity.CENTER);
        copy.setPadding(dp(16),0,dp(16),dp(18));
        page.addView(copy);
        TextView dots=tv("●  ○  ○",12,BLUE,true);
        dots.setGravity(Gravity.CENTER);
        page.addView(dots);
        Space lower=new Space(this);
        page.addView(lower,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout actions=new LinearLayout(this);
        actions.setGravity(Gravity.CENTER);
        TextView skip=tv("Skip",13,TEXT,true);
        skip.setGravity(Gravity.CENTER);
        skip.setBackground(round(CARD,22));
        skip.setOnClickListener(v->finishOnboarding());
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(48),1);
        sp.setMargins(0,0,dp(10),0);
        actions.addView(skip,sp);
        TextView next=tv("Continue",13,Color.WHITE,true);
        next.setGravity(Gravity.CENTER);
        next.setBackground(round(BLUE,22));
        next.setOnClickListener(v->finishOnboarding());
        actions.addView(next,new LinearLayout.LayoutParams(0,dp(48),1));
        page.addView(actions);
        addScroll(page);
    }

    private void finishOnboarding() {
        prefs.edit().putBoolean("onetv_onboarding_complete",true).apply();
        if(headerView!=null)headerView.setVisibility(View.VISIBLE);
        if(fixedBottom!=null)fixedBottom.setVisibility(View.VISIBLE);
        updateFooterAdVisibility();
        showHome(false);
    }

    private void showEntertainmentCollection(String category, boolean push) {
        entertainmentContext=true;
        if(push) push("ent:"+category);
        selectedEntertainment=category;
        screen="entCollection";
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar(category,true));
        String type = "Movies".equals(category) || "TV & Series".equals(category) ||
                "Music".equals(category) || "Celebrity".equals(category) ||
                "Live Events".equals(category) ? category : "Trending";
        page.addView(sectionLabel(type, "Licensed/provider-supplied content only"));
        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(14),0,dp(14),dp(20));
        page.addView(list);
        list.addView(homeSmallState("Checking authorized provider catalogue…"));
        addScroll(page);
        if(!remoteDataEnabled || BACKEND_URL==null || BACKEND_URL.contains("REPLACE")) {
            list.removeAllViews();
            list.addView(emptyStateCard("Catalogue unavailable","Connect an authorized entertainment source."));
            return;
        }
        network.execute(()->{
            JSONArray all=new JSONArray();
            try {
                JSONObject p=new JSONObject(getUrl(BACKEND_URL+"/media?type=photo&limit=100"));
                JSONArray items=p.optJSONArray("items");
                if(items!=null) for(int i=0;i<items.length();i++) all.put(items.opt(i));
            }catch(Exception ignored){}
            try {
                JSONObject p=new JSONObject(getUrl(BACKEND_URL+"/media?type=video&limit=100"));
                JSONArray items=p.optJSONArray("items");
                if(items!=null) for(int i=0;i<items.length();i++) all.put(items.opt(i));
            }catch(Exception ignored){}
            runOnUiThread(()->{
                if(!"entCollection".equals(screen) || !category.equals(selectedEntertainment))return;
                list.removeAllViews();
                int count=0;
                for(int i=0;i<all.length();i++){
                    JSONObject item=all.optJSONObject(i);
                    if(item==null || !entertainmentCategoryMatch(category,item))continue;
                    list.addView(authorizedEntertainmentCard(item),marginBottomParams(10));
                    count++;
                }
                if(count==0) list.addView(emptyStateCard("Nothing licensed available",
                        "No verified "+category.toLowerCase(Locale.US)+" content is available from the configured provider."));
            });
        });
    }

    private boolean entertainmentCategoryMatch(String category,JSONObject x){
        String kind=pickText(x,"category").toLowerCase(Locale.US);
        if("Trending".equals(category)) return true;
        if("Movies".equals(category))return kind.contains("movie") || kind.contains("film") || kind.contains("trailer");
        if("TV & Series".equals(category))return kind.contains("series") || kind.contains("episode") || kind.contains("television");
        if("Music".equals(category))return kind.contains("music") || kind.contains("song") || kind.contains("concert");
        if("Celebrity".equals(category))return kind.contains("celebrity") || kind.contains("artist") || kind.contains("creator");
        if("Live Events".equals(category))return kind.contains("event") || kind.contains("live entertainment");
        return false;
    }

    private View entertainmentTile(String icon, String label,int[] gradient,View.OnClickListener click){
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(8),dp(9),dp(8),dp(9));
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,gradient);
        bg.setCornerRadius(dp(13));
        card.setBackground(bg);
        TextView glyph=tv(icon,29,Color.WHITE,true);
        glyph.setGravity(Gravity.CENTER);
        card.addView(glyph);
        TextView title=tv(label,11,Color.WHITE,true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0,dp(4),0,0);
        card.addView(title);
        card.setOnClickListener(click);
        card.setContentDescription(label);
        card.setFocusable(true);
        return card;
    }

    private View authorizedEntertainmentCard(JSONObject item){
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(10),dp(10),dp(10),dp(10));
        card.setBackground(round(CARD,14));
        String image=pickText(item,"thumbnail_url","media_url");
        ImageView poster=new ImageView(this);
        poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        poster.setBackground(round(CARD_2,10));
        card.addView(poster,new LinearLayout.LayoutParams(dp(90),dp(98)));
        if(isValidProviderImageUrl(image))loadProviderPhoto(poster,image);
        LinearLayout info=new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(12),0,0,0);
        info.addView(tv(pickText(item,"title"),14,TEXT,true));
        String category=pickText(item,"category","media_type");
        if(!category.isEmpty())info.addView(tv(category,10,CYAN,true));
        String credit=pickText(item,"source_name");
        if(!credit.isEmpty())info.addView(tv(credit,9,MUTED,false));
        card.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        card.setOnClickListener(v->showEntertainmentItem(item,true));
        return card;
    }

    private void showEntertainmentItem(JSONObject item,boolean push) {
        if(item==null)return;
        if(push)push("entItem");
        screen="entItem";
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar(pickText(item,"category","media_type"),true));
        String image=pickText(item,"thumbnail_url","media_url");
        if(isValidProviderImageUrl(image)) {
            ImageView art=new ImageView(this);
            art.setScaleType(ImageView.ScaleType.CENTER_CROP);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(225));
            lp.setMargins(dp(14),dp(8),dp(14),dp(10));
            page.addView(art,lp);
            loadProviderPhoto(art,image);
        }
        page.addView(sectionLabel(pickText(item,"title"),pickText(item,"category","media_type")));
        String desc=pickText(item,"description");
        if(!desc.isEmpty()){
            TextView t=tv(desc,12,TEXT,false);
            t.setPadding(dp(18),dp(4),dp(18),dp(12));
            page.addView(t);
        }
        String provider=pickText(item,"source_name","provider_key");
        if(!provider.isEmpty())page.addView(detailRow("Provider",provider));
        String rights=pickText(item,"rights_status");
        if(!rights.isEmpty())page.addView(detailRow("License",rights));
        String url=pickText(item,"source_url");
        if(isValidProviderImageUrl(url))page.addView(menuAction("↗","Original source","View the licensed content source",v->openExternalSource(url)));
        page.addView(emptyStateCard("Playback availability","Media playback requires a validated playable manifest and rights-enabled player integration; no unauthorized stream will be started."));
        addScroll(page);
    }

    private void openExternalSource(String url) {
        try {
            if(!isValidProviderImageUrl(url))return;
            Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(url));
            startActivity(intent);
        }catch(Exception ignored){android.widget.Toast.makeText(this,"Source cannot be opened",android.widget.Toast.LENGTH_SHORT).show();}
    }

    private void showUserAccount(boolean push) {
        if(push)push("account");
        screen="account";
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar("My Account",false));
        TextView avatar=tv("◉",42,TEXT,true);
        avatar.setGravity(Gravity.CENTER);
        avatar.setPadding(0,dp(25),0,dp(7));
        page.addView(avatar);
        TextView guest=tv("Guest",19,TEXT,true);
        guest.setGravity(Gravity.CENTER);
        page.addView(guest);
        TextView description=tv("Browse without an account. Optional cloud sync is not configured in this build.",10,MUTED,false);
        description.setGravity(Gravity.CENTER);
        description.setPadding(dp(24),dp(7),dp(24),dp(20));
        page.addView(description);
        page.addView(menuAction("★","My Favorites","Saved provider-backed matches",v->showFavorites(true)));
        page.addView(menuAction("◷","Watch History","Items opened in this app",v->showHistory(true)));
        page.addView(menuAction("♧","Reminders","Upcoming events saved on this device",v->showReminders(true)));
        page.addView(menuAction("⚙","Settings","Preferences and privacy",v->showSettings(true)));
        addScroll(page);
    }

    private void rememberOpenedItem(String kind,String title,String id) {
        if(prefs==null || title==null || title.trim().isEmpty())return;
        try {
            JSONObject item=new JSONObject();
            item.put("kind",kind);item.put("title",title);item.put("id",id);
            item.put("openedAt",System.currentTimeMillis());
            JSONArray old=new JSONArray(prefs.getString("onetv_history","[]"));
            JSONArray list=new JSONArray();list.put(item);
            for(int i=0;i<old.length() && list.length()<40;i++) {
                JSONObject entry=old.optJSONObject(i);
                if(entry==null || (kind.equals(entry.optString("kind")) && id.equals(entry.optString("id"))))continue;
                list.put(entry);
            }
            prefs.edit().putString("onetv_history",list.toString()).apply();
        }catch(Exception ignored){}
    }

    private void showHistory(boolean push) {
        if(push)push("history");
        screen="history";
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar("History",false));
        page.addView(sectionLabel("Recently Viewed","Actual items opened on this device"));
        try {
            JSONArray rows=new JSONArray(prefs.getString("onetv_history","[]"));
            if(rows.length()==0) page.addView(emptyStateCard("No history yet","Items you open will appear here."));
            else for(int i=0;i<rows.length();i++) {
                JSONObject row=rows.optJSONObject(i);
                if(row==null)continue;
                page.addView(detailRow(row.optString("title"),row.optString("kind")));
            }
        }catch(Exception ignored){}
        page.addView(menuAction("×","Clear History","Remove local viewing records",v->{
            prefs.edit().remove("onetv_history").apply();showHistory(false);
        }));
        addScroll(page);
    }

    private void showReminders(boolean push) {
        if(push)push("reminders");
        screen="reminders";clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar("Reminders",false));
        page.addView(sectionLabel("Match Reminders","Verified kickoff time • alert 30 minutes before the match"));
        try {
            JSONArray saved=new JSONArray(prefs.getString("onetv_reminders","[]"));
            if(saved.length()==0)page.addView(emptyStateCard("No reminders","Open an upcoming match to save a reminder."));
            for(int i=0;i<saved.length();i++){
                JSONObject m=saved.optJSONObject(i);if(m==null)continue;
                String id=homeMatchIdentity(m);
                page.addView(menuAction("♧",canonicalMatchTitle(m),
                        formatMatchSchedule(pickText(m,"time","startsAt","startTime","start_time")),
                        v->removeReminder(id)));
            }
        }catch(Exception ignored){}
        page.addView(sectionLabel("Manage reminders","Alerts are scheduled 30 minutes before the event. Delivery is subject to Android notification and battery restrictions. Tap an item to remove it."));
        addScroll(page);
    }

    private void removeReminder(String id) {
        try {
            JSONArray rows=new JSONArray(prefs.getString("onetv_reminders","[]"));
            JSONArray left=new JSONArray();
            for(int i=0;i<rows.length();i++){
                JSONObject row=rows.optJSONObject(i);
                if(row!=null && id.equals(row.optString("reminder_id",homeMatchIdentity(row))))OneTvReminderReceiver.cancel(this,id);
                else if(row!=null)left.put(row);
            }
            prefs.edit().putString("onetv_reminders",left.toString()).apply();
        }catch(Exception ignored){}
        showReminders(false);
    }

    private void saveReminder(JSONObject match) {
        if(match==null || !"UPCOMING".equals(normalizedMatchStatus(
                pickText(match,"status","state","statusText")))) {
            android.widget.Toast.makeText(this,"Reminders are available for upcoming matches only",
                    android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        long startsAt=verifiedUpcomingKickoff(match);
        if(startsAt<=0L){
            android.widget.Toast.makeText(this,
                    "Kickoff date, time or timezone is not confirmed by the provider",
                    android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        long now=System.currentTimeMillis();
        if(startsAt<=now){
            android.widget.Toast.makeText(this,
                    "The scheduled kickoff time has passed. Refresh the fixture before setting a reminder.",
                    android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        try {
            JSONArray rows=new JSONArray(prefs.getString("onetv_reminders","[]"));
            String id=homeMatchIdentity(match);
            if(id.isEmpty()){
                android.widget.Toast.makeText(this,"Match identity is unavailable",
                        android.widget.Toast.LENGTH_SHORT).show();
                return;
            }
            for(int i=0;i<rows.length();i++){
                JSONObject r=rows.optJSONObject(i);
                if(r!=null&&id.equals(r.optString("reminder_id",homeMatchIdentity(r)))){
                    android.widget.Toast.makeText(this,"Reminder is already saved",
                            android.widget.Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            if(!OneTvReminderReceiver.schedule(this,id,canonicalMatchTitle(match),startsAt)){
                android.widget.Toast.makeText(this,"Could not schedule alarm. Check device alarm settings.",
                        android.widget.Toast.LENGTH_LONG).show();
                return;
            }
            JSONObject reminder=new JSONObject(match.toString());
            reminder.put("reminder_at_ms",startsAt);
            reminder.put("reminder_id",id);
            rows.put(reminder);
            prefs.edit().putString("onetv_reminders",rows.toString()).apply();
            if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(
                    "android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED){
                requestNotificationPermission();
                android.widget.Toast.makeText(this,
                    "Reminder saved. Allow notifications to receive the alert.",
                    android.widget.Toast.LENGTH_LONG).show();
            } else {
                boolean halfHour=startsAt-now>=30L*60L*1000L;
                android.widget.Toast.makeText(this,
                    halfHour?"Reminder scheduled 30 minutes before kickoff":"Reminder scheduled at kickoff",
                    android.widget.Toast.LENGTH_SHORT).show();
            }
        }catch(Exception error){
            android.widget.Toast.makeText(this,"Unable to save reminder on this device",
                    android.widget.Toast.LENGTH_LONG).show();
        }
    }

    private void showDownloads(boolean push){
        if(push)push("downloads");screen="downloads";clearContent();
        LinearLayout page=page();page.addView(selectedSectionBar("Downloads",false));
        page.addView(emptyStateCard("No permitted downloads", "Offline media downloads are only enabled when an authorized provider grants download rights and the player supports its DRM/expiry rules."));
        addScroll(page);
    }

    private void showDataSaver(boolean push){
        if(push)push("dataSaver");screen="dataSaver";clearContent();
        LinearLayout page=page();page.addView(selectedSectionBar("Data Saver",false));
        page.addView(sectionLabel("Network & Cache","Provider TTL and offline preferences"));
        page.addView(detailRow("Sports refresh",(sportsRefreshMs/1000)+" seconds (backend policy)"));
        page.addView(detailRow("Match refresh",(cricketDetailRefreshMs/1000)+" seconds (backend policy)"));
        page.addView(menuAction("×","Clear cached matches","Remove locally stored Home fixtures",v->{
            prefs.edit().remove(HOME_CACHE_KEY).apply();
            android.widget.Toast.makeText(this,"Match cache cleared",android.widget.Toast.LENGTH_SHORT).show();
        }));
        addScroll(page);
    }

    private void showLanguage(boolean push){
        if(push)push("language");screen="language";clearContent();
        LinearLayout page=page();page.addView(selectedSectionBar("Language",false));
        page.addView(sectionLabel("Display Language","English is the currently available complete translation"));
        page.addView(detailRow("Current", "English"));
        addScroll(page);
    }

    private void showNotificationSettings(boolean push){
        if(push)push("notificationSettings");screen="notificationSettings";clearContent();
        LinearLayout page=page();page.addView(selectedSectionBar("Notifications",false));
        page.addView(sectionLabel("Alert Settings", "Android permission and categories"));
        page.addView(menuAction("🔔","Notification permission","Manage Android notification access",v->requestNotificationPermission()));
        page.addView(detailRow("Timezone",java.util.TimeZone.getDefault().getID()));
        addScroll(page);
    }


    private void showEntertainmentPhotos(boolean push) {
        if(push)push("photos");
        selectedEntertainment="Photos";
        screen="photos";
        clearContent();
        LinearLayout page=page();
        page.addView(selectedSectionBar("Photo Stories",true));
        buildPhotoFront(page);
    }

    private void loadEntertainmentTrending(LinearLayout list) {
        if(BACKEND_URL==null || BACKEND_URL.contains("REPLACE") || !remoteDataEnabled){
            list.removeAllViews();list.addView(emptyStateCard("Unavailable", "Connect a licensed provider."));return;
        }
        network.execute(()->{
            try {
                JSONObject response=new JSONObject(getUrl(BACKEND_URL+"/media?limit=20"));
                JSONArray a=response.optJSONArray("items");
                runOnUiThread(()->{
                    if(!"entertainment".equals(screen))return;
                    list.removeAllViews();int count=0;
                    if(a!=null)for(int i=0;i<a.length() && count<4;i++){
                        JSONObject item=a.optJSONObject(i);
                        if(item==null || !isValidProviderImageUrl(pickText(item,"thumbnail_url","media_url")))continue;
                        list.addView(authorizedEntertainmentCard(item),marginBottomParams(8));count++;
                    }
                    if(count==0)list.addView(emptyStateCard("No authorized content", "Nothing currently available from the licensed media provider."));
                });
            }catch(Exception ignored){runOnUiThread(()->{if("entertainment".equals(screen)){
                list.removeAllViews();list.addView(emptyStateCard("Media unavailable", "Please retry when provider connectivity returns."));
            }});}
        });
    }


    private boolean newsMatchesCategory(JSONObject item,String filter) {
        if("All".equals(filter))return true;
        String category=pickText(item,"category").toLowerCase(Locale.US);
        if("Breaking".equals(filter))return category.contains("breaking");
        if("Bangladesh".equals(filter))return category.contains("bangladesh") || category.contains("national");
        if("World".equals(filter))return category.contains("world") || category.contains("international");
        return category.contains(filter.toLowerCase(Locale.US));
    }


    private void showSportTeamDetail(String sport,String key,boolean push){
        if(push)push("team:"+sport+":"+key);
        screen="teamDetail";clearContent();
        LinearLayout page=page();page.addView(selectedSectionBar("Team",false));
        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12),0,dp(12),dp(20));
        list.addView(homeSmallState("Loading verified team data…"));
        page.addView(list);addScroll(page);
        network.execute(()->{
            try {
                JSONObject result=new JSONObject(getUrl(BACKEND_URL+"/sports/"+sport+"/team/"+Uri.encode(key)));
                JSONObject team=result.optJSONObject("team");
                JSONArray matches=result.optJSONArray("matches");
                runOnUiThread(()->{
                    if(!"teamDetail".equals(screen))return;
                    list.removeAllViews();
                    if(team!=null){
                        list.addView(sectionLabel(pickText(team,"name","team_name"),sportName(sport)));
                        String logo=pickText(team,"logo","image_url","image");
                        if(isValidProviderImageUrl(logo)){
                            ImageView art=new ImageView(this);
                            list.addView(art,new LinearLayout.LayoutParams(dp(76),dp(76)));
                            loadProviderPhoto(art,logo);
                        }
                        JSONArray roster=pickArray(team,"roster","players","squad");
                        if(roster.length()>0)renderProviderPeople(list,roster,"Squad");
                    }
                    if(matches!=null && matches.length()>0){
                        list.addView(sectionLabel("Matches","Provider fixtures and results"));
                        for(int i=0;i<matches.length()&&i<20;i++){
                            JSONObject m=matches.optJSONObject(i);if(m==null)continue;
                            try{m.put("sport",sport);}catch(Exception ignored){}
                            list.addView(sportsListCard(m,false),marginBottomParams(7));
                        }
                    }
                    if(list.getChildCount()==0)list.addView(emptyStateCard("Team unavailable","No verified data for this team."));
                });
            }catch(Exception ignored){runOnUiThread(()->{if("teamDetail".equals(screen)){
                list.removeAllViews();list.addView(emptyStateCard("Team unavailable","Provider details could not be fetched."));
            }});}
        });
    }


    private long parseEventStartMillis(String raw) {
        return OneTvMatchTime.parseMillis(raw);
    }

    // Details and list feeds sometimes use different timestamp field names.
    // Use a complete timezone-qualified kickoff, never a time-of-day or date-only.
    private long verifiedUpcomingKickoff(JSONObject match) {
        if(match==null)return -1L;
        long verified=-1L;
        for(String key:new String[]{"time","startsAt","starts_at","startTime","start_time",
                "scheduledAt","scheduled_at","datetime","dateTime","kickoff","kickoffAt"}) {
            String candidate=pickText(match,key);
            if(candidate.isEmpty())continue;
            long value=parseEventStartMillis(candidate);
            if(value<=0L)continue;
            if(verified<=0L)verified=value;
            else if(Math.abs(value-verified)>5L*60L*1000L)return -1L;
        }
        return verified;
    }


}
