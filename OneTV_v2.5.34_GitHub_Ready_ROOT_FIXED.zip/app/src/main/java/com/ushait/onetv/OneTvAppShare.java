package com.ushait.onetv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Share the installed, self-contained OneTV installer, not a Play Store link.
 * No backend, third-party API, Internet, storage or install permissions required.
 * APK = direct install; ZIP = messenger-compatible fallback (extract before install).
 */
public final class OneTvAppShare {
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();
    private static final AtomicBoolean BUSY = new AtomicBoolean(false);

    private OneTvAppShare() { }

    public static void shareInstalledApk(Activity activity, boolean zipInsteadOfApk) {
        if (!BUSY.compareAndSet(false, true)) {
            Toast.makeText(activity,"Preparing your OneTV installer…",Toast.LENGTH_SHORT).show();
            return;
        }
        final ApplicationInfo appInfo = activity.getApplicationInfo();
        if (appInfo.splitSourceDirs != null && appInfo.splitSourceDirs.length > 0) {
            BUSY.set(false);
            new AlertDialog.Builder(activity)
                    .setTitle("Universal APK required")
                    .setMessage("This installation uses multiple APK splits. Sharing only base.apk would not install correctly on another phone. Install a universal APK build of OneTV to enable direct installer sharing.")
                    .setPositiveButton("OK",(dialog,which)->dialog.dismiss())
                    .show();
            return;
        }
        Toast.makeText(activity,"Preparing OneTV installer…",Toast.LENGTH_SHORT).show();
        WORKER.execute(() -> {
            try {
                final File source = new File(appInfo.sourceDir);
                if (!source.isFile() || !source.canRead() || source.length() <= 0)
                    throw new IOException("Installed APK is unavailable");

                final File directory = new File(activity.getCacheDir(),"onetv_installer");
                if (!directory.isDirectory() && !directory.mkdirs())
                    throw new IOException("Cannot create installer cache");

                final int versionCode = currentVersionCode(activity);
                final String sharedName = "OneTV-v" + versionCode;
                // Version-coded filenames avoid overwriting a file while a recipient
                // app is still transferring it. Cached copies are reused.
                final File file;
                final String mime;
                if (zipInsteadOfApk) {
                    file = new File(directory,sharedName+".zip");
                    mime = "application/zip";
                    if (!file.isFile() || file.length() == 0L) {
                        File staging = new File(directory,sharedName+".zip.tmp");
                        if (staging.exists()) staging.delete();
                        try (FileInputStream in = new FileInputStream(source);
                             ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(staging))) {
                            zip.setLevel(0); // APK is already compressed; faster, lower CPU.
                            zip.putNextEntry(new ZipEntry(sharedName+".apk"));
                            byte[] buffer = new byte[64 * 1024];
                            int count;
                            while ((count = in.read(buffer)) != -1) zip.write(buffer,0,count);
                            zip.closeEntry();
                        } catch (IOException failure) {
                            staging.delete();
                            throw failure;
                        }
                        replaceAtomically(staging,file);
                    }
                } else {
                    file = new File(directory,sharedName+".apk");
                    mime = "application/vnd.android.package-archive";
                    if (!file.isFile() || file.length() != source.length()) {
                        File staging = new File(directory,sharedName+".apk.tmp");
                        if (staging.exists()) staging.delete();
                        try (FileInputStream in = new FileInputStream(source);
                             FileOutputStream out = new FileOutputStream(staging)) {
                            byte[] buffer = new byte[64 * 1024];
                            int count;
                            while ((count = in.read(buffer)) != -1) out.write(buffer,0,count);
                            out.getFD().sync();
                        } catch (IOException failure) {
                            staging.delete();
                            throw failure;
                        }
                        replaceAtomically(staging,file);
                    }
                }
                if (!file.isFile() || file.length() < 1024)
                    throw new IOException("Installer package not ready");
                final Uri uri = FileProvider.getUriForFile(activity,
                        activity.getPackageName()+".shareprovider",file);
                activity.runOnUiThread(() -> {
                    try {
                        if (activity.isFinishing() || activity.isDestroyed()) return;
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType(mime);
                        send.putExtra(Intent.EXTRA_STREAM,uri);
                        send.setClipData(ClipData.newRawUri("OneTV installer",uri));
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        Intent chooser=Intent.createChooser(send, "Share OneTV app");
                        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        activity.startActivity(chooser);
                    } catch (Exception failure) {
                        Toast.makeText(activity,"No compatible sharing app found",Toast.LENGTH_LONG).show();
                    } finally { BUSY.set(false); }
                });
            } catch (Exception problem) {
                BUSY.set(false);
                activity.runOnUiThread(() -> {
                    if (!activity.isFinishing() && !activity.isDestroyed())
                        new AlertDialog.Builder(activity)
                                .setTitle("Could not prepare installer")
                                .setMessage("OneTV could not access its installed APK. Please install a universal APK build and retry. No upload was attempted.")
                                .setPositiveButton("OK",(dialog,which)->dialog.dismiss()).show();
                });
            }
        });
    }

    private static int currentVersionCode(Activity activity) throws Exception {
        PackageInfo info=activity.getPackageManager().getPackageInfo(activity.getPackageName(),0);
        return info.versionCode;
    }

    private static void replaceAtomically(File staging, File dest) throws IOException {
        if (dest.exists() && !dest.delete()) throw new IOException("Old cached installer cannot be replaced");
        if (!staging.renameTo(dest)) throw new IOException("Installer cache rename failed");
    }
}
