package com.ushait.onetv;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Parses verified fixture kickoffs without silently guessing an ambiguous timezone.
 * D1 sports fixtures use ISO-8601 timestamps (UTC Z or explicit offsets), or epoch.
 * A bare date, relative text or an offset-less local wall clock is NOT a safe alarm.
 */
public final class OneTvMatchTime {
    private OneTvMatchTime() {}

    public static long parseMillis(String input) {
        if (input == null) return -1L;
        String raw = input.trim();
        if (raw.length() < 10 || raw.length() > 90) return -1L;
        try {
            if (raw.matches("\\d{13}")) return Long.parseLong(raw);
            if (raw.matches("\\d{10}")) return Math.multiplyExact(Long.parseLong(raw), 1000L);
        } catch (Exception ignored) { return -1L; }

        // ISO: normalize explicit UTC suffix, fractional seconds and separator.
        String iso = raw.replaceAll("(?i)\\s+(UTC|GMT)$", "Z");
        iso = iso.replaceFirst("^(\\d{4}-\\d{2}-\\d{2})[ ](?=\\d{2}:\\d{2})", "$1T");
        iso = iso.replaceFirst("(?<=\\d)z$", "Z");
        iso = iso.replaceFirst("(?<=\\d)[ ]+(?=[+-]\\d{2}:?\\d{2}$)", "");
        // SimpleDateFormat S supports only milliseconds. Preserve timestamps
        // with higher-precision fractions by truncating extra digits.
        iso = iso.replaceFirst("\\.(\\d{1,2})(?=Z$|[+-]\\d{2}:?\\d{2}$|[+-]\\d{2}$)", ".$100");
        iso = iso.replaceFirst("\\.(\\d{3})\\d+(?=Z$|[+-]\\d{2}:?\\d{2}$|[+-]\\d{2}$)", ".$1");
        String[] patterns = {
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mmXXX",
            "yyyy-MM-dd'T'HH:mm:ss.SSSZ", "yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd'T'HH:mmZ",
            "yyyy-MM-dd'T'HH:mm:ss.SSSX", "yyyy-MM-dd'T'HH:mm:ssX", "yyyy-MM-dd'T'HH:mmX"
        };
        for (String format : patterns) {
            long value = strictParse(iso, format);
            if (value > 0L) return value;
        }
        // Recognized named timezone in RFC-1123 timestamps.
        if (raw.endsWith(" GMT") || raw.endsWith(" UTC")) {
            long value = strictParse(raw, "EEE, dd MMM yyyy HH:mm:ss z");
            if (value > 0L) return value;
        }
        return -1L;
    }

    private static long strictParse(String value, String format) {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.US);
            formatter.setLenient(false);
            formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
            ParsePosition cursor = new ParsePosition(0);
            Date parsed = formatter.parse(value, cursor);
            if (parsed != null && cursor.getIndex() == value.length()) return parsed.getTime();
        } catch (Exception ignored) { }
        return -1L;
    }

    public static String formattedLocal(String value) {
        long millis = parseMillis(value);
        if (millis <= 0L) return "";
        SimpleDateFormat formatter = new SimpleDateFormat("EEE, d MMM • h:mm a", Locale.US);
        formatter.setTimeZone(TimeZone.getDefault());
        return formatter.format(new Date(millis));
    }
}
