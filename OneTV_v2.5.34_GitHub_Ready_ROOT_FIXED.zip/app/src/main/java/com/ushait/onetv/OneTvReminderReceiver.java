package com.ushait.onetv;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import org.json.JSONArray;
import org.json.JSONObject;

/** Only schedules user-selected, provider-confirmed upcoming match reminders. */
public final class OneTvReminderReceiver extends BroadcastReceiver {
    private static final String ACTION_REMIND="com.ushait.onetv.ACTION_REMIND";
    private static final String CHANNEL="onetv_match_reminders";

    public static boolean schedule(Context context,String eventId,String title,long matchStartAt){
        long alarmAt=matchStartAt-30L*60L*1000L;
        if(alarmAt<=System.currentTimeMillis())alarmAt=matchStartAt;
        if(alarmAt<=System.currentTimeMillis())return false;
        AlarmManager manager=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if(manager==null)return false;
        try {
            PendingIntent pending=pending(context,eventId,title,PendingIntent.FLAG_UPDATE_CURRENT);
            // Exact alarm only where Android permits it; on Android 12+ use
            // inexact while-idle fallback without requesting restricted access.
            if(Build.VERSION.SDK_INT>=31){
                if(manager.canScheduleExactAlarms())
                    manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,alarmAt,pending);
                else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,alarmAt,pending);
            } else if(Build.VERSION.SDK_INT>=23)
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,alarmAt,pending);
            else manager.set(AlarmManager.RTC_WAKEUP,alarmAt,pending);
            return true;
        } catch(SecurityException | IllegalArgumentException ex) { return false; }
    }

    public static void cancel(Context context,String eventId){
        AlarmManager manager=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if(manager==null)return;
        PendingIntent pending=pending(context,eventId,"",PendingIntent.FLAG_NO_CREATE);
        if(pending!=null){manager.cancel(pending);pending.cancel();}
    }

    private static PendingIntent pending(Context c,String id,String title,int flags){
        Intent intent=new Intent(c,OneTvReminderReceiver.class);
        intent.setAction(ACTION_REMIND);
        intent.putExtra("eventId",id);
        intent.putExtra("title",title);
        return PendingIntent.getBroadcast(c,id.hashCode(),intent,flags|PendingIntent.FLAG_IMMUTABLE);
    }

    @Override public void onReceive(Context context,Intent intent){
        if(intent==null)return;
        if(Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) ||
                Intent.ACTION_MY_PACKAGE_REPLACED.equals(intent.getAction())){
            restoreFutureReminders(context);return;
        }
        if(!ACTION_REMIND.equals(intent.getAction()))return;
        if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)return;
        NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(manager==null)return;
        if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(new NotificationChannel(CHANNEL,"OneTV Match Reminders",NotificationManager.IMPORTANCE_DEFAULT));
        String title=intent.getStringExtra("title");
        if(title==null || title.trim().isEmpty())title="Upcoming Match";
        Intent open=new Intent(context,MainActivity.class);
        PendingIntent openApp=PendingIntent.getActivity(context,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder builder=new NotificationCompat.Builder(context,CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Match reminder")
                .setContentText(title+" starts soon")
                .setAutoCancel(true).setContentIntent(openApp);
        manager.notify(intent.getStringExtra("eventId")==null?0:intent.getStringExtra("eventId").hashCode(),builder.build());
    }

    public static void restoreFutureReminders(Context context){
        SharedPreferences prefs=context.getSharedPreferences("onetv_prefs",Context.MODE_PRIVATE);
        try{
            JSONArray entries=new JSONArray(prefs.getString("onetv_reminders","[]"));
            for(int i=0;i<entries.length();i++){
                JSONObject item=entries.optJSONObject(i);
                if(item==null)continue;
                long startsAt=item.optLong("reminder_at_ms",0L);
                String id=item.optString("reminder_id","");
                if(startsAt<=System.currentTimeMillis()||id.isEmpty())continue;
                String title=item.optString("title",item.optString("name","Match"));
                schedule(context,id,title,startsAt);
            }
        }catch(Exception ignored){}
    }
}
