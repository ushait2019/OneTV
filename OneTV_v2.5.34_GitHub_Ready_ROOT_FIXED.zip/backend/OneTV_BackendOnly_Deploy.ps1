# OneTV Backend-Only Sports Data Architecture - Cloudflare deployment.
# Execute from an extracted, trusted OneTV project directory.
param([switch]$SkipMigration)
$ErrorActionPreference = 'Stop'
$backend = Split-Path -Parent $MyInvocation.MyCommand.Path
Push-Location $backend
try {
  Write-Host 'OneTV scheduled-ingestion deployment' -ForegroundColor Cyan
  if (-not (Get-Command npx -ErrorAction SilentlyContinue)) {
    throw 'Node.js and npm/npx are needed. Install Node.js LTS first.'
  }
  Write-Host 'Checking Wrangler Cloudflare login...' -ForegroundColor Yellow
  & npx wrangler whoami
  if ($LASTEXITCODE -ne 0) { throw 'Cloudflare authentication failed. Run: npx wrangler login' }
  if (-not $SkipMigration) {
    Write-Host 'Applying safe, idempotent sports snapshot D1 migration...' -ForegroundColor Yellow
    & npx wrangler d1 execute one-tv-db --remote --file=./migration-sports-backend-only.sql
    if ($LASTEXITCODE -ne 0) { throw 'D1 migration failed; deployment halted.' }
  }
  Write-Host 'Deploying Worker with configured 1-minute Cron trigger...' -ForegroundColor Yellow
  & npx wrangler deploy
  if ($LASTEXITCODE -ne 0) { throw 'Worker deployment failed.' }
  Write-Host 'Deployed. Public sports routes now serve only D1 snapshots.' -ForegroundColor Green
  Write-Host 'Verify: https://one-tv-backend.ushait2019.workers.dev/sports/cache-status'
  Write-Host 'The first Cron runs populate the database; no user request initiates provider calls.'
} finally { Pop-Location }
