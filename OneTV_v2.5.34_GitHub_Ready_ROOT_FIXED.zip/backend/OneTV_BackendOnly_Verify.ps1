# Read-only public sports D1 snapshot checks. No admin/RapidAPI key required.
param([string]$Base='https://one-tv-backend.ushait2019.workers.dev')
$ErrorActionPreference = 'Stop'
$Base = $Base.TrimEnd('/')
$urls = @('/health','/sports/cache-status','/sports/cricket/live',
          '/cricket/live','/cricket/provider-status','/sports/football/live',
          '/sports/tennis/upcoming','/sports/basketball/results')
foreach($path in $urls) {
  try {
    $data = Invoke-RestMethod -Uri ($Base + $path) -TimeoutSec 20
    Write-Host ('[OK] ' + $path) -ForegroundColor Green
    if($null -ne $data.requestsProvider) {
      Write-Host ('  requestsProvider=' + $data.requestsProvider) -ForegroundColor Cyan
      if($data.requestsProvider -ne $false) { Write-Warning 'Expected D1-only route. Check deployment.' }
    }
    if($null -ne $data.matches) { Write-Host ('  matches=' + @($data.matches).Count) }
    if($null -ne $data.cacheReady) { Write-Host ('  cacheReady=' + $data.cacheReady) }
    if($path -eq '/sports/cache-status') {
      Write-Host ('  architecture=' + $data.architecture)
      Write-Host ('  snapshots=' + @($data.feeds).Count)
    }
  } catch {
    Write-Warning ('[FAILED] ' + $path + ': ' + $_.Exception.Message)
  }
}
Write-Host 'Public URLs only: this diagnostic never contacts SportScore or RapidAPI directly.'
