#!/usr/bin/env python3
"""Import recent Cricsheet JSON archive to OneTV D1 using authenticated Admin API.

Usage (requires Python 3.9+, no third-party packages):
  set ONETV_ADMIN_TOKEN=your_admin_token   (Windows cmd)
  $env:ONETV_ADMIN_TOKEN='your_admin_token' (PowerShell)
  python OneTV_Cricsheet_Import.py --limit 50
  python OneTV_Cricsheet_Import.py --zip recently_played_7_json.zip --limit 50

Licensing: ODC Attribution (JSON data), display credit and license in your app/site.
Only completed historical records; NO ESPN source, no live cricket feed.
"""
from __future__ import annotations
import argparse
import json
import os
import sys
import urllib.request
import zipfile
from io import BytesIO
from pathlib import Path

SOURCE_URL = 'https://cricsheet.org/downloads/recently_played_7_json.zip'
DEFAULT_BACKEND = 'https://one-tv-backend.ushait2019.workers.dev'

def match_from_entry(name: str, raw: dict) -> dict | None:
    info=raw.get('info') or {}
    teams=info.get('teams') or []
    dates=info.get('dates') or []
    if not isinstance(teams,list) or len(teams)!=2 or not dates:
        return None
    home,away=teams
    day=str(dates[0])[:10]
    if len(day)!=10 or not day[:4].isdigit(): return None
    name_id=Path(name).stem
    if not name_id.replace('_','').replace('-','').isalnum():return None
    innings=raw.get('innings') or []
    score_by_team={str(home):[],str(away):[]}
    for item in innings:
        if not isinstance(item,dict):continue
        batting_team=str(item.get('team',''))
        if batting_team not in score_by_team:continue
        runs=0;outs=0;balls=0
        for over in item.get('overs') or []:
            for ball in over.get('deliveries') or []:
                runs+=int((ball.get('runs') or {}).get('total') or 0)
                for wicket in ball.get('wickets') or []:
                    if str(wicket.get('kind','')).lower() not in {'retired hurt'}:outs+=1
                extras=(ball.get('extras') or {})
                if not ('wides' in extras or 'noballs' in extras):balls+=1
        penalty=item.get('penalty_runs') or {}
        runs+=int(penalty.get('pre') or 0)+int(penalty.get('post') or 0)
        score_by_team[batting_team].append(f'{runs}/{outs}')
    def team(value):
        return {'name':value,'slug':'','id':'','logo':'','flag':'',
                'score':' & '.join(score_by_team.get(str(value),[])),'overs':'','wickets':''}
    outcome=info.get('outcome') or {}
    winner=outcome.get('winner')
    result=('Winner: '+str(winner)) if winner else ('Outcome: '+str(outcome.get('result'))) if outcome.get('result') else ''
    return {'id':'cricsheet:cricket:'+name_id,'providerMatchId':name_id,'provider':'Cricsheet',
            'sport':'cricket','name':f'{home} vs {away}','status':'FINISHED',
            'statusText':result or 'FINISHED','time':day+'T00:00:00Z',
            'home':team(home),'away':team(away),'competition':str((info.get('event') or {}).get('name') or ''),
            'format':str(info.get('match_type') or ''),'venue':str(info.get('venue') or ''),
            'result':result,'archiveOnly':True,'attribution':'Cricsheet — ODC-BY-1.0'}

def post(url: str, token: str, matches: list[dict]) -> dict:
    data=json.dumps({'matches':matches},separators=(',',':')).encode('utf-8')
    request=urllib.request.Request(url+'/admin/sports/cricsheet/import',data=data,method='POST',headers={
        'Authorization':'Bearer '+token,'Content-Type':'application/json'})
    with urllib.request.urlopen(request,timeout=35) as response:
        return json.load(response)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--zip',dest='zip_path',help='Path to official Cricsheet recent JSON zip')
    ap.add_argument('--backend',default=DEFAULT_BACKEND,help='OneTV Worker URL')
    ap.add_argument('--limit',type=int,default=50,help='Max number of recent matches to import (default 50)')
    ap.add_argument('--dry-run',action='store_true',help='Only verify and display what would be imported')
    args=ap.parse_args()
    if args.limit<1 or args.limit>2000:ap.error('--limit must be between 1 and 2000')
    token=os.environ.get('ONETV_ADMIN_TOKEN','').strip()
    if not args.dry_run and not token:ap.error('Set ONETV_ADMIN_TOKEN environment variable first')
    if args.zip_path:
        b=Path(args.zip_path).read_bytes()
    else:
        print('Downloading official Cricsheet recent historic dataset (ZIP)...')
        req=urllib.request.Request(SOURCE_URL,headers={'User-Agent':'OneTV-Historical-Cricket-Importer/1.0'})
        with urllib.request.urlopen(req,timeout=60) as r:b=r.read(15000000)
    parsed=[]
    with zipfile.ZipFile(BytesIO(b)) as z:
        for name in z.namelist():
            if not name.endswith('.json') or '/' in name.strip('/'):continue
            item=match_from_entry(name,json.loads(z.read(name)))
            if item:parsed.append(item)
    parsed.sort(key=lambda m:(m['time'],m['id']),reverse=True)
    selected=parsed[:args.limit]
    print('Parsed:',len(parsed),'Selected:',len(selected))
    if args.dry_run:
        print(json.dumps(selected[:3],indent=2));return
    endpoint=args.backend.rstrip('/')
    # Only HTTPS Worker URL; never post a token to an arbitrary insecure host.
    if not endpoint.startswith('https://'):ap.error('Backend must use https://')
    saved=0
    for start in range(0,len(selected),50):
        batch=selected[start:start+50]
        response=post(endpoint,token,batch)
        saved+=int(response.get('saved',0))
        print('Imported',saved,'of',len(selected))
    print('Done. Historical-only endpoint: '+endpoint+'/sports/cricket/history')
    print('Remember Cricsheet ODC BY attribution in UI before publishing.')

if __name__=='__main__':
    try:main()
    except Exception as e:
        print('Import failed:',str(e),file=sys.stderr);sys.exit(1)
