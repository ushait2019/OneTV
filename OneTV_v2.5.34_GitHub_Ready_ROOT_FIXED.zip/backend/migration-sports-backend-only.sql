-- OneTV sports snapshot storage: idempotent, safe on existing one-tv-db.
-- Apply with Wrangler (optional: scheduled Worker also creates these tables):
-- npx wrangler d1 execute one-tv-db --remote --file=./migration-sports-backend-only.sql
CREATE TABLE IF NOT EXISTS sports_feed_snapshots (
    sport TEXT NOT NULL,
    bucket TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    provider TEXT NOT NULL DEFAULT '',
    fetched_at INTEGER NOT NULL,
    PRIMARY KEY (sport,bucket)
);
CREATE TABLE IF NOT EXISTS sports_match_snapshots (
    sport TEXT NOT NULL,
    match_id TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    provider TEXT NOT NULL DEFAULT '',
    fetched_at INTEGER NOT NULL,
    detail_available INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (sport,match_id)
);
CREATE TABLE IF NOT EXISTS sports_ingest_jobs (
    job_key TEXT PRIMARY KEY,
    last_attempt INTEGER NOT NULL DEFAULT 0,
    last_success INTEGER NOT NULL DEFAULT 0,
    next_allowed INTEGER NOT NULL DEFAULT 0,
    failures INTEGER NOT NULL DEFAULT 0,
    last_error TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS sports_provider_health (
    provider TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL,
    checked_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sports_provider_budget (
    provider TEXT NOT NULL,
    period_key TEXT NOT NULL,
    calls INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (provider,period_key)
);
CREATE TABLE IF NOT EXISTS sports_ingest_lock (
    lock_name TEXT PRIMARY KEY,
    lease_until INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_sports_match_snapshots_fetched_at ON sports_match_snapshots(fetched_at);
CREATE INDEX IF NOT EXISTS idx_sports_ingest_jobs_last_attempt ON sports_ingest_jobs(last_attempt);
