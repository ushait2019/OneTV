-- OneTV D1 Sports Source Control (additive, no DROP/DELETE)
-- OneTV sports snapshot storage: idempotent, safe on existing one-tv-db.
-- Apply with Wrangler (optional: scheduled Worker also creates these tables):
-- npx wrangler d1 execute one-tv-db --remote --file=./migration-sports-backend-only.sql
CREATE TABLE IF NOT EXISTS sports_feed_snapshots (
    sport TEXT NOT NULL,
    bucket TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    provider TEXT NOT NULL DEFAULT '',
    fetched_at INTEGER NOT NULL,
    PRIMARY KEY (sport,bucket)
);
CREATE TABLE IF NOT EXISTS sports_match_snapshots (
    sport TEXT NOT NULL,
    match_id TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    provider TEXT NOT NULL DEFAULT '',
    fetched_at INTEGER NOT NULL,
    detail_available INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (sport,match_id)
);
CREATE TABLE IF NOT EXISTS sports_ingest_jobs (
    job_key TEXT PRIMARY KEY,
    last_attempt INTEGER NOT NULL DEFAULT 0,
    last_success INTEGER NOT NULL DEFAULT 0,
    next_allowed INTEGER NOT NULL DEFAULT 0,
    failures INTEGER NOT NULL DEFAULT 0,
    last_error TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS sports_provider_health (
    provider TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL,
    checked_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sports_provider_budget (
    provider TEXT NOT NULL,
    period_key TEXT NOT NULL,
    calls INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (provider,period_key)
);
CREATE TABLE IF NOT EXISTS sports_ingest_lock (
    lock_name TEXT PRIMARY KEY,
    lease_until INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_sports_match_snapshots_fetched_at ON sports_match_snapshots(fetched_at);
CREATE INDEX IF NOT EXISTS idx_sports_ingest_jobs_last_attempt ON sports_ingest_jobs(last_attempt);


-- New source-control tables:
CREATE TABLE IF NOT EXISTS sports_source_controls (
    source_id TEXT PRIMARY KEY, display_name TEXT NOT NULL, enabled INTEGER NOT NULL,
    license_approved INTEGER NOT NULL, priority INTEGER NOT NULL, sports_csv TEXT NOT NULL,
    daily_limit INTEGER NOT NULL, monthly_limit INTEGER NOT NULL,
    min_interval_seconds INTEGER NOT NULL, fallback_only INTEGER NOT NULL,
    cooldown_until INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sports_runtime_controls (control_key TEXT PRIMARY KEY,control_value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sports_force_jobs (sport TEXT NOT NULL,bucket TEXT NOT NULL,requested_at INTEGER NOT NULL,
    PRIMARY KEY(sport,bucket));
CREATE TABLE IF NOT EXISTS sports_cricsheet_archive (
    match_id TEXT PRIMARY KEY,payload_json TEXT NOT NULL,match_date TEXT NOT NULL,
    imported_at INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS idx_cricsheet_match_date ON sports_cricsheet_archive(match_date);

-- Seeds are inserted automatically on first Admin/Cron run.
