CREATE TABLE IF NOT EXISTS channels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_number TEXT NOT NULL,
  name TEXT NOT NULL,
  country TEXT NOT NULL DEFAULT 'International',
  category TEXT NOT NULL DEFAULT 'TV',
  logo_url TEXT NOT NULL DEFAULT '',
  stream_url TEXT NOT NULL DEFAULT '',
  source_type TEXT NOT NULL DEFAULT 'link',
  source_value TEXT NOT NULL DEFAULT '',
  api_key TEXT NOT NULL DEFAULT '',
  program_name TEXT NOT NULL DEFAULT '',
  program_api_url TEXT NOT NULL DEFAULT '',
  show_viewers INTEGER NOT NULL DEFAULT 0,
  loop_playback INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_channels_active_sort ON channels(active, sort_order, id);

CREATE TABLE IF NOT EXISTS notices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL DEFAULT 'text',
  title TEXT NOT NULL DEFAULT '',
  html_content TEXT NOT NULL DEFAULT '',
  media_url TEXT NOT NULL DEFAULT '',
  link_url TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notices_active_sort ON notices(active, sort_order, id);


CREATE TABLE IF NOT EXISTS viewer_sessions (
  viewer_id TEXT PRIMARY KEY,
  channel_id INTEGER NOT NULL,
  last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_viewer_sessions_channel_seen ON viewer_sessions(channel_id, last_seen);

CREATE TABLE IF NOT EXISTS channel_views (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_id INTEGER NOT NULL,
  viewer_id TEXT NOT NULL,
  started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_channel_views_channel ON channel_views(channel_id);
CREATE INDEX IF NOT EXISTS idx_channel_views_started ON channel_views(started_at);

CREATE TABLE IF NOT EXISTS ad_platforms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  platform_key TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 0,
  priority INTEGER NOT NULL DEFAULT 99,
  banner_enabled INTEGER NOT NULL DEFAULT 1,
  interstitial_enabled INTEGER NOT NULL DEFAULT 0,
  rewarded_enabled INTEGER NOT NULL DEFAULT 0,
  app_id TEXT NOT NULL DEFAULT '',
  banner_unit_id TEXT NOT NULL DEFAULT '',
  interstitial_unit_id TEXT NOT NULL DEFAULT '',
  rewarded_unit_id TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sports_event_state (
  event_key TEXT PRIMARY KEY,
  sport TEXT NOT NULL,
  match_id TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_sports_event_state_sport ON sports_event_state(sport);

-- OneTV sports snapshot storage: idempotent, safe on existing one-tv-db.
-- Apply with Wrangler (optional: scheduled Worker also creates these tables):
-- npx wrangler d1 execute one-tv-db --remote --file=./migration-sports-backend-only.sql
CREATE TABLE IF NOT EXISTS sports_feed_snapshots (
    sport TEXT NOT NULL,
    bucket TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    provider TEXT NOT NULL DEFAULT '',
    fetched_at INTEGER NOT NULL,
    PRIMARY KEY (sport,bucket)
);
CREATE TABLE IF NOT EXISTS sports_match_snapshots (
    sport TEXT NOT NULL,
    match_id TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    provider TEXT NOT NULL DEFAULT '',
    fetched_at INTEGER NOT NULL,
    detail_available INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (sport,match_id)
);
CREATE TABLE IF NOT EXISTS sports_ingest_jobs (
    job_key TEXT PRIMARY KEY,
    last_attempt INTEGER NOT NULL DEFAULT 0,
    last_success INTEGER NOT NULL DEFAULT 0,
    next_allowed INTEGER NOT NULL DEFAULT 0,
    failures INTEGER NOT NULL DEFAULT 0,
    last_error TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS sports_provider_health (
    provider TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL,
    checked_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sports_provider_budget (
    provider TEXT NOT NULL,
    period_key TEXT NOT NULL,
    calls INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (provider,period_key)
);
CREATE TABLE IF NOT EXISTS sports_ingest_lock (
    lock_name TEXT PRIMARY KEY,
    lease_until INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_sports_match_snapshots_fetched_at ON sports_match_snapshots(fetched_at);
CREATE INDEX IF NOT EXISTS idx_sports_ingest_jobs_last_attempt ON sports_ingest_jobs(last_attempt);
