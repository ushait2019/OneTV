const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,PATCH,DELETE,OPTIONS",
    "access-control-allow-headers": "Content-Type, Authorization"
  }
});

const text = (data, status = 200) => new Response(data, {
  status,
  headers: { "content-type": "text/plain; charset=utf-8" }
});

function adminOk(request, env) {
  const auth = request.headers.get("Authorization") || "";
  return auth === `Bearer ${env.ADMIN_TOKEN}` && !!env.ADMIN_TOKEN;
}

function findStreamUrl(value) {
  if (!value) return "";
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (/^https?:\/\//i.test(trimmed)) return trimmed;
    try { value = JSON.parse(trimmed); } catch (_) { return ""; }
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = findStreamUrl(item);
      if (found) return found;
    }
    return "";
  }
  if (typeof value !== "object") return "";
  const directKeys = ["streamUrl", "stream_url", "stream", "url", "playUrl", "play_url", "sourceUrl", "source_url"];
  for (const key of directKeys) {
    const found = findStreamUrl(value[key]);
    if (found) return found;
  }
  for (const key of ["data", "result", "source", "channel", "response"]) {
    const found = findStreamUrl(value[key]);
    if (found) return found;
  }
  return "";
}

function extractYouTubeVideoId(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  if (/^[A-Za-z0-9_-]{11}$/.test(raw)) return raw;
  try {
    const u = new URL(raw);
    const host = u.hostname.toLowerCase().replace(/^www\./, '');
    if (host === 'youtu.be') return (u.pathname.split('/').filter(Boolean)[0] || '').slice(0, 11);
    if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'music.youtube.com') {
      const v = u.searchParams.get('v');
      if (v) return v.slice(0, 11);
      const parts = u.pathname.split('/').filter(Boolean);
      if (parts[0] === 'shorts' || parts[0] === 'embed' || parts[0] === 'live') return (parts[1] || '').slice(0, 11);
    }
  } catch (_) {}
  const m = raw.match(/(?:v=|youtu\.be\/|\/shorts\/|\/embed\/|\/live\/)([A-Za-z0-9_-]{11})/i);
  return m ? m[1] : '';
}

async function resolveYouTube(videoId, env) {
  if (!videoId || !env.YOUTUBE_API_KEY) return null;
  try {
    const api = 'https://www.googleapis.com/youtube/v3/videos?part=snippet&id=' + encodeURIComponent(videoId) + '&key=' + encodeURIComponent(env.YOUTUBE_API_KEY);
    const r = await fetch(api, { signal: AbortSignal.timeout(8000) });
    if (!r.ok) return null;
    const data = await r.json();
    const item = data.items && data.items[0];
    if (!item) return null;
    const sn = item.snippet || {};
    const thumbs = sn.thumbnails || {};
    const thumb = (thumbs.maxres || thumbs.standard || thumbs.high || thumbs.medium || thumbs.default || {}).url || '';
    return { videoId, title: String(sn.title || ''), description: String(sn.description || ''), channelTitle: String(sn.channelTitle || ''), thumbnailUrl: thumb };
  } catch (_) { return null; }
}

async function resolveSource(channel, env) {
  const type = String(channel.source_type || "link").toLowerCase();
  const fallbackProgram = String(channel.program_name || "");
  if (type === "youtube") {
    const videoId = extractYouTubeVideoId(channel.source_value || channel.stream_url || '');
    const meta = await resolveYouTube(videoId, env);
    return { youtubeVideoId: videoId, youtubeTitle: meta?.title || fallbackProgram, youtubeThumbnail: meta?.thumbnailUrl || '', programName: meta?.title || fallbackProgram, url: '' };
  }
  if (type !== "api") return { url: channel.source_value || channel.stream_url || "", programName: fallbackProgram };
  const apiUrl = channel.source_value || "";
  if (!apiUrl) return { url: "", programName: fallbackProgram };
  try {
    const headers = { "Accept": "application/json, text/plain;q=0.9, */*;q=0.8" };
    if (channel.api_key) { headers["Authorization"] = `Bearer ${channel.api_key}`; headers["X-API-Key"] = channel.api_key; }
    const response = await fetch(apiUrl, { method: "GET", headers, signal: AbortSignal.timeout(8000) });
    if (!response.ok) return { url: "", programName: fallbackProgram };
    const raw = await response.text();
    let parsed = null;
    try { parsed = JSON.parse(raw); } catch (_) {}
    const program = findProgramName(parsed) || fallbackProgram;
    const url = findStreamUrl(parsed ?? raw);
    return { url, programName: program };
  } catch (_) { return { url: "", programName: fallbackProgram }; }
}

function findProgramName(value) {
  if (!value) return "";
  if (typeof value === "string") return "";
  if (Array.isArray(value)) {
    for (const item of value) { const found = findProgramName(item); if (found) return found; }
    return "";
  }
  if (typeof value !== "object") return "";
  for (const key of ["programName","program_name","nowPlaying","now_playing","program","showName","show_name","title"]) {
    if (typeof value[key] === "string" && value[key].trim()) return value[key].trim();
  }
  for (const key of ["data","result","source","channel","response"]) { const found = findProgramName(value[key]); if (found) return found; }
  return "";
}

async function cleanupViewers(env) {
  await env.DB.prepare("DELETE FROM viewer_sessions WHERE last_seen < datetime('now','-90 seconds')").run();
}

async function viewerCount(env, channelId) {
  const r = await env.DB.prepare("SELECT COUNT(*) AS count FROM viewer_sessions WHERE channel_id=? AND last_seen >= datetime('now','-90 seconds')").bind(channelId).first();
  return Number(r?.count || 0);
}

async function listChannels(env) {
  await cleanupViewers(env);
  const { results } = await env.DB.prepare(`
    SELECT id, channel_number, name, country, category, logo_url, stream_url,
           source_type, source_value, api_key, program_name, program_api_url,
           show_viewers, loop_playback, active, sort_order
    FROM channels WHERE active = 1 ORDER BY sort_order ASC, id ASC
  `).all();
  const resolved = await Promise.all(results.map(async c => {
    const src = await resolveSource(c, env);
    let programName = src.programName || c.program_name || "";
    if (c.program_api_url) {
      try {
        const r = await fetch(c.program_api_url, {headers:{"Accept":"application/json,text/plain;q=0.9,*/*;q=0.8"}, signal: AbortSignal.timeout(6000)});
        if (r.ok) programName = findProgramName(JSON.parse(await r.text())) || programName;
      } catch (_) {}
    }
    const viewers = c.show_viewers ? await viewerCount(env, c.id) : 0;
    const connected = !!src.url;
    return { id:c.id, number:c.channel_number, name:c.name, country:c.country, category:c.category, logoUrl:c.logo_url, streamUrl:src.url || '', url:src.url || '', sourceType:String(c.source_type || 'link').toLowerCase(), youtubeVideoId:src.youtubeVideoId || '', youtubeTitle:src.youtubeTitle || '', youtubeThumbnail:src.youtubeThumbnail || '', programName, viewerCount:viewers, showViewerCount:!!c.show_viewers, loop:!!c.loop_playback, active:!!c.active, connected, sortOrder:c.sort_order };
  }));
  return resolved;
}

async function adminListChannels(env) {
  const { results } = await env.DB.prepare(`
    SELECT id, channel_number, name, country, category, logo_url, stream_url,
           source_type, source_value, api_key, program_name, program_api_url, show_viewers, loop_playback, active, sort_order
    FROM channels ORDER BY sort_order ASC, id ASC
  `).all();
  return results;
}

async function getActiveNotice(env) {
  const { results } = await env.DB.prepare(`
    SELECT id, type, title, html_content, media_url, link_url, active, sort_order
    FROM notices WHERE active = 1 ORDER BY sort_order ASC, id ASC LIMIT 1
  `).all();
  const n = results[0];
  if (!n) return null;
  return {
    id: n.id, type: n.type, title: n.title,
    html: n.html_content, mediaUrl: n.media_url, linkUrl: n.link_url,
    active: !!n.active, sortOrder: n.sort_order
  };
}

async function adminListNotices(env) {
  const { results } = await env.DB.prepare(`
    SELECT id, type, title, html_content, media_url, link_url, active, sort_order
    FROM notices ORDER BY sort_order ASC, id ASC
  `).all();
  return results;
}

function cleanHtml(html) {
  let s = String(html || "");
  s = s.replace(/<script[\\s\\S]*?<\/script>/gi, "");
  s = s.replace(/<iframe[\\s\\S]*?<\/iframe>/gi, "");
  s = s.replace(/\\son[a-z]+\\s*=\\s*(?:\"[^\"]*\"|'[^']*')/gi, "");
  s = s.replace(/javascript:/gi, "");
  return s;
}

function escAttr(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;");
}


const SPORTS = ["football", "basketball", "cricket", "tennis", "baseball"];
const SPORT_CACHE_TTL = 45;

function sportScoreUrl(path, params = {}) {
  const u = new URL("https://sportscore.com" + path);
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && String(v) !== "") u.searchParams.set(k, String(v));
  });
  u.searchParams.set("src", "onetv");
  return u.toString();
}

async function fetchJson(url, headers = {}, timeout = 10000) {
  const response = await fetch(url, {
    headers: { "Accept": "application/json", ...headers },
    signal: AbortSignal.timeout(timeout)
  });
  const body = await response.text();
  if (response.status === 204) return {};
  if (!response.ok) {
    // URLs, response bodies and headers can contain credentials or private data.
    throw new Error(`Provider request failed (HTTP ${response.status})`);
  }
  try { return JSON.parse(body); } catch (_) { throw new Error("Upstream returned invalid JSON"); }
}

async function cachedJsonWithTtl(url, headers = {}, timeout = 10000, ttl = SPORT_CACHE_TTL) {
  // Cloudflare Workers extends CacheStorage with a default edge cache.
  const cache = /** @type {any} */ (caches).default;
  const cacheKey = new Request(url, { method: "GET" });
  const hit = await cache.match(cacheKey);
  if (hit) return await hit.json();
  const data = await fetchJson(url, headers, timeout);
  const response = new Response(JSON.stringify(data), {
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": `public, max-age=${ttl}` }
  });
  await cache.put(cacheKey, response.clone());
  return data;
}

async function cachedJson(url, headers = {}, timeout = 10000) {
  // Cloudflare Workers extends CacheStorage with a default edge cache.
  const cache = /** @type {any} */ (caches).default;
  const cacheKey = new Request(url, { method: "GET" });
  const hit = await cache.match(cacheKey);
  if (hit) return await hit.json();
  const data = await fetchJson(url, headers, timeout);
  const response = new Response(JSON.stringify(data), {
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": `public, max-age=${SPORT_CACHE_TTL}` }
  });
  await cache.put(cacheKey, response.clone());
  return data;
}

function extractMatchArray(raw) {
  if (Array.isArray(raw?.matches)) return raw.matches;
  if (Array.isArray(raw?.data?.matches)) return raw.data.matches;
  if (Array.isArray(raw?.data)) return raw.data;
  if (Array.isArray(raw?.results)) return raw.results;
  if (Array.isArray(raw)) return raw;
  return [];
}

function pick(obj, keys, fallback = "") {
  for (const key of keys) {
    const v = obj?.[key];
    if (v !== undefined && v !== null && String(v).trim() !== "") return v;
  }
  return fallback;
}


function deepPick(obj, keys, fallback = "", depth = 0) {
  if (!obj || depth > 4) return fallback;
  const direct = pick(obj, keys, "");
  if (String(direct ?? "").trim() !== "") return direct;
  if (Array.isArray(obj)) {
    for (const item of obj) { const v = deepPick(item, keys, "", depth + 1); if (String(v ?? "").trim() !== "") return v; }
    return fallback;
  }
  if (typeof obj === "object") {
    for (const value of Object.values(obj)) {
      if (value && typeof value === "object") { const v = deepPick(value, keys, "", depth + 1); if (String(v ?? "").trim() !== "") return v; }
    }
  }
  return fallback;
}

function deepFindArray(obj, keys, depth = 0) {
  if (!obj || depth > 6) return null;
  if (Array.isArray(obj)) {
    for (const item of obj) {
      if (item && typeof item === "object") {
        const nested = deepFindArray(item, keys, depth + 1);
        if (nested && nested.length) return nested;
      }
    }
    return null;
  }
  if (typeof obj !== "object") return null;
  for (const key of keys) {
    const v = obj?.[key];
    if (Array.isArray(v) && v.length) return v;
    if (v && typeof v === "object") {
      const nested = deepFindArray(v, keys, depth + 1);
      if (nested && nested.length) return nested;
    }
  }
  for (const value of Object.values(obj)) {
    if (value && typeof value === "object") {
      const nested = deepFindArray(value, keys, depth + 1);
      if (nested && nested.length) return nested;
    }
  }
  return null;
}

function deepFindObject(obj, keys, depth = 0) {
  if (!obj || depth > 6 || typeof obj !== "object" || Array.isArray(obj)) return null;
  for (const key of keys) {
    const v = obj?.[key];
    if (v && typeof v === "object" && !Array.isArray(v)) return v;
  }
  for (const value of Object.values(obj)) {
    if (value && typeof value === "object") {
      const nested = deepFindObject(value, keys, depth + 1);
      if (nested) return nested;
    }
  }
  return null;
}

function firstStructuredArray(root, keys) { return deepFindArray(root, keys) || []; }
function firstStructuredObject(root, keys) { return deepFindObject(root, keys) || {}; }
function collectStructuredArrays(root, keys, out = [], depth = 0) {
  if (!root || depth > 7) return out;
  if (Array.isArray(root)) {
    for (const item of root) collectStructuredArrays(item, keys, out, depth + 1);
    return out;
  }
  if (typeof root !== "object") return out;
  for (const key of keys) {
    const value = root?.[key];
    if (Array.isArray(value)) out.push(...value);
    else if (value && typeof value === "object") {
      for (const containerKey of ["items","data","results","list","entries","records","rows","values"]) {
        if (Array.isArray(value?.[containerKey])) out.push(...value[containerKey]);
      }
    }
  }
  for (const value of Object.values(root)) {
    if (value && typeof value === "object") collectStructuredArrays(value, keys, out, depth + 1);
  }
  return out;
}

// Standardize REAL provider player data; no invented pictures or gender.
// Gender is accepted only when explicitly provided without contradiction.
const PLAYER_PHOTO_KEYS = ['avatar_url','avatarUrl','image_url','imageUrl','photo_url','photoUrl',
  'headshot_url','headshotUrl','profile_image','profileImage','player_image','playerImage',
  'profile_photo','profilePhoto','photo','avatar','headshot','image'];
const PLAYER_GENDER_KEYS = ['gender','sex','player_gender','playerGender','gender_type',
  'genderType','gender_code','genderCode'];
function directPlayerText(x, keys) {
  if (!x || typeof x !== 'object' || Array.isArray(x)) return '';
  for (const key of keys) {
    const value=x[key];
    if ((typeof value==='string'||typeof value==='number') && String(value).trim() &&
        String(value).trim().toLowerCase()!=='null') return String(value).trim();
  }
  return '';
}
function providerPlayerNode(x) {
  for (const key of ['player','athlete','person']) {
    const v=x?.[key];
    if (v && typeof v==='object' && !Array.isArray(v)) return v;
  }
  return null;
}
function verifiedPlayerGender(x) {
  let confirmed='';
  for (const row of [x,providerPlayerNode(x)]) {
    if (!row) continue;
    for (const key of PLAYER_GENDER_KEYS) {
      if (!Object.prototype.hasOwnProperty.call(row,key)) continue;
      const raw=String(row[key]??'').trim().toLowerCase();
      if (!raw) continue;
      const parsed=['male','m','man','men'].includes(raw)?'male':
        ['female','f','woman','women'].includes(raw)?'female':'';
      // Numeric codes (1/2) are not standardized across providers.
      if (!parsed || (confirmed && confirmed!==parsed)) return '';
      confirmed=parsed;
    }
  }
  return confirmed;
}
function verifiedPlayerPhoto(x) {
  for (const row of [x,providerPlayerNode(x)]) {
    if (!row) continue;
    for (const key of PLAYER_PHOTO_KEYS) {
      const v=directPlayerText(row,[key]);
      if (!v || v.length>1600)continue;
      try {
        const url=new URL(v);
        if(url.protocol==='https:' && url.hostname && !url.username && !url.password)
          return v;
      } catch(_){}
    }
  }
  return '';
}
function normalizePlayerRecord(x,teamName='') {
  if (!x || typeof x!=='object'||Array.isArray(x)) return x;
  const person=providerPlayerNode(x);
  const name=directPlayerText(x,['name','player_name','playerName','full_name','fullName','batName',
    'bowlName','batter','batsman','bowler'])||directPlayerText(person,['name','player_name','playerName','full_name','fullName']);
  const avatar_url=verifiedPlayerPhoto(x);
  const gender=verifiedPlayerGender(x);
  const out={...x};
  if(name)out.name=name;
  // Explicit empty values signal neutral placeholder in client, not a guess.
  out.avatar_url=avatar_url;
  out.gender=gender;
  // Prevent a client from re-inferring a gender from conflicting raw fields.
  out.onetv_gender_verified=!!gender;
  if(teamName && !out.team)out.team=teamName;
  return out;
}
function normalizePlayerRows(rows, inheritedTeam='', depth=0) {
  if(!Array.isArray(rows)||depth>5)return [];
  const result=[];
  for(const x of rows.slice(0,250)) {
    if (!x || typeof x!=='object' || Array.isArray(x)) continue;
    const children=['players','squad','roster','lineup','lineups','playing_xi',
      'playingXI','playingXIPlayers','members','athletes'].map(k=>x[k]).find(Array.isArray);
    if(children){
      const group=directPlayerText(x.team,['name','teamName','team_name'])||
        directPlayerText(x,['team_name','teamName','name'])||inheritedTeam;
      result.push(...normalizePlayerRows(children,group,depth+1));
    } else result.push(normalizePlayerRecord(x,inheritedTeam));
  }
  return result;
}
function normalizeInningsPlayerSections(innings) {
  if(!Array.isArray(innings))return [];
  return innings.map(x=>{
    if(!x||typeof x!=='object'||Array.isArray(x))return x;
    const row={...x};
    for(const key of ['batting','batting_scorecard','battingScorecard','batters','batsmen',
      'bowling','bowling_scorecard','bowlingScorecard','bowlers',
      'current_batters','currentBatters','current_bowler','currentBowler']){
      if(Array.isArray(row[key]))row[key]=normalizePlayerRows(row[key]);
    }
    return row;
  });
}
function normalizeMatchPlayerSections(match) {
  if(!match || typeof match!=='object')return match;
  for(const key of ['squads','squad','lineups','playing_xi','playingXI','playing_xi_players',
    'team_players','players','batting','batting_scorecard','battingScorecard','batters','batsmen',
    'bowling','bowling_scorecard','bowlingScorecard','bowlers','current_batters','currentBatters',
    'current_bowler','currentBowler']) {
    if(Array.isArray(match[key]))match[key]=normalizePlayerRows(match[key]);
  }
  if(Array.isArray(match.innings))match.innings=normalizeInningsPlayerSections(match.innings);
  return match;
}

function normalizeCricketFeaturePayload(m) {
  const root = m && typeof m === "object" ? m : {};
  const innings = normalizeInningsPlayerSections(firstStructuredArray(root, ["innings", "innings_summary", "inningsSummary"]));
  const scorecard = firstStructuredObject(root, ["scorecard", "score_card", "scoreCard"]);
  const get = (keys) => {
    const primary = firstStructuredArray(root, keys);
    if (primary.length) return primary;
    const fromScorecard = collectStructuredArrays(scorecard, keys);
    if (fromScorecard.length) return fromScorecard;
    return collectStructuredArrays(innings, keys);
  };
  return {
    commentary: firstStructuredArray(root, ["commentary", "ball_by_ball", "ballByBall", "commentaries", "commentary_feed", "commentaryFeed"]),
    overs: get(["overs", "over_by_over", "overByOver", "over_summary", "overSummary"]),
    highlights: firstStructuredArray(root, ["highlights", "highlight", "key_events", "keyEvents"]),
    squads: normalizePlayerRows(firstStructuredArray(root, ["squads", "squad", "playing_xi", "playingXI", "playing_xi_players", "team_players"])),
    innings,
    batting: normalizePlayerRows(get(["batting", "batting_scorecard", "battingScorecard", "batters", "batsmen"])),
    bowling: normalizePlayerRows(get(["bowling", "bowling_scorecard", "bowlingScorecard", "bowlers"])),
    fallOfWickets: get(["fall_of_wickets", "fallOfWickets", "fow"]),
    partnerships: get(["partnerships", "partnership"]),
    extras: get(["extras"]),
    currentBatters: normalizePlayerRows(firstStructuredArray(root, ["current_batters", "currentBatters", "current_batter", "currentBattersData"])),
    currentBowler: normalizePlayerRows(firstStructuredArray(root, ["current_bowler", "currentBowler", "current_bowler_data", "currentBowlerData"])),
    scorecard,
    series: firstStructuredObject(root, ["series", "series_data", "seriesData", "seriesDetails"])
  };
}

function teamObject(value, fallbackName = "Team", extra = {}) {
  if (value && typeof value === "object") {
    return {
      name: String(pick(value, ["name", "short_name", "team_name"], fallbackName)),
      slug: String(pick(value, ["slug", "team_slug", "teamSlug"], extra.slug || "")),
      id: String(pick(value, ["id", "team_id", "teamId"], extra.id || "")),
      logo: String(pick(value, ["logo", "logo_url", "image", "badge", "crest", "team_logo", "teamLogo"], extra.logo || "")),
      flag: String(pick(value, ["flag", "country_flag", "countryCode", "country_code", "countryCode2", "country_iso", "countryIso", "iso2", "nationality_code"], extra.flag || "")),
      score: normalizedTeamScore(value, extra.score ?? ""),
      overs: String(pick(value, ["overs", "over", "overs_text", "oversText", "over_text", "overText"], extra.overs ?? "")),
      wickets: String(pick(value, ["wickets", "wicket"], extra.wickets ?? ""))
    };
  }
  return {
    name: String(value || fallbackName),
    slug: String(extra.slug || ""),
    id: String(extra.id || ""),
    logo: String(extra.logo || ""),
    flag: String(extra.flag || ""),
    score: normalizedTeamScore({}, extra.score ?? ""),
    overs: String(extra.overs || ""),
    wickets: String(extra.wickets || "")
  };
}

// A missing score is NOT real provider data. Numeric zero is valid, but an
// upstream "-", "—", "N/A", etc. must never suppress a verified fallback.
function validProviderScore(value) {
  const raw = String(value ?? '').trim();
  if (!raw || /^(?:-|--|–|—|n\/?a|na|none|null|undefined|pending|not\s+available|score\s+unavailable)$/i.test(raw)) return '';
  return /\d/.test(raw) && raw.length <= 60 ? raw : '';
}
function normalizedTeamScore(value, fallback = "") {
  const direct = pick(value, ["score_text", "scoreText", "display_score", "displayScore", "score"], "");
  if (direct && typeof direct === "object") {
    const runs = validProviderScore(pick(direct, ["runs", "run", "total", "points"], ""));
    const wickets = validProviderScore(pick(direct, ["wickets", "wicket"], ""));
    if (runs && wickets) return `${runs}-${wickets}`;
    if (runs) return runs;
  }
  const asText = validProviderScore(direct);
  if (asText) return asText;
  const runs = validProviderScore(pick(value, ["runs", "run", "total", "points"], ""));
  const wickets = validProviderScore(pick(value, ["wickets", "wicket"], ""));
  if (runs && wickets) return `${runs}-${wickets}`;
  return runs || validProviderScore(fallback);
}

function canonicalMatchTitle(home, away, rawName = "") {
  const h = String(home?.name || "").trim();
  const a = String(away?.name || "").trim();
  if (h && a && h !== "Home" && a !== "Away" && h !== "TBD" && a !== "TBD") return `${h} vs ${a}`;
  const raw = String(rawName || "").trim();
  return raw || "Match";
}

function slugifyTeamName(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function canonicalMatchId(provider, sport, rawId, home, away, startTime) {
  const direct = String(rawId || '').trim();
  if (direct) return `${provider.toLowerCase()}:${sport}:${direct}`;
  const fallback = slugifyMatchName(`${home} vs ${away}`);
  const time = String(startTime || '').trim().toLowerCase();
  return `${provider.toLowerCase()}:${sport}:${fallback}:${time || 'undated'}`;
}

function unwrapProviderMatchId(id, provider, sport) {
  const prefix = `${provider.toLowerCase()}:${sport}:`;
  const value = String(id || '');
  return value.startsWith(prefix) ? value.slice(prefix.length) : value;
}

function sportScoreMatches(raw, sport) {
  const list = extractMatchArray(raw);
  const seen = new Set();
  return list.map((m, i) => {
    const declaredSport = String(pick(m, ['sport', 'sport_type', 'sportType'], sport)).toLowerCase();
    if (declaredSport && declaredSport !== sport.toLowerCase()) return null;
    const home = teamObject(pick(m, ['home_team', 'homeTeam', 'home'], null), 'Home', {
      logo: pick(m, ['home_logo', 'homeLogo'], ''),
      flag: pick(m, ['home_flag', 'homeFlag', 'home_country_code', 'homeCountryCode'], ''),
      score: pick(m, ['home_score', 'homeScore'], ''),
      overs: pick(m, ['home_overs', 'homeOvers', 'home_over', 'homeOver'], ''),
      wickets: pick(m, ['home_wickets', 'homeWickets', 'home_wicket', 'homeWicket'], ''),
      slug: pick(m, ['home_slug', 'homeSlug'], ''),
      id: pick(m, ['home_id', 'homeId'], '')
    });
    const away = teamObject(pick(m, ['away_team', 'awayTeam', 'away'], null), 'Away', {
      logo: pick(m, ['away_logo', 'awayLogo'], ''),
      flag: pick(m, ['away_flag', 'awayFlag', 'away_country_code', 'awayCountryCode'], ''),
      score: pick(m, ['away_score', 'awayScore'], ''),
      overs: pick(m, ['away_overs', 'awayOvers', 'away_over', 'awayOver'], ''),
      wickets: pick(m, ['away_wickets', 'awayWickets', 'away_wicket', 'awayWicket'], ''),
      slug: pick(m, ['away_slug', 'awaySlug'], ''),
      id: pick(m, ['away_id', 'awayId'], '')
    });
    if (!home.slug) home.slug = home.id || slugifyTeamName(home.name);
    if (!away.slug) away.slug = away.id || slugifyTeamName(away.name);
    const rawId = pick(m, ['slug', 'match_slug', 'id', 'match_id'], '');
    const time = String(pick(m, ['time', 'start_time', 'starts_at', 'date', 'datetime'], ''));
    const id = canonicalMatchId('sportscore', sport, rawId, home.name, away.name, time);
    if (seen.has(id)) return null;
    seen.add(id);
    return {
      id,
      providerMatchId: String(rawId || id),
      provider: 'SportScore',
      sport,
      name: canonicalMatchTitle(home, away, pick(m, ['name', 'title'], '')),
      status: String(pick(m, ['status', 'state', 'match_status'], '')),
      statusText: String(pick(m, ['status_text', 'statusText', 'status', 'state'], '')),
      time,
      home,
      away,
      competition: String(pick(m, ['competition', 'league', 'tournament', 'competition_name'], '')),
      competitionLogo: String(deepPick(m, ['competition_logo', 'competitionLogo', 'competition_logo_url', 'competitionLogoUrl', 'competition_image', 'competitionImage', 'competition_image_url', 'competitionImageUrl', 'league_logo', 'leagueLogo', 'league_logo_url', 'leagueLogoUrl', 'league_image', 'leagueImage', 'league_image_url', 'leagueImageUrl', 'tournament_logo', 'tournamentLogo', 'tournament_logo_url', 'tournamentLogoUrl', 'tournament_image', 'tournamentImage', 'tournament_image_url', 'tournamentImageUrl'], '')),
      round: String(deepPick(m, ['round', 'round_name', 'roundName', 'roundInfo', 'round_info', 'stage', 'stage_name', 'stageName', 'match_number', 'matchNumber', 'match_no', 'matchNo', 'match_round', 'matchRound', 'fixture_round', 'fixtureRound'], '')),
      format: String(deepPick(m, ['format', 'match_format', 'matchFormat', 'match_type', 'matchType', 'game_type', 'gameType', 'type', 'competition_format', 'competitionFormat', 'format_name', 'formatName', 'match_kind', 'matchKind', 'game_format', 'gameFormat'], '')),
      matchTitle: String(deepPick(m, ['match_title', 'matchTitle', 'match_name', 'matchName', 'fixture_title', 'fixtureTitle'], '')),
      venue: String(deepPick(m, ['venue', 'venue_name', 'venueName', 'stadium', 'ground', 'ground_name', 'groundName', 'venue_title', 'venueTitle', 'location', 'location_name', 'locationName'], '')),
      result: String(pick(m, ['result', 'result_text', 'status_text'], '')),
      popularityScore: Number(pick(m, ['popularityScore','popularity_score','popularity','interestScore','rankScore','viewers','views','audience'], "0")) || 0
    };
  }).filter(Boolean);
}


function hasData(value) {
  if (Array.isArray(value)) return value.length > 0;
  if (value && typeof value === "object") return Object.keys(value).length > 0;
  if (typeof value === 'string' && /^(?:-|--|–|—|n\/?a|na|none|null|undefined|pending|not\s+available|score\s+unavailable)$/i.test(value.trim())) return false;
  return value !== undefined && value !== null && String(value).trim() !== "";
}

function mergeMissing(target, source) {
  if (!target || !source || typeof target !== "object" || typeof source !== "object") return target;
  for (const [key, value] of Object.entries(source)) {
    if (!hasData(target[key]) && hasData(value)) target[key] = value;
    else if (target[key] && value && typeof target[key] === "object" && typeof value === "object" && !Array.isArray(target[key]) && !Array.isArray(value)) mergeMissing(target[key], value);
  }
  return target;
}

function configuredCricbuzzHost(env) {
  // Honor Cloudflare's existing CRICBUZZ_RAPIDAPI_HOST secret. Never insert
  // keys into the URL or accept arbitrary hosts (SSRF risk).
  const raw = String(env?.CRICBUZZ_RAPIDAPI_HOST || 'cricbuzz-cricket.p.rapidapi.com').trim();
  const host = raw.replace(/^https?:\/\//i, '').replace(/\/.*$/, '').toLowerCase();
  if (!/^[a-z0-9][a-z0-9.-]*\.p\.rapidapi\.com$/.test(host))
    throw new Error('Invalid CRICBUZZ_RAPIDAPI_HOST configuration');
  return host;
}
function cricbuzzHeaders(env) {
  const key = String(env.CRICBUZZ_RAPIDAPI_KEY || "").trim();
  if (!key) throw new Error("CRICBUZZ_RAPIDAPI_KEY is not configured");
  return {
    "x-rapidapi-key": key,
    "x-rapidapi-host": configuredCricbuzzHost(env)
  };
}

function cricbuzzUrl(path, params = {}, env) {
  const host = configuredCricbuzzHost(env);
  const u = new URL("https://" + host + path);
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && String(v) !== "") u.searchParams.set(k, String(v));
  });
  return u.toString();
}

// Cricbuzz v1 adapters: cover BOTH list camelCase and mcenter lowercase JSON.
// These shapes were checked against the user's actual saved RapidAPI response bodies.
function cbGet(obj, ...keys) {
  if (!obj || typeof obj !== 'object') return undefined;
  for (const key of keys) if (Object.prototype.hasOwnProperty.call(obj, key)
      && obj[key] !== undefined && obj[key] !== null) return obj[key];
  const normalized = Object.keys(obj);
  for (const key of keys) {
    const actual = normalized.find(x => x.toLowerCase() === String(key).toLowerCase());
    if (actual !== undefined && obj[actual] !== undefined && obj[actual] !== null) return obj[actual];
  }
  return undefined;
}
function cbText(obj, ...keys) {
  const v = cbGet(obj, ...keys);
  if (v === undefined || v === null || typeof v === 'object') return '';
  return String(v).trim();
}
function cbObj(obj, ...keys) {
  const value = cbGet(obj, ...keys);
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function cbArr(obj, ...keys) {
  const value = cbGet(obj, ...keys);
  return Array.isArray(value) ? value : [];
}
function cbScoreEntry(entry) {
  if (!entry || typeof entry !== 'object') return null;
  const r = cbText(entry, 'runs', 'run', 'score', 'total');
  if (!/^\d+$/.test(r)) return null;
  const w = cbText(entry, 'wickets', 'wicket');
  const overs = cbText(entry, 'overs', 'over');
  return { score: r + (/^\d+$/.test(w) ? '/' + w : ''), runs:r, wickets:/^\d+$/.test(w)?w:'', overs, inningsId:cbText(entry,'inningsId','inningsid') };
}
function cbScoreFromSide(raw) {
  const direct = cbScoreEntry(raw);
  if (direct) return { ...direct, innings:[direct] };
  const entries=[];
  for (const key of Object.keys(raw || {})) {
    if (/^inngs\d+$/i.test(key) || /^innings\d+$/i.test(key)) {
      const parsed = cbScoreEntry(raw[key]);
      if (parsed) entries.push(parsed);
    }
  }
  entries.sort((a,b)=>Number(a.inningsId||0)-Number(b.inningsId||0));
  return entries.length ? {...entries[entries.length-1], innings:entries} : null;
}
function cbInfoTeams(info) {
  return [cbObj(info,'team1'), cbObj(info,'team2')].map(t=>teamObject({
    name:cbText(t,'teamName','teamname','name','teamSName','teamsname')||'TBD',
    id:cbText(t,'teamId','teamid','id'),
    short_name:cbText(t,'teamSName','teamsname'),
    imageId:cbText(t,'imageId','imageid')
  },'TBD'));
}
function cbApplyScore(team, entry) {
  if (!entry || !team) return;
  team.score = entry.score;
  team.overs = entry.overs || '';
  team.wickets = entry.wickets || '';
}
function cbMatchTime(value) {
  const raw=String(value||'').trim();
  if (!raw) return '';
  if (/^\d{12,13}$/.test(raw)) {
    const d=new Date(Number(raw));
    return Number.isFinite(d.valueOf())?d.toISOString():'';
  }
  return raw;
}
function cbCommentary(raw) {
  const out=[];
  const wrappers=cbArr(raw,'comwrapper','commentaryList');
  const direct=wrappers.length ? wrappers : cbArr(raw,'commentary','items');
  for (const w of direct) {
    const c=cbObj(w,'commentary');
    const x=Object.keys(c).length?c:w;
    if (!x || typeof x!=='object') continue;
    let text=cbText(x,'commtxt','commText','text','description','commentary');
    // Cricbuzz tokens B0$, B1$ refer to human-readable emphasis parts.
    for (const format of cbArr(x,'commentaryformats','commentaryFormats')) {
      for (const phrase of cbArr(format,'value')) {
        const token=cbText(phrase,'id');
        const value=cbText(phrase,'value');
        if (token && value) text=text.split(token).join(value);
      }
    }
    text=text.replace(/B\d+\$/g,'').replace(/\s+/g,' ').trim();
    if (!text) continue;
    out.push({text, commentary:text, over:cbText(x,'overnum','overNum','over'),
      timestamp:cbText(x,'timestamp','commTimestamp'),
      eventType:cbText(x,'eventtype','eventType')});
  }
  return out;
}
function cbMapPeople(rows,type) {
  return rows.filter(x=>x && typeof x==='object').map(x=>({
    avatar_url:verifiedPlayerPhoto(x),gender:verifiedPlayerGender(x),
    name:cbText(x,type==='bat'?'batName':'bowlName','name','nickname',
      type==='bat'?'batShortName':'bowlShortName'),
    playerId:cbText(x,'id',type==='bat'?'batId':'bowlerId'),
    runs:cbText(x,'runs'), balls:cbText(x,'balls'),
    fours:cbText(x,'fours'), sixes:cbText(x,'sixes'),
    overs:cbText(x,'overs'), maidens:cbText(x,'maidens'),
    wickets:cbText(x,'wickets'), strikeRate:cbText(x,'strkrate','strikeRate'),
    economy:cbText(x,'economy','economyRate'), status:cbText(x,'outdec','outDesc')
  }));
}

function collectCricbuzzMatches(raw, out = [], depth = 0) {
  if (!raw || depth > 10) return out;
  if (Array.isArray(raw)) {
    for (const entry of raw) collectCricbuzzMatches(entry,out,depth+1);
    return out;
  }
  if (typeof raw !== 'object') return out;
  // Stop recursion on a match wrapper. Previously the nested matchInfo was
  // collected AGAIN without its matchScore, making duplicate, scoreless rows.
  if (raw.matchInfo && typeof raw.matchInfo==='object' && cbText(raw.matchInfo,'matchId','matchid')) {
    out.push(raw); return out;
  }
  if (cbText(raw,'matchId','matchid') && cbObj(raw,'team1').teamName) {
    out.push({matchInfo:raw,matchScore:cbObj(raw,'matchScore')}); return out;
  }
  for (const value of Object.values(raw)) if (value && typeof value==='object')
    collectCricbuzzMatches(value,out,depth+1);
  return out;
}

function normalizeCricbuzzMatch(wrapper, i = 0) {
  const m=cbObj(wrapper,'matchInfo','matchinfo');
  const info=Object.keys(m).length?m:wrapper;
  const scoreRoot=cbObj(wrapper,'matchScore','matchscore');
  const [home,away]=cbInfoTeams(info);
  const hs=cbScoreFromSide(cbObj(scoreRoot,'team1Score','team1score'));
  const as=cbScoreFromSide(cbObj(scoreRoot,'team2Score','team2score'));
  cbApplyScore(home,hs); cbApplyScore(away,as);
  const rawId=cbText(info,'matchId','matchid','id');
  if (!rawId) return null; // do not invent IDs which cannot open detail pages
  const time=cbMatchTime(cbText(info,'startDate','startdate','startTime'));
  const venue=cbObj(info,'venueInfo','venueinfo','venue');
  const state=cbText(info,'state','matchState');
  const statusText=cbText(info,'status','stateTitle','statustitle');
  return {
    id:canonicalMatchId('cricbuzz','cricket',rawId,home.name,away.name,time),
    providerMatchId:rawId, provider:'Cricbuzz', sport:'cricket',
    name:canonicalMatchTitle(home,away,cbText(info,'matchDesc','matchdesc')),
    status:state,statusText:statusText,time,home,away,teams:[home,away],
    competition:cbText(info,'seriesName','seriesname'),
    format:cbText(info,'matchFormat','matchformat'),
    round:cbText(info,'matchDesc','matchdesc'),
    venue:cbText(venue,'ground','name','city'),
    result:/complete|finish|result/i.test(state)?statusText:'',
    innings:[...(hs?.innings||[]).map(x=>({...x,team:home.name})),
      ...(as?.innings||[]).map(x=>({...x,team:away.name}))],
    rawProviderData:wrapper
  };
}

async function cricbuzzList(kind, env) {
  const raw = await cachedJson(cricbuzzUrl(`/matches/v1/${kind}`, {}, env), cricbuzzHeaders(env), 10000);
  const seen = new Set();
  return collectCricbuzzMatches(raw).map((m,i)=>normalizeCricbuzzMatch(m,i))
    .filter(m=>m && !seen.has(m.id) && seen.add(m.id));
}

function teamNameValue(value) {
  if (value && typeof value === "object") return String(pick(value, ["name", "teamName", "team_name", "short_name", "teamSName"], ""));
  return String(value || "");
}

function sameTeam(a, b) {
  const x = slugifyTeamName(teamNameValue(a)), y = slugifyTeamName(teamNameValue(b));
  if (!x || !y) return false;
  return x === y || x.includes(y) || y.includes(x);
}

function findCricbuzzMatchId(matches, base) {
  // Reused rivalries happen constantly. Team names alone are NOT a valid ID bridge.
  const expected=Date.parse(String(base?.time || base?.startsAt || ''));
  if (!Number.isFinite(expected)) return '';
  const compatible=(m)=> {
    const actual=Date.parse(String(m?.time||''));
    return Number.isFinite(actual) && Math.abs(actual-expected)<=90*60*1000;
  };
  const h=base?.home?.name||'',a=base?.away?.name||'';
  const matched=matches.find(m=>compatible(m) && (
    (sameTeam(m.home?.name,h)&&sameTeam(m.away?.name,a)) ||
    (sameTeam(m.home?.name,a)&&sameTeam(m.away?.name,h))));
  return matched?.providerMatchId||'';
}

function cricbuzzScorecardToNormalized(raw) {
  const rows=cbArr(raw,'scorecard','scoreCard');
  const innings=[],batting=[],bowling=[],extras=[],fallOfWickets=[];
  for (const row of rows) {
    if (!row || typeof row!=='object') continue;
    const bat=cbObj(row,'batTeamDetails','batteamdetails');
    const bowl=cbObj(row,'bowlTeamDetails','bowlteamdetails');
    const sc=cbObj(row,'scoreDetails','scoredetails');
    const score=Object.keys(sc).length?sc:row;
    const batRaw=cbGet(row,'batsman','batsmen') || cbGet(bat,'batsmenData','batsmendata') || [];
    const bowlRaw=cbGet(row,'bowler','bowlers') || cbGet(bowl,'bowlersData','bowlersdata') || [];
    const batters=cbMapPeople(Array.isArray(batRaw)?batRaw:Object.values(batRaw),'bat');
    const bowlers=cbMapPeople(Array.isArray(bowlRaw)?bowlRaw:Object.values(bowlRaw),'bowl');
    batting.push(...batters);bowling.push(...bowlers);
    const ex=cbObj(row,'extras','extrasData');
    if (Object.keys(ex).length) extras.push(ex);
    const fow=cbGet(row,'fow','wicketsData','fallOfWickets')||[];
    const wickets=Array.isArray(fow)?fow:Object.values(fow).filter(v=>v&&typeof v==='object');
    fallOfWickets.push(...wickets);
    const entry=cbScoreEntry(score);
    innings.push({team:cbText(row,'batteamname','batTeamName')||cbText(bat,'batTeamName'),
      inningsId:cbText(row,'inningsid','inningsId'),
      score:entry?.score||'', wickets:entry?.wickets||'',overs:entry?.overs||'',
      batting:batters,bowling:bowlers,extras:Object.keys(ex).length?[ex]:[],fall_of_wickets:wickets});
  }
  return {innings,batting,bowling,extras,fallOfWickets};
}

async function cricbuzzMatchDetail(matchId, env) {
  const uri='/mcenter/v1/'+encodeURIComponent(matchId);
  const headers=cricbuzzHeaders(env);
  // Info is mandatory; scorecard/score/teams are independently optional.
  // Cloudflare edge caching limits RapidAPI quota, while live scores expire soon.
  const [infoRaw,liveRaw,scoreRaw,teamsRaw,commentaryRaw] = await Promise.all([
    cachedJsonWithTtl(cricbuzzUrl(uri,{},env),headers,10000,90),
    cachedJsonWithTtl(cricbuzzUrl(uri+'/livescore',{},env),headers,10000,20).catch(()=>({})),
    cachedJsonWithTtl(cricbuzzUrl(uri+'/scard',{},env),headers,10000,90).catch(()=>({})),
    cachedJsonWithTtl(cricbuzzUrl(uri+'/teams',{},env),headers,10000,300).catch(()=>({})),
    cachedJsonWithTtl(cricbuzzUrl(uri+'/comm',{},env),headers,10000,40).catch(()=>({}))
  ]);
  const info=cbObj(infoRaw,'matchInfo','matchinfo');
  const header=Object.keys(info).length?info:infoRaw;
  const [home,away]=cbInfoTeams(header);
  if (home.name==='TBD' || away.name==='TBD') throw new Error('Cricbuzz match teams unavailable');
  const mapped=cricbuzzScorecardToNormalized(scoreRaw);
  const mini=cbObj(liveRaw,'miniscore','miniScore');
  const inningsScores=cbArr(cbObj(mini,'inningsscores','inningsScores'),'inningsscore','inningsScore');
  // Each innings belongs to an explicit batTeam ID, never guess by order.
  for (const row of inningsScores) {
    const side=cbText(row,'batteamid','batTeamId');
    const entry=cbScoreEntry(row);
    if (!side || !entry) continue;
    if (side===home.id) cbApplyScore(home,entry);
    if (side===away.id) cbApplyScore(away,entry);
  }
  for (const row of mapped.innings) {
    const entry=cbScoreEntry(row);
    if (!entry) continue;
    if (!home.score && sameTeam(row.team,home.name)) cbApplyScore(home,entry);
    if (!away.score && sameTeam(row.team,away.name)) cbApplyScore(away,entry);
  }
  const battingTeam=cbObj(mini,'batteamscore','batTeamScore');
  const battingId=cbText(battingTeam,'teamid','teamId');
  const currentScore=cbScoreEntry({runs:cbText(battingTeam,'teamscore','teamScore'),
    wickets:cbText(battingTeam,'teamwkts','teamWkts'),
    overs:cbText(mini,'curovsstats','currentOvers')});
  if (currentScore && battingId===home.id) cbApplyScore(home,currentScore);
  if (currentScore && battingId===away.id) cbApplyScore(away,currentScore);
  const commentary=[];
  const commentarySeen=new Set();
  // Full commentary is independent of live score; keep latest ball and complete
  // commentary feed without duplicating the same provider event.
  for (const row of [...cbCommentary(liveRaw), ...cbCommentary(commentaryRaw)]) {
    const key=String(row.over||'')+'|'+row.text;
    if (commentarySeen.has(key)) continue;
    commentarySeen.add(key);
    commentary.push(row);
  }
  const squads=[];
  for (const side of ['team1','team2']) {
    const squad=cbObj(teamsRaw,side);
    const players=cbArr(squad,'players');
    if (players.length) {
      const teamName=cbText(cbObj(squad,'team'),'teamname','teamName');
      squads.push(...normalizePlayerRows(players,teamName).map(x=>({
        ...x,id:cbText(x,'id','playerId'),role:cbText(x,'role')
      })));
    }
  }
  const status=cbText(header,'state','status');
  const statusText=cbText(header,'status','stateTitle');
  const matchTime=cbMatchTime(cbText(header,'startDate','startdate','startTime'));
  const sourceInfo=cbObj(header,'venueInfo','venueinfo','venue');
  const scorecardAvailable=mapped.innings.some(x=>x.score);
  return {
    id:canonicalMatchId('cricbuzz','cricket',matchId,home.name,away.name,matchTime),
    provider:'Cricbuzz',providerMatchId:String(matchId),sport:'cricket',
    name:canonicalMatchTitle(home,away),status,statusText,time:matchTime,
    home,away,teams:[home,away],
    competition:cbText(header,'seriesName','seriesname'),
    round:cbText(header,'matchDesc','matchdesc'),format:cbText(header,'matchFormat','matchformat'),
    venue:cbText(sourceInfo,'ground','name','city'),
    toss:cbText(header,'toss','tossText'),
    result:/complete|finish|result/i.test(status)?statusText:'',
    innings:mapped.innings,batting:mapped.batting,bowling:mapped.bowling,
    extras:mapped.extras,fall_of_wickets:mapped.fallOfWickets,
    commentary, squads, scorecard:scoreRaw,
    current_score:currentScore?.score||'',current_wickets:currentScore?.wickets||'',
    current_over:cbText(mini,'curovsstats','overs','over'),
    target:cbText(mini,'target','revisedtarget'),
    balls_remaining:cbText(mini,'ballsrem','ballsRemaining'),
    runs_required:cbText(mini,'runsneeded','runsNeeded','runsRequired'),
    crr:cbText(mini,'crr','currentRunRate'),
    rrr:cbText(mini,'rrr','requiredRunRate'),
    dataAvailability:{scores:!!(home.score||away.score),scorecard:scorecardAvailable,
      commentary:commentary.length>0,squads:squads.length>0},
    rawProviderData:{info:infoRaw,live:liveRaw,commentary:commentaryRaw,scorecard:scoreRaw,teams:teamsRaw}
  };
}

async function enrichCricketDetailFromCricbuzz(detail, env) {
  if (!env.CRICBUZZ_RAPIDAPI_KEY) return detail;
  const mode = /finished|complete|result|final|ended/i.test(String(detail.status || detail.statusText || "")) ? "recent" : /upcoming|scheduled|not/i.test(String(detail.status || detail.statusText || "")) ? "upcoming" : "live";
  try {
    const list = await cricbuzzList(mode, env);
    const matchId = findCricbuzzMatchId(list, detail);
    if (!matchId) return detail;
    const cb = await cricbuzzMatchDetail(matchId, env);
    mergeMissing(detail, cb);
    const sportRaw = detail.rawProviderData && typeof detail.rawProviderData === "object" ? detail.rawProviderData : {};
    sportRaw.Cricbuzz = cb.rawProviderData;
    detail.rawProviderData = sportRaw;
    detail.dataSources = { ...(detail.dataSources || {}), fallbackFields: "Cricbuzz" };
  } catch (_) {}
  return detail;
}

async function enrichCricketListFromCricketData(matches, env) {
  if (!env.CRICKETDATA_API_KEY || !matches?.length) return matches;
  try {
    const u = new URL("https://api.cricapi.com/v1/currentMatches");
    u.searchParams.set("apikey", String(env.CRICKETDATA_API_KEY));
    u.searchParams.set("offset", "0");
    const raw = await cachedJson(u.toString(), {}, 10000);
    const source = extractMatchArray(raw);
    for (const m of matches) {
      const found = source.find(x => {
        const h = pick(x, ["team1", "home", "team1Name"], "");
        const a = pick(x, ["team2", "away", "team2Name"], "");
        return sameTeam(Array.isArray(h) ? h[0] : h, m.home?.name) && sameTeam(Array.isArray(a) ? a[0] : a, m.away?.name)
          || sameTeam(Array.isArray(h) ? h[0] : h, m.away?.name) && sameTeam(Array.isArray(a) ? a[0] : a, m.home?.name);
      });
      if (!found) continue;
      // The same teams can play multiple matches: never borrow another date's
      // score just because the names match. Unstamped responses are skipped.
      const foundTime = pick(found,['dateTimeGMT','dateTime','start_time','startTime'], '');
      const gap = matchTimeDistanceMinutes(foundTime, m.time);
      if (!Number.isFinite(gap) || gap > 120) continue;
      const scores = Array.isArray(found.score) ? found.score : [];
      for (const sc of scores) {
        const runs = validProviderScore(pick(sc,['r','runs'],''));
        if (!runs) continue;
        const wickets = validProviderScore(pick(sc,['w','wickets'],''));
        const overs = validProviderScore(pick(sc,['o','overs'],''));
        const score = runs + (wickets ? '/' + wickets : '') + (overs ? ' (' + overs + ')' : '');
        const teamName = pick(sc,['inning','team','teamName'],'');
        if (sameTeam(teamName, m.home?.name) && !validProviderScore(m.home.score)) m.home.score = score;
        if (sameTeam(teamName, m.away?.name) && !validProviderScore(m.away.score)) m.away.score = score;
      }
      if (!hasData(m.venue)) m.venue = String(pick(found,["venue","ground"],""));
    }
  } catch (_) {}
  return matches;
}

function providerStatusError(error) {
  const message = String(error?.message || '');
  const code = message.match(/HTTP\s+(\d{3})/i);
  if (code) return 'http_' + code[1];
  if (/not configured/i.test(message)) return 'not_configured';
  if (/timeout|abort/i.test(message)) return 'timeout';
  if (/Invalid CRICBUZZ_RAPIDAPI_HOST/i.test(message)) return 'invalid_host';
  return 'request_failed';
}

function sportScoreHeaders(env) {
  const key=String(env?.SPORTSCORE_API_KEY||'').trim();
  return key?{'X-Api-Key':key}:{};
}
async function sportScoreList(sport, status, env, dateOverride = "") {
  if (!SPORTS.includes(sport)) throw new Error("Unsupported sport");
  // Use the documented v1 fixtures endpoint for all three states. It accepts
  // sport + UTC date + status and keeps the provider contract consistent.
  const days = dateOverride ? [dateOverride] : status === 'upcoming'
    ? [shiftIsoDate(0),shiftIsoDate(1),shiftIsoDate(2)]
    : status === 'finished' ? [shiftIsoDate(0),shiftIsoDate(-1)] : [shiftIsoDate(0)];
  const all = await Promise.all(days.map(date => cachedJson(
    sportScoreUrl('/api/v1/fixtures/', { sport,date,status,limit:200 }),
    sportScoreHeaders(env),10000
  ).then(x=>sportScoreMatches(x,sport)).catch(()=>[])));
  const unique=new Map();
  for (const m of all.flat()) if (!unique.has(m.id)) unique.set(m.id,m);
  const matches=Array.from(unique.values());
  const requestedBucket = status === "finished" ? "FINISHED" : String(status || "").toUpperCase();
  // The provider endpoint is queried with status, but we enforce the bucket
  // server-side as a second guard so Live/Upcoming/Results never share the same
  // match set when a provider returns stale or mixed-status fixtures.
  return matches.filter(m => statusBucket(m) === requestedBucket);
}

function normalizeOpenCricketMatch(m, i = 0) {
  const home = teamObject(pick(m, ["home_team", "homeTeam", "team1", "home"], null), "TBD");
  const away = teamObject(pick(m, ["away_team", "awayTeam", "team2", "away"], null), "TBD");
  const rawId = String(pick(m, ["id", "match_id", "matchId"], `opencricket-${i}`));
  const status = String(pick(m, ["status", "state", "match_status"], ""));
  const time = String(pick(m, ["start_time", "starts_at", "date", "datetime", "time"], ""));
  const id = canonicalMatchId("opencricket", "cricket", rawId, home.name, away.name, time);
  return {
    id,
    providerMatchId: rawId,
    name: canonicalMatchTitle(home, away, pick(m, ["name", "title"], "")),
    status,
    statusText: String(pick(m, ["status_text", "statusText", "status", "state"], status)),
    time,
    home,
    away,
    competition: String(pick(m, ["competition", "league", "tournament", "competition_name"], "")),
    competitionLogo: String(pick(m, ["competition_logo", "competitionLogo", "competition_logo_url", "competitionLogoUrl", "league_logo", "leagueLogo", "league_logo_url", "leagueLogoUrl", "tournament_logo", "tournamentLogo", "tournament_logo_url", "tournamentLogoUrl"], "")),
    round: String(deepPick(m, ["round", "round_name", "roundName", "stage", "stage_name", "stageName", "match_number", "matchNumber", "match_round", "matchRound", "fixture_round", "fixtureRound"], "")),
    format: String(deepPick(m, ["format", "match_format", "matchFormat", "type", "competition_format", "competitionFormat", "match_kind", "matchKind", "game_format", "gameFormat"], "")),
    matchTitle: String(deepPick(m, ["match_title", "matchTitle", "match_name", "matchName", "fixture_title", "fixtureTitle"], "")),
    venue: String(deepPick(m, ["venue", "venue_name", "venueName", "stadium", "ground", "ground_name", "groundName", "venue_title", "venueTitle", "location", "location_name", "locationName"], "")),
    result: String(pick(m, ["result", "result_text"], "")),
    popularityScore: Number(pick(m, ["popularityScore","popularity_score","popularity","interestScore","rankScore","viewers","views","audience"], "0")) || 0
  };
}

function openCricketHeaders(env) {
  const key = String(env.OPENCRICKET_API_KEY || "").trim();
  if (!key) throw new Error("OPENCRICKET_API_KEY is not configured");
  return { Authorization: `Bearer ${key}` };
}

async function openCricketList(status, env) {
  const today = new Date().toISOString().slice(0, 10);
  const raw = await cachedJson(
    (() => {
      const u = new URL(String(env.OPENCRICKET_BASE_URL || "https://opencricketapi.com").replace(/\/$/, "") + "/v1/matches");
      u.searchParams.set("date", today);
      u.searchParams.set("limit", "200");
      return u.toString();
    })(),
    openCricketHeaders(env),
    10000
  );
  const all = extractMatchArray(raw).map((m, i) => normalizeOpenCricketMatch(m, i));
  const lower = all.map(m => ({...m, _status: m.status.toLowerCase(), _time: m.time}));
  if (status === "live") return lower.filter(m => /live|in.?play|playing|started/.test(m._status));
  if (status === "finished") return lower.filter(m => /finished|complete|result|final|ended/.test(m._status));
  return lower.filter(m => /upcoming|scheduled|not.?started|fixture/.test(m._status));
}


function statusBucket(match) {
  const classify=(value)=> {
    const s=String(value||'').trim().toLowerCase();
    if (/^(live|live now|in[ -]?play|in progress|playing|ongoing|started|1st innings|2nd innings|innings break|stumps|end of day|lunch|tea|drinks)$/i.test(s)) return 'LIVE';
    if (/^(finished|complete|completed|result|final|ended|match complete|match completed)$/i.test(s)) return 'FINISHED';
    if (/^(upcoming|scheduled|not[ -]?started|fixture|pre[ -]?match|preview)$/i.test(s)) return 'UPCOMING';
    return '';
  };
  // Provider state is authoritative. StatusText is often a result sentence.
  for (const v of [match?.status,match?.state,match?.statusText]) {
    const bucket=classify(v);
    if (bucket) return bucket;
  }
  const text=String(match?.statusText||'').toLowerCase();
  if (/\b(won by|won on|match completed|match abandoned|match drawn|drawn|tied)\b/.test(text)) return 'FINISHED';
  const time=Date.parse(String(match?.time||''));
  if (Number.isFinite(time) && time>Date.now()) return 'UPCOMING';
  return ''; // never mark past event as LIVE merely because it started
}

function matchSortTime(match) {
  const candidates = [
    match?.finishedAt, match?.finished_at, match?.completedAt, match?.completed_at,
    match?.endTime, match?.end_time, match?.endedAt, match?.ended_at, match?.time
  ];
  for (const value of candidates) {
    const t = Date.parse(String(value || ''));
    if (Number.isFinite(t)) return t;
  }
  return 0;
}

function matchPopularityScore(match) {
  const explicit = [
    match?.popularityScore, match?.popularity, match?.popularity_score,
    match?.audience, match?.viewers, match?.views, match?.interestScore, match?.rankScore
  ];
  for (const value of explicit) {
    const n = Number(value);
    if (Number.isFinite(n) && n > 0) return Math.max(0, Math.min(1000, n));
  }

  // Provider popularity is preferred. When a provider does not expose it,
  // use a deterministic competition/format/team-interest fallback. This is
  // a ranking heuristic, not a claim about real-world audience measurement.
  const text = `${match?.competition || ''} ${match?.name || ''}`.toLowerCase();
  let score = 0;
  /** @type {Array<[RegExp, number]>} */
  const competitionWeights = [
    [/world cup|t20 world cup|odi world cup|champions trophy/, 100],
    [/ipl|indian premier league/, 95],
    [/asia cup/, 90],
    [/bbl|big bash/, 82],
    [/psl|pakistan super league/, 80],
    [/cpl|caribbean premier league/, 78],
    [/the hundred/, 75],
    [/ranji trophy/, 62],
    [/county championship/, 55]
  ];
  for (const [rx, weight] of competitionWeights) { if (rx.test(text)) { score += weight; break; } }
  const format = String(match?.format || '').toLowerCase();
  if (/t20|twenty20/.test(format)) score += 18;
  else if (/odi|one day/.test(format)) score += 12;
  else if (/test/.test(format)) score += 8;
  const teams = `${match?.home?.name || ''} ${match?.away?.name || ''}`.toLowerCase();
  if (/india|australia|england|pakistan|new zealand|south africa|sri lanka|bangladesh/.test(teams)) score += 10;
  return score;
}

function sortCricketForListing(matches, bucket) {
  const list = (matches || []).filter(m => statusBucket(m) === bucket);
  return list.sort((a, b) => {
    const popularity = matchPopularityScore(b) - matchPopularityScore(a);
    if (popularity) return popularity;
    if (bucket === 'UPCOMING') return matchSortTime(a) - matchSortTime(b);
    return matchSortTime(b) - matchSortTime(a);
  });
}

function recentCricketHighlights(liveMatches, upcomingMatches, finishedMatches, maxLive = 3, maxUpcoming = 5, maxRecent = 3) {
  const live = sortCricketForListing(liveMatches, 'LIVE');
  const upcoming = sortCricketForListing(upcomingMatches, 'UPCOMING');
  const finished = sortCricketForListing(finishedMatches, 'FINISHED');

  const leadLive = live.slice(0, maxLive);
  const upcomingBlock = upcoming.slice(0, maxUpcoming).map(m => ({
    ...m,
    status: 'UPCOMING',
    statusText: m.statusText || m.status || 'Upcoming',
    _listingSection: 'upcoming',
    _popularityScore: matchPopularityScore(m)
  }));
  const recent = finished.slice(0, maxRecent).map(m => ({
    ...m,
    status: 'FINISHED',
    statusText: m.statusText || m.status || 'Finished',
    _listingSection: 'recent_finished',
    _highlightEligible: true,
    _popularityScore: matchPopularityScore(m)
  }));

  // Home feed priority: top live matches first, then the most popular
  // upcoming matches, then the most recently finished highlight-eligible
  // matches. Older finished matches naturally fall down as new matches finish.
  return [...leadLive, ...upcomingBlock, ...recent, ...live.slice(maxLive), ...upcoming.slice(maxUpcoming)];
}

async function cricketHomeFeed(env) {
  const [liveResult, upcomingResult, finishedResult] = await Promise.all([
    withSportFallback('cricket', 'live', env),
    withSportFallback('cricket', 'upcoming', env),
    withSportFallback('cricket', 'finished', env)
  ]);
  const matches = recentCricketHighlights(liveResult.matches, upcomingResult.matches, finishedResult.matches, 3, 5, 3);
  return {
    provider: liveResult.provider,
    matches,
    recentFinishedCount: Math.min(3, (finishedResult.matches || []).filter(m => statusBucket(m) === 'FINISHED').length),
    liveCount: (liveResult.matches || []).filter(m => statusBucket(m) === 'LIVE').length,
    upcomingCount: (upcomingResult.matches || []).filter(m => statusBucket(m) === 'UPCOMING').length
  };
}

async function withSportFallback(sport, status, env) {
  try {
    let primary = await sportScoreList(sport, status, env);
    if (sport === "cricket") {
      primary = await enrichCricketListFromCricketData(primary, env);
      primary = await enrichMissingCricketListScores(primary, status, env);
    }

    // SportScore is primary. If it returns a mixed/empty state for a requested
    // cricket bucket, use the already-configured Cricbuzz list as a targeted
    // state fallback before OpenCricket. This prevents Live/Upcoming/Results
    // from collapsing onto the same provider response.
    if (sport === "cricket" && primary.length === 0 && env.CRICBUZZ_RAPIDAPI_KEY) {
      try {
        const kind = status === "finished" ? "recent" : status === "upcoming" ? "upcoming" : "live";
        const cricbuzz = await cricbuzzList(kind, env);
        const bucket=status==='finished'?'FINISHED':status.toUpperCase();
        const matching=cricbuzz.filter(m=>statusBucket(m)===bucket);
        if (matching.length) return { provider: 'Cricbuzz', matches: matching };
      } catch (_) {}
    }

    if (sport === "cricket" && primary.length === 0 && env.OPENCRICKET_API_KEY) {
      try {
        const alternate=await openCricketList(status,env);
        if (alternate.length) return { provider:"OpenCricket",matches:alternate };
      } catch (_) { /* Return verified empty SportScore set when fallback is unavailable. */ }
    }
    return {
      provider: "SportScore",
      matches: primary
    };
  } catch (primaryError) {
    if (sport !== "cricket") throw primaryError;

    if (env.CRICBUZZ_RAPIDAPI_KEY) {
      try {
        const kind = status === "finished" ? "recent" : status === "upcoming" ? "upcoming" : "live";
        const cricbuzz = await cricbuzzList(kind, env);
        const bucket=status==='finished'?'FINISHED':status.toUpperCase();
        const matching=cricbuzz.filter(m=>statusBucket(m)===bucket);
        if (matching.length) return { provider: 'Cricbuzz', matches: matching };
      } catch (_) {}
    }

    const fallback = await openCricketList(status, env);

    if (!fallback.length) {
      throw new Error(
        `SportScore failed and cricket fallbacks returned no ${status} matches`
      );
    }

    return {
      provider: "OpenCricket",
      matches: fallback
    };
  }
}

function slugifyMatchName(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function openCricketMatchKey(m) {
  const home = String(m?.home?.name || "");
  const away = String(m?.away?.name || "");
  return slugifyMatchName(home + " vs " + away);
}

function parseSportScoreCricketMatchReference(providerId) {
  const value = String(providerId || "").trim();
  const match = value.match(/^(.*)-vs-(.*):(\d{4}-\d{2}-\d{2}t.+)$/i);
  if (!match) return { slug: value, homeSlug: "", awaySlug: "", startTime: "" };
  return {
    slug: `${match[1]}-vs-${match[2]}`,
    homeSlug: match[1],
    awaySlug: match[2],
    startTime: match[3]
  };
}

function matchDateFromIso(value) {
  const match = String(value || "").match(/^(\d{4}-\d{2}-\d{2})/);
  return match ? match[1] : "";
}

function matchTimeDistanceMinutes(a, b) {
  const ta = Date.parse(String(a || ""));
  const tb = Date.parse(String(b || ""));
  if (!Number.isFinite(ta) || !Number.isFinite(tb)) return Number.POSITIVE_INFINITY;
  return Math.abs(ta - tb) / 60000;
}

async function openCricketMatchDetailFallback(id, env) {
  if (!env.OPENCRICKET_API_KEY) throw new Error("OPENCRICKET_API_KEY is not configured");
  const base = String(env.OPENCRICKET_BASE_URL || "https://opencricketapi.com").replace(/\/$/, "");
  const providerId = unwrapProviderMatchId(id, "opencricket", "cricket");

  // If the app selected an OpenCricket-native ID, use the documented detail endpoint.
  if (String(providerId).startsWith("match_")) {
    const raw = await cachedJson(base + "/v1/matches/" + encodeURIComponent(providerId), openCricketHeaders(env), 10000);
    return normalizeOpenCricketDetail(raw, "cricket", providerId);
  }

  // SportScore IDs are provider-specific. Resolve them against OpenCricket by
  // team pair first, then start-time proximity. The old implementation only
  // compared the entire SportScore ID with an OpenCricket team slug, which
  // cannot work when the SportScore ID contains its own timestamp suffix.
  const ref = parseSportScoreCricketMatchReference(providerId);
  const wanted = String(ref.slug || providerId).toLowerCase();
  const requestedDate = matchDateFromIso(ref.startTime);
  const dates = [];
  if (requestedDate) {
    const baseDate = new Date(`${requestedDate}T00:00:00Z`);
    for (const delta of [0, -1, 1, -2, 2]) {
      const d = new Date(baseDate);
      d.setUTCDate(d.getUTCDate() + delta);
      dates.push(d.toISOString().slice(0, 10));
    }
  } else {
    dates.push(new Date().toISOString().slice(0, 10));
  }

  const candidates = [];
  for (const date of [...new Set(dates)]) {
    const raw = await cachedJson(
      base + "/v1/matches?date=" + encodeURIComponent(date) + "&limit=200",
      openCricketHeaders(env),
      10000
    );
    candidates.push(...extractMatchArray(raw).map((m, i) => normalizeOpenCricketMatch(m, i)));
  }

  const homeWanted = String(ref.homeSlug || "").toLowerCase();
  const awayWanted = String(ref.awaySlug || "").toLowerCase();
  const scored = candidates.map(m => {
    const home = slugifyMatchName(m.home?.name || "").toLowerCase();
    const away = slugifyMatchName(m.away?.name || "").toLowerCase();
    const directId = String(m.providerMatchId || "").toLowerCase();
    const key = openCricketMatchKey(m).toLowerCase();
    let score = 0;
    if (directId === wanted) score += 1000;
    if (key === wanted) score += 900;
    if (homeWanted && awayWanted && home === homeWanted && away === awayWanted) score += 700;
    if (homeWanted && awayWanted && home === awayWanted && away === homeWanted) score += 650;
    if (homeWanted && home.includes(homeWanted)) score += 100;
    if (awayWanted && away.includes(awayWanted)) score += 100;
    if (homeWanted && away.includes(homeWanted)) score += 50;
    if (awayWanted && home.includes(awayWanted)) score += 50;
    const distance = matchTimeDistanceMinutes(m.time, ref.startTime);
    if (Number.isFinite(distance)) {
      if (distance <= 30) score += 200;
      else if (distance <= 180) score += 100;
      else if (distance <= 720) score += 25;
    }
    return { m, score, distance };
  }).sort((a, b) => b.score - a.score || a.distance - b.distance);

  const best = scored[0];
  if (!best || best.score < 650 || (requestedDate && (!Number.isFinite(best.distance) || best.distance > 360))) {
    throw new Error("OpenCricket could not verify both match identity and start time");
  }

  const found = best.m;
  const detailRaw = await cachedJson(
    base + "/v1/matches/" + encodeURIComponent(found.providerMatchId || found.id),
    openCricketHeaders(env),
    10000
  );
  return normalizeOpenCricketDetail(detailRaw, "cricket", found.providerMatchId || found.id);
}

async function resolveSportScoreMatchSlug(sport, providerId, env) {
  const wanted = String(providerId || "").trim().toLowerCase();
  const clean = sportScoreMatchSlugCandidates(sport, providerId)[0].toLowerCase();
  const m = String(providerId).match(/:(\d{4}-\d{2}-\d{2}[Tt]\d{2}:\d{2}[^/]*)$/);
  const expectedTime = m ? Date.parse(m[1]) : NaN;
  if (!wanted) return "";
  for (const offset of [0, -1, -2, 1]) {
    try {
      const raw = await cachedJson(sportScoreUrl("/api/v1/fixtures/", { sport, date: shiftIsoDate(offset), limit: 200 }), sportScoreHeaders(env), 10000);
      const found = extractMatchArray(raw).find(item => {
        const ids = [pick(item,["slug","match_slug","matchSlug"],""),pick(item,["id","match_id","matchId"],"")].map(v=>String(v||"").trim().toLowerCase());
        const start = Date.parse(String(pick(item,['time','start_time','starts_at','date','datetime'],'')));
        if (Number.isFinite(expectedTime) &&
            (!Number.isFinite(start) || Math.abs(start-expectedTime)>6*3600000)) return false;
        if (ids.includes(wanted) || ids.includes(clean)) return true;
        const h=pick(item?.home||item?.home_team||{},["name","team_name","short_name"],""); const a=pick(item?.away||item?.away_team||{},["name","team_name","short_name"],"");
        const pair=slugifyMatchName(`${h} vs ${a}`).toLowerCase();
        // No partial-name match: it can select an unrelated rematch.
        return !!pair && pair===clean;
      });
      if(found) return String(pick(found,["slug","match_slug","matchSlug"],""));
    } catch (_) {}
  }
  return "";
}


function parseCricbuzzMatchReference(providerId) {
  const value = String(providerId || "").trim();
  const match = value.match(/^(.*)-vs-(.*):(\d{4}-\d{2}-\d{2}t.+)$/i);
  if (!match) return { homeSlug: "", awaySlug: "", startTime: "" };
  return { homeSlug: match[1], awaySlug: match[2], startTime: match[3] };
}

function collectCricbuzzTeams(raw, out = [], depth = 0) {
  if (!raw || depth > 8) return out;
  if (Array.isArray(raw)) {
    for (const v of raw) collectCricbuzzTeams(v, out, depth + 1);
    return out;
  }
  if (typeof raw !== "object") return out;
  if (raw.teamId && (raw.teamName || raw.name || raw.teamSName)) out.push(raw);
  for (const v of Object.values(raw)) if (v && typeof v === "object") collectCricbuzzTeams(v, out, depth + 1);
  return out;
}

function cricbuzzTeamNameScore(value, wanted) {
  const a = slugifyMatchName(teamNameValue(value));
  const b = slugifyMatchName(wanted);
  if (!a || !b) return 0;
  if (a === b) return 1000;
  if (a.includes(b) || b.includes(a)) return 700;
  return 0;
}

async function cricbuzzTeamList(type, env) {
  const raw = await cachedJson(
    cricbuzzUrl(`/teams/v1/${type}`, {}, env),
    cricbuzzHeaders(env),
    10000
  );
  const teams = collectCricbuzzTeams(raw);
  const seen = new Set();
  return teams.filter(t => {
    const id = String(t.teamId || t.id || "");
    if (!id || seen.has(id)) return false;
    seen.add(id);
    return true;
  });
}

async function cricbuzzTeamMatches(teamId, mode, env) {
  const raw = await cachedJson(
    cricbuzzUrl(`/teams/v1/${encodeURIComponent(teamId)}/${mode}`, {}, env),
    cricbuzzHeaders(env),
    10000
  );
  return collectCricbuzzMatches(raw).map((m, i) => normalizeCricbuzzMatch(m, i));
}

async function cricbuzzTeamScheduleCandidates(ref, env) {
  const allCandidates = [];
  const seen = new Set();
  const types = ["league", "domestic", "international", "women"];
  for (const type of types) {
    let teams = [];
    try {
  teams = await cricbuzzTeamList(type, env);
} catch (e) {
  continue;
}
    const homeTeam = teams
      .map(t => ({ t, score: cricbuzzTeamNameScore(t, ref.homeSlug.replace(/-/g, " ")) }))
      .sort((a, b) => b.score - a.score)[0];
    const awayTeam = teams
      .map(t => ({ t, score: cricbuzzTeamNameScore(t, ref.awaySlug.replace(/-/g, " ")) }))
      .sort((a, b) => b.score - a.score)[0];
    const selected = [];
    if (homeTeam?.score >= 700) selected.push(homeTeam.t);
    if (awayTeam?.score >= 700 && String(awayTeam.t.teamId) !== String(homeTeam?.t?.teamId || "")) selected.push(awayTeam.t);
    if (!selected.length) continue;

    for (const team of selected) {
      for (const mode of ["schedule", "results"]) {
        try {
          const list = await cricbuzzTeamMatches(team.teamId, mode, env);
          for (const m of list) {
            const key = String(m.providerMatchId || m.id || "");
            if (!key || seen.has(key)) continue;
            seen.add(key);
            allCandidates.push(m);
          }
          const scored = list
            .map(m => scoreCricbuzzCandidate(m, ref))
            .sort((a, b) => b.score - a.score || a.distance - b.distance);
          if (scored[0] && scored[0].score >= 1000) return scored[0].m;
        } catch (e) {
      }
      }
    }
  }
  return allCandidates;
}

async function cricbuzzScheduleList(type, env, lastTime = "") {
  const raw = await cachedJson(
    cricbuzzUrl(`/schedule/v1/${type}`, lastTime ? { lastTime } : {}, env),
    cricbuzzHeaders(env),
    10000
  );
  return collectCricbuzzMatches(raw).map((m, i) => normalizeCricbuzzMatch(m, i));
}

function scoreCricbuzzCandidate(m, ref) {
  const home = slugifyMatchName(m.home?.name || "").toLowerCase();
  const away = slugifyMatchName(m.away?.name || "").toLowerCase();
  const homeWanted = String(ref.homeSlug || "").toLowerCase();
  const awayWanted = String(ref.awaySlug || "").toLowerCase();
  const distance = matchTimeDistanceMinutes(m.time, ref.startTime);
  let score = 0;
  if (home === homeWanted && away === awayWanted) score += 1000;
  else if (home === awayWanted && away === homeWanted) score += 900;
  if (home.includes(homeWanted) || homeWanted.includes(home)) score += 120;
  if (away.includes(awayWanted) || awayWanted.includes(away)) score += 120;
  if (Number.isFinite(distance)) {
    if (distance <= 30) score += 300;
    else if (distance <= 180) score += 180;
    else if (distance <= 720) score += 50;
  }
  return { m, score, distance };
}

async function cricbuzzScheduleCandidates(ref, env) {
  const candidates = [];
  const seen = new Set();
  const types = ["league", "domestic", "international", "women"];
  const targetMs = Date.parse(ref.startTime);
  const lastTimes = Number.isFinite(targetMs)
    ? ["", String(targetMs), String(Math.max(0, targetMs - 7 * 86400000))]
    : [""];

  for (const type of types) {
    for (const lastTime of lastTimes) {
      try {
        const list = await cricbuzzScheduleList(type, env, lastTime);
        for (const m of list) {
          const key = String(m.providerMatchId || m.id || "");
          if (!key || seen.has(key)) continue;
          seen.add(key);
          candidates.push(m);
        }
        const scored = list.map(m => scoreCricbuzzCandidate(m, ref)).sort((a, b) => b.score - a.score || a.distance - b.distance);
        if (scored[0] && scored[0].score >= 1000) return scored[0].m;
      } catch (_) {}
    }
  }
  return candidates;
}

async function cricbuzzMatchDetailFallbackFromSportScoreId(providerId, env) {
  if (!env.CRICBUZZ_RAPIDAPI_KEY) throw new Error("CRICBUZZ_RAPIDAPI_KEY is not configured");
  const ref = parseCricbuzzMatchReference(providerId);
  if (!ref.homeSlug || !ref.awaySlug) throw new Error("Could not parse SportScore cricket match teams");

  // Resolve the exact teams and start time from Cricbuzz's short public lists
  // before attempting the expensive team/schedule discovery paths.
  if (!Number.isFinite(Date.parse(ref.startTime)))
    throw new Error('SportScore match timestamp is unavailable for safe Cricbuzz ID resolution');
  const quickLists = await Promise.all(['live','upcoming','recent'].map(mode =>
    cricbuzzList(mode, env).catch(() => [])));
  const quickMatches = quickLists.flat().filter(m =>
    sameCricketFixture({home:{name:ref.homeSlug.replace(/-/g,' ')},
      away:{name:ref.awaySlug.replace(/-/g,' ')},time:ref.startTime}, m));
  if (quickMatches.length) {
    const best = quickMatches.sort((a,b)=>
      matchTimeDistanceMinutes(a.time,ref.startTime)-matchTimeDistanceMinutes(b.time,ref.startTime))[0];
    return cricbuzzMatchDetail(best.providerMatchId,env);
  }

  const candidates = [];
  const teamResult = await cricbuzzTeamScheduleCandidates(ref, env);
if (Array.isArray(teamResult)) candidates.push(...teamResult);
  else if (teamResult) candidates.push(teamResult);

  for (const mode of ["live", "upcoming", "recent"]) {
    try {
      const list = await cricbuzzList(mode, env);
      candidates.push(...list);
    } catch (_) {}
  }

  const scheduleResult = await cricbuzzScheduleCandidates(ref, env);
  if (Array.isArray(scheduleResult)) candidates.push(...scheduleResult);
  else if (scheduleResult) candidates.push(scheduleResult);

  const deduped = [];
  const seen = new Set();
  for (const m of candidates) {
    const key = String(m.providerMatchId || m.id || "");
    if (!key || seen.has(key)) continue;
    seen.add(key);
    deduped.push(m);
  }

  const scored = deduped.map(m => scoreCricbuzzCandidate(m, ref))
    .sort((a, b) => b.score - a.score || a.distance - b.distance);
  const best = scored[0];
  const target = {home:{name:ref.homeSlug.replace(/-/g,' ')},
    away:{name:ref.awaySlug.replace(/-/g,' ')},time:ref.startTime};
  if (!best || best.score < 1000 || !best.m.providerMatchId ||
      !sameCricketFixture(target, best.m)) {
    throw new Error("Cricbuzz could not safely resolve the selected fixture and start time");
  }
  return await cricbuzzMatchDetail(best.m.providerMatchId, env);
}

// A fixture without an upstream matchId uses a canonical ID of the form
// sportscore:cricket:new-zealand-vs-india:2026-11-04T02:00:00+00:00.
// The upstream match detail endpoint accepts the fixture SLUG, not this key.
function sportScoreMatchSlugCandidates(sport, selectedId) {
  const p = `sportscore:${sport}:`;
  let value = String(selectedId || '').trim();
  if (value.startsWith(p)) value = value.slice(p.length);
  if (value.startsWith(p)) value = value.slice(p.length);
  const result = [];
  const stamp = value.match(/^(.*):(\d{4}-\d{2}-\d{2}[Tt]\d{2}:\d{2}[^/]*)$/);
  if (stamp) result.push(stamp[1]);
  result.push(value);
  return [...new Set(result.filter(Boolean))];
}

function sameCricketFixture(a, b) {
  const timeGap = matchTimeDistanceMinutes(a?.time || a?.startsAt, b?.time || b?.startsAt);
  if (!Number.isFinite(timeGap) || timeGap > 120) return false;
  const aH = slugifyTeamName(a?.home?.name), aA = slugifyTeamName(a?.away?.name);
  const bH = slugifyTeamName(b?.home?.name), bA = slugifyTeamName(b?.away?.name);
  if (!aH || !aA || !bH || !bA) return false;
  return (aH === bH && aA === bA) || (aH === bA && aA === bH);
}

async function enrichMissingCricketListScores(matches, mode, env) {
  if (!env.CRICBUZZ_RAPIDAPI_KEY || mode === 'upcoming' || !Array.isArray(matches)) return matches;
  if (!matches.some(m => !validProviderScore(m?.home?.score) || !validProviderScore(m?.away?.score))) return matches;
  try {
    const kind = mode === 'finished' ? 'recent' : 'live';
    const source = await cricbuzzList(kind, env);
    for (const selected of matches) {
      if (validProviderScore(selected?.home?.score) && validProviderScore(selected?.away?.score)) continue;
      const verified = source.find(candidate => sameCricketFixture(selected, candidate)
        && (validProviderScore(candidate?.home?.score) || validProviderScore(candidate?.away?.score)));
      if (!verified) continue;
      const direct = slugifyTeamName(selected.home.name) === slugifyTeamName(verified.home.name);
      const h = direct ? verified.home : verified.away;
      const a = direct ? verified.away : verified.home;
      let updated = false;
      for (const [target, actual] of [[selected.home,h],[selected.away,a]]) {
        const score = validProviderScore(actual?.score);
        if (score && !validProviderScore(target.score)) {
          target.score = score;
          if (actual?.overs) target.overs = actual.overs;
          if (actual?.wickets) target.wickets = actual.wickets;
          updated = true;
        }
      }
      if (updated) selected.dataSources = { ...(selected.dataSources || {}), cricketScores: 'Cricbuzz' };
    }
  } catch (_) { /* A fallback failure must not inject stale or invented scores. */ }
  return matches;
}

// Some SportScore fixtures appear in the dated fixtures feed before a match-detail
// document is published. Resolve them by *exact* provider ID, or by both sides
// AND timestamp. Never use team names without a verified start time.
async function verifiedSportScoreFixture(sport, selectedId, env) {
  const selected = unwrapProviderMatchId(selectedId, 'sportscore', sport);
  const stamped = selected.match(/^(.*):(\d{4}-\d{2}-\d{2}[Tt]\d{2}:\d{2}[^/]*)$/);
  const matchKey = stamped ? stamped[1] : selected;
  const expected = stamped ? Date.parse(stamped[2]) : NaN;
  const day = Number.isFinite(expected) ? new Date(expected).toISOString().slice(0,10) : '';
  const days = day ? [day, shiftDayFromDate(day,-1),shiftDayFromDate(day,1)]
                   : [shiftIsoDate(0),shiftIsoDate(-1),shiftIsoDate(1)];
  const query = await Promise.all(days.map(date =>
    cachedJsonWithTtl(sportScoreUrl('/api/v1/fixtures/', {sport,date,limit:200}),
      sportScoreHeaders(env), 8500, 30)
      .then(raw => sportScoreMatches(raw, sport)).catch(() => [])));
  const matched = [];
  for (const match of query.flat()) {
    const id = String(match?.providerMatchId || '');
    const fullId = String(match?.id || '');
    const actualTime = Date.parse(String(match?.time || ''));
    const matchingId = fullId === selectedId || id === selected || id === matchKey;
    const sideSlug = slugifyMatchName(`${match?.home?.name || ''} vs ${match?.away?.name || ''}`);
    const reverseSlug = slugifyMatchName(`${match?.away?.name || ''} vs ${match?.home?.name || ''}`);
    const matchingPair = sideSlug === matchKey || reverseSlug === matchKey;
    const timeMatches = Number.isFinite(expected) && Number.isFinite(actualTime)
      && Math.abs(actualTime - expected) <= 10 * 60 * 1000;
    // For synthetic IDs, both exact teams and a closely matching UTC kickoff
    // are required. Otherwise accept an exact native provider match ID.
    if (matchingId && (!Number.isFinite(expected) || timeMatches)) matched.push(match);
    else if (matchingPair && timeMatches) matched.push(match);
  }
  return matched[0] || null;
}
function shiftDayFromDate(date, delta) {
  const d = new Date(date + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + delta);
  return d.toISOString().slice(0,10);
}
function verifiedFixtureDetailReply(match) {
  return {provider:'SportScore', detailAvailable:false, dataStatus:'fixture_only',
    match: {...match, detailAvailable:false, dataStatus:'fixture_only',
      dataAvailability: {detail:false,
        scores:!!(match.home?.score || match.away?.score),
        timeline:false, lineups:false, stats:false}}
  };
}

// Read a *real* Cricbuzz fixture score for a timestamped SportScore fixture.
// This deliberately requires BOTH exact teams and a compatible start time.
// Never combine different fixtures or invent a missing score.
function hasActualCricketScore(team) {
  return /^\d+(?:[\/\-]\d+)?(?:\s|$)/.test(validProviderScore(team?.score));
}

async function verifiedCricbuzzFixtureScore(providerId, env) {
  if (!env.CRICBUZZ_RAPIDAPI_KEY) return null;
  const ref = parseCricbuzzMatchReference(providerId);
  if (!ref.homeSlug || !ref.awaySlug || !Number.isFinite(Date.parse(ref.startTime))) return null;
  const wanted = {
    home: {name: ref.homeSlug.replace(/-/g, ' ')},
    away: {name: ref.awaySlug.replace(/-/g, ' ')},
    time: ref.startTime
  };
  // Query only live/recent score lists, not every team schedule or match ID.
  // Both requests are independently cached by the provider adapter.
  const feeds = await Promise.all(['live', 'recent', 'upcoming'].map(kind =>
    cricbuzzList(kind, env).catch(() => [])));
  const candidates = feeds.flat().filter(m =>
    sameCricketFixture(wanted, m)
    && matchTimeDistanceMinutes(wanted.time, m.time) <= 90
    && (hasActualCricketScore(m?.home) || hasActualCricketScore(m?.away)));
  if (!candidates.length) return null;
  const match = candidates[0];
  return {provider: 'Cricbuzz', detailAvailable: false,
    dataStatus: 'verified_score_feed',
    match: {...match, detailAvailable: false, dataStatus: 'verified_score_feed',
      dataAvailability: {detail: false, scores: true, scorecard: false,
        commentary: false, squads: false}}};
}

async function sportScoreMatchDetail(sport, id, env) {
  if (sport === 'cricket' && String(id).startsWith('cricbuzz:cricket:')) {
    const matchedId=unwrapProviderMatchId(id,'cricbuzz','cricket');
    return {provider:'Cricbuzz',match:await cricbuzzMatchDetail(matchedId,env)};
  }
  if (sport === 'cricket' && String(id).startsWith('opencricket:cricket:')) {
    return {provider:'OpenCricket',match:await openCricketMatchDetailFallback(id,env)};
  }
  let primaryError = null;
  const providerId = unwrapProviderMatchId(id, 'sportscore', sport);
  // Start this optional score lookup alongside SportScore's match request.
  // Await it only if the primary provider supplies no usable team score.
  const cricbuzzScoreTask = sport === 'cricket'
    ? verifiedCricbuzzFixtureScore(providerId, env).catch(() => null)
    : Promise.resolve(null);
  const candidates = sportScoreMatchSlugCandidates(sport, providerId);
  const stamped = String(providerId).match(/:(\d{4}-\d{2}-\d{2}[Tt]\d{2}:\d{2}[^/]*)$/);
  const requestedTime = stamped ? Date.parse(stamped[1]) : NaN;
  const tryCandidate = async (candidate) => {
    // Check both known endpoint families simultaneously, so one unavailable
    // endpoint does not consume the entire Android read timeout.
    const alternatives = await Promise.all(['/api/v1/match/', '/api/widget/match/'].map(async path => {
      try {
        const raw = await cachedJsonWithTtl(sportScoreUrl(path, {sport, slug:candidate}),
          sportScoreHeaders(env), 8500, 10);
        const detail = normalizeSportScoreDetail(raw, sport);
        const realTeams = detail.providerMatchId && detail.home?.name && detail.away?.name
          && !['TBD','Home','Away','Team'].includes(detail.home.name)
          && !['TBD','Home','Away','Team'].includes(detail.away.name);
        const detailTime = Date.parse(String(detail.time || ''));
        const timeMatches = !Number.isFinite(requestedTime) ||
          (Number.isFinite(detailTime) && Math.abs(detailTime-requestedTime) <= 6*3600000);
        return realTeams && timeMatches ? detail : null;
      } catch (e) { primaryError = e; return null; }
    }));
    const detail = alternatives.find(Boolean);
    if (!detail) return null;
    if (sport === 'cricket' && !detail.time && stamped) detail.time = stamped[1];
    detail.detailAvailable = true;
    detail.dataStatus = 'verified_detail';
    return {provider:'SportScore', detailAvailable:true, dataStatus:'verified_detail',
      match: sport === 'cricket' ? await enrichCricketDetailFromCricbuzz(detail, env) : detail};
  };
  // Common path: one direct request, no sequential 4-day lookup beforehand.
  // The two documented match endpoint families are checked concurrently for
  // the canonical slug and the original ID; avoid sequential timeout chains.
  const directDetails = await Promise.all(candidates.map(tryCandidate));
  let verified = directDetails.find(Boolean) || null;
  if (verified) {
    const hasScore = hasActualCricketScore(verified.match?.home)
      || hasActualCricketScore(verified.match?.away);
    if (sport === 'cricket' && !hasScore) {
      const realCricbuzzScore = await cricbuzzScoreTask;
      if (realCricbuzzScore) {
        mergeMissing(verified.match, realCricbuzzScore.match);
        verified.match.dataSources = {...(verified.match.dataSources || {}),
          verifiedCricketScore: 'Cricbuzz'};
      }
    }
    return verified;
  }
  // A timestamped synthetic ID already supplied its canonical slug. Only
  // resolve provider aliases for IDs without a verifiable fixture timestamp.
  if (!stamped) {
    const resolvedSlug = await resolveSportScoreMatchSlug(sport, providerId, env);
    if (resolvedSlug && !candidates.includes(resolvedSlug)) {
      verified = await tryCandidate(resolvedSlug);
      if (verified) {
        const hasScore = hasActualCricketScore(verified.match?.home)
      || hasActualCricketScore(verified.match?.away);
        if (sport === 'cricket' && !hasScore) {
          const realCricbuzzScore = await cricbuzzScoreTask;
          if (realCricbuzzScore) {
            mergeMissing(verified.match, realCricbuzzScore.match);
            verified.match.dataSources = {...(verified.match.dataSources || {}),
              verifiedCricketScore: 'Cricbuzz'};
          }
        }
        return verified;
      }
    }
  }
  // A valid dated fixture may have no detailed page yet. Prefer the genuine
  // provider fixture over an unhelpful 500 error, and never fabricate stats.
  const verifiedFixture = await verifiedSportScoreFixture(sport, id, env);
  if (verifiedFixture) {
    // Crucial fix: a genuine fixture can have no score. Do not return that
    // scoreless fixture before attempting the verified Cricbuzz score feed.
    if (sport === 'cricket' && !hasActualCricketScore(verifiedFixture.home)
        && !hasActualCricketScore(verifiedFixture.away)) {
      const realCricbuzzScore = await cricbuzzScoreTask;
      if (realCricbuzzScore) {
        // Keep SportScore fixture identity and sports-page metadata.
        mergeMissing(verifiedFixture, realCricbuzzScore.match);
        verifiedFixture.dataSources = {...(verifiedFixture.dataSources || {}),
          verifiedCricketScore: 'Cricbuzz'};
      }
    }
    const nativeId=String(verifiedFixture.providerMatchId || '');
    if (nativeId && !candidates.includes(nativeId) && nativeId !== providerId) {
      const nativeDetail = await tryCandidate(nativeId);
      if (nativeDetail) return nativeDetail;
    }
    return verifiedFixtureDetailReply(verifiedFixture);
  }
  if(sport==="cricket"){
    const realCricbuzzScore = await cricbuzzScoreTask;
    if (realCricbuzzScore) return realCricbuzzScore;
    let cricbuzzError=null;
    try{
      const cb = await cricbuzzMatchDetailFallbackFromSportScoreId(providerId, env);
      return {provider:"Cricbuzz",match:{...cb, dataSources:{fallbackFields:"Cricbuzz"}}};
    }catch(e){cricbuzzError=e;}

    try{
      return {provider:"OpenCricket",match:await openCricketMatchDetailFallback(id,env)};
    }catch(fallbackError){
      const cbMsg = cricbuzzError ? `; Cricbuzz fallback failed: ${cricbuzzError.message||cricbuzzError}` : "";
      throw new Error(`SportScore detail failed${cbMsg}; OpenCricket fallback failed: ${fallbackError.message||fallbackError}`);
    }
  }
  throw primaryError||new Error("Match detail unavailable");
}

function normalizeOpenCricketDetail(raw, sport, id) {
  const m = raw?.data?.match || raw?.match || raw?.data || raw;
  const home = teamObject(pick(m,["home_team","homeTeam","team1","home"],null),"TBD");
  const away = teamObject(pick(m,["away_team","awayTeam","team2","away"],null),"TBD");
  const f = normalizeCricketFeaturePayload(m);
  return {id:String(pick(m,["id","match_id","matchId","slug"],id)),providerMatchId:String(pick(m,["id","match_id","matchId","slug"],id)),provider:"OpenCricket",sport,
    name:canonicalMatchTitle(home,away,pick(m,["name","title"],"")),status:String(pick(m,["status","state","result"],"")),statusText:String(pick(m,["status_text","statusText","status","state","result"],"")),time:String(pick(m,["time","start_time","starts_at","date","datetime"],"")),
    competition:String(pick(m,["competition","league","tournament","competition_name"],"")),competitionLogo:String(deepPick(m,["competition_logo","competitionLogo","competition_image","competitionImage","league_logo","leagueLogo","tournament_logo","tournamentLogo"],"")),
    round:String(deepPick(m,["round","round_name","roundName","stage","stage_name","stageName","match_number","matchNumber","match_no","matchNo"],"")),format:String(deepPick(m,["format","match_format","matchFormat","type","match_type","matchType","competition_format","competitionFormat"],"")),
    matchTitle:String(deepPick(m,["match_title","matchTitle","match_name","matchName","fixture_title","fixtureTitle"],"")),venue:String(deepPick(m,["venue","venue_name","venueName","stadium","ground","ground_name","groundName","venue_title","venueTitle","location","location_name","locationName"],"")),
    result:String(pick(m,["result","result_text","status_text"],"")),home,away,teams:[home,away],innings:f.innings,timeline:f.commentary,lineups:f.squads,commentary:f.commentary,overs:f.overs,highlights:f.highlights,squads:f.squads,scorecard:f.scorecard,batting:f.batting,bowling:f.bowling,fall_of_wickets:f.fallOfWickets,partnerships:f.partnerships,extras:f.extras,current_batters:f.currentBatters,current_bowler:f.currentBowler,series:f.series,rawProviderData:m};
}

function normalizeSportScoreDetail(raw, sport) {
  const m = raw?.match || raw?.data?.match || raw?.data || raw;
  const home = teamObject(pick(m,["home_team","homeTeam","home"],"TBD"),"TBD",{logo:pick(m,["home_logo","homeLogo"],""),flag:pick(m,["home_flag","homeFlag","home_country_code","homeCountryCode"],""),score:pick(m,["home_score","homeScore"],""),overs:pick(m,["home_overs","homeOvers","home_over","homeOver"],""),wickets:pick(m,["home_wickets","homeWickets","home_wicket","homeWicket"],""),slug:pick(m,["home_slug","homeSlug"],""),id:pick(m,["home_id","homeId"],"")});
  const away = teamObject(pick(m,["away_team","awayTeam","away"],"TBD"),"TBD",{logo:pick(m,["away_logo","awayLogo"],""),flag:pick(m,["away_flag","awayFlag","away_country_code","awayCountryCode"],""),score:pick(m,["away_score","awayScore"],""),overs:pick(m,["away_overs","awayOvers","away_over","awayOver"],""),wickets:pick(m,["away_wickets","awayWickets","away_wicket","awayWicket"],""),slug:pick(m,["away_slug","awaySlug"],""),id:pick(m,["away_id","awayId"],"")});
  if(!home.slug) home.slug=slugifyTeamName(home.name); if(!away.slug) away.slug=slugifyTeamName(away.name);
  const rawId=String(pick(m,["slug","match_slug","id","match_id"],"")); const startTime=String(pick(m,["time","start_time","starts_at","date","datetime"],""));
  const d={id:canonicalMatchId("sportscore",sport,rawId,home.name,away.name,startTime),providerMatchId:rawId,provider:"SportScore",sport,name:canonicalMatchTitle(home,away,pick(m,["name","title"],"")),status:String(pick(m,["status_text","status","state"],"")),statusText:String(pick(m,["status_text","statusText","status","state"],"")),time:startTime,competition:String(pick(m,["competition","league","tournament","competition_name"],"")),competitionLogo:String(deepPick(m,["competition_logo","competitionLogo","competition_image","competitionImage","league_logo","leagueLogo","tournament_logo","tournamentLogo"],"")),round:String(deepPick(m,["round","round_name","roundName","roundInfo","round_info","stage","stage_name","stageName","match_number","matchNumber","match_no","matchNo","match_round","matchRound"],"")),format:String(deepPick(m,["format","match_format","matchFormat","match_type","matchType","game_type","gameType","type","competition_format","competitionFormat","format_name","formatName"],"")),matchTitle:String(deepPick(m,["match_title","matchTitle","match_name","matchName","fixture_title","fixtureTitle"],"")),venue:String(deepPick(m,["venue","venue_name","venueName","stadium","ground","ground_name","groundName","venue_title","venueTitle","location","location_name","locationName"],"")),result:String(pick(m,["result","result_text","status_text"],"")),home,away,teams:[home,away],rawProviderData:m};
  if(sport==="cricket"){const f=normalizeCricketFeaturePayload(m);d.innings=f.innings;d.timeline=f.commentary;d.lineups=f.squads;d.commentary=f.commentary;d.overs=f.overs;d.highlights=f.highlights;d.squads=f.squads;d.scorecard=f.scorecard;d.batting=f.batting;d.bowling=f.bowling;d.fall_of_wickets=f.fallOfWickets;d.partnerships=f.partnerships;d.extras=f.extras;d.current_batters=f.currentBatters;d.current_bowler=f.currentBowler;d.series=f.series;d.current_score=String(deepPick(m,["current_score","currentScore","score","innings_score","inningsScore"],""));d.current_over=String(deepPick(m,["current_over","currentOver","overs","over"],""));d.target=String(deepPick(m,["target","target_score","targetScore"],""));d.runs_required=String(deepPick(m,["runs_required","runsRequired","required_runs","requiredRuns"],""));d.crr=String(deepPick(m,["crr","current_run_rate","currentRunRate","run_rate","runRate"],""));d.rrr=String(deepPick(m,["rrr","required_run_rate","requiredRunRate"],""));}
  return d;
}

async function sportScoreTeam(sport, slug, env) {
  let lastError = null;
  for (const path of ["/api/v1/team/", "/api/widget/team/"]) {
    try {
      const raw = await cachedJson(sportScoreUrl(path, { sport, slug, limit: 30 }), sportScoreHeaders(env), 10000);
      const root = raw?.team || raw?.data?.team || raw?.data || raw;
      const teamName = String(pick(root, ["name", "team_name", "title"], slug.replace(/-/g, " ")));
      const teamLogo = String(pick(root, ["logo", "logo_url", "image", "badge"], ""));
      const list = sportScoreMatches(raw, sport);
      if (list.length || teamName) {
        const finished = list.filter(m => /finished|complete|result|final|ended|stumps/.test(String(m.statusText || m.status).toLowerCase()));
        const upcoming = list.filter(m => !finished.includes(m));
        return { provider: "SportScore", team: { name: teamName, slug, logo: teamLogo }, matches: list, recent: finished, upcoming };
      }
    } catch (e) { lastError = e; }
  }
  throw lastError || new Error("SportScore team summary unavailable");
}

async function cricketTeam(slug, env) {
  // Team summaries are supported by SportScore. OpenCricket has no documented
  // equivalent team-schedule endpoint, so never fabricate a summary when SportScore fails.
  return sportScoreTeam("cricket", slug, env);
}

async function cricketMatch(id, env) {
  return sportScoreMatchDetail("cricket", id, env);
}

async function sportsList(sport, status, env) {
  if (!SPORTS.includes(sport)) throw new Error("Unsupported sport");
  const feed = await readStoredFeed(env, sport, status === "results" ? "finished" : status);
  return {provider: feed.provider || "D1 cache", matches: feed.matches,
    updatedAt: feed.updatedAt, stale: feed.stale};
}


// --- OneTV source control: all provider traffic originates in Cron ------------
// Providers are never invoked by public requests, including /search and match detail.
const SPORTS_SOURCE_DEFS = [
  {id:'sportscore',label:'SportScore',sports:'cricket,football,tennis,basketball',enabled:1,approved:1,priority:1,daily:9000,monthly:0,interval:120,fallback:0,kind:'live_and_fixtures'},
  {id:'api_football',label:'API-Football (API-Sports)',sports:'football',enabled:0,approved:0,priority:2,daily:90,monthly:0,interval:900,fallback:1,kind:'live_and_fixtures'},
  {id:'api_basketball',label:'API-Basketball (API-Sports)',sports:'basketball',enabled:0,approved:0,priority:2,daily:90,monthly:0,interval:900,fallback:1,kind:'live_and_fixtures'},
  {id:'sportsapi',label:'SportsAPI.app',sports:'cricket,football,tennis,basketball,baseball',enabled:0,approved:0,priority:3,daily:90,monthly:0,interval:900,fallback:1,kind:'live_and_fixtures'},
  {id:'cricbuzz',label:'Cricbuzz RapidAPI',sports:'cricket',enabled:0,approved:0,priority:4,daily:2,monthly:80,interval:21600,fallback:1,kind:'live_and_fixtures'},
  {id:'cricketdata',label:'CricketData/CricAPI (legacy)',sports:'cricket',enabled:0,approved:0,priority:5,daily:0,monthly:0,interval:3600,fallback:1,kind:'existing_enrichment_only'},
  {id:'opencricket',label:'OpenCricket (legacy, check upstream rights)',sports:'cricket',enabled:0,approved:0,priority:6,daily:0,monthly:0,interval:3600,fallback:1,kind:'live_and_fixtures'},
  {id:'cricsheet',label:'Cricsheet Historical Cricket',sports:'cricket',enabled:0,approved:0,priority:7,daily:0,monthly:0,interval:86400,fallback:1,kind:'manual_historical_import'}
];
const SPORTS_SOURCE_IDS = new Set(SPORTS_SOURCE_DEFS.map(s=>s.id));
const SPORTS_SCHEMA_READY = new WeakSet();
const SPORTS_SOURCE_DDL = [
  `CREATE TABLE IF NOT EXISTS sports_source_controls (
    source_id TEXT PRIMARY KEY, display_name TEXT NOT NULL, enabled INTEGER NOT NULL,
    license_approved INTEGER NOT NULL, priority INTEGER NOT NULL, sports_csv TEXT NOT NULL,
    daily_limit INTEGER NOT NULL, monthly_limit INTEGER NOT NULL,
    min_interval_seconds INTEGER NOT NULL, fallback_only INTEGER NOT NULL,
    cooldown_until INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
  `CREATE TABLE IF NOT EXISTS sports_runtime_controls (control_key TEXT PRIMARY KEY,control_value TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS sports_force_jobs (sport TEXT NOT NULL,bucket TEXT NOT NULL,requested_at INTEGER NOT NULL,
    PRIMARY KEY(sport,bucket))`,
  `CREATE TABLE IF NOT EXISTS sports_custom_source_configs (source_id TEXT PRIMARY KEY, template_url TEXT NOT NULL, items_path TEXT NOT NULL DEFAULT 'matches', auth_secret_name TEXT NOT NULL DEFAULT '', auth_header_name TEXT NOT NULL DEFAULT 'Authorization', auth_scheme TEXT NOT NULL DEFAULT 'Bearer')`,
  `CREATE TABLE IF NOT EXISTS sports_cricsheet_archive (
    match_id TEXT PRIMARY KEY,payload_json TEXT NOT NULL,match_date TEXT NOT NULL,
    imported_at INTEGER NOT NULL DEFAULT 0)`,
  `CREATE INDEX IF NOT EXISTS idx_cricsheet_match_date ON sports_cricsheet_archive(match_date)`
];
const SPORTS_RUNTIME_DEFAULTS={paused:false,detail_prefetch:true,max_feeds_per_tick:3,
  fallback_on_missing_scores:true,max_fallbacks_per_feed:2};
async function ensureSportsControlSchema(env){
  if(SPORTS_SCHEMA_READY.has(env.DB))return;
  await ensureSportsSnapshotSchema(env);
  for(const q of SPORTS_SOURCE_DDL)await env.DB.prepare(q).run();
  for(const s of SPORTS_SOURCE_DEFS){
    await env.DB.prepare(`INSERT OR IGNORE INTO sports_source_controls
      (source_id,display_name,enabled,license_approved,priority,sports_csv,daily_limit,monthly_limit,
       min_interval_seconds,fallback_only) VALUES(?,?,?,?,?,?,?,?,?,?)`)
      .bind(s.id,s.label,s.enabled,s.approved,s.priority,s.sports,s.daily,s.monthly,s.interval,s.fallback).run();
  }
  SPORTS_SCHEMA_READY.add(env.DB);
}
async function sportsControlList(env){
  await ensureSportsControlSchema(env);
  const rows=await env.DB.prepare('SELECT * FROM sports_source_controls ORDER BY priority,source_id').all();
  const now=new Date().toISOString(),day=now.slice(0,10),month=now.slice(0,7);
  const configs=await env.DB.prepare('SELECT * FROM sports_custom_source_configs').all();
  const customById=new Map((configs.results||[]).map(c=>[c.source_id,c]));
  const out=[];
  for(const s of rows.results||[]){
    const [d,m]=await Promise.all([day,month].map(k=>env.DB.prepare(
      'SELECT calls FROM sports_provider_budget WHERE provider=? AND period_key=?').bind(s.source_id,k).first()));
    const health=await readSportsProviderHealth(env,s.source_id);
    const custom=customById.get(s.source_id);
    out.push({...s,kind:custom?'custom_json':(SPORTS_SOURCE_DEFS.find(x=>x.id===s.source_id)?.kind||''),
      ...(custom?{custom_config:{...custom,auth_secret_configured:!custom.auth_secret_name||!!String(env[custom.auth_secret_name]||'').trim()}}:{}),
      enabled:!!s.enabled,license_approved:!!s.license_approved,
      fallback_only:!!s.fallback_only,configured:custom?(!custom.auth_secret_name||!!String(env[custom.auth_secret_name]||'').trim()):sportsSourceConfigured(s.source_id,env),
      used_today:Number(d?.calls||0),used_month:Number(m?.calls||0),health});
  }
  return out;
}
async function readSportsSettings(env){
  await ensureSportsControlSchema(env);
  const rows=await env.DB.prepare('SELECT control_key,control_value FROM sports_runtime_controls').all();
  const result={...SPORTS_RUNTIME_DEFAULTS};
  for(const x of rows.results||[]){if(!Object.prototype.hasOwnProperty.call(result,x.control_key))continue;
    const original=SPORTS_RUNTIME_DEFAULTS[x.control_key];
    result[x.control_key]=typeof original==='boolean'?x.control_value==='true':Number(x.control_value);
  }
  return result;
}
function sportsSourceConfigured(id,env){
  if(id==='sportscore'||id==='cricsheet')return true;
  const keys={api_football:'API_FOOTBALL_KEY',api_basketball:'API_BASKETBALL_KEY',
    sportsapi:'SPORTSAPI_KEY',cricbuzz:'CRICBUZZ_RAPIDAPI_KEY',
    cricketdata:'CRICKETDATA_API_KEY',opencricket:'OPENCRICKET_API_KEY'};
  return !!String(env[keys[id]]||'').trim();
}
async function activeSourcesFor(env,sport,bucket){
  await ensureSportsControlSchema(env);
  const rows=await env.DB.prepare('SELECT * FROM sports_source_controls WHERE enabled=1 AND license_approved=1 ORDER BY priority ASC,source_id ASC').all();
  const customRows=await env.DB.prepare('SELECT * FROM sports_custom_source_configs').all();
  const custom=new Map((customRows.results||[]).map(c=>[c.source_id,c]));
  return (rows.results||[]).filter(s=>String(s.sports_csv).split(',').includes(sport)&&
     (custom.has(s.source_id)||SPORTS_SOURCE_DEFS.find(x=>x.id===s.source_id)?.kind==='live_and_fixtures')&&
     (custom.has(s.source_id)?(!custom.get(s.source_id).auth_secret_name||!!String(env[custom.get(s.source_id).auth_secret_name]||'').trim()):sportsSourceConfigured(s.source_id,env)))
   .map(s=>({...s,custom_config:custom.get(s.source_id)||null}));
}
async function updateSportsSource(env,id,data){
  if(!SPORTS_SOURCE_IDS.has(id)){
    await ensureSportsControlSchema(env);
    const custom=await env.DB.prepare('SELECT source_id FROM sports_custom_source_configs WHERE source_id=?').bind(id).first();
    if(!custom)throw new Error('Unknown source ID');
  }
  if(id==='cricketdata'&&data.enabled)throw new Error('CricketData legacy integration is not wired into scheduled ingestion; cannot activate it yet.');
  const allowed=['display_name','enabled','license_approved','priority','sports_csv','daily_limit','monthly_limit',
    'min_interval_seconds','fallback_only'];
  const changes=[];const values=[];
  for(const k of allowed){if(!Object.prototype.hasOwnProperty.call(data,k))continue;
    let v=data[k];
    if(k==='display_name'){v=String(v||'').trim().slice(0,100);if(!v)throw Error('Provider name required');}
    else if(['enabled','license_approved','fallback_only'].includes(k))v=v?1:0;
    else if(k==='sports_csv'){
      const sports=String(v).split(',').map(x=>x.trim().toLowerCase()).filter(x=>SPORTS.includes(x));
      if(!sports.length)throw new Error('Select at least one supported sport');
      const defined=(SPORTS_SOURCE_DEFS.find(s=>s.id===id)?.sports||SPORTS.join(',')).split(',');
      if(sports.some(x=>!defined.includes(x)))throw new Error('Provider does not support one selected sport');
      v=[...new Set(sports)].join(',');
    }else{
      v=Number(v);if(!Number.isSafeInteger(v))throw new Error('Invalid integer '+k);
      const maximum=k==='priority'?99:k==='min_interval_seconds'?86400:1000000;
      if(v<0||v>maximum)throw new Error('Out of range '+k);
      if(k==='min_interval_seconds'&&v<30)throw new Error('Min interval must be at least 30 seconds');
    }
    changes.push(k+'=?');values.push(v);
  }
  if(!changes.length)throw new Error('No supported fields supplied');
  changes.push('updated_at=CURRENT_TIMESTAMP');
  await env.DB.prepare(`UPDATE sports_source_controls SET ${changes.join(',')} WHERE source_id=?`).bind(...values,id).run();
  return sportsControlList(env);
}
async function updateSportsSettings(env,values){
  for(const [key,defaultValue] of Object.entries(SPORTS_RUNTIME_DEFAULTS)){
    if(!Object.prototype.hasOwnProperty.call(values,key))continue;
    let value=values[key];
    if(typeof defaultValue==='boolean')value=!!value;
    else {value=Number(value);if(!Number.isSafeInteger(value)||value<1||value>10)throw new Error('Invalid '+key);}
    await env.DB.prepare(`INSERT INTO sports_runtime_controls(control_key,control_value) VALUES(?,?)
      ON CONFLICT(control_key) DO UPDATE SET control_value=excluded.control_value`).bind(key,String(value)).run();
  }
  return readSportsSettings(env);
}
async function reserveSportsProviderCall(env,s,jobKey){
  const now=Math.floor(Date.now()/1000);
  if(!s.enabled||!s.license_approved||Number(s.cooldown_until||0)>now)return false;
  const state=await sportsJob(env,'src:'+s.source_id+':'+jobKey);
  if(Number(state.next_allowed||0)>now)return false;
  if(now-Number(state.last_attempt||0)<Number(s.min_interval_seconds||30))return false;
  const day=new Date().toISOString().slice(0,10),month=day.slice(0,7);
  for(const period of [{key:day,limit:Number(s.daily_limit)},{key:month,limit:Number(s.monthly_limit)}]){
    const key=period.key,limit=period.limit;
    if(limit<=0)continue; // 0 means NO calls allowed for this provider (safe, never unlimited).
    const used=await env.DB.prepare('SELECT calls FROM sports_provider_budget WHERE provider=? AND period_key=?')
      .bind(s.source_id,key).first();
    if(Number(used?.calls||0)>=limit)return false;
  }
  if(Number(s.daily_limit)<=0||Number(s.monthly_limit)<0)return false;
  // All Cron work is serialized by the D1 sports lease. Reserve before network.
  for(const key of [day,month])await env.DB.prepare(`INSERT INTO sports_provider_budget(provider,period_key,calls)
      VALUES(?,?,1) ON CONFLICT(provider,period_key) DO UPDATE SET calls=calls+1`)
      .bind(s.source_id,key).run();
  await sportsJobResult(env,'src:'+s.source_id+':'+jobKey,true);
  return true;
}
async function sourceRequest(env,s,jobKey,url,headers={}){
  if(!await reserveSportsProviderCall(env,s,jobKey))return {skipped:true,reason:'cooldown_or_budget'};
  try{
    const raw=await fetchJson(url,headers,9000);
    const errors=raw?.errors;
    if(errors&&(Array.isArray(errors)?errors.length>0:typeof errors==='object'?Object.keys(errors).length>0:!!errors))
      throw new Error('Provider returned API validation errors');
    return {raw};
  }catch(e){
    const status=providerStatusError(e);
    const cooldown=status==='http_429'?86400:status==='http_401'||status==='http_403'?21600:900;
    await env.DB.prepare(`UPDATE sports_source_controls SET cooldown_until=? WHERE source_id=?`)
      .bind(Math.floor(Date.now()/1000)+cooldown,s.source_id).run();
    await sportsJobResult(env,'src:'+s.source_id+':'+jobKey,false,status,cooldown);
    await recordSportsProviderHealth(env,s.source_id,{reachable:false,error:status,matches:0,scoredMatches:0});
    throw e;
  }
}
// SportsAPI cricket wickets/overs live in each side's ScoreSide.innings,
// not in ScoreSide.current (which is runs only). Keep innings associated with
// its OWN side; never pull a number from the opponent's score object.
function sportsApiCricketSide(scoreSide, desiredPeriod=''){
  const root=scoreSide && typeof scoreSide==='object'?scoreSide:{};
  const innings=root.innings && typeof root.innings==='object' && !Array.isArray(root.innings)
    ? root.innings : {};
  const rows=Object.entries(innings).filter(([key,value]) =>
    /^inning\d+$/i.test(key) && value && typeof value==='object');
  rows.sort((a,b)=>Number(a[0].replace(/\D/g,''))-Number(b[0].replace(/\D/g,'')));
  const chosen=rows.find(([key])=>key.toLowerCase()===String(desiredPeriod||'').toLowerCase())
    || rows[rows.length-1];
  const entry=chosen?.[1] || {};
  const digits=v=>v===null||v===undefined||!/^\d+$/.test(String(v))?'':String(v);
  const runs=digits(entry.runs) || digits(root.current);
  const wickets=digits(entry.wickets);
  const o=entry.overs;
  const overs=o===null||o===undefined?'':String(o);
  const validOvers=/^\d+(?:\.[0-5])?$/.test(overs)?overs:'';
  const rate=entry.runRate===null||entry.runRate===undefined?'':String(entry.runRate);
  const runRate=/^\d+(?:\.\d+)?$/.test(rate)?rate:'';
  return {score:runs+(runs&&wickets?'/'+wickets:''),runs,wickets,
    overs:validOvers,runRate,inningsKey:chosen?.[0]||''};
}

function normalizeExternalMatch(r,sport,provider){
  if(!r||typeof r!=='object')return null;
  const isApiSports=provider==='api_football'||provider==='api_basketball';
  let homeName='',awayName='',rawId='',time='',status='',league='',venue='',scores=[],logos=[];
  if(provider==='api_football'){
    homeName=r.teams?.home?.name||'';awayName=r.teams?.away?.name||'';
    scores=[r.goals?.home,r.goals?.away];logos=[r.teams?.home?.logo,r.teams?.away?.logo];
    rawId=r.fixture?.id;time=r.fixture?.date;status=r.fixture?.status?.short||'';
    league=r.league?.name||'';venue=r.fixture?.venue?.name||'';
  }else if(provider==='api_basketball'){
    homeName=r.teams?.home?.name||'';awayName=r.teams?.away?.name||'';
    scores=[r.scores?.home?.total,r.scores?.away?.total];
    logos=[r.teams?.home?.logo,r.teams?.away?.logo];rawId=r.id;time=r.date||'';
    status=r.status?.short||'';league=r.league?.name||'';venue=r.arena?.name||'';
  }else if(provider==='sportsapi'){
    homeName=r.home?.name||'';awayName=r.away?.name||'';
    scores=[r.homeScore?.current,r.awayScore?.current];
    logos=[r.home?.image,r.away?.image];rawId=r.id;time=r.startTime||'';
    status=r.status?.type||r.status?.description||'';league=r.league?.name||'';
    venue=r.venue?.name||'';
  }else return null;
  if(!homeName||!awayName||!time||rawId===undefined||rawId===null||rawId==='')return null;
  const date=Date.parse(time);if(!Number.isFinite(date))return null;
  let normStatus='UPCOMING';
  const val=String(status).toLowerCase();
  if(provider==='api_football'){
    normStatus=['ft','aet','pen'].includes(val)?'FINISHED':
      ['ns','tbd','pst','canc'].includes(val)?'UPCOMING':'LIVE';
  }else if(provider==='api_basketball'){
    normStatus=['ft','aot','awd','abd'].includes(val)?'FINISHED':
      ['ns','post','canc'].includes(val)?'UPCOMING':'LIVE';
  }else normStatus=['finished','ended','completed'].includes(val)?'FINISHED':
    ['notstarted','not_started','scheduled','postponed','cancelled'].includes(val)?'UPCOMING':'LIVE';
  const score=v=>v===null||v===undefined?'':validProviderScore(String(v));
  const isSportsApiCricket=provider==='sportsapi' && sport==='cricket';
  const homeStats=isSportsApiCricket?sportsApiCricketSide(r.homeScore,r.status?.period):null;
  const awayStats=isSportsApiCricket?sportsApiCricketSide(r.awayScore,r.status?.period):null;
  const home=teamObject({name:homeName,id:r.home?.id,
    score:homeStats?.score||score(scores[0]),logo:logos[0]||'',
    wickets:homeStats?.wickets||'',overs:homeStats?.overs||''},'Home');
  const away=teamObject({name:awayName,id:r.away?.id,
    score:awayStats?.score||score(scores[1]),logo:logos[1]||'',
    wickets:awayStats?.wickets||'',overs:awayStats?.overs||''},'Away');
  if(isSportsApiCricket){home.runRate=homeStats.runRate;away.runRate=awayStats.runRate;}
  home.slug=slugifyTeamName(homeName);away.slug=slugifyTeamName(awayName);
  const id=canonicalMatchId(provider,sport,String(rawId),homeName,awayName,time);
  const statusText=provider==='sportsapi'
    ? String(r.status?.description||r.status?.phase||status)
    : String(status);
  const match={id,providerMatchId:String(rawId),provider:provider==='sportsapi'?'SportsAPI':
      provider==='api_football'?'API-Football':'API-Basketball',sport,
    name:canonicalMatchTitle(home,away),status:normStatus,statusText,
    time,home,away,competition:String(league),competitionLogo:'',round:'',format:'',
    venue:String(venue),result:'',popularityScore:0};
  if(isSportsApiCricket){
    const batting=String(r.battingSide||'').toLowerCase();
    const active=batting==='home'?homeStats:batting==='away'?awayStats:null;
    if(active){
      match.current_over=active.overs;
      match.current_score=active.score;
      match.current_wickets=active.wickets;
      match.crr=active.runRate;
    }
    match.innings=[...Object.entries(r.homeScore?.innings||{}).map(([key,v])=>({
      team:homeName,inningsId:key,score:v?.runs===null?'':String(v?.runs??''),
      wickets:v?.wickets===null?'':String(v?.wickets??''),
      overs:v?.overs===null?'':String(v?.overs??'')})),
      ...Object.entries(r.awayScore?.innings||{}).map(([key,v])=>({
      team:awayName,inningsId:key,score:v?.runs===null?'':String(v?.runs??''),
      wickets:v?.wickets===null?'':String(v?.wickets??''),
      overs:v?.overs===null?'':String(v?.overs??'')}))];
  }
  return match;
}
// The documented SportScore fixtures feed may show LIVE and match phase
// without publishing a score. The separate public widget feed can sometimes
// include a current score for the same fixture. Both match names AND UTC start
// times must agree before a widget score can be attached to a fixture.
// This is called by scheduled() only; the Android GET routes stay D1-only.
async function enrichSportScoreLiveWithWidget(matches,s,env){
  if(!Array.isArray(matches)||!matches.length)return matches;
  const needs=matches.some(m=>{
    const sides=[m?.home,m?.away].filter(t=>validProviderScore(t?.score));
    return sides.length===0 || sides.some(t=>!t.wickets || !t.overs);
  });
  if(!needs)return matches;
  try{
    const url=sportScoreUrl('/api/widget/matches/',{sport:'cricket',limit:50});
    const result=await sourceRequest(env,s,'cricket:live:widget-scores',url,sportScoreHeaders(env));
    if(result.skipped)return matches;
    const candidates=sportScoreMatches(result.raw,'cricket')
      .filter(m=>statusBucket(m)==='LIVE'&&sportsSourceScore(m));
    const verified=candidates.filter(m=>matches.some(primary=>sameCricketFixture(primary,m)));
    if(!verified.length)return matches;
    // Restrict to known fixtures; merging the entire widget feed could add
    // a different live match or change the listing order unexpectedly.
    return mergeSportsSources(matches,verified,'SportScore live widget');
  }catch(_){
    // Widget failure must never invalidate the already verified fixture feed.
    return matches;
  }
}

async function sourceFeedFor(s,env,sport,bucket){
  const today=shiftIsoDate(0);
  if(s.source_id==='sportscore'){
    const dates=bucket==='upcoming'?[today,shiftIsoDate(1)]:bucket==='finished'?
      [today,shiftIsoDate(-1)]:[today];
    const all=[],errors=[];
    for(const date of dates){
      try{
        const q=new URL(sportScoreUrl('/api/v1/fixtures/',{sport,date,status:bucket,limit:200}));
        const result=await sourceRequest(env,s,`${sport}:${bucket}:${date}`,q.toString(),sportScoreHeaders(env));
        if(result.skipped)continue;
        all.push(...sportScoreMatches(result.raw,sport));
      }catch(e){errors.push(e);}
    }
    if(!all.length&&errors.length)throw errors[0];
    const matches=all.filter(m=>statusBucket(m)===bucket.toUpperCase());
    return sport==='cricket'&&bucket==='live'
      ? await enrichSportScoreLiveWithWidget(matches,s,env) : matches;
  }
  if(s.source_id==='api_football'){
    const q=new URL('https://v3.football.api-sports.io/fixtures');q.searchParams.set('date',today);
    const result=await sourceRequest(env,s,`${sport}:${bucket}:daily`,q.toString(),
      {'x-apisports-key':String(env.API_FOOTBALL_KEY).trim()});
    return result.skipped?null:(result.raw?.response||[]).map(m=>normalizeExternalMatch(m,sport,s.source_id))
      .filter(m=>m&&statusBucket(m)===bucket.toUpperCase());
  }
  if(s.source_id==='api_basketball'){
    const q=new URL('https://v1.basketball.api-sports.io/games');q.searchParams.set('date',today);
    const result=await sourceRequest(env,s,`${sport}:${bucket}:daily`,q.toString(),
      {'x-apisports-key':String(env.API_BASKETBALL_KEY).trim()});
    return result.skipped?null:(result.raw?.response||[]).map(m=>normalizeExternalMatch(m,sport,s.source_id))
      .filter(m=>m&&statusBucket(m)===bucket.toUpperCase());
  }
  if(s.source_id==='sportsapi'){
    const url=bucket==='live'?`https://api.sportsapi.app/v2/livescores?sport=${sport}`:
      `https://api.sportsapi.app/v2/fixtures?date=${today}&sport=${sport}&page=0`;
    const result=await sourceRequest(env,s,`${sport}:${bucket}:daily`,url,
      {Authorization:`Bearer ${String(env.SPORTSAPI_KEY).trim()}`});
    return result.skipped?null:(result.raw?.data||[]).map(m=>normalizeExternalMatch(m,sport,s.source_id))
      .filter(m=>m&&statusBucket(m)===bucket.toUpperCase());
  }
  if(s.source_id==='cricbuzz'&&sport==='cricket'){
    const kind=bucket==='live'?'live':bucket==='upcoming'?'upcoming':'recent';
    const url=cricbuzzUrl('/matches/v1/'+kind,{},env);
    const result=await sourceRequest(env,s,`${sport}:${bucket}:cricbuzz`,url.toString(),cricbuzzHeaders(env));
    if(result.skipped)return null;
    const matches=[];collectCricbuzzMatches(result.raw,matches);
    return matches.map((x,i)=>normalizeCricbuzzMatch(x,i)).filter(m=>m&&statusBucket(m)===bucket.toUpperCase());
  }
  if(s.source_id==='opencricket'&&sport==='cricket'){
    const q=new URL(String(env.OPENCRICKET_BASE_URL||'https://opencricketapi.com').replace(/\/$/,'')+'/v1/matches');
    q.searchParams.set('date',today);q.searchParams.set('limit','200');
    const result=await sourceRequest(env,s,`${sport}:${bucket}:daily`,q.toString(),openCricketHeaders(env));
    return result.skipped?null:extractMatchArray(result.raw).map((m,i)=>normalizeOpenCricketMatch(m,i))
      .filter(m=>statusBucket(m)===bucket.toUpperCase());
  }
  if(s.custom_config){
    const cfg=s.custom_config,date=shiftIsoDate(0);
    const apiUrl=validOneTvHttpsTemplate(cfg.template_url)
      .replace(/\{sport\}/g,encodeURIComponent(sport)).replace(/\{bucket\}/g,encodeURIComponent(bucket))
      .replace(/\{date\}/g,encodeURIComponent(date));
    const headers={Accept:'application/json'};
    if(cfg.auth_secret_name){const k=String(env[cfg.auth_secret_name]||'').trim();if(!k)return null;
      headers[cfg.auth_header_name]=cfg.auth_scheme==='Bearer'?'Bearer '+k:k;
    }
    const result=await sourceRequest(env,s,`${sport}:${bucket}:custom`,apiUrl,headers);
    if(result.skipped)return null;
    const entries=getJsonPath(result.raw,cfg.items_path);
    if(!Array.isArray(entries))throw Error('Custom JSON items_path does not resolve to an array');
    return entries.slice(0,200).map((x,i)=>normalizeCustomOneTvFixture(x,s,sport,i))
      .filter(m=>m&&statusBucket(m)===bucket.toUpperCase());
  }
  return null; // Historical/legacy sources are not generic live adapters.
}
function externalFixtureMatch(a,b){
  if(a?.sport==='cricket' && b?.sport==='cricket')
    return sameCricketFixture(a,b); // two team names + verified start time <= 120 min
  const namePair=(sameTeam(a?.home?.name,b?.home?.name)&&sameTeam(a?.away?.name,b?.away?.name))||
    (sameTeam(a?.home?.name,b?.away?.name)&&sameTeam(a?.away?.name,b?.home?.name));
  if(!namePair)return false;
  const ta=Date.parse(a?.time||''),tb=Date.parse(b?.time||'');
  return Number.isFinite(ta)&&Number.isFinite(tb)&&Math.abs(ta-tb)<=4*3600000;
}
function mergeSportsSources(base,backup,sourceName){
  const out=base.map(m=>JSON.parse(JSON.stringify(m)));
  for(const m of backup){
    const existing=out.find(x=>externalFixtureMatch(x,m));
    if(!existing){out.push(m);continue;}
    const aligned=sameTeam(existing.home?.name,m.home?.name);
      for(const side of ['home','away']){
        const from=m[aligned?side:side==='home'?'away':'home'],to=existing[side];
        const incoming=validProviderScore(from?.score);
        const current=validProviderScore(to?.score);
        if(!incoming)continue;
        // A verified /wickets score is richer than bare runs, but only when
        // the run number agrees. Never overwrite contradictory live scores.
        const currentRuns=(current.match(/^\d+/)||[])[0]||'';
        const incomingRuns=(incoming.match(/^\d+/)||[])[0]||'';
        const upgrade=!!current && current===currentRuns && incomingRuns===currentRuns
          && /^\d+\/\d+$/.test(incoming);
        const replace=!current || upgrade;
        if(replace)to.score=incoming;
        if(replace || (currentRuns && incomingRuns===currentRuns)){
          if(from.overs)to.overs=from.overs;
          if(from.wickets)to.wickets=from.wickets;
          if(from.runRate)to.runRate=from.runRate;
        }
        if(replace)existing.dataSources={...(existing.dataSources||{}),scoreFallback:sourceName};
      }
      // Do not mix metadata from the wrong fixture; this source was matched by
      // exact team pair and start time before any score enrichment. 
      if(m.current_over && !existing.current_over)existing.current_over=m.current_over;
      if(m.crr && !existing.crr)existing.crr=m.crr;
    if(!existing.statusText&&m.statusText)existing.statusText=m.statusText;
  }
  return out;
}
async function fetchControlledSportsFeed(sport,bucket,env){
  const settings=await readSportsSettings(env);
  if(settings.paused)throw Error('Sports ingestion paused from Admin Panel');
  const sources=await activeSourcesFor(env,sport,bucket);
  if(!sources.length)throw Error('No enabled licensed source configured for '+sport);
  let matches=[],used=[],attempted=0;
  const hasPrimary=sources.some(x=>!x.fallback_only);
  for(const s of sources){
    const needs=matches.length===0 ||
      (settings.fallback_on_missing_scores&&bucket!=='upcoming'&&matches.some(m=>!sportsSourceScore(m)));
    if(!needs)break;
    // Fallback-only is meaningful: do not let it outrank an enabled primary.
    // When all primaries are disabled/unconfigured, the first backup may lead.
    if(s.fallback_only&&hasPrimary&&attempted===0)continue;
    if(used.length>settings.max_fallbacks_per_feed)break;
    attempted++;
    try{
      const loaded=await sourceFeedFor(s,env,sport,bucket);
      if(loaded===null)continue; // throttled, not a source success
      matches=mergeSportsSources(matches,loaded,s.display_name);
      used.push(s.display_name);
      await recordSportsProviderHealth(env,s.source_id,{reachable:true,matches:loaded.length,
        scoredMatches:loaded.filter(sportsSourceScore).length,sport,bucket});
    }catch(e){
      await recordSportsProviderHealth(env,s.source_id,{reachable:false,error:providerStatusError(e),sport,bucket});
    }
  }
  if(!used.length)throw Error('All eligible sources unavailable, disabled or budget-limited');
  return {matches,provider:used.join(' + ')};
}
async function getCricsheetArchive(env,limit=30){
  await ensureSportsControlSchema(env);
  const setting=await env.DB.prepare('SELECT enabled,license_approved FROM sports_source_controls WHERE source_id=?')
    .bind('cricsheet').first();
  if(!setting?.enabled||!setting?.license_approved)return {matches:[],enabled:false};
  const rows=await env.DB.prepare('SELECT payload_json FROM sports_cricsheet_archive ORDER BY match_date DESC LIMIT ?')
    .bind(Math.min(100,Math.max(1,Number(limit)||30))).all();
  return {matches:(rows.results||[]).map(x=>safeSnapshotJson(x.payload_json,null)).filter(Boolean),
    provider:'Cricsheet',enabled:true,live:false,requestsProvider:false};
}
async function importCricsheetArchive(env,body){
  await ensureSportsControlSchema(env);
  const setting=await env.DB.prepare('SELECT enabled,license_approved FROM sports_source_controls WHERE source_id=?')
    .bind('cricsheet').first();
  if(!setting?.enabled||!setting?.license_approved)throw Error('Enable and approve Cricsheet license first');
  const rows=body?.matches;
  if(!Array.isArray(rows)||!rows.length||rows.length>50)throw Error('Send 1-50 completed normalized matches');
  let saved=0;
  for(const m of rows){
    if(!m||typeof m!=='object'||!m.id||!m.time||!m.home?.name||!m.away?.name||
      statusBucket(m)!=='FINISHED')continue;
    const payload=JSON.stringify({...m,provider:'Cricsheet',sport:'cricket',
      scoreVerifiedAt:null,archiveOnly:true});
    if(payload.length>30000)continue;
    await env.DB.prepare(`INSERT INTO sports_cricsheet_archive(match_id,payload_json,match_date,imported_at)
      VALUES(?,?,?,?) ON CONFLICT(match_id) DO UPDATE SET payload_json=excluded.payload_json,
      match_date=excluded.match_date,imported_at=excluded.imported_at`)
      .bind(String(m.id).slice(0,200),payload,String(m.time).slice(0,10),Math.floor(Date.now()/1000)).run();
    saved++;
  }
  return {ok:true,saved};
}
// Custom provider adapters require a normalized JSON response. Values stay in
// Cloudflare Secrets, never in D1 and never returned to the PC controller.
function validOneTvHttpsTemplate(raw){
  const value=String(raw||'').trim();
  if(value.length>1500||!/^https:\/\//i.test(value))throw Error('HTTPS API template URL is required');
  const sample=value.replace(/\{(?:sport|bucket|date)\}/g,'cricket');
  let u;try{u=new URL(sample)}catch(_){throw Error('Invalid API template URL')}
  if(u.username||u.password||u.port||!u.hostname.includes('.')||/^(localhost|.*\.local|.*\.internal)$/i.test(u.hostname)||
     /^(\d{1,3}\.){3}\d{1,3}$/.test(u.hostname)||u.hostname.includes(':'))throw Error('Public HTTPS hostname required');
  if(/\{[^}]+\}/.test(sample))throw Error('Only {sport}, {bucket}, {date} placeholders are supported');
  return value;
}
function sanitizeCustomConfig(x){
  const auth_secret_name=String(x.auth_secret_name||'').trim();
  if(auth_secret_name&&!/^[A-Z][A-Z0-9_]{2,79}$/.test(auth_secret_name))throw Error('Secret name must be a Cloudflare environment variable name');
  const auth_header_name=String(x.auth_header_name||'Authorization').trim();
  if(!/^(Authorization|X-Api-Key|X-RapidAPI-Key|api-key)$/i.test(auth_header_name))throw Error('Unsupported auth header');
  const auth_scheme=String(x.auth_scheme||'Bearer').trim();
  if(!['Bearer','Raw'].includes(auth_scheme))throw Error('auth_scheme must be Bearer or Raw');
  const items_path=String(x.items_path||'matches').trim();
  if(items_path&&!/^[a-zA-Z0-9_]+(?:\.[a-zA-Z0-9_]+)*$/.test(items_path))throw Error('Invalid JSON items_path');
  return {template_url:validOneTvHttpsTemplate(x.template_url),items_path,auth_secret_name,auth_header_name,auth_scheme};
}
async function createCustomSportsSource(env,x){
  await ensureSportsControlSchema(env);
  const id=String(x.source_id||'').trim().toLowerCase();
  if(!/^[a-z][a-z0-9_]{2,39}$/.test(id)||SPORTS_SOURCE_IDS.has(id))throw Error('Choose a unique source_id (3-40 letters, numbers, underscore)');
  const current=await env.DB.prepare('SELECT source_id FROM sports_source_controls WHERE source_id=?').bind(id).first();
  if(current)throw Error('Source ID already exists');
  const c=sanitizeCustomConfig(x);
  const sports=String(x.sports_csv||'cricket').split(',').map(s=>s.trim().toLowerCase()).filter(s=>SPORTS.includes(s));
  if(!sports.length)throw Error('Select a supported sport');
  const name=String(x.display_name||id).trim().slice(0,100);
  await env.DB.prepare(`INSERT INTO sports_source_controls(source_id,display_name,enabled,license_approved,priority,sports_csv,daily_limit,monthly_limit,min_interval_seconds,fallback_only) VALUES(?,?,0,0,?,?,0,0,900,1)`)
    .bind(id,name,Number.isInteger(x.priority)&&x.priority>=0&&x.priority<=99?x.priority:80,[...new Set(sports)].join(',')).run();
  await env.DB.prepare(`INSERT INTO sports_custom_source_configs(source_id,template_url,items_path,auth_secret_name,auth_header_name,auth_scheme) VALUES(?,?,?,?,?,?)`)
    .bind(id,c.template_url,c.items_path,c.auth_secret_name,c.auth_header_name,c.auth_scheme).run();
  return {ok:true,source_id:id,enabled:false,license_approved:false};
}
async function updateCustomSportsConfig(env,id,x){
  await ensureSportsControlSchema(env);
  const old=await env.DB.prepare('SELECT * FROM sports_custom_source_configs WHERE source_id=?').bind(id).first();
  if(!old)throw Error('Only custom sources have an editable API definition');
  const c=sanitizeCustomConfig({...old,...x});
  await env.DB.prepare(`UPDATE sports_custom_source_configs SET template_url=?,items_path=?,auth_secret_name=?,auth_header_name=?,auth_scheme=? WHERE source_id=?`)
    .bind(c.template_url,c.items_path,c.auth_secret_name,c.auth_header_name,c.auth_scheme,id).run();
  return {ok:true};
}
async function deleteCustomSportsSource(env,id){
  await ensureSportsControlSchema(env);
  const old=await env.DB.prepare('SELECT source_id FROM sports_custom_source_configs WHERE source_id=?').bind(id).first();
  if(!old)throw Error('Built-in providers cannot be deleted; disable them instead');
  await env.DB.prepare('DELETE FROM sports_source_controls WHERE source_id=?').bind(id).run();
  await env.DB.prepare('DELETE FROM sports_custom_source_configs WHERE source_id=?').bind(id).run();
  return {ok:true};
}
function getJsonPath(value,path){
  for(const p of String(path||'').split('.').filter(Boolean))value=value?.[p];
  return value;
}
function normalizeCustomOneTvFixture(x,s,sport,i){
  if(!x||typeof x!=='object')return null;
  const h=x.home||{},a=x.away||{};
  const homeName=String(h.name||x.home_name||'').trim(),awayName=String(a.name||x.away_name||'').trim();
  if(!homeName||!awayName||!x.time||!x.status)return null;
  const time=String(x.time),status=String(x.status).trim().toUpperCase();
  const home=teamObject({name:homeName,score:validProviderScore(h.score)?String(h.score):'',logo:h.logo||''},'Home');
  const away=teamObject({name:awayName,score:validProviderScore(a.score)?String(a.score):'',logo:a.logo||''},'Away');
  home.slug=slugifyTeamName(homeName);away.slug=slugifyTeamName(awayName);
  return {id:canonicalMatchId(s.source_id,sport,String(x.id||i),homeName,awayName,time),provider:s.display_name,sport,name:canonicalMatchTitle(home,away),
    status,statusText:String(x.status),time,home,away,competition:String(x.competition||''),venue:String(x.venue||''),result:String(x.result||''),
    sourceMatchId:String(x.id||i)};
}

// --- End source controls ------------------------------------------------------

function sportsAdminPage(){
  // The HTML page is public, but every API operation requires ADMIN_TOKEN.
  return new Response(`<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>OneTV Sports Sources</title>
<style>
:root{color-scheme:dark}*{box-sizing:border-box}body{background:#0b1220;color:#e6edf5;font:15px/1.5 system-ui,Arial;margin:0}
main{max-width:1320px;margin:20px auto;padding:0 16px}a{color:#93c5fd}h1{margin-bottom:3px}small,.muted{color:#91a0b4}
.card{background:#111c2e;border:1px solid #293a50;border-radius:12px;padding:16px;margin:12px 0}
.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}input,button,select{font:inherit;padding:7px 9px;border-radius:7px;border:1px solid #40516a;background:#1a2940;color:#fff;max-width:100%}
input[type=number]{width:105px}input[type=password]{min-width:260px}button{background:#1d4ed8;cursor:pointer}button:hover{filter:brightness(1.15)}button.secondary{background:#334155}button.danger{background:#9f2727}
table{border-collapse:collapse;width:100%;min-width:1040px}td,th{padding:10px 6px;border-bottom:1px solid #283950;text-align:left;vertical-align:top}th{color:#9fb3cc;font-size:12px}td small{display:block}
.scroll{overflow-x:auto}.green{color:#7bd8a6}.yellow{color:#f8c878}.red{color:#f59b9b}.chip{display:inline-block;padding:2px 7px;border:1px solid #41556e;border-radius:24px;font-size:12px}
</style></head><body><main><p><a href="/admin">← OneTV Admin</a></p><h1>Sports Source Control</h1>
<p class="muted">Scheduled Worker → D1 → Android. App visitors never call the upstream sports APIs. Key values remain in Cloudflare Secrets.</p>
<div class="card"><div class="row"><label>Admin token <input id="token" type="password" placeholder="Cloudflare ADMIN_TOKEN" autocomplete="off"></label>
<button onclick="loadAll()">Connect / Refresh</button><span id="status" class="muted">Not connected</span></div></div>
<div class="card"><h2>Global Sports Controls</h2><div class="row">
<label><input type="checkbox" id="paused"> Pause all scheduled sports requests</label>
<label><input type="checkbox" id="detail_prefetch"> Prefetch selected match details</label>
<label><input type="checkbox" id="fallback_on_missing_scores"> Use backup when score missing</label></div>
<div class="row"><label>Max feeds per cron <input type="number" id="max_feeds_per_tick" min="1" max="10"></label>
<label>Max fallback sources per feed <input type="number" id="max_fallbacks_per_feed" min="1" max="10"></label>
<button onclick="saveSettings()">Save Global Settings</button></div></div>
<div class="card"><h2>Providers</h2><p><small>Activate a source only after its terms permit commercial display, caching and attribution. Daily=0 disables provider network calls. Monthly=0 means no additional monthly application cap (provider's own quota still applies).</small></p>
<div class="scroll"><table><thead><tr><th>Provider / status</th><th>Enabled</th><th>Rights confirmed</th><th>Priority</th><th>Daily cap</th><th>Monthly cap</th><th>Min seconds</th><th>Fallback-only</th><th>Sports</th><th>Actions</th></tr></thead>
<tbody id="sources"><tr><td colspan="10">Connect to load providers</td></tr></tbody></table></div></div>
<div class="card"><h2>Queue next Cron refresh</h2><p class="muted">This only queues a job in D1. No external API call runs from the Admin request.</p>
<div class="row"><select id="sport"><option>cricket</option><option>football</option><option>tennis</option><option>basketball</option><option>baseball</option></select>
<select id="bucket"><option>live</option><option>upcoming</option><option>finished</option></select>
<button onclick="queueSync()">Queue Refresh</button></div></div>
<div class="card"><h2>Historical Cricsheet data</h2><p>Cricsheet is an archive, NOT a live-score feed. Enable/approve the source before importing verified completed matches. API route: <code>POST /admin/sports/cricsheet/import</code> (max 50 matches per batch).</p>
<p><small>Saved historical matches: <code>GET /sports/cricket/history</code>. This does not change existing live or results feeds.</small></p></div>
</main><script>
const $=id=>document.getElementById(id), esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let sources=[];async function api(url,method='GET',body){const r=await fetch(url,{method,headers:{Authorization:'Bearer '+$('token').value,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});
 const data=await r.json();if(!r.ok)throw Error(data.error||'HTTP '+r.status);return data}
async function loadAll(){try{const [data,settings]=await Promise.all([api('/admin/sports/sources'),api('/admin/sports/settings')]);sources=data.sources;
 for(const k of Object.keys(settings)){if($(k))$(k).type==='checkbox'?$(k).checked=!!settings[k]:$(k).value=settings[k]}
 render();$('status').textContent='Connected';$('status').className='green'}catch(e){$('status').textContent=e.message;$('status').className='red'}}
function render(){$('sources').innerHTML=sources.map(s=>{const id=esc(s.source_id);const use='Today '+s.used_today+'/'+(s.daily_limit||'BLOCKED')+', Month '+s.used_month+'/'+(s.monthly_limit||'no extra cap');
const err=s.health?.error||'',ready=s.configured?'Key ready':'Key missing';const state=s.enabled?(s.license_approved?'ACTIVE':'RIGHTS NOT CONFIRMED'):'OFF';
return '<tr data-source="'+id+'"><td><b>'+esc(s.display_name)+'</b><small>'+esc(s.source_id)+' · <span class="chip">'+esc(state)+'</span></small><small>'+esc(use)+'</small><small>'+esc(ready)+'</small><small>Last: '+esc(s.health?.checkedAt||'Not checked')+' · '+esc(err||'no error')+'</small></td>'+['enabled','license_approved'].map(x=>'<td><input type="checkbox" data-field="'+x+'" '+(s[x]?'checked':'')+'></td>').join('')+
['priority','daily_limit','monthly_limit','min_interval_seconds'].map(k=>'<td><input type="number" data-field="'+k+'" value="'+Number(s[k])+'" min="0"></td>').join('')+
'<td><input type="checkbox" data-field="fallback_only" '+(s.fallback_only?'checked':'')+'></td><td><input data-field="sports_csv" value="'+esc(s.sports_csv)+'" style="width:180px"></td><td><button onclick="saveSource(\''+id+'\')">Save</button> <button class="secondary" onclick="resetCooldown(\''+id+'\')">Clear cooldown</button></td></tr>'}).join('')}
function values(id){const row=[...document.querySelectorAll('tr[data-source]')].find(x=>x.dataset.source===id);if(!row)throw Error('Missing source');
const fields={};row.querySelectorAll('[data-field]').forEach(el=>{let v=el.type==='checkbox'?el.checked:el.type==='number'?Number(el.value):el.value;fields[el.dataset.field]=v});return fields}
async function saveSource(id){try{await api('/admin/sports/source/'+encodeURIComponent(id),'PATCH',values(id));await loadAll();alert('Saved '+id)}catch(e){alert(e.message)}}
async function resetCooldown(id){if(!confirm('Clear cooldown for '+id+'? This does NOT reset its quota.'))return;try{await api('/admin/sports/source/'+encodeURIComponent(id)+'/clear-cooldown','POST');await loadAll()}catch(e){alert(e.message)}}
async function saveSettings(){const fields={};for(const k of ['paused','detail_prefetch','fallback_on_missing_scores','max_feeds_per_tick','max_fallbacks_per_feed'])fields[k]=$(k).type==='checkbox'?$(k).checked:Number($(k).value);
try{await api('/admin/sports/settings','PATCH',fields);alert('Sports control settings saved')}catch(e){alert(e.message)}}
async function queueSync(){try{await api('/admin/sports/queue-refresh','POST',{sport:$('sport').value,bucket:$('bucket').value});alert('Queued for the next scheduled Cron tick')}catch(e){alert(e.message)}}
</script></body></html>`,{headers:{'content-type':'text/html; charset=utf-8',
  'cache-control':'no-store','content-security-policy':"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; form-action 'none'; frame-ancestors 'none'",'x-content-type-options':'nosniff'}});
}

// --- OneTV sports ingestion architecture -----------------------------------
// Strict boundary: only scheduled() may call the provider adapters below.
// Public routes in serveStoredSports() read Cloudflare D1 exclusively.
// No API key, token or raw provider error response is ever returned publicly.
const SPORTS_SNAPSHOT_SCHEMA = [
  `CREATE TABLE IF NOT EXISTS sports_feed_snapshots (
    sport TEXT NOT NULL, bucket TEXT NOT NULL, payload_json TEXT NOT NULL,
    provider TEXT NOT NULL DEFAULT '', fetched_at INTEGER NOT NULL,
    PRIMARY KEY (sport,bucket))`,
  `CREATE TABLE IF NOT EXISTS sports_match_snapshots (
    sport TEXT NOT NULL, match_id TEXT NOT NULL, payload_json TEXT NOT NULL,
    provider TEXT NOT NULL DEFAULT '', fetched_at INTEGER NOT NULL,
    detail_available INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (sport,match_id))`,
  `CREATE TABLE IF NOT EXISTS sports_ingest_jobs (
    job_key TEXT PRIMARY KEY, last_attempt INTEGER NOT NULL DEFAULT 0,
    last_success INTEGER NOT NULL DEFAULT 0, next_allowed INTEGER NOT NULL DEFAULT 0,
    failures INTEGER NOT NULL DEFAULT 0, last_error TEXT NOT NULL DEFAULT '')`,
  `CREATE TABLE IF NOT EXISTS sports_provider_health (
    provider TEXT PRIMARY KEY, payload_json TEXT NOT NULL, checked_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS sports_provider_budget (
    provider TEXT NOT NULL, period_key TEXT NOT NULL, calls INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(provider,period_key))`,
  `CREATE TABLE IF NOT EXISTS sports_ingest_lock (
    lock_name TEXT PRIMARY KEY, lease_until INTEGER NOT NULL DEFAULT 0)`,
  `CREATE INDEX IF NOT EXISTS idx_sports_match_snapshots_fetched_at
    ON sports_match_snapshots(fetched_at)`,
  `CREATE INDEX IF NOT EXISTS idx_sports_ingest_jobs_last_attempt
    ON sports_ingest_jobs(last_attempt)`
];

async function ensureSportsSnapshotSchema(env) {
  for (const ddl of SPORTS_SNAPSHOT_SCHEMA) await env.DB.prepare(ddl).run();
}

function safeSnapshotJson(value, fallback) {
  try { return JSON.parse(String(value)); } catch (_) { return fallback; }
}

function snapshotTimestamp(seconds) {
  return seconds > 0 ? new Date(seconds * 1000).toISOString() : null;
}

async function readStoredFeed(env, sport, bucket) {
  const row = await env.DB.prepare(
    'SELECT payload_json,provider,fetched_at FROM sports_feed_snapshots WHERE sport=? AND bucket=?'
  ).bind(sport,bucket).first();
  if (!row) return {matches:[],provider:'',updatedAt:null,fetchedAt:0,ready:false,stale:true};
  const matches = safeSnapshotJson(row.payload_json, []);
  const fetchedAt = Number(row.fetched_at || 0);
  const ttl = sportsFeedInterval(sport,bucket);
  return {matches:Array.isArray(matches)?matches:[],provider:String(row.provider||''),
    updatedAt:snapshotTimestamp(fetchedAt),fetchedAt,ready:true,
    stale:(Date.now()-fetchedAt*1000)>Math.max(3*ttl,600000)};
}

async function latestStoredFixture(env,sport,id){
  let newest=null;
  for(const bucket of ['live','upcoming','finished']){
    const feed=await readStoredFeed(env,sport,bucket);
    const match=feed.matches.find(m=>String(m.id)===String(id));
    if(match&&(!newest||feed.fetchedAt>newest.fetchedAt))
      newest={match,provider:feed.provider,fetchedAt:feed.fetchedAt,
        updatedAt:feed.updatedAt};
  }
  return newest;
}

async function readStoredDetails(env, sport, id) {
  const row = await env.DB.prepare(
    'SELECT payload_json,provider,fetched_at,detail_available FROM sports_match_snapshots WHERE sport=? AND match_id=?'
  ).bind(sport,id).first();
  const fixture=await latestStoredFixture(env,sport,id);
  if(row){
    const original=safeSnapshotJson(row.payload_json,null);
    if(original){
      const detailAt=Number(row.fetched_at||0);
      const match=normalizeMatchPlayerSections(JSON.parse(JSON.stringify(original)));
      // A newer scheduled fixture may contain a fresher score/status than
      // the prefetched commentary/scorecard. Merge in memory, D1 read-only.
      if(fixture&&fixture.fetchedAt>detailAt&&sameSportsFixture(match,fixture.match)){
        const fresh=fixture.match;
        if(fresh.status)match.status=fresh.status;
        if(fresh.statusText)match.statusText=fresh.statusText;
        const direct=slugifyTeamName(match.home?.name)===slugifyTeamName(fresh.home?.name);
        for(const side of ['home','away']){
          const source=fresh[direct?side:side==='home'?'away':'home'];
          if(validProviderScore(source?.score)){
            match[side]={...match[side],score:source.score,
              overs:source.overs||match[side]?.overs||'',
              wickets:source.wickets||match[side]?.wickets||'',
              runRate:source.runRate||match[side]?.runRate||''};
          }
        }
        for(const key of ['current_over','current_score','current_wickets','crr']){
          if(hasData(fresh[key]))match[key]=fresh[key];
        }
        match.teams=[match.home,match.away];
        match.scoreVerifiedAt=fresh.scoreVerifiedAt||fresh._lastFetchedAt||fixture.updatedAt;
        match.scoreFromPreviousSnapshot=!!fresh.scoreFromPreviousSnapshot;
        match.dataSources={...(match.dataSources||{}),...(fresh.dataSources||{})};
      }
      return {match,provider:String(row.provider||'SportScore'),
        detailAvailable:!!row.detail_available,
        dataStatus:row.detail_available?'verified_detail':'verified_fixture',
        updatedAt:fixture?.fetchedAt>detailAt?fixture.updatedAt:snapshotTimestamp(detailAt),
        detailUpdatedAt:snapshotTimestamp(detailAt)};
    }
  }
  // Legitimate fixture fallback. The feed is already verified and in D1;
  // never use a user-triggered upstream request to resolve a missing ID.
  if(fixture){
    const match=normalizeMatchPlayerSections({...fixture.match,teams:[fixture.match.home,fixture.match.away],
      detailAvailable:false,dataStatus:'verified_fixture'});
    return {match,provider:fixture.provider||String(match.provider||'SportScore'),
      detailAvailable:false,dataStatus:'verified_fixture',updatedAt:fixture.updatedAt};
  }
  return null;
}

function sportsFeedInterval(sport,bucket) {
  if(bucket==='live') return {
    cricket:180000,football:240000,tennis:420000,
    basketball:420000,baseball:600000
  }[sport]||600000;
  if(bucket==='upcoming') return 1800000; // 30 min
  return 2700000; // results: 45 min
}

async function upsertSportsFeed(env,sport,bucket,matches,provider,nowSecs) {
  await env.DB.prepare(`INSERT INTO sports_feed_snapshots
    (sport,bucket,payload_json,provider,fetched_at) VALUES(?,?,?,?,?)
    ON CONFLICT(sport,bucket) DO UPDATE SET
      payload_json=excluded.payload_json,provider=excluded.provider,fetched_at=excluded.fetched_at`)
    .bind(sport,bucket,JSON.stringify(matches),provider,nowSecs).run();
}

async function upsertSportsDetail(env,sport,id,match,provider,nowSecs,detailAvailable) {
  await env.DB.prepare(`INSERT INTO sports_match_snapshots
    (sport,match_id,payload_json,provider,fetched_at,detail_available) VALUES(?,?,?,?,?,?)
    ON CONFLICT(sport,match_id) DO UPDATE SET payload_json=excluded.payload_json,
      provider=excluded.provider,fetched_at=excluded.fetched_at,
      detail_available=excluded.detail_available`)
    .bind(sport,String(id),JSON.stringify(match),provider,nowSecs,detailAvailable?1:0).run();
}

async function sportsJob(env,key){
  return await env.DB.prepare('SELECT * FROM sports_ingest_jobs WHERE job_key=?').bind(key).first()
    || {last_attempt:0,last_success:0,next_allowed:0,failures:0,last_error:''};
}

async function sportsJobResult(env,key,success,error='',cooldownSeconds=0){
  const now=Math.floor(Date.now()/1000);
  const old=await sportsJob(env,key);
  const failures=success?0:Number(old.failures||0)+1;
  const nextAllowed=success?0:now+Math.max(cooldownSeconds,Math.min(3600,120*Math.pow(2,Math.min(failures,5))));
  await env.DB.prepare(`INSERT INTO sports_ingest_jobs
    (job_key,last_attempt,last_success,next_allowed,failures,last_error) VALUES(?,?,?,?,?,?)
    ON CONFLICT(job_key) DO UPDATE SET last_attempt=excluded.last_attempt,
    last_success=excluded.last_success,next_allowed=excluded.next_allowed,
    failures=excluded.failures,last_error=excluded.last_error`)
    .bind(key,now,success?now:Number(old.last_success||0),nextAllowed,failures,error).run();
}

async function recordSportsProviderHealth(env,provider,report){
  const at=Math.floor(Date.now()/1000);
  await env.DB.prepare(`INSERT INTO sports_provider_health (provider,payload_json,checked_at)
    VALUES(?,?,?) ON CONFLICT(provider) DO UPDATE SET payload_json=excluded.payload_json,
    checked_at=excluded.checked_at`).bind(provider,JSON.stringify(report),at).run();
}

async function readSportsProviderHealth(env,provider){
  const row=await env.DB.prepare('SELECT payload_json,checked_at FROM sports_provider_health WHERE provider=?')
    .bind(provider).first();
  return row?{...safeSnapshotJson(row.payload_json,{}),checkedAt:snapshotTimestamp(Number(row.checked_at||0))}:
    {reachable:false,matches:0,scoredMatches:0,error:'not_yet_synced',checkedAt:null};
}

function sportsSourceScore(match){
  return !!(validProviderScore(match?.home?.score)||validProviderScore(match?.away?.score));
}

function carryPriorVerifiedScores(existing,latest){
  const before=new Map((existing||[]).map(m=>[String(m.id),m]));
  return (latest||[]).map(m=>{
    const prev=before.get(String(m.id));
    if(!prev||!sameTeam(prev?.home?.name,m?.home?.name)||!sameTeam(prev?.away?.name,m?.away?.name))return m;
    if(m.sport==='cricket' && !sameCricketFixture(prev,m))return m;
    const verified=Date.parse(String(prev.scoreVerifiedAt||prev._lastFetchedAt||''));
    if(!Number.isFinite(verified)||Date.now()-verified>30*60*1000)return m;
    const next={...m,home:{...m.home},away:{...m.away}};
    for(const side of ['home','away']){
      if(!validProviderScore(next[side]?.score)&&validProviderScore(prev[side]?.score)){
        next[side].score=prev[side].score;
        if(!next[side].overs&&prev[side]?.overs)next[side].overs=prev[side].overs;
        if(!next[side].wickets&&prev[side]?.wickets)next[side].wickets=prev[side].wickets;
        next.scoreFromPreviousSnapshot=true;
        next.scoreVerifiedAt=prev.scoreVerifiedAt||prev.scoreUpdatedAt||prev._lastFetchedAt||null;
      }
    }
    return next;
  });
}

// This ingester does NOT call withSportFallback(): the legacy helper may fan
// out to several Cricbuzz endpoints and consume the Basic plan's entire quota.
async function fetchScheduledSportsFeed(sport,bucket,env){
  return fetchControlledSportsFeed(sport,bucket,env);
}

async function runSportsFeedJob(env,job){
  const key=`feed:${job.sport}:${job.bucket}`;
  try{
    const old=await readStoredFeed(env,job.sport,job.bucket);
    const source=await fetchScheduledSportsFeed(job.sport,job.bucket,env);
    const now=Math.floor(Date.now()/1000);
    const merged=carryPriorVerifiedScores(old.matches,source.matches);
    // Explicit provenance for old scores; never label a reused score as fresh.
    for(const m of merged){
      if(!m.scoreFromPreviousSnapshot&&sportsSourceScore(m))m.scoreVerifiedAt=snapshotTimestamp(now);
      m._lastFetchedAt=snapshotTimestamp(now);
    }
    await upsertSportsFeed(env,job.sport,job.bucket,merged,source.provider,now);
    await sportsJobResult(env,key,true);
    await recordSportsProviderHealth(env,'sportscore:'+job.sport+':'+job.bucket,{
      reachable:source.provider==='SportScore',sport:job.sport,bucket:job.bucket,
      matches:merged.length,scoredMatches:merged.filter(sportsSourceScore).length,
      source:source.provider});
    return true;
  }catch(e){
    const error=providerStatusError(e);
    await sportsJobResult(env,key,false,error,error==='http_429'?3600:0);
    await recordSportsProviderHealth(env,'sportscore:'+job.sport+':'+job.bucket,{reachable:false,error,
      sport:job.sport,bucket:job.bucket,matches:0,scoredMatches:0});
    return false; // Existing verified snapshot is preserved.
  }
}

function sameSportsFixture(detail,fixture){
  const names=(sameTeam(detail?.home?.name,fixture?.home?.name)&&
    sameTeam(detail?.away?.name,fixture?.away?.name))||
    (sameTeam(detail?.home?.name,fixture?.away?.name)&&
    sameTeam(detail?.away?.name,fixture?.home?.name));
  if(!names)return false;
  const a=Date.parse(String(detail?.time||''));
  const b=Date.parse(String(fixture?.time||''));
  return Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=3*3600000;
}

// No Cricbuzz calls here: scorecard/commentary enrichment from Cricbuzz is
// managed by the tiny scheduled budget; fetching multiple Cricbuzz endpoints
// for every detail view would rapidly exceed the 200/month free plan.
async function scheduledSportScoreDetail(sport,fixture,env){
  if(!String(fixture.id||'').startsWith(`sportscore:${sport}:`))return null;
  const available=await activeSourcesFor(env,sport,'live');
  const s=available.find(x=>x.source_id==='sportscore');
  if(!s)return null;
  const candidates=sportScoreMatchSlugCandidates(sport,fixture.id).slice(0,2);
  for(const candidate of candidates){
    for(const path of ['/api/v1/match/','/api/widget/match/']){
      try{
        const result=await sourceRequest(env,s,`detail:${sport}:${fixture.id}:${path}`,
          sportScoreUrl(path,{sport,slug:candidate}),sportScoreHeaders(env));
        if(result.skipped)continue;
        const detail=normalizeMatchPlayerSections(normalizeSportScoreDetail(result.raw,sport));
        if(!sameSportsFixture(detail,fixture))continue;
        const verified=JSON.parse(JSON.stringify(fixture));
        mergeMissing(verified,detail);
        verified.teams=[verified.home,verified.away];
        verified.detailAvailable=true;
        verified.dataStatus='verified_detail';
        delete verified.rawProviderData;
        return verified;
      }catch(_){ /* The next documented endpoint may support this fixture. */ }
    }
  }
  return null;
}

async function runSportsDetailPrefetch(env){
  const now=Math.floor(Date.now()/1000);
  const candidates=[];
  for(const sport of SPORTS){
    for(const bucket of ['live','upcoming','finished']){
      const feed=await readStoredFeed(env,sport,bucket);
      if(!feed.ready)continue;
      const sorted=[...feed.matches].sort((a,b)=>matchPopularityScore(b)-matchPopularityScore(a));
      for(const m of sorted.slice(0,bucket==='live'?5:bucket==='upcoming'?2:1)){
        if(!String(m.id||'').startsWith(`sportscore:${sport}:`))continue;
        const key=`detail:${sport}:${m.id}`;
        const state=await sportsJob(env,key);
        const cooldown=bucket==='live'?600:bucket==='upcoming'?10800:43200;
        if(now-Number(state.last_attempt||0)<cooldown||Number(state.next_allowed||0)>now)continue;
        candidates.push({sport,bucket,match:m,key,lastAttempt:Number(state.last_attempt||0),
          popularity:matchPopularityScore(m)});
      }
    }
  }
  // Prefer live games, then unpopulated/older details; rank only breaks ties.
  candidates.sort((a,b)=>{
    const prio=x=>x.bucket==='live'?0:x.bucket==='upcoming'?1:2;
    return prio(a)-prio(b)||a.lastAttempt-b.lastAttempt||b.popularity-a.popularity;
  });
  const candidate=candidates[0];
  if(!candidate)return;
  const {sport,match,key}=candidate;
  try{
    const detail=await scheduledSportScoreDetail(sport,match,env);
    const verified=detail||{...match,teams:[match.home,match.away],
      detailAvailable:false,dataStatus:'verified_fixture'};
    await upsertSportsDetail(env,sport,match.id,verified,'SportScore',now,!!detail);
    // Lack of a detail endpoint should not cause per-minute retries.
    await sportsJobResult(env,key,true);
  }catch(e){await sportsJobResult(env,key,false,providerStatusError(e));}
}

async function allowCricbuzzScheduledCall(env){
  const now=new Date();
  const month=now.toISOString().slice(0,7), day=now.toISOString().slice(0,10);
  const configuredMonthly=Number(env.CRICBUZZ_BUDGET_MONTHLY ?? 100);
  const configuredDaily=Number(env.CRICBUZZ_BUDGET_DAILY ?? 4);
  const monthLimit=Number.isFinite(configuredMonthly)?Math.min(10000,Math.max(0,configuredMonthly)):100;
  const dayLimit=Number.isFinite(configuredDaily)?Math.min(1000,Math.max(0,configuredDaily)):4;
  const used=await Promise.all([month,day].map(key=>env.DB.prepare(
    'SELECT calls FROM sports_provider_budget WHERE provider=? AND period_key=?')
    .bind('cricbuzz',key).first()));
  if(Number(used[0]?.calls||0)>=monthLimit||Number(used[1]?.calls||0)>=dayLimit)return false;
  // The single cron lease serializes all of these increments across requests.
  for(const period of [month,day]){
    await env.DB.prepare(`INSERT INTO sports_provider_budget(provider,period_key,calls)
      VALUES('cricbuzz',?,1) ON CONFLICT(provider,period_key)
      DO UPDATE SET calls=calls+1`).bind(period).run();
  }
  return true;
}

function mergeFromCricbuzzVerified(existing,source){
  const out=existing.map(m=>JSON.parse(JSON.stringify(m)));
  for(const actual of source){
    if(!sportsSourceScore(actual))continue;
    const i=out.findIndex(selected=>sameCricketFixture(selected,actual));
    if(i<0){
      if(statusBucket(actual)==='LIVE')out.push(actual);
      continue;
    }
    const selected=out[i];
    const direct=sameTeam(selected.home?.name,actual.home?.name);
    const pairs=direct?[[selected.home,actual.home],[selected.away,actual.away]]:
      [[selected.home,actual.away],[selected.away,actual.home]];
    let changed=false;
    for(const [target,origin] of pairs){
      const score=validProviderScore(origin?.score);
      if(score&&(!validProviderScore(target.score)||selected.scoreFromPreviousSnapshot)){
        target.score=score;
        if(origin.overs)target.overs=origin.overs;
        if(origin.wickets)target.wickets=origin.wickets;
        changed=true;
      }
    }
    if(changed){
      selected.dataSources={...(selected.dataSources||{}),verifiedCricketScore:'Cricbuzz'};
      selected.scoreVerifiedAt=new Date().toISOString();
      delete selected.scoreFromPreviousSnapshot;
    }
  }
  return out;
}

async function runBudgetedCricbuzzSync(env){
  if(!env.CRICBUZZ_RAPIDAPI_KEY)return;
  const now=Math.floor(Date.now()/1000);
  // Live: at most three requests/day; results: once/day. Hard daily/monthly
  // ceilings are enforced regardless of how often the cron trigger runs.
  for(const item of [{kind:'live',interval:8*3600},{kind:'recent',interval:24*3600}]){
    const kind=item.kind,interval=item.interval;
    const key=`cricbuzz:${kind}`;
    const state=await sportsJob(env,key);
    if(now-Number(state.last_attempt||0)<interval||now<Number(state.next_allowed||0))continue;
    if(!await allowCricbuzzScheduledCall(env))return;
    try{
      const source=await cricbuzzList(kind,env);
      const bucket=kind==='live'?'live':'finished';
      const old=await readStoredFeed(env,'cricket',bucket);
      const updated=mergeFromCricbuzzVerified(old.matches,
        source.filter(m=>statusBucket(m)===bucket.toUpperCase()));
      if(old.ready||updated.length)
        await upsertSportsFeed(env,'cricket',bucket,updated,old.provider||'Cricbuzz',now);
      await sportsJobResult(env,key,true);
      await recordSportsProviderHealth(env,'cricbuzz',{
        configured:true,reachable:true,matches:source.length,
        scoredMatches:source.filter(sportsSourceScore).length});
    }catch(e){
      const error=providerStatusError(e);
      await sportsJobResult(env,key,false,error,error==='http_429'?72*3600:2*3600);
      await recordSportsProviderHealth(env,'cricbuzz',{
        configured:true,reachable:false,error,matches:0,scoredMatches:0});
      // Skip other Cricbuzz feed types after an upstream error.
      return;
    }
  }
}

async function acquireSportsCronLease(env){
  const now=Math.floor(Date.now()/1000);
  const result=await env.DB.prepare(`INSERT INTO sports_ingest_lock(lock_name,lease_until)
    VALUES('sports',?) ON CONFLICT(lock_name) DO UPDATE
    SET lease_until=excluded.lease_until WHERE sports_ingest_lock.lease_until<?`)
    .bind(now+115,now).run();
  return Number(result?.meta?.changes||0)>0;
}

async function releaseSportsCronLease(env){
  await env.DB.prepare("UPDATE sports_ingest_lock SET lease_until=0 WHERE lock_name='sports'").run();
}

async function scheduledSportsMaintenance(env){
  const now=Math.floor(Date.now()/1000);
  const job=await sportsJob(env,'maintenance:sports');
  if(now-Number(job.last_attempt||0)<86400)return;
  try{
    await env.DB.prepare('DELETE FROM sports_match_snapshots WHERE fetched_at<?')
      .bind(now-30*86400).run();
    await env.DB.prepare("DELETE FROM sports_ingest_jobs WHERE job_key LIKE 'detail:%' AND last_attempt<?")
      .bind(now-30*86400).run();
    // Keep current and recent-period provider budgets for auditability.
    const cutoff=new Date((now-100*86400)*1000).toISOString().slice(0,7);
    await env.DB.prepare('DELETE FROM sports_provider_budget WHERE substr(period_key,1,7)<?')
      .bind(cutoff).run();
    await sportsJobResult(env,'maintenance:sports',true);
  }catch(e){await sportsJobResult(env,'maintenance:sports',false,providerStatusError(e));}
}

async function scheduledSportsIngestion(env){
  await ensureSportsSnapshotSchema(env);
  await ensureSportsControlSchema(env);
  const settings=await readSportsSettings(env);
  if(settings.paused)return;
  if(!await acquireSportsCronLease(env))return;
  try{
    const now=Math.floor(Date.now()/1000);
    const all=await env.DB.prepare('SELECT sport,bucket,fetched_at FROM sports_feed_snapshots').all();
    const existing=new Map((all.results||[]).map(row=>[`${row.sport}:${row.bucket}`,row]));
    const due=[];
    const forced=await env.DB.prepare('SELECT sport,bucket FROM sports_force_jobs').all();
    const forceSet=new Set((forced.results||[]).map(x=>x.sport+':'+x.bucket));
    for(const sport of SPORTS)for(const bucket of ['live','upcoming','finished']){
      const active=await activeSourcesFor(env,sport,bucket);
      if(!active.length)continue; // Don't spend calls on unsupported sports (e.g. baseball).
      const isForced=forceSet.has(sport+':'+bucket);
      const snap=existing.get(`${sport}:${bucket}`);
      const last=Number(snap?.fetched_at||0);
      const interval=sportsFeedInterval(sport,bucket)/1000;
      if(!isForced&&last&&now-last<interval)continue;
      const job=await sportsJob(env,`feed:${sport}:${bucket}`);
      if(Number(job.next_allowed||0)>now)continue;
      if(!isForced&&!last&&now-Number(job.last_attempt||0)<120)continue;
      due.push({sport,bucket,last,overdue:last?(now-last)/interval:100,
        priority:sport==='cricket'?0:sport==='football'?1:sport==='tennis'?2:sport==='basketball'?3:4});
    }
    due.sort((a,b)=>b.overdue-a.overdue||a.priority-b.priority||
      (a.bucket==='live'?-1:b.bucket==='live'?1:0));
    const maxFeeds=Math.max(1,Math.min(10,Number(settings.max_feeds_per_tick||3)));
    for(const job of due.slice(0,maxFeeds)){
      await runSportsFeedJob(env,job);
      await env.DB.prepare('DELETE FROM sports_force_jobs WHERE sport=? AND bucket=?')
        .bind(job.sport,job.bucket).run();
    }
    // Provider calls here are only from scheduled ingestion, never GET routes.
    // Cricbuzz is no longer an independent scheduled job. It is ONLY a
    // low-priority conditional source in fetchControlledSportsFeed().
    try{if(settings.detail_prefetch&&env.SPORTS_DETAIL_PREFETCH_DISABLED!=='true')await runSportsDetailPrefetch(env);}catch(_){}
    try{await scheduledSportsMaintenance(env);}catch(_){}
  }finally{await releaseSportsCronLease(env);}
}

async function cachedSportTeam(env,sport,requested){
  const token=slugifyTeamName(requested);
  const collected=new Map();
  let foundTeam=null;
  for(const bucket of ['live','upcoming','finished']){
    const feed=await readStoredFeed(env,sport,bucket);
    for(const m of feed.matches){
      const team=[m.home,m.away].find(t=>slugifyTeamName(t?.name)===token||
        slugifyTeamName(t?.slug)===token||String(t?.id||'')===String(requested));
      if(team){foundTeam=team;collected.set(String(m.id),m);}
    }
  }
  const matches=[...collected.values()];
  if(!foundTeam)return {team:{name:String(requested),slug:String(requested)},
    matches:[],recent:[],upcoming:[],provider:'D1 cache'};
  return {team:foundTeam,matches,recent:matches.filter(m=>statusBucket(m)==='FINISHED'),
    upcoming:matches.filter(m=>statusBucket(m)==='UPCOMING'),provider:'D1 cache'};
}

async function storedCricketHome(env){
  const [live,upcoming,finished]=await Promise.all(['live','upcoming','finished']
    .map(bucket=>readStoredFeed(env,'cricket',bucket)));
  const all=recentCricketHighlights(live.matches,upcoming.matches,finished.matches,3,5,3);
  return {matches:all,provider:live.provider||'D1 cache',
    liveCount:live.matches.filter(m=>statusBucket(m)==='LIVE').length,
    upcomingCount:upcoming.matches.filter(m=>statusBucket(m)==='UPCOMING').length,
    recentFinishedCount:Math.min(3,finished.matches.filter(m=>statusBucket(m)==='FINISHED').length),
    updatedAt:live.updatedAt||upcoming.updatedAt||finished.updatedAt,
    stale:live.stale||upcoming.stale||finished.stale,
    ready:live.ready||upcoming.ready||finished.ready};
}

function cricketHomeSummaryMatch(m){
  return {id:m.id,providerMatchId:m.providerMatchId||'',name:m.name,status:m.status,
    state:statusBucket(m),statusText:m.statusText||'',competition:m.competition,
    round:m.round||'',format:m.format||'',venue:m.venue,result:m.result,
    startsAt:m.time,section:m._listingSection||'live',
    highlightEligible:!!m._highlightEligible,
    score:validProviderScore(m.home?.score)||validProviderScore(m.away?.score)||'',
    teams:[m.home,m.away].map(t=>({name:t?.name||'',slug:String(t?.slug||''),
      id:String(t?.id||''),score:String(validProviderScore(t?.score)||''),
      overs:String(t?.overs??''),wickets:String(t?.wickets??''),
      logo:String(t?.logo||''),flag:String(t?.flag||'')})),
    popularityScore:matchPopularityScore(m)};
}

async function storedCricketIndex(env,bucket){
  const feed=await readStoredFeed(env,'cricket',bucket);
  return {updatedAt:feed.updatedAt,matches:feed.matches.map(cricketHomeSummaryMatch),
    provider:feed.provider||'D1 cache',primaryProvider:'SportScore',
    fallbackProvider:'OpenCricket',stale:feed.stale,ready:feed.ready,
    dataStatus:feed.ready?'cached':'awaiting_first_sync'};
}

async function storedSportStatus(env){
  const snapshots=await env.DB.prepare(
    'SELECT sport,bucket,fetched_at,provider FROM sports_feed_snapshots ORDER BY sport,bucket').all();
  const budgets=await env.DB.prepare('SELECT period_key,calls FROM sports_provider_budget WHERE provider=?')
    .bind('cricbuzz').all();
  return {architecture:'scheduled_ingestion_d1_read_only',
    userTriggeredProviderRequests:false,
    checkedAt:new Date().toISOString(),
    feeds:(snapshots.results||[]).map(x=>({sport:x.sport,bucket:x.bucket,
      provider:x.provider,updatedAt:snapshotTimestamp(Number(x.fetched_at||0))})),
    cricbuzzBudgetUsed:(budgets.results||[]).map(x=>({period:x.period_key,calls:x.calls})),
    sourceControls:'admin_only:/admin/sports', sourceMode:'scheduled_provider_fetch_only'};
}

async function serveStoredSports(request,url,env){
  if(request.method!=='GET')return null;
  const path=url.pathname;
  const isSports=/^\/sports\/(football|basketball|cricket|tennis|baseball)\/(live|upcoming|results|team\/|match\/)/.test(path);
  const isCricket=/^\/cricket\/(live|upcoming|results|health|provider-status|match\/|team\/)/.test(path);
  if(!isSports&&!isCricket&&path!=='/sports/cache-status'&&path!=='/sports/cricket/history')return null;
  // Tables are created by Cron or the included migration, never by a public GET.
  try{
    if(path==='/sports/cricket/history')return json(await getCricsheetArchive(env,url.searchParams.get('limit')));
    if(path==='/sports/cache-status')return json(await storedSportStatus(env));
    if(path==='/cricket/provider-status'){
      const [cricbuzz,sportscore]=await Promise.all(['cricbuzz','sportscore:cricket:live']
        .map(p=>readSportsProviderHealth(env,p)));
      return json({checkedAt:cricbuzz.checkedAt||sportscore.checkedAt,
        cricbuzz:{configured:!!env.CRICBUZZ_RAPIDAPI_KEY,...cricbuzz},sportscore,
        diagnosticMode:'last_scheduled_check',requestsProvider:false});
    }
    if(path==='/cricket/health'){
      const live=await readStoredFeed(env,'cricket','live');
      return json({ok:true,primaryProvider:'SportScore',fallbackProvider:'OpenCricket',
        provider:live.provider||'D1 cache',openCricketKeyConfigured:!!env.OPENCRICKET_API_KEY,
        liveMatches:live.matches.length,cacheReady:live.ready,stale:live.stale,
        updatedAt:live.updatedAt,requestsProvider:false});
    }
    if(path==='/cricket/live'){
      const feed=await storedCricketHome(env);
      return json({updatedAt:feed.updatedAt,matches:feed.matches.map(cricketHomeSummaryMatch),
        liveCount:feed.liveCount,upcomingCount:feed.upcomingCount,
        recentFinishedCount:feed.recentFinishedCount,
        primaryProvider:'SportScore',fallbackProvider:'OpenCricket',provider:feed.provider,
        stale:feed.stale,cacheReady:feed.ready,requestsProvider:false});
    }
    if(path==='/cricket/upcoming'||path==='/cricket/results')
      return json(await storedCricketIndex(env,path.endsWith('results')?'finished':'upcoming'));
    let m=path.match(/^\/cricket\/match\/(.+)$/);
    if(m){
      const result=await readStoredDetails(env,'cricket',decodeURIComponent(m[1]));
      return result?json({match:result.match,provider:result.provider,
        detailAvailable:result.detailAvailable,dataStatus:result.dataStatus,
        updatedAt:result.updatedAt,primaryProvider:'SportScore',fallbackProvider:'OpenCricket',
        requestsProvider:false}):json({error:'Match is not yet synchronized',
        dataStatus:'waiting_for_the_latest_update',requestsProvider:false},404);
    }
    m=path.match(/^\/cricket\/team\/(.+)$/);
    if(m){
      const result=await cachedSportTeam(env,'cricket',decodeURIComponent(m[1]));
      return json({sport:'cricket',...result,primaryProvider:'SportScore',
        fallbackProvider:'OpenCricket',requestsProvider:false});
    }
    m=path.match(/^\/sports\/(football|basketball|cricket|tennis|baseball)\/(live|upcoming|results)$/);
    if(m){
      const sport=m[1],mode=m[2],bucket=mode==='results'?'finished':mode;
      const feed=await readStoredFeed(env,sport,bucket);
      return json({updatedAt:feed.updatedAt,sport,mode,matches:feed.matches,
        primaryProvider:'SportScore',fallbackProvider:sport==='cricket'?'OpenCricket':null,
        provider:feed.provider||'D1 cache',cacheReady:feed.ready,stale:feed.stale,
        dataStatus:feed.ready?'cached':'awaiting_first_sync',requestsProvider:false});
    }
    m=path.match(/^\/sports\/(football|basketball|cricket|tennis|baseball)\/match\/(.+)$/);
    if(m){
      const sport=m[1],id=decodeURIComponent(m[2]);
      const result=await readStoredDetails(env,sport,id);
      return result?json({sport,match:result.match,provider:result.provider,
        detailAvailable:result.detailAvailable,dataStatus:result.dataStatus,
        updatedAt:result.updatedAt,primaryProvider:'SportScore',
        fallbackProvider:sport==='cricket'?'OpenCricket':null,requestsProvider:false}):
        json({error:'Match is not yet synchronized',
          dataStatus:'waiting_for_the_latest_update',requestsProvider:false},404);
    }
    m=path.match(/^\/sports\/(football|basketball|cricket|tennis|baseball)\/team\/(.+)$/);
    if(m){
      const sport=m[1],result=await cachedSportTeam(env,sport,decodeURIComponent(m[2]));
      return json({sport,...result,primaryProvider:'SportScore',
        fallbackProvider:sport==='cricket'?'OpenCricket':null,requestsProvider:false});
    }
  }catch(e){
    // A missing schema means the migration/first scheduled run is pending.
    // Never fallback to upstream on a public request, even on a D1 failure.
    return json({error:'Sports snapshot unavailable; check D1 migration and Cron',
      dataStatus:'waiting_for_the_latest_update',requestsProvider:false},503);
  }
  return null;
}
// --- End of OneTV sports snapshot module -----------------------------------


function publicStatusLabel(value){
  const k=String(value||'').toLowerCase().replace(/[_-]+/g,' ').replace(/\s+/g,' ').trim();
  if(['live','in play','inplay','playing','ongoing','started'].includes(k)) return 'LIVE';
  if(['upcoming','scheduled','not started','fixture','pre match'].includes(k)) return 'UPCOMING';
  if(['finished','complete','completed','ended','end of day','final','result'].includes(k)) return 'FINISHED';
  if(k==='postponed') return 'POSTPONED';
  if(['cancelled','canceled'].includes(k)) return 'CANCELLED';
  if(k==='abandoned') return 'ABANDONED';
  return '';
}

function shiftIsoDate(days){
  const d=new Date();
  d.setUTCDate(d.getUTCDate()+Number(days||0));
  return d.toISOString().slice(0,10);
}

async function publicSearch(q, env) {
  const query = String(q || "").trim().toLowerCase();
  if (!query) return [];
  const items = [];
  const channels = await listChannels(env);
  for (const c of channels) {
    const hay = `${c.name} ${c.category} ${c.country} ${c.programName}`.toLowerCase();
    if (hay.includes(query)) {
      items.push({
        kind:'channel', icon:'ðŸ“º', id:c.id, title:c.name,
        subtitle:c.connected ? (c.programName || c.category || 'Live TV') : 'Coming soon',
        url:c.url||'', program:c.programName||'', category:c.category,
        country:c.country, connected:!!c.connected
      });
    }
  }

  // Search the same canonical live/upcoming/result feeds used by the app.
  // Keep this bounded so a single search never fans out into a large provider burst.
  const requests=[];
  for(const sport of SPORTS){
    requests.push({sport, promise:sportsList(sport,'live',env)});
    requests.push({sport, promise:sportsList(sport,'upcoming',env)});
    requests.push({sport, promise:sportsList(sport,'finished',env)});
  }
  const batches=await Promise.all(requests.map(r=>r.promise.catch(()=>({matches:[]}))));
  const seen=new Set();
  for(let i=0;i<batches.length;i++){
    const result=batches[i];
    const sport=requests[i].sport;
    for(const m of (result?.matches || [])){
      const hay = `${m.name} ${m.home?.name||''} ${m.away?.name||''} ${m.competition||''} ${m.venue||''}`.toLowerCase();
      if(!hay.includes(query) || seen.has(m.id)) continue;
      seen.add(m.id);
      const status=publicStatusLabel(m.statusText||m.status);
      items.push({
        kind:'match', icon:'ðŸ†', id:m.id, providerMatchId:m.providerMatchId||'',
        sport, title:canonicalMatchTitle(m.home,m.away,m.name),
        subtitle:`${m.competition||sport}${status ? ' â€¢ '+status : ''}`,
        home:m.home, away:m.away, competition:m.competition, venue:m.venue,
        status:status || '', time:m.time
      });
    }
  }
  // Include only published news and rights-cleared media in unified search.
  // Failed provider queries do not create synthetic search results.
  try {
    const news=await listPublicNews(env,50);
    for(const article of news){
      const hay=`${article.headline||''} ${article.summary||''} ${article.category||''} ${article.source_name||''}`.toLowerCase();
      if(!hay.includes(query))continue;
      items.push({
        kind:'article',id:article.id,title:article.headline,headline:article.headline,
        subtitle:`${article.category||'News'} · ${article.source_name||''}`,
        summary:article.summary||'',body:article.body||'',category:article.category||'News',
        source_name:article.source_name||'',source_url:article.source_url||'',
        image_url:article.image_url||'',published_at:article.published_at||'',
        icon:'▤'
      });
    }
  }catch(_){}
  try {
    const media=await listAuthorizedMedia(env,'',50);
    for(const content of media){
      const hay=`${content.title||''} ${content.description||''} ${content.category||''} ${content.source_name||''}`.toLowerCase();
      if(!hay.includes(query))continue;
      items.push({
        kind:'media',id:content.id,title:content.title||'',
        subtitle:`${content.category||'Entertainment'} · ${content.source_name||''}`,
        description:content.description||'',category:content.category||'',
        source_name:content.source_name||'',source_url:content.source_url||'',
        thumbnail_url:content.thumbnail_url||'',media_url:content.media_url||'',
        media_type:content.media_type||'',rights_status:content.rights_status||'',
        provider_key:content.provider_key||'',allowed_usage:content.allowed_usage||'',icon:'▣'
      });
    }
  }catch(_){}
  return items.slice(0,50);
}

async function notificationFeed(env) {
  const items=[];
  const {results: notices=[]}=await env.DB.prepare(`SELECT id,type,title,html_content,media_url,link_url,created_at FROM notices WHERE active=1 ORDER BY sort_order ASC,id DESC LIMIT 20`).all();
  for(const n of notices) items.push({id:`notice-${n.id}`,icon:'â„¹',title:n.title||'ONE TV',body:n.type==='text'?String(n.html_content||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim():`New ${n.type} published`,type:'notice',createdAt:n.created_at});
  // Provider-driven live state. State transitions are persisted centrally so the app never invents match events.
  for(const sport of SPORTS){
    try{
      const result=await sportsList(sport,'live',env);
      for(const m of result.matches){
        const key=`${sport}:${m.id}`;
        const state=String(m.statusText||m.status||'LIVE');
        const prev=await env.DB.prepare(`SELECT state FROM sports_event_state WHERE event_key=?`).bind(key).first();
        if(!prev){
          // Establish the initial provider state silently. A fresh install should
          // not manufacture a notification simply because a live match exists.
          await env.DB.prepare(`INSERT OR REPLACE INTO sports_event_state(event_key,sport,match_id,state,updated_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)`).bind(key,sport,m.id,state).run();
        } else if(String(prev.state)!==state){
          await env.DB.prepare(`UPDATE sports_event_state SET state=?,updated_at=CURRENT_TIMESTAMP WHERE event_key=?`).bind(state,key).run();
          const eventTitle=/innings|break/i.test(state)?'Innings break':/finished|complete|final|ended/i.test(state)?'Result':'Match update';
          const eventIcon=eventTitle==='Innings break'?'ðŸ':eventTitle==='Result'?'ðŸ':'ðŸ”´';
          items.unshift({id:`auto-${key}-${Date.now()}`,icon:eventIcon,title:`${m.name} â€¢ ${eventTitle}`,body:'The match status has changed.',type:'sport',sport,matchId:m.id});
        }
      }
    }catch(_){ }
  }
  // Detect completed matches for previously live matches. This is provider data, not a fabricated result.
  try {
    const liveStates = await env.DB.prepare(`SELECT event_key,sport,match_id,state FROM sports_event_state WHERE state LIKE '%live%' OR state LIKE '%in play%' OR state LIKE '%playing%' OR state LIKE '%started%'`).all();
    for (const sport of SPORTS) {
      const relevant=(liveStates.results||[]).filter(x=>x.sport===sport);
      if(!relevant.length) continue;
      try {
        const result=await sportsList(sport,'finished',env);
        for(const m of result.matches){
          const hit=relevant.find(x=>String(x.match_id)===String(m.id));
          if(!hit) continue;
          await env.DB.prepare(`UPDATE sports_event_state SET state=?,updated_at=CURRENT_TIMESTAMP WHERE event_key=?`).bind(String(m.statusText||m.status||'FINISHED'),hit.event_key).run();
          items.unshift({id:`auto-${hit.event_key}-result`,icon:'ðŸ',title:`${m.name} â€¢ Result`,body:'The match has finished.',type:'sport',sport,matchId:m.id});
        }
      } catch (_) {}
    }
  } catch (_) {}
  return {items:items.slice(0,50),unreadCount:items.length,updatedAt:new Date().toISOString()};
}



// News sources are stored in D1; their API secrets stay in Cloudflare Secrets.
async function ensureNewsSourceSchema(env){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS news_source_controls (
    source_id TEXT PRIMARY KEY, name TEXT NOT NULL, api_url TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 0, license_approved INTEGER NOT NULL DEFAULT 0,
    priority INTEGER NOT NULL DEFAULT 50, daily_limit INTEGER NOT NULL DEFAULT 20,
    min_interval_seconds INTEGER NOT NULL DEFAULT 1800,
    auth_secret_name TEXT NOT NULL DEFAULT '', auth_header_name TEXT NOT NULL DEFAULT 'X-Api-Key',
    items_path TEXT NOT NULL DEFAULT 'articles',last_fetch INTEGER NOT NULL DEFAULT 0,
    last_error TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS news_source_daily_usage (
    source_id TEXT NOT NULL, date TEXT NOT NULL, calls INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(source_id,date))`).run();
}
async function adminNewsSourceList(env){
  await ensureNewsSourceSchema(env);
  const r=await env.DB.prepare(`SELECT * FROM news_source_controls ORDER BY priority,source_id`).all();
  const today=new Date().toISOString().slice(0,10), out=[];
  for(const s of r.results||[]){
    const u=await env.DB.prepare('SELECT calls FROM news_source_daily_usage WHERE source_id=? AND date=?').bind(s.source_id,today).first();
    out.push({...s,enabled:!!s.enabled,license_approved:!!s.license_approved,used_today:Number(u?.calls||0),
      secret_configured:!s.auth_secret_name||!!String(env[s.auth_secret_name]||'').trim()});
  }
  return out;
}
async function upsertNewsSource(env,x,id=null){
  await ensureNewsSourceSchema(env);
  id=id||String(x.source_id||'').trim().toLowerCase();
  if(!/^[a-z][a-z0-9_]{2,39}$/.test(id))throw Error('Invalid source_id');
  const prev=id?await env.DB.prepare('SELECT * FROM news_source_controls WHERE source_id=?').bind(id).first():null;
  if(prev&&!x.__edit)throw Error('Source already exists');
  if(!prev&&x.__edit)throw Error('Source not found');
  const v={...prev,...x},api_url=validOneTvHttpsTemplate(v.api_url),
    name=String(v.name||id).trim().slice(0,100),secret=String(v.auth_secret_name||'').trim();
  if(secret&&!/^[A-Z][A-Z0-9_]{2,79}$/.test(secret))throw Error('Invalid Cloudflare Secret name');
  const header=String(v.auth_header_name||'X-Api-Key');
  if(!/^(Authorization|X-Api-Key|X-RapidAPI-Key|api-key)$/i.test(header))throw Error('Invalid auth header');
  const path=String(v.items_path||'articles');if(!/^[a-zA-Z0-9_]+(?:\.[a-zA-Z0-9_]+)*$/.test(path))throw Error('Invalid items_path');
  const priority=Number(v.priority??50),daily=Number(v.daily_limit??20),min=Number(v.min_interval_seconds??1800);
  if(!Number.isInteger(priority)||priority<0||priority>99||!Number.isInteger(daily)||daily<0||daily>100000||!Number.isInteger(min)||min<60||min>86400)throw Error('Invalid limits');
  if(prev){
    await env.DB.prepare(`UPDATE news_source_controls SET name=?,api_url=?,enabled=?,license_approved=?,priority=?,daily_limit=?,min_interval_seconds=?,auth_secret_name=?,auth_header_name=?,items_path=?,updated_at=CURRENT_TIMESTAMP WHERE source_id=?`)
      .bind(name,api_url,v.enabled?1:0,v.license_approved?1:0,priority,daily,min,secret,header,path,id).run();
  }else{
    await env.DB.prepare(`INSERT INTO news_source_controls(source_id,name,api_url,enabled,license_approved,priority,daily_limit,min_interval_seconds,auth_secret_name,auth_header_name,items_path) VALUES(?,?,?,?,?,?,?,?,?,?,?)`)
      .bind(id,name,api_url,v.enabled?1:0,v.license_approved?1:0,priority,daily,min,secret,header,path).run();
  }
  return {ok:true,source_id:id};
}
async function fetchControlledNewsSources(env){
  await ensureNewsSourceSchema(env);
  const cfg=await env.DB.prepare('SELECT * FROM news_source_controls ORDER BY priority,source_id').all();
  // Preserve pre-existing NEWS_PROVIDER integration until a source is explicitly configured.
  if(!(cfg.results||[]).some(v=>v.enabled&&v.license_approved))return null;
  const all=[],now=Math.floor(Date.now()/1000),date=new Date().toISOString().slice(0,10);
  for(const s of (cfg.results||[]).filter(v=>v.enabled&&v.license_approved).slice(0,8)){
    if(s.daily_limit===0||now-Number(s.last_fetch||0)<s.min_interval_seconds)continue;
    const used=await env.DB.prepare('SELECT calls FROM news_source_daily_usage WHERE source_id=? AND date=?').bind(s.source_id,date).first();
    if(Number(used?.calls||0)>=s.daily_limit)continue;
    const key=s.auth_secret_name?String(env[s.auth_secret_name]||'').trim():'';
    if(s.auth_secret_name&&!key)continue;
    const headers={Accept:'application/json'};
    if(key)headers[s.auth_header_name]=s.auth_header_name.toLowerCase()==='authorization'?'Bearer '+key:key;
    await env.DB.prepare(`UPDATE news_source_controls SET last_fetch=? WHERE source_id=?`).bind(now,s.source_id).run();
    await env.DB.prepare(`INSERT INTO news_source_daily_usage(source_id,date,calls) VALUES(?,?,1)
      ON CONFLICT(source_id,date) DO UPDATE SET calls=calls+1`).bind(s.source_id,date).run();
    try{
      const r=await fetch(s.api_url,{headers,signal:AbortSignal.timeout(12000)});
      if(!r.ok)throw Error('HTTP '+r.status);
      const data=await r.json(),items=getJsonPath(data,s.items_path);
      if(!Array.isArray(items))throw Error('items_path not an array');
      all.push(...items.slice(0,40).map(x=>({
        sourceKey:s.source_id,sourceName:s.name,sourceWeight:10,
        title:String(x.title||x.headline||'').trim(),link:String(x.url||x.link||x.source_url||'').trim(),
        description:stripHtml(String(x.description||x.summary||x.content||'')).slice(0,1600),
        imageUrl:/^https:\/\//i.test(String(x.urlToImage||x.image_url||x.imageUrl||''))?String(x.urlToImage||x.image_url||x.imageUrl):'',
        pubDate:String(x.publishedAt||x.pubDate||x.published_at||'')
      })).filter(x=>x.title&&/^https:\/\//i.test(x.link)));
      await env.DB.prepare(`UPDATE news_source_controls SET last_error='' WHERE source_id=?`).bind(s.source_id).run();
    }catch(e){
      await env.DB.prepare('UPDATE news_source_controls SET last_error=? WHERE source_id=?').bind(String(e.message||e).slice(0,140),s.source_id).run();
    }
  }
  return all;
}

const NEWS_SOURCES = [];
let newsImageColumnReady = false;

async function fetchLicensedNewsCandidates(env) {
  const apiUrl = String(env.NEWS_PROVIDER_API_URL || "").trim();
  const apiKey = String(env.NEWS_PROVIDER_API_KEY || "").trim();
  if (!apiUrl || !apiKey) return [];
  try {
    const u = new URL(apiUrl);
    if (!u.searchParams.has("q")) u.searchParams.set("q", "sports OR cricket OR football OR tennis OR basketball OR world");
    if (!u.searchParams.has("pageSize")) u.searchParams.set("pageSize", "30");
    const r = await fetch(u.toString(), {headers:{"Accept":"application/json","X-Api-Key":apiKey,"Authorization":`Bearer ${apiKey}`},signal:AbortSignal.timeout(12000)});
    if (!r.ok) return [];
    const data = await r.json();
    const arr = Array.isArray(data.articles) ? data.articles : (Array.isArray(data.results) ? data.results : (Array.isArray(data.items) ? data.items : []));
    return arr.slice(0,40).map(x=>({
      sourceKey:String(x.source?.id || x.source?.name || x.source_name || "licensed-news-provider"),
      sourceName:String(x.source?.name || x.source_name || "Licensed News Provider"),
      sourceWeight:10, title:String(x.title || x.headline || "").trim(), link:String(x.url || x.link || x.source_url || "").trim(),
      description:stripHtml(String(x.description || x.summary || x.content || "")).slice(0,1600),
      imageUrl:(/^https:\/\//i.test(String(x.urlToImage || x.image_url || x.imageUrl || x.image || x.thumbnail || "").trim()) ? String(x.urlToImage || x.image_url || x.imageUrl || x.image || x.thumbnail || "").trim() : ""),
      pubDate:String(x.publishedAt || x.pubDate || x.published_at || "")
    })).filter(x=>x.title && x.link);
  } catch (_) { return []; }
}

function stripHtml(value) {
  return String(value || "").replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}

function newsFingerprint(item) {
  return String(item.title || "").toLowerCase().replace(/[^a-z0-9\s]/g, "").replace(/\s+/g, " ").trim().slice(0, 240);
}

function newsTopicScore(item) {
  const text = `${item.title} ${item.description}`.toLowerCase();
  let score = Number(item.sourceWeight || 0);
  const high = ["world cup","final","election","president","prime minister","war","ceasefire","crisis","earthquake","hurricane","breaking","championship","tournament","cricket","football","tennis","basketball","sports"];
  for (const k of high) if (text.includes(k)) score += 5;
  if (/today|breaking|live|latest/.test(text)) score += 2;
  return score;
}

async function fetchNewsCandidates(env) {
  const registered=await fetchControlledNewsSources(env);
  const all = registered===null?await fetchLicensedNewsCandidates(env):registered;
  const unique = new Map();
  for (const item of all) { const key=newsFingerprint(item); if(!key)continue; const prev=unique.get(key); if(!prev||newsTopicScore(item)>newsTopicScore(prev))unique.set(key,item); }
  return Array.from(unique.values()).sort((a,b)=>newsTopicScore(b)-newsTopicScore(a));
}

async function rewriteNewsWithOpenAI(item, env) {
  if (!env.OPENAI_API_KEY) return null;
  const model = String(env.OPENAI_MODEL || "gpt-4.1-mini");
  const prompt = `You are the editorial engine for One TV, an international sports and current-affairs app.\n\nRewrite the supplied RSS metadata into an original, concise news item. Do NOT copy sentences verbatim. Do NOT invent facts, quotes, statistics, names, or details not present in the supplied material. Preserve uncertainty where the source is uncertain. The result must be suitable for mobile publishing.\n\nReturn JSON only with: headline, summary, body, category, tags.\nheadline: max 95 characters.\nsummary: 1-2 sentences.\nbody: 2-4 short paragraphs, 80-180 words total.\ncategory: one of Sports, Cricket, Football, Tennis, Basketball, World, Business, Technology, Entertainment, Other.\ntags: array of 3-6 short strings.\n\nSource: ${item.sourceName}\nTitle: ${item.title}\nDescription: ${item.description}\nPublished: ${item.pubDate}\nOriginal URL: ${item.link}`;
  try {
    const r = await fetch("https://api.openai.com/v1/responses", {
      method:"POST",
      headers:{"content-type":"application/json","authorization":`Bearer ${env.OPENAI_API_KEY}`},
      body:JSON.stringify({model,input:prompt,temperature:0.2,max_output_tokens:700}),
      signal:AbortSignal.timeout(30000)
    });
    if (!r.ok) return null;
    const data = await r.json();
    const output = Array.isArray(data.output) ? data.output.map(x => Array.isArray(x.content) ? x.content.map(y => y.text || "").join("") : "").join("\n") : "";
    const cleaned = output.replace(/^```json\s*/i, "").replace(/```$/i, "").trim();
    const parsed = JSON.parse(cleaned);
    if (!parsed.headline || !parsed.summary || !parsed.body) return null;
    return parsed;
  } catch (_) { return null; }
}

async function publishOneNewsArticle(env) {
  await ensureNewsTable(env);
  const candidates = await fetchNewsCandidates(env);
  if (!candidates.length) return {ok:false, reason:"no_candidates"};
  for (const item of candidates.slice(0, 12)) {
    const exists = await env.DB.prepare("SELECT id FROM news_articles WHERE source_url=? OR fingerprint=? LIMIT 1").bind(item.link, newsFingerprint(item)).first();
    if (exists) continue;
    const rewritten = await rewriteNewsWithOpenAI(item, env);
    if (!rewritten) continue;
    const category = String(rewritten.category || "Other").trim();
    const tags = Array.isArray(rewritten.tags) ? rewritten.tags.slice(0,6) : [];
    await env.DB.prepare(`INSERT INTO news_articles(source_name,source_url,source_published_at,image_url,fingerprint,headline,summary,body,category,tags_json,source_score,published_at,active) VALUES(?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP,1)`)
      .bind(item.sourceName,item.link,item.pubDate || "",item.imageUrl || "",newsFingerprint(item),String(rewritten.headline).slice(0,180),String(rewritten.summary).slice(0,600),String(rewritten.body).slice(0,6000),category,JSON.stringify(tags),newsTopicScore(item)).run();
    return {ok:true, source:item.sourceName, headline:String(rewritten.headline), publishedAt:new Date().toISOString()};
  }
  return {ok:false, reason:"no_new_generated_article"};
}

async function ensureNewsTable(env) {
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS news_articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_name TEXT NOT NULL,
    source_url TEXT NOT NULL,
    source_published_at TEXT NOT NULL DEFAULT '',
    image_url TEXT NOT NULL DEFAULT '',
    fingerprint TEXT NOT NULL UNIQUE,
    headline TEXT NOT NULL,
    summary TEXT NOT NULL,
    body TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'Other',
    tags_json TEXT NOT NULL DEFAULT '[]',
    source_score REAL NOT NULL DEFAULT 0,
    published_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    active INTEGER NOT NULL DEFAULT 1
  )`).run();
  if (!newsImageColumnReady) {
    try { await env.DB.prepare("ALTER TABLE news_articles ADD COLUMN image_url TEXT NOT NULL DEFAULT ''").run(); } catch (_) { /* column already exists */ }
    newsImageColumnReady = true;
  }
  await env.DB.prepare("CREATE INDEX IF NOT EXISTS idx_news_active_published ON news_articles(active,published_at DESC)").run();
  await env.DB.prepare("CREATE INDEX IF NOT EXISTS idx_news_category_published ON news_articles(category,published_at DESC)").run();
}

async function listPublicNews(env, limit=30) {
  await ensureNewsTable(env);
  const r = await env.DB.prepare(`SELECT id,source_name,source_url,source_published_at,image_url,headline,summary,body,category,tags_json,published_at FROM news_articles WHERE active=1 ORDER BY published_at DESC LIMIT ?`).bind(Math.min(Math.max(Number(limit)||30,1),50)).all();
  return (r.results || []).map(x => ({...x,tags: (()=>{try{return JSON.parse(x.tags_json||"[]")}catch(_){return []}})()}));
}


// Rights-gated automatic media publishing. No media is published unless the
// upstream record explicitly declares permission for the requested use.
let mediaSchemaReady = false;
async function ensureMediaTable(env) {
  if (mediaSchemaReady) return;
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS media_assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    provider_key TEXT NOT NULL,
    provider_asset_id TEXT NOT NULL,
    media_type TEXT NOT NULL CHECK(media_type IN ('photo','video')),
    content_key TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    media_url TEXT NOT NULL,
    thumbnail_url TEXT NOT NULL DEFAULT '',
    source_url TEXT NOT NULL DEFAULT '',
    source_name TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL DEFAULT 'general',
    related_entity_id TEXT NOT NULL DEFAULT '',
    related_entity_name TEXT NOT NULL DEFAULT '',
    duration_seconds INTEGER NOT NULL DEFAULT 0,
    rights_status TEXT NOT NULL,
    rights_reference TEXT NOT NULL DEFAULT '',
    allowed_usage TEXT NOT NULL DEFAULT '',
    priority REAL NOT NULL DEFAULT 0,
    source_published_at TEXT NOT NULL DEFAULT '',
    first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    active INTEGER NOT NULL DEFAULT 1,
    UNIQUE(provider_key, provider_asset_id)
  )`).run();
  await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_media_active_type_priority ON media_assets(active,media_type,priority DESC,last_seen_at DESC)').run();
  await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_media_content_key ON media_assets(content_key,active)').run();
  mediaSchemaReady = true;
}
function mediaPermission(item, type) {
  const status = String(item.rights_status || item.license_status || item.permission_status || '').toLowerCase().trim();
  const allowed = item.allowed_usage ?? item.permissions ?? item.usage_rights ?? '';
  const usage = (Array.isArray(allowed) ? allowed.join(',') : String(allowed)).toLowerCase();
  const approved = ['authorized','licensed','owned','public_domain','cc0','cc-by','creative_commons_by'].includes(status);
  const useAllowed = type === 'video'
    ? /(^|[,\s])(embed|stream|display|in_app)([,\s]|$)/.test(usage)
    : /(^|[,\s])(display|publish|in_app|editorial)([,\s]|$)/.test(usage);
  const reference = String(item.rights_reference || item.license_url || item.permission_url || '').trim();
  return approved && useAllowed && /^https:\/\//i.test(reference);
}
function normalizeMediaCandidate(x, providerKey) {
  const type = String(x.media_type || x.type || x.kind || '').toLowerCase();
  if (!['photo','image','video','highlight','trailer','feature'].includes(type)) return null;
  const mediaType = ['photo','image'].includes(type) ? 'photo' : 'video';
  const mediaUrl = String(x.media_url || x.url || x.video_url || x.image_url || x.imageUrl || '').trim();
  const sourceUrl = String(x.source_url || x.original_url || x.page_url || '').trim();
  const id = String(x.id || x.asset_id || x.guid || '').trim();
  const contentKey = String(x.content_key || x.related_entity_id || x.match_id || x.event_id || id).trim().slice(0,180);
  if (!id || !contentKey || !/^https:\/\//i.test(mediaUrl) || !/^https:\/\//i.test(sourceUrl)) return null;
  if (!mediaPermission(x, mediaType)) return null;
  const duration = Math.max(0, Math.floor(Number(x.duration_seconds || x.duration || 0)));
  if (mediaType === 'video' && (duration < 15 || duration > 180)) return null;
  return {
    providerKey, id, mediaType, contentKey,
    title: String(x.title || x.name || '').trim().slice(0,240),
    description: String(x.description || x.summary || '').trim().slice(0,1600),
    mediaUrl, thumbnailUrl: /^https:\/\//i.test(String(x.thumbnail_url || x.thumbnail || x.poster || '')) ? String(x.thumbnail_url || x.thumbnail || x.poster) : '',
    sourceUrl, sourceName: String(x.source_name || x.provider_name || providerKey).slice(0,160),
    category: String(x.category || x.sport || 'general').slice(0,80),
    entityId: String(x.related_entity_id || x.match_id || x.event_id || '').slice(0,180),
    entityName: String(x.related_entity_name || x.match_name || x.event_name || '').slice(0,240),
    duration, rightsStatus: String(x.rights_status || x.license_status || x.permission_status),
    rightsReference: String(x.rights_reference || x.license_url || x.permission_url),
    allowedUsage: Array.isArray(x.allowed_usage || x.permissions || x.usage_rights) ? (x.allowed_usage || x.permissions || x.usage_rights).join(',') : String(x.allowed_usage || x.permissions || x.usage_rights),
    priority: Number(x.priority || x.relevance_score || 0), publishedAt: String(x.published_at || x.publishedAt || '')
  };
}
async function refreshAuthorizedMedia(env) {
  await ensureMediaTable(env);
  const apiUrl = String(env.MEDIA_PROVIDER_API_URL || '').trim();
  const apiKey = String(env.MEDIA_PROVIDER_API_KEY || '').trim();
  if (!apiUrl || !apiKey) return {ok:false, reason:'media_provider_not_configured', published:0, rejected:0};
  let payload;
  try {
    const u = new URL(apiUrl);
    if (!u.searchParams.has('updated_since')) u.searchParams.set('updated_since', new Date(Date.now()-24*60*60*1000).toISOString());
    const response = await fetch(u.toString(), {headers:{Accept:'application/json','X-Api-Key':apiKey,Authorization:`Bearer ${apiKey}`},signal:AbortSignal.timeout(15000)});
    if (!response.ok) return {ok:false, reason:`provider_http_${response.status}`, published:0, rejected:0};
    payload = await response.json();
  } catch (e) { return {ok:false, reason:'provider_fetch_failed', detail:String(e.message || e), published:0, rejected:0}; }
  const list = Array.isArray(payload) ? payload : (Array.isArray(payload.items) ? payload.items : (Array.isArray(payload.results) ? payload.results : (Array.isArray(payload.data) ? payload.data : [])));
  const providerKey = String(payload.provider || env.MEDIA_PROVIDER_NAME || 'configured-media-provider').slice(0,100);
  let published=0, rejected=0;
  const accepted=[];
  for (const raw of list.slice(0,200)) {
    const item = normalizeMediaCandidate(raw, providerKey);
    if (!item) { rejected++; continue; }
    accepted.push(item);
  }
  // A provider response is not a deletion signal unless it explicitly marks itself complete.
  for (const item of accepted) {
    await env.DB.prepare(`INSERT INTO media_assets(provider_key,provider_asset_id,media_type,content_key,title,description,media_url,thumbnail_url,source_url,source_name,category,related_entity_id,related_entity_name,duration_seconds,rights_status,rights_reference,allowed_usage,priority,source_published_at,last_seen_at,active)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP,1)
      ON CONFLICT(provider_key,provider_asset_id) DO UPDATE SET media_type=excluded.media_type,content_key=excluded.content_key,title=excluded.title,description=excluded.description,media_url=excluded.media_url,thumbnail_url=excluded.thumbnail_url,source_url=excluded.source_url,source_name=excluded.source_name,category=excluded.category,related_entity_id=excluded.related_entity_id,related_entity_name=excluded.related_entity_name,duration_seconds=excluded.duration_seconds,rights_status=excluded.rights_status,rights_reference=excluded.rights_reference,allowed_usage=excluded.allowed_usage,priority=excluded.priority,source_published_at=excluded.source_published_at,last_seen_at=CURRENT_TIMESTAMP,active=1`)
      .bind(item.providerKey,item.id,item.mediaType,item.contentKey,item.title,item.description,item.mediaUrl,item.thumbnailUrl,item.sourceUrl,item.sourceName,item.category,item.entityId,item.entityName,item.duration,item.rightsStatus,item.rightsReference,item.allowedUsage,item.priority,item.publishedAt).run();
    published++;
  }
  // For each logical content slot, retain the highest-priority newest approved asset.
  await env.DB.prepare(`UPDATE media_assets SET active=0 WHERE id NOT IN (
    SELECT id FROM (SELECT id, ROW_NUMBER() OVER (PARTITION BY media_type,content_key ORDER BY priority DESC, COALESCE(source_published_at,'') DESC, last_seen_at DESC, id DESC) AS rn FROM media_assets WHERE active=1) WHERE rn=1
  )`).run();
  return {ok:true, scanned:list.length, published, rejected, updatedAt:new Date().toISOString()};
}
async function listAuthorizedMedia(env, type, limit=40) {
  await ensureMediaTable(env);
  const safeType = ['photo','video'].includes(type) ? type : null;
  const max = Math.min(Math.max(Number(limit)||40,1),100);
  const q = safeType
    ? await env.DB.prepare('SELECT * FROM media_assets WHERE active=1 AND media_type=? ORDER BY priority DESC,source_published_at DESC,last_seen_at DESC LIMIT ?').bind(safeType,max).all()
    : await env.DB.prepare('SELECT * FROM media_assets WHERE active=1 ORDER BY priority DESC,source_published_at DESC,last_seen_at DESC LIMIT ?').bind(max).all();
  return q.results || [];
}

const DEFAULT_APP_CONFIG = {
  sports_refresh_ms: 30000,
  cricket_detail_refresh_ms: 20000,
  notifications_refresh_ms: 30000,
  status_live: "Live Now",
  status_upcoming: "Upcoming",
  status_finished: "Finished",
  status_live_badge: "LIVE NOW",
  live_score_refresh_enabled: true,
  remote_data_enabled: true,
  news_auto_publish_enabled: true
};

async function ensureAppConfig(env) {
  try {
    await env.DB.prepare(`CREATE TABLE IF NOT EXISTS app_config (
      config_key TEXT PRIMARY KEY,
      config_value TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )`).run();
    for (const [key, value] of Object.entries(DEFAULT_APP_CONFIG)) {
      await env.DB.prepare(`INSERT OR IGNORE INTO app_config(config_key,config_value) VALUES(?,?)`).bind(key, String(value)).run();
    }
  } catch (_) {}
}

async function getAppConfig(env) {
  await ensureAppConfig(env);
  const out = {...DEFAULT_APP_CONFIG, _updatedAt: ""};
  let updatedAt = "";
  try {
    const rows = await env.DB.prepare(`SELECT config_key,config_value,updated_at FROM app_config`).all();
    for (const r of (rows.results || [])) {
      if (r.updated_at && String(r.updated_at) > updatedAt) updatedAt = String(r.updated_at);
      if (!(r.config_key in out)) continue;
      const def = DEFAULT_APP_CONFIG[r.config_key];
      if (typeof def === 'boolean') out[r.config_key] = String(r.config_value).toLowerCase() === 'true' || String(r.config_value) === '1';
      else if (typeof def === 'number') out[r.config_key] = Number(r.config_value) || def;
      else out[r.config_key] = String(r.config_value);
    }
  } catch (_) {}
  out._updatedAt = updatedAt;
  return out;
}

async function saveAppConfig(env, values) {
  await ensureAppConfig(env);
  for (const [key, value] of Object.entries(values || {})) {
    if (!(key in DEFAULT_APP_CONFIG)) continue;
    await env.DB.prepare(`INSERT INTO app_config(config_key,config_value,updated_at) VALUES(?,?,CURRENT_TIMESTAMP)
      ON CONFLICT(config_key) DO UPDATE SET config_value=excluded.config_value,updated_at=CURRENT_TIMESTAMP`)
      .bind(key, String(value)).run();
  }
  return getAppConfig(env);
}

async function adminPage(env) {
  const channels = [];
  const notices = [];
  const channelJson = JSON.stringify(channels).replace(/</g, "\\u003c");
  const noticeJson = JSON.stringify(notices).replace(/</g, "\\u003c");

  return new Response(`<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>One TV Admin</title>
<style>
body{font-family:Arial,sans-serif;max-width:1180px;margin:24px auto;padding:0 16px;background:#0b0f14;color:#fff}
input,select,button,textarea{padding:10px;margin:4px;border-radius:6px;border:1px solid #333;background:#151b22;color:#fff;box-sizing:border-box}
button{cursor:pointer}.card{border:1px solid #29313b;border-radius:10px;padding:14px;margin:12px 0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:8px}
small{color:#9aa4af}.on{color:#69db7c}.off{color:#ff8787}.danger{background:#7f1d1d}.source-fields{margin-top:8px}.tabs{display:flex;gap:8px;position:sticky;top:0;background:#0b0f14;padding:10px 0;z-index:5}.tabs button.active{background:#2563eb}
.editor{min-height:160px;border:1px solid #333;border-radius:8px;background:#fff;color:#111;padding:12px;margin:4px;overflow:auto}.toolbar{display:flex;flex-wrap:wrap;align-items:center;gap:2px;background:#151b22;padding:6px;border-radius:8px;margin:4px}.toolbar button{padding:7px 9px;margin:0}.toolbar input{width:42px;padding:6px;margin:0}.html-source{min-height:160px;width:100%;font-family:monospace}.hidden{display:none!important}.preview{border:1px solid #29313b;background:#0b0f14;padding:10px;margin-top:8px}.notice-item{display:flex;justify-content:space-between;gap:10px;align-items:center}.badge{display:inline-block;padding:3px 7px;border-radius:20px;background:#263241;font-size:12px}
</style></head><body>
<h1>One TV Admin</h1>
<p><small>Manage channels and optional notices/personal ads. Changes become available to app users after the next refresh.</small></p>
<div class="card"><b>Admin token</b><br><input id="token" type="password" placeholder="Paste ADMIN_TOKEN" style="width:100%;max-width:600px"><button onclick="connectAdmin()">Connect</button> <span id="connStatus"><small>Not connected</small></span></div>
<p><a href="/admin/sports" style="color:#93c5fd">Sports Sources — Full Backend Control</a></p>
<div class="tabs"><button id="tabChannels" class="active" onclick="showTab('channels')">Channels</button><button id="tabNotices" onclick="showTab('notices')">Notices / Personal Ads</button><button id="tabAds" onclick="showTab('ads')">Ad Platforms</button><button id="tabConfig" onclick="showTab('config')">App Config</button></div>

<section id="configTab" class="hidden">
<div class="card"><h3>Remote App Configuration</h3><p><small>These values are delivered by the backend to already-installed app builds. Changing them does not require an APK rebuild, as long as the installed app already supports the setting.</small></p>
<div class="grid">
<label>Sports refresh (ms)<input id="cfgSportsRefresh" type="number"></label>
<label>Cricket detail refresh (ms)<input id="cfgCricketRefresh" type="number"></label>
<label>Notifications refresh (ms)<input id="cfgNotificationsRefresh" type="number"></label>
<label>Live status label<input id="cfgLive" value="Live Now"></label>
<label>Upcoming status label<input id="cfgUpcoming" value="Upcoming"></label>
<label>Finished status label<input id="cfgFinished" value="Finished"></label>
<label>Live badge label<input id="cfgLiveBadge" value="LIVE NOW"></label>
</div>
<label><input id="cfgLiveScoreEnabled" type="checkbox"> Live score auto refresh enabled</label><br>
<label><input id="cfgNewsEnabled" type="checkbox"> Automatic news publishing enabled (every 30 minutes)</label><br>
<label><input id="cfgRemoteDataEnabled" type="checkbox" checked> Remote data enabled</label><br>
<button onclick="loadConfig()">Reload</button><button onclick="saveConfig()">Save configuration</button>
</div></section>

<section id="channelsTab">
<div class="card"><h3>Add / Edit channel</h3><input id="cid" type="hidden">
<div class="grid">
<input id="number" placeholder="Channel number"><input id="name" placeholder="Channel name"><input id="country" placeholder="Country" value="International">
<select id="category"><option value="TV">TV</option><option value="Movies">Movies</option><option value="Sports">Sports</option><option value="News">News</option><option value="Kids">Kids</option></select>
<input id="logoUrl" placeholder="Logo URL"><input id="programName" placeholder="Program / movie title (optional)"><input id="programApiUrl" placeholder="Program API URL (optional)"><input id="sortOrder" type="number" placeholder="Sort order" value="0">
<select id="sourceType" onchange="updateSourceFields()"><option value="link">Source: Direct Link</option><option value="api">Source: API</option><option value="youtube">Source: YouTube</option></select>
</div>
<div id="linkFields" class="source-fields"><input id="streamUrl" placeholder="Stream link (HLS / DASH / MP4)" style="width:100%"></div>
<div id="youtubeFields" class="source-fields hidden"><input id="youtubeUrl" placeholder="YouTube watch / shorts / live URL or Video ID" style="width:100%"><small>YouTube Data API resolves title/thumbnail on the server. Playback uses the official embedded YouTube player.</small></div>
<div id="apiFields" class="source-fields hidden"><input id="sourceValue" placeholder="API URL that returns the stream URL" style="width:100%"><input id="apiKey" type="password" placeholder="API key (optional)" style="width:100%"></div>
<label><input id="showViewers" type="checkbox"> Show viewer count</label> <label><input id="loopPlayback" type="checkbox"> Loop playback (Movies)</label><br><label><input id="active" type="checkbox" checked> Active</label><br><button onclick="saveChannel()">Save channel</button><button onclick="clearChannelForm()">Clear</button></div>
<div id="channelList"></div>
</section>

<section id="adsTab" class="hidden">
<div class="card"><h3>Ad Platform Priority</h3><small>Keep only 2-3 platforms active. Priority 1 is preferred; the app may fall back to the next active supported network. New SDKs still require a new APK/AAB.</small><div id="adList"></div><button onclick="saveAds()">Save Ad Configuration</button></div>
</section>

<section id="noticesTab" class="hidden">
<div class="card"><h3>Publish notice / personal ad</h3><input id="nid" type="hidden">
<div class="grid"><input id="noticeTitle" placeholder="Internal title / label"><select id="noticeType" onchange="updateNoticeFields()"><option value="text">Text</option><option value="banner">Banner image</option><option value="video">Video</option></select><input id="noticeSort" type="number" value="0" placeholder="Sort order"></div>
<div id="textNoticeFields">
<div class="toolbar">
<select onchange="cmd('fontName',this.value)"><option value="Arial">Arial</option><option value="Verdana">Verdana</option><option value="Georgia">Georgia</option><option value="Times New Roman">Times New Roman</option><option value="Courier New">Courier New</option><option value="Trebuchet MS">Trebuchet MS</option><option value="Impact">Impact</option></select>
<select onchange="cmd('fontSize',this.value)"><option value="2">Small</option><option value="3" selected>Normal</option><option value="4">Large</option><option value="5">XL</option><option value="6">XXL</option></select>
<button type="button" onclick="cmd('bold')"><b>B</b></button><button type="button" onclick="cmd('italic')"><i>I</i></button><button type="button" onclick="cmd('underline')"><u>U</u></button><button type="button" onclick="cmd('strikeThrough')"><s>S</s></button>
<button type="button" onclick="cmd('justifyLeft')">Left</button><button type="button" onclick="cmd('justifyCenter')">Center</button><button type="button" onclick="cmd('justifyRight')">Right</button>
<button type="button" onclick="cmd('insertUnorderedList')">â€¢ List</button><button type="button" onclick="cmd('insertOrderedList')">1. List</button>
<label>Text <input type="color" value="#ffffff" onchange="cmd('foreColor',this.value)"></label><label>BG <input type="color" value="#111827" onchange="cmd('hiliteColor',this.value)"></label>
<button type="button" onclick="addLink()">Link</button><button type="button" onclick="toggleSource()">HTML</button>
</div>
<div id="noticeEditor" class="editor" contenteditable="true"><div style="font-family:Arial;font-size:18px;text-align:center">Write your notice here...</div></div>
<textarea id="noticeHtml" class="html-source hidden" placeholder="Advanced HTML/CSS"></textarea>
</div>
<div id="mediaNoticeFields" class="hidden"><input id="mediaUrl" placeholder="Image / video URL" style="width:100%"><input id="linkUrl" placeholder="Optional click URL" style="width:100%"><small>Banner: use a direct image URL. Video: use a direct MP4/WebM URL.</small></div>
<label><input id="noticeActive" type="checkbox" checked> Publish now</label><br><button onclick="saveNotice()">Publish / Save notice</button><button onclick="clearNoticeForm()">Clear</button></div>
<div class="card"><h3>Notice preview</h3><div id="noticePreview" class="preview">Nothing published.</div></div>
<div id="noticeList"></div>
</section>

<script>
const initialChannels=${channelJson}; const initialNotices=${noticeJson}; let channels=initialChannels, notices=initialNotices, adPlatforms=[];
const $=id=>document.getElementById(id); function token(){return $('token').value}
async function api(path,opts={}){opts.headers={...(opts.headers||{}),'Authorization':'Bearer '+token(),'Content-Type':'application/json'};const r=await fetch(path,opts);let d={};try{d=await r.json()}catch(_){d={error:'Invalid server response'}}if(!r.ok)throw new Error(d.error||'Request failed');return d}
async function connectAdmin(){try{channels=await api('/admin/channels');notices=await api('/admin/notices');adPlatforms=await api('/admin/ads');renderChannels();renderNotices();renderAds();$('connStatus').innerHTML='<span class=on>Connected</span>'}catch(e){$('connStatus').innerHTML='<span class=off>'+esc(e.message)+'</span>'}}
function showTab(tab){$('channelsTab').classList.toggle('hidden',tab!=='channels');$('noticesTab').classList.toggle('hidden',tab!=='notices');$('adsTab').classList.toggle('hidden',tab!=='ads');$('configTab').classList.toggle('hidden',tab!=='config');$('tabChannels').classList.toggle('active',tab==='channels');$('tabNotices').classList.toggle('active',tab==='notices');$('tabAds').classList.toggle('active',tab==='ads');$('tabConfig').classList.toggle('active',tab==='config');if(tab==='config')loadConfig()}
async function loadConfig(){try{const c=await api('/admin/config');$('cfgSportsRefresh').value=c.sports_refresh_ms||30000;$('cfgCricketRefresh').value=c.cricket_detail_refresh_ms||20000;$('cfgNotificationsRefresh').value=c.notifications_refresh_ms||30000;$('cfgLive').value=c.status_live||'Live Now';$('cfgUpcoming').value=c.status_upcoming||'Upcoming';$('cfgFinished').value=c.status_finished||'Finished';$('cfgLiveBadge').value=c.status_live_badge||'LIVE NOW';$('cfgLiveScoreEnabled').checked=!!c.live_score_refresh_enabled;$('cfgNewsEnabled').checked=c.news_auto_publish_enabled!==false;$('cfgRemoteDataEnabled').checked=c.remote_data_enabled!==false}catch(e){alert(e.message)}}
async function saveConfig(){try{const body={sports_refresh_ms:Math.max(5000,Number($('cfgSportsRefresh').value||30000)),cricket_detail_refresh_ms:Math.max(5000,Number($('cfgCricketRefresh').value||20000)),notifications_refresh_ms:Math.max(5000,Number($('cfgNotificationsRefresh').value||30000)),status_live:$('cfgLive').value.trim()||'Live Now',status_upcoming:$('cfgUpcoming').value.trim()||'Upcoming',status_finished:$('cfgFinished').value.trim()||'Finished',status_live_badge:$('cfgLiveBadge').value.trim()||'LIVE NOW',live_score_refresh_enabled:$('cfgLiveScoreEnabled').checked,news_auto_publish_enabled:$('cfgNewsEnabled').checked,remote_data_enabled:$('cfgRemoteDataEnabled').checked};const c=await api('/admin/config',{method:'PATCH',body:JSON.stringify(body)});alert('App configuration saved');return c}catch(e){alert(e.message)}}

function updateSourceFields(){const t=$('sourceType').value; const a=t==='api'; const y=t==='youtube'; $('linkFields').classList.toggle('hidden',a||y); $('apiFields').classList.toggle('hidden',!a); $('youtubeFields').classList.toggle('hidden',!y)}
function renderAds(){ $('adList').innerHTML=adPlatforms.map((a,i)=>'<div class="card"><b>'+esc(a.name)+'</b> <span class="'+(a.active?'on':'off')+'">'+(a.active?'ACTIVE':'OFF')+'</span><div class="grid"><label>Active <input data-ad="active" data-i="'+i+'" type="checkbox" '+(a.active?'checked':'')+'></label><label>Priority <input data-ad="priority" data-i="'+i+'" type="number" value="'+esc(a.priority)+'"></label><input data-ad="app_id" data-i="'+i+'" placeholder="App ID" value="'+esc(a.app_id||'')+'"><input data-ad="banner_unit_id" data-i="'+i+'" placeholder="Banner Ad Unit ID" value="'+esc(a.banner_unit_id||'')+'"></div></div>').join('') }
function saveAds(){try{document.querySelectorAll('[data-ad]').forEach(el=>{const i=Number(el.dataset.i),k=el.dataset.ad;if(el.type==='checkbox')adPlatforms[i][k]=el.checked;else adPlatforms[i][k]=el.value});api('/admin/ads',{method:'PATCH',body:JSON.stringify({platforms:adPlatforms})}).then(x=>{adPlatforms=x;renderAds();alert('Ad configuration saved')}).catch(e=>alert(e.message))}catch(e){alert(e.message)}}
function renderChannels(){ $('channelList').innerHTML=channels.map(c=>'<div class="card"><b>'+esc(c.name)+'</b> <span class="'+(c.active?'on':'off')+'">'+(c.active?'ACTIVE':'DISABLED')+'</span><br><small>'+esc(c.country)+' â€¢ '+esc(c.category)+' â€¢ '+esc(c.source_type)+'</small><br><small>'+esc(c.source_type==='api'?c.source_value:c.stream_url)+'</small><br><button onclick="editChannel('+c.id+')">Edit</button><button class="danger" onclick="deleteChannel('+c.id+')">Delete</button></div>').join('') }
function renderNotices(){ $('noticeList').innerHTML=notices.map(n=>'<div class="card notice-item"><div><b>'+esc(n.title||'(Untitled)')+'</b> <span class="badge">'+esc(n.type)+'</span> <span class="'+(n.active?'on':'off')+'">'+(n.active?'PUBLISHED':'HIDDEN')+'</span><br><small>'+esc(n.type==='text'?'Rich text notice':n.media_url)+'</small></div><div><button onclick="editNotice('+n.id+')">Edit</button><button class="danger" onclick="deleteNotice('+n.id+')">Delete</button></div></div>').join('')||'<div class="card"><small>No notices yet.</small></div>' }
function esc(s){return String(s??'').replace(/[&<>\"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]))}
function clearChannelForm(){['cid','number','name','country','logoUrl','programName','programApiUrl','streamUrl','sourceValue','apiKey','youtubeUrl'].forEach(x=>$(x).value='');$('country').value='International';$('category').value='TV';$('sortOrder').value='0';$('showViewers').checked=false;$('loopPlayback').checked=false;$('sourceType').value='link';$('youtubeUrl').value='';$('active').checked=true;updateSourceFields()}
function editChannel(id){const c=channels.find(x=>x.id===id);$('cid').value=c.id;$('number').value=c.channel_number;$('name').value=c.name;$('country').value=c.country;$('category').value=c.category;$('logoUrl').value=c.logo_url;$('programName').value=c.program_name||'';$('programApiUrl').value=c.program_api_url||'';$('sortOrder').value=c.sort_order;$('showViewers').checked=!!c.show_viewers;$('loopPlayback').checked=!!c.loop_playback;$('sourceType').value=c.source_type||'link';$('streamUrl').value=c.source_type==='api'||c.source_type==='youtube'?'':(c.source_value||c.stream_url||'');$('sourceValue').value=c.source_type==='api'?(c.source_value||''):'';$('youtubeUrl').value=c.source_type==='youtube'?(c.source_value||''):'';$('apiKey').value=c.api_key||'';$('active').checked=!!c.active;updateSourceFields();showTab('channels');scrollTo(0,0)}
async function saveChannel(){try{const type=$('sourceType').value;const sourceValue=type==='api'?$('sourceValue').value:(type==='youtube'?$('youtubeUrl').value:$('streamUrl').value); const body={channel_number:$('number').value,name:$('name').value,country:$('country').value,category:$('category').value,logo_url:$('logoUrl').value,stream_url:type==='link'?$('streamUrl').value:'',source_type:type,source_value:sourceValue,api_key:type==='api'?$('apiKey').value:'',program_name:$('programName').value,program_api_url:$('programApiUrl').value,show_viewers:$('showViewers').checked,loop_playback:$('loopPlayback').checked,sort_order:Number($('sortOrder').value||0),active:$('active').checked};if(!body.name)throw new Error('Channel name is required');if(type==='link'&&!body.stream_url)throw new Error('Stream link is required');if(type==='api'&&!body.source_value)throw new Error('API URL is required');if(type==='youtube'&&!body.source_value)throw new Error('YouTube URL is required');const id=$('cid').value;await api(id?'/admin/channels/'+id:'/admin/channels',{method:id?'PATCH':'POST',body:JSON.stringify(body)});clearChannelForm();channels=await api('/admin/channels');renderChannels();alert('Saved')}catch(e){alert(e.message)}}
async function deleteChannel(id){if(!confirm('Delete this channel?'))return;try{await api('/admin/channels/'+id,{method:'DELETE'});channels=await api('/admin/channels');renderChannels()}catch(e){alert(e.message)}}
function cmd(name,value){document.execCommand(name,false,value||null);$('noticeEditor').focus();updatePreview()}
function addLink(){const u=prompt('Enter https:// link');if(u)cmd('createLink',u)}
function toggleSource(){const source=$('noticeHtml'), editor=$('noticeEditor');if(source.classList.contains('hidden')){source.value=editor.innerHTML;source.classList.remove('hidden');editor.classList.add('hidden')}else{editor.innerHTML=source.value;source.classList.add('hidden');editor.classList.remove('hidden')}updatePreview()}
function getNoticeHtml(){return $('noticeHtml').classList.contains('hidden')?$('noticeEditor').innerHTML:$('noticeHtml').value}
function updateNoticeFields(){const type=$('noticeType').value;const text=type==='text';$('textNoticeFields').classList.toggle('hidden',!text);$('mediaNoticeFields').classList.toggle('hidden',text);updatePreview()}
function updatePreview(){const type=$('noticeType').value;let html='';if(type==='text')html=getNoticeHtml();else if(type==='banner')html='<img src="'+esc($('mediaUrl').value)+'" style="max-width:100%;display:block;margin:auto">';else html='<video src="'+esc($('mediaUrl').value)+'" controls muted style="max-width:100%;width:100%"></video>';$('noticePreview').innerHTML=html||'Nothing to preview.'}
function clearNoticeForm(){$('nid').value='';$('noticeTitle').value='';$('noticeType').value='text';$('noticeSort').value='0';$('noticeEditor').innerHTML='<div style="font-family:Arial;font-size:18px;text-align:center">Write your notice here...</div>';$('noticeHtml').value='';$('noticeHtml').classList.add('hidden');$('noticeEditor').classList.remove('hidden');$('mediaUrl').value='';$('linkUrl').value='';$('noticeActive').checked=true;updateNoticeFields();updatePreview()}
function editNotice(id){const n=notices.find(x=>x.id===id);$('nid').value=n.id;$('noticeTitle').value=n.title||'';$('noticeType').value=n.type||'text';$('noticeSort').value=n.sort_order||0;$('noticeEditor').innerHTML=n.html_content||'';$('noticeHtml').value=n.html_content||'';$('noticeHtml').classList.add('hidden');$('noticeEditor').classList.remove('hidden');$('mediaUrl').value=n.media_url||'';$('linkUrl').value=n.link_url||'';$('noticeActive').checked=!!n.active;updateNoticeFields();updatePreview();showTab('notices');scrollTo(0,0)}
async function saveNotice(){try{const type=$('noticeType').value;const body={title:$('noticeTitle').value,type,html_content:type==='text'?getNoticeHtml():'',media_url:type==='text'?'':$('mediaUrl').value,link_url:type==='text'?'':$('linkUrl').value,sort_order:Number($('noticeSort').value||0),active:$('noticeActive').checked};if(type==='text'&&!body.html_content.trim())throw new Error('Notice text is required');if(type!=='text'&&!body.media_url.trim())throw new Error('Media URL is required');const id=$('nid').value;await api(id?'/admin/notices/'+id:'/admin/notices',{method:id?'PATCH':'POST',body:JSON.stringify(body)});clearNoticeForm();notices=await api('/admin/notices');renderNotices();alert('Notice saved')}catch(e){alert(e.message)}}
async function deleteNotice(id){if(!confirm('Delete this notice?'))return;try{await api('/admin/notices/'+id,{method:'DELETE'});notices=await api('/admin/notices');renderNotices()}catch(e){alert(e.message)}}
$('noticeEditor').addEventListener('input',updatePreview);$('mediaUrl').addEventListener('input',updatePreview);updateSourceFields();updateNoticeFields();renderChannels();renderNotices();if(token())connectAdmin();
</script></body></html>`, {headers:{"content-type":"text/html; charset=utf-8"}});
}

async function ensureAdPlatforms(env) {
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS ad_platforms (id INTEGER PRIMARY KEY AUTOINCREMENT, platform_key TEXT NOT NULL UNIQUE, name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 0, priority INTEGER NOT NULL DEFAULT 99, banner_enabled INTEGER NOT NULL DEFAULT 1, interstitial_enabled INTEGER NOT NULL DEFAULT 0, rewarded_enabled INTEGER NOT NULL DEFAULT 0, app_id TEXT NOT NULL DEFAULT '', banner_unit_id TEXT NOT NULL DEFAULT '', interstitial_unit_id TEXT NOT NULL DEFAULT '', rewarded_unit_id TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  const rows = await env.DB.prepare('SELECT COUNT(*) AS n FROM ad_platforms').first();
  if (!Number(rows?.n || 0)) {
    const seed=[['admob','AdMob'],['applovin','AppLovin'],['unity_levelplay','Unity LevelPlay'],['meta','Meta Audience Network'],['liftoff','Liftoff Monetize'],['inmobi','InMobi'],['pangle','Pangle'],['mintegral','Mintegral'],['dt_exchange','DT Exchange'],['bigo','BIGO Ads']];
    for (let i=0;i<seed.length;i++) await env.DB.prepare('INSERT INTO ad_platforms(platform_key,name,priority) VALUES(?,?,?)').bind(seed[i][0],seed[i][1],i+1).run();
  }
}
async function listAdPlatforms(env) { await ensureAdPlatforms(env); const r=await env.DB.prepare('SELECT * FROM ad_platforms ORDER BY active DESC, priority ASC, id ASC').all(); return r.results||[]; }

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, {status: 204, headers: {"access-control-allow-origin":"*","access-control-allow-methods":"GET,POST,PATCH,DELETE,OPTIONS","access-control-allow-headers":"Content-Type, Authorization"}});
    const url = new URL(request.url);
    try {
      // Public root landing response; never exposes secrets or claims provider health.
      if (url.pathname === "/" && request.method === "GET") {
        return json({
          ok: true,
          app: env.APP_NAME || "One TV",
          status: "online",
          healthEndpoint: "/health",
          api: {
            channels: "/channels",
            notices: "/notice",
            cricketLive: "/cricket/live",
            cricketUpcoming: "/cricket/upcoming",
            cricketResults: "/cricket/results"
          }
        });
      }
      if (url.pathname === "/health" && request.method === "GET") {
        let dbOk = false;
        try { await env.DB.prepare("SELECT 1 AS ok").first(); dbOk = true; } catch (_) {}
        return json({ok: dbOk, app: env.APP_NAME || "One TV", database: dbOk ? "connected" : "unavailable"});
      }
      if (url.pathname === "/config" && request.method === "GET") {
        const appConfig = await getAppConfig(env);
        return json({
          app: env.APP_NAME || "One TV",
          backendVersion: "2026-11-04-control-center-v1",
          remoteConfigVersion: appConfig._updatedAt || new Date().toISOString(),
          config: appConfig,
          sports: { primary: "SportScore", cricketFieldFallbacks: ["CricketData", "Cricbuzz"], cricketFallback: "OpenCricket", refreshMs: Number(appConfig.cricket_detail_refresh_ms || 20000) },
          sportScoreKeyConfigured: !!env.SPORTSCORE_API_KEY,
          cricketDataKeyConfigured: !!env.CRICKETDATA_API_KEY,
          cricbuzzKeyConfigured: !!env.CRICBUZZ_RAPIDAPI_KEY,
          openCricketKeyConfigured: !!env.OPENCRICKET_API_KEY,
          openCricketBaseUrl: String(env.OPENCRICKET_BASE_URL || "https://opencricketapi.com")
        });
      }
      if (url.pathname === "/ads" && request.method === "GET") {
        const platforms=await listAdPlatforms(env);
        const active=platforms.filter(x=>Number(x.active)===1).sort((a,b)=>Number(a.priority)-Number(b.priority)).slice(0,3);
        return json({updatedAt:new Date().toISOString(),activePlatforms:active,availablePlatforms:platforms.map(x=>({platform_key:x.platform_key,name:x.name,active:!!x.active,priority:x.priority}))});
      }
      if (url.pathname === "/channels" && request.method === "GET") return json({version: Date.now(), channels: await listChannels(env)});
      if ((url.pathname === "/notice" || url.pathname === "/notices") && request.method === "GET") {
        const notice = await getActiveNotice(env);
        return json(notice ? {enabled:true, ...notice} : {enabled:false});
      }
      if (url.pathname === "/notifications" && request.method === "GET") return json(await notificationFeed(env));
      if ((url.pathname === "/news" || url.pathname === "/news/" ) && request.method === "GET") return json({updatedAt:new Date().toISOString(),items:await listPublicNews(env, Number(url.searchParams.get("limit") || 30)),autoPublishEnabled:(await getAppConfig(env)).news_auto_publish_enabled !== false});
      if ((url.pathname === "/media" || url.pathname === "/media/" ) && request.method === "GET") return json({updatedAt:new Date().toISOString(),items:await listAuthorizedMedia(env,url.searchParams.get("type")||"",Number(url.searchParams.get("limit") || 40)),rightsGated:true,providerConfigured:!!(env.MEDIA_PROVIDER_API_URL&&env.MEDIA_PROVIDER_API_KEY)});
      if (url.pathname === "/search" && request.method === "GET") return json({query:url.searchParams.get("q")||"",items:await publicSearch(url.searchParams.get("q")||"",env)});
      // Public sports requests must be served from D1 snapshots only.
      // No public request is allowed to initiate a Provider API fetch.
      const cachedSportsReply = await serveStoredSports(request, url, env);
      if (cachedSportsReply) return cachedSportsReply;
      if (url.pathname === "/viewer/ping" && request.method === "POST") {
        const b = await request.json();
        const viewerId = String(b.viewerId || "").trim();
        const channelId = Number(b.channelId || 0);
        if (!viewerId || !channelId) return json({error:"viewerId and channelId are required"},400);
        const existing = await env.DB.prepare("SELECT channel_id FROM viewer_sessions WHERE viewer_id=?").bind(viewerId).first();
        if (!existing || Number(existing.channel_id) !== channelId) {
          await env.DB.prepare("INSERT INTO channel_views(channel_id,viewer_id,started_at) VALUES(?,?,CURRENT_TIMESTAMP)").bind(channelId,viewerId).run();
        }
        await env.DB.prepare("INSERT INTO viewer_sessions(viewer_id,channel_id,last_seen) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(viewer_id) DO UPDATE SET channel_id=excluded.channel_id,last_seen=CURRENT_TIMESTAMP").bind(viewerId,channelId).run();
        return json({ok:true});
      }
      if (url.pathname === "/viewer/ping" && request.method === "OPTIONS") return new Response(null,{status:204});

      if (url.pathname === "/admin" && request.method === "GET") return adminPage(env);
      if (url.pathname === "/admin/sports" && request.method === "GET") return sportsAdminPage();
      if (!url.pathname.startsWith("/admin/")) return text("Not found", 404);
      if (!adminOk(request, env)) return json({error:"Unauthorized"}, 401);
      if(url.pathname==='/admin/sports/sources'&&request.method==='POST'){
        try{return json(await createCustomSportsSource(env,await request.json()),201)}
        catch(e){return json({error:String(e.message||e)},400)}
      }
      let customRoute=url.pathname.match(/^\/admin\/sports\/custom\/([a-z][a-z0-9_]{2,39})$/);
      if(customRoute&&request.method==='PATCH'){
        try{return json(await updateCustomSportsConfig(env,customRoute[1],await request.json()))}
        catch(e){return json({error:String(e.message||e)},400)}
      }
      if(customRoute&&request.method==='DELETE'){
        try{return json(await deleteCustomSportsSource(env,customRoute[1]))}
        catch(e){return json({error:String(e.message||e)},400)}
      }
      if (url.pathname === "/admin/sports/sources" && request.method === "GET")
        return json({sources:await sportsControlList(env)});
      if (url.pathname === "/admin/sports/settings" && request.method === "GET")
        return json(await readSportsSettings(env));
      if (url.pathname === "/admin/sports/settings" && request.method === "PATCH")
        return json(await updateSportsSettings(env,await request.json()));
      let sourceRoute=url.pathname.match(/^\/admin\/sports\/source\/([a-z][a-z0-9_]{2,39})$/);
      if (sourceRoute && request.method === "PATCH"){
        try{return json({sources:await updateSportsSource(env,sourceRoute[1],await request.json())});}
        catch(e){return json({error:String(e.message||e)},400)}
      }
      sourceRoute=url.pathname.match(/^\/admin\/sports\/source\/([a-z][a-z0-9_]{2,39})\/clear-cooldown$/);
      if (sourceRoute && request.method === "POST"){
        const known=await env.DB.prepare('SELECT source_id FROM sports_source_controls WHERE source_id=?').bind(sourceRoute[1]).first();
        if(!known)return json({error:'Unknown source'},404);
        await ensureSportsControlSchema(env);
        await env.DB.prepare('UPDATE sports_source_controls SET cooldown_until=0 WHERE source_id=?')
          .bind(sourceRoute[1]).run();
        await env.DB.prepare("DELETE FROM sports_ingest_jobs WHERE job_key LIKE ?")
          .bind('src:'+sourceRoute[1]+':%').run();
        return json({ok:true,budgetUnchanged:true});
      }
      if(url.pathname==='/admin/sports/queue-refresh'&&request.method==='POST'){
        const body=await request.json();
        const sport=String(body.sport||''),bucket=String(body.bucket||'');
        if(!SPORTS.includes(sport)||!['live','upcoming','finished'].includes(bucket))
          return json({error:'Invalid sport or bucket'},400);
        await ensureSportsControlSchema(env);
        await env.DB.prepare(`INSERT INTO sports_force_jobs(sport,bucket,requested_at) VALUES(?,?,?)
          ON CONFLICT(sport,bucket) DO UPDATE SET requested_at=excluded.requested_at`)
          .bind(sport,bucket,Math.floor(Date.now()/1000)).run();
        return json({queued:true,nextRun:'scheduled_cron_only',requestsProvider:false});
      }
      if(url.pathname==='/admin/sports/cricsheet/import'&&request.method==='POST'){
        try{return json(await importCricsheetArchive(env,await request.json()));}
        catch(e){return json({error:String(e.message||e)},400)}
      }

      if (url.pathname === "/admin/stats" && request.method === "GET") {
        await cleanupViewers(env);
        const rows = await env.DB.prepare(`SELECT c.id,c.name,c.category,c.active,
          (SELECT COUNT(*) FROM viewer_sessions v WHERE v.channel_id=c.id AND v.last_seen >= datetime('now','-90 seconds')) AS viewers,
          (SELECT COUNT(*) FROM channel_views cv WHERE cv.channel_id=c.id) AS total_views,
          (SELECT COUNT(*) FROM channel_views cv WHERE cv.channel_id=c.id AND cv.started_at >= datetime('now','-24 hours')) AS views_24h
          FROM channels c ORDER BY c.sort_order ASC,c.id ASC`).all();
        const totals = await env.DB.prepare(`SELECT COUNT(*) AS total_views, COUNT(DISTINCT viewer_id) AS unique_viewers FROM channel_views`).first();
        return json({channels: rows.results || [], totals: totals || {total_views:0,unique_viewers:0}});
      }
      if(url.pathname==='/admin/ads/platforms'&&request.method==='POST'){
        const b=await request.json();const key=String(b.platform_key||'').trim().toLowerCase();
        if(!/^[a-z][a-z0-9_]{2,39}$/.test(key))return json({error:'Invalid platform_key'},400);
        await ensureAdPlatforms(env);
        const prev=await env.DB.prepare('SELECT id FROM ad_platforms WHERE platform_key=?').bind(key).first();
        if(prev)return json({error:'Platform already exists'},409);
        await env.DB.prepare('INSERT INTO ad_platforms(platform_key,name,active,priority) VALUES(?,?,0,99)')
          .bind(key,String(b.name||key).slice(0,90)).run();
        return json({ok:true,warning:'New ad network requires native Android SDK integration before it can serve ads'},201);
      }
      let adCustomRoute=url.pathname.match(/^\/admin\/ads\/platform\/([a-z][a-z0-9_]{2,39})$/);
      if(adCustomRoute&&request.method==='DELETE'){
        await ensureAdPlatforms(env);
        await env.DB.prepare('DELETE FROM ad_platforms WHERE platform_key=?').bind(adCustomRoute[1]).run();
        return json({ok:true});
      }
      if (url.pathname === "/admin/ads" && request.method === "GET") return json(await listAdPlatforms(env));
      if (url.pathname === "/admin/ads" && request.method === "PATCH") {
        const b=await request.json(); await ensureAdPlatforms(env);
        if (Array.isArray(b.platforms)) {
          for (const x of b.platforms) {
            const key=String(x.platform_key||'').trim(); if(!key) continue;
            await env.DB.prepare(`UPDATE ad_platforms SET name=?,active=?,priority=?,banner_enabled=?,interstitial_enabled=?,rewarded_enabled=?,app_id=?,banner_unit_id=?,interstitial_unit_id=?,rewarded_unit_id=?,updated_at=CURRENT_TIMESTAMP WHERE platform_key=?`).bind(String(x.name||key).slice(0,90),x.active?1:0,Number(x.priority||99),x.banner_enabled===false?0:1,x.interstitial_enabled?1:0,x.rewarded_enabled?1:0,String(x.app_id||''),String(x.banner_unit_id||''),String(x.interstitial_unit_id||''),String(x.rewarded_unit_id||''),key).run();
          }
        }
        return json(await listAdPlatforms(env));
      }
      if(url.pathname==='/admin/news/sources'&&request.method==='GET')return json(await adminNewsSourceList(env));
      if(url.pathname==='/admin/news/sources'&&request.method==='POST'){
        try{return json(await upsertNewsSource(env,await request.json()),201)}catch(e){return json({error:String(e.message||e)},400)}
      }
      let newsRoute=url.pathname.match(/^\/admin\/news\/source\/([a-z][a-z0-9_]{2,39})$/);
      if(newsRoute&&request.method==='PATCH'){
        try{return json(await upsertNewsSource(env,{...await request.json(),__edit:true},newsRoute[1]))}
        catch(e){return json({error:String(e.message||e)},400)}
      }
      if(newsRoute&&request.method==='DELETE'){
        await ensureNewsSourceSchema(env);
        await env.DB.prepare('DELETE FROM news_source_controls WHERE source_id=?').bind(newsRoute[1]).run();
        return json({ok:true});
      }
      if(url.pathname==='/admin/news/articles'&&request.method==='GET'){
        await ensureNewsTable(env);const r=await env.DB.prepare(`SELECT * FROM news_articles ORDER BY published_at DESC,id DESC LIMIT 100`).all();
        return json(r.results||[]);
      }
      if(url.pathname==='/admin/news/articles'&&request.method==='POST'){
        await ensureNewsTable(env);const x=await request.json();
        const headline=String(x.headline||'').trim(),body=String(x.body||'').trim();
        if(!headline||!body)return json({error:'Headline and body required'},400);
        await env.DB.prepare(`INSERT INTO news_articles(source_name,source_url,image_url,fingerprint,headline,summary,body,category,tags_json,active,published_at)
          VALUES(?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)`)
          .bind(String(x.source_name||'OneTV Editorial').slice(0,100),String(x.source_url||'').slice(0,600),String(x.image_url||'').slice(0,600),'manual-'+crypto.randomUUID(),headline.slice(0,180),String(x.summary||'').slice(0,600),body.slice(0,6000),String(x.category||'Sports').slice(0,60),JSON.stringify([]),x.active===false?0:1).run();
        return json({ok:true},201);
      }
      let articleRoute=url.pathname.match(/^\/admin\/news\/articles\/(\d+)$/);
      if(articleRoute&&request.method==='DELETE'){
        await ensureNewsTable(env);await env.DB.prepare('DELETE FROM news_articles WHERE id=?').bind(Number(articleRoute[1])).run();return json({ok:true});
      }
      if(articleRoute&&request.method==='PATCH'){
        await ensureNewsTable(env);const x=await request.json();
        const old=await env.DB.prepare('SELECT * FROM news_articles WHERE id=?').bind(Number(articleRoute[1])).first();
        if(!old)return json({error:'Article not found'},404);
        const v={...old,...x};
        await env.DB.prepare(`UPDATE news_articles SET headline=?,summary=?,body=?,category=?,source_name=?,source_url=?,image_url=?,active=? WHERE id=?`)
          .bind(String(v.headline||'').slice(0,180),String(v.summary||'').slice(0,600),String(v.body||'').slice(0,6000),String(v.category||'Sports').slice(0,60),String(v.source_name||'OneTV Editorial').slice(0,100),String(v.source_url||'').slice(0,600),String(v.image_url||'').slice(0,600),v.active?1:0,Number(articleRoute[1])).run();
        return json({ok:true});
      }
      if (url.pathname === "/admin/media/refresh" && request.method === "POST") { if (!adminOk(request,env)) return json({error:"Unauthorized"},401); return json(await refreshAuthorizedMedia(env)); }
      if (url.pathname === "/admin/config" && request.method === "GET") return json(await getAppConfig(env));
      if (url.pathname === "/admin/config" && request.method === "PATCH") {
        const b = await request.json();
        const allowed = {};
        for (const key of Object.keys(DEFAULT_APP_CONFIG)) if (Object.prototype.hasOwnProperty.call(b, key)) allowed[key] = b[key];
        return json(await saveAppConfig(env, allowed));
      }
      if (url.pathname === "/admin/channels" && request.method === "GET") return json(await adminListChannels(env));
      if (url.pathname === "/admin/channels" && request.method === "POST") {
        const b = await request.json();
        const requestedType = String(b.source_type || "link").toLowerCase();
        const sourceType = ["link","api","youtube"].includes(requestedType) ? requestedType : "link";
        const sourceValue = String(b.source_value || (sourceType === "link" ? b.stream_url || "" : ""));
        if (!b.name) return json({error:"Channel name is required"},400);
        if (!sourceValue) return json({error: sourceType === "api" ? "API URL is required" : sourceType === "youtube" ? "YouTube URL is required" : "Stream link is required"},400);
        await env.DB.prepare(`INSERT INTO channels(channel_number,name,country,category,logo_url,stream_url,source_type,source_value,api_key,program_name,program_api_url,show_viewers,loop_playback,active,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
          .bind(String(b.channel_number||""),String(b.name),String(b.country||"International"),String(b.category||"TV"),String(b.logo_url||""),String(b.stream_url||""),sourceType,sourceValue,String(b.api_key||""),String(b.program_name||""),String(b.program_api_url||""),b.show_viewers?1:0,b.loop_playback?1:0,b.active===false?0:1,Number(b.sort_order||0)).run();
        return json({ok:true},201);
      }

      if (url.pathname === "/admin/notices" && request.method === "GET") return json(await adminListNotices(env));
      if (url.pathname === "/admin/notices" && request.method === "POST") {
        const b = await request.json();
        const type = ["text","banner","video"].includes(String(b.type||"text")) ? String(b.type||"text") : "text";
        const html = cleanHtml(b.html_content || "");
        const media = String(b.media_url || "");
        if (type === "text" && !html.trim()) return json({error:"Notice text is required"},400);
        if (type !== "text" && !media.trim()) return json({error:"Media URL is required"},400);
        await env.DB.prepare(`INSERT INTO notices(type,title,html_content,media_url,link_url,active,sort_order) VALUES(?,?,?,?,?,?,?)`)
          .bind(type,String(b.title||""),html,media,String(b.link_url||""),b.active===false?0:1,Number(b.sort_order||0)).run();
        return json({ok:true},201);
      }

      let m = url.pathname.match(/^\/admin\/channels\/(\d+)$/);
      if (m) {
        const id = Number(m[1]);
        if (request.method === "DELETE") { await env.DB.prepare("DELETE FROM channels WHERE id=?").bind(id).run(); return json({ok:true}); }
        if (request.method === "PATCH") {
          const b = await request.json();
          const requestedType = String(b.source_type || "link").toLowerCase();
          const sourceType = ["link","api","youtube"].includes(requestedType) ? requestedType : "link";
          const sourceValue = String(b.source_value || (sourceType === "link" ? b.stream_url || "" : ""));
          if (!b.name) return json({error:"Channel name is required"},400);
          if (!sourceValue) return json({error: sourceType === "api" ? "API URL is required" : sourceType === "youtube" ? "YouTube URL is required" : "Stream link is required"},400);
          await env.DB.prepare(`UPDATE channels SET channel_number=?,name=?,country=?,category=?,logo_url=?,stream_url=?,source_type=?,source_value=?,api_key=?,program_name=?,program_api_url=?,show_viewers=?,loop_playback=?,active=?,sort_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
            .bind(String(b.channel_number||""),String(b.name),String(b.country||"International"),String(b.category||"TV"),String(b.logo_url||""),String(b.stream_url||""),sourceType,sourceValue,String(b.api_key||""),String(b.program_name||""),String(b.program_api_url||""),b.show_viewers?1:0,b.loop_playback?1:0,b.active===false?0:1,Number(b.sort_order||0),id).run();
          return json({ok:true});
        }
      }

      m = url.pathname.match(/^\/admin\/notices\/(\d+)$/);
      if (m) {
        const id = Number(m[1]);
        if (request.method === "DELETE") { await env.DB.prepare("DELETE FROM notices WHERE id=?").bind(id).run(); return json({ok:true}); }
        if (request.method === "PATCH") {
          const b = await request.json();
          const type = ["text","banner","video"].includes(String(b.type||"text")) ? String(b.type||"text") : "text";
          const html = cleanHtml(b.html_content || "");
          const media = String(b.media_url || "");
          if (type === "text" && !html.trim()) return json({error:"Notice text is required"},400);
          if (type !== "text" && !media.trim()) return json({error:"Media URL is required"},400);
          await env.DB.prepare(`UPDATE notices SET type=?,title=?,html_content=?,media_url=?,link_url=?,active=?,sort_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
            .bind(type,String(b.title||""),html,media,String(b.link_url||""),b.active===false?0:1,Number(b.sort_order||0),id).run();
          return json({ok:true});
        }
      }

      return text("Not found",404);
    } catch (e) {
      return json({error: e?.message || "Server error"},500);
    }
  },
  async scheduled(controller, env, ctx) {
    // Sports ingestion must not wait behind potentially slow news/media jobs.
    // Each workflow is independent; public GET routes always use D1 snapshots.
    ctx.waitUntil(Promise.allSettled([
      scheduledSportsIngestion(env).catch(e => {
        console.warn('Scheduled sports ingestion failed:', providerStatusError(e));
      }),
      (async () => {
        const cfg=await getAppConfig(env);
        if(cfg.news_auto_publish_enabled !== false) await publishOneNewsArticle(env);
      })(),
      refreshAuthorizedMedia(env)
    ]));
  }
};
