import assert from 'node:assert/strict';
import fs from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
let external=0,traffic=[];
const today=new Date().toISOString().slice(0,10);
const dt=today+'T07:30:00Z';
const mock=async (url,opts={})=>{
  external++;const u=new URL(url);traffic.push(u.host+u.pathname);
  if(u.host==='sportscore.com'&&u.pathname==='/api/v1/fixtures/'){
    const sport=u.searchParams.get('sport'),status=u.searchParams.get('status');
    const match={sport,slug:`uae-oman-${sport}`,start_time:dt,
      home_team:'United Arab Emirates',away_team:'Oman',
      home_score:status==='live'?'-':'-',away_score:'-',
      status:status==='live'?'LIVE':status==='upcoming'?'UPCOMING':'FINISHED',
      competition:'ICC Test'};
    return new Response(JSON.stringify({matches:[match]}),{status:200});
  }
  if(u.host==='sportscore.com'&&u.pathname.startsWith('/api/'))return new Response('{}',{status:404});
  if(u.host==='v3.football.api-sports.io'){
    return new Response(JSON.stringify({response:[{fixture:{id:999,date:dt,status:{short:'1H'},venue:{name:'Test Arena'}},teams:{home:{name:'United Arab Emirates'},away:{name:'Oman'}},goals:{home:2,away:1},league:{name:'League A'}}]}),{status:200});
  }
  if(u.host==='v1.basketball.api-sports.io'){
    return new Response(JSON.stringify({response:[{id:998,date:dt,status:{short:'Q1'},teams:{home:{name:'United Arab Emirates'},away:{name:'Oman'}},scores:{home:{total:5},away:{total:4}},league:{name:'League B'}}]}),{status:200});
  }
  if(u.host==='api.sportsapi.app'){
    return new Response(JSON.stringify({data:[{id:997,sport:u.searchParams.get('sport'),status:{type:'inprogress'},startTime:dt,home:{name:'United Arab Emirates'},away:{name:'Oman'},homeScore:{current:3},awayScore:{current:2},league:{name:'League C'}}]}),{status:200});
  }
  throw Error('Unexpected external request: '+url);
};
globalThis.fetch=mock;
const content=fs.readFileSync(new URL('../src/index.js',import.meta.url),'utf8');
const mod=await import('data:text/javascript;base64,'+Buffer.from(content+'\nexport {scheduledSportsIngestion, fetchControlledSportsFeed, sourceFeedFor, activeSourcesFor, sportsControlList, ensureSportsControlSchema};').toString('base64'));
const db=new DatabaseSync(':memory:');
const env={DB:{prepare(sql){const st=db.prepare(sql);let args=[];return {bind(...v){args=v;return this},async first(){return st.get(...args)||null},async all(){return {results:st.all(...args)}},async run(){const r=st.run(...args);return {meta:{changes:r.changes}}}}}},ADMIN_TOKEN:'test-admin-token',API_FOOTBALL_KEY:'fake-test-key',API_BASKETBALL_KEY:'fake-test-key',SPORTSAPI_KEY:'fake-test-key',CRICBUZZ_RAPIDAPI_KEY:''};
const r=async(path,method='GET',body,auth)=>{
 const req=new Request('https://example.com'+path,{method,headers:auth?{Authorization:'Bearer '+env.ADMIN_TOKEN,'Content-Type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined});
 return mod.default.fetch(req,env,{});
};
await mod.ensureSportsControlSchema(env);
let response=await r('/admin/sports/sources');assert.equal(response.status,401);
response=await r('/admin/sports/sources','GET',null,true);let json=await response.json();
assert.equal(json.sources.length,8);
assert.equal(json.sources.find(x=>x.source_id==='sportscore').enabled,true);
assert.equal(json.sources.find(x=>x.source_id==='api_football').enabled,false);
response=await r('/admin/sports/source/api_football','PATCH',{enabled:true,license_approved:true,priority:2},true);assert.equal(response.status,200);
response=await r('/admin/sports/source/api_basketball','PATCH',{enabled:true,license_approved:true,priority:2},true);assert.equal(response.status,200);
response=await r('/admin/sports/source/sportsapi','PATCH',{enabled:true,license_approved:true,priority:3},true);assert.equal(response.status,200);
// Empty D1: end users must never trigger a call.
response=await r('/sports/football/live');assert.equal((await response.json()).matches.length,0);assert.equal(external,0);
// Main source gives scoreless data; backup provides verified scoring.
const f=await mod.fetchControlledSportsFeed('football','live',env);
assert.ok(f.matches.length>=1);assert.equal(f.matches[0].home.score,'2');assert.equal(f.matches[0].away.score,'1');
assert.ok(f.matches[0].dataSources.scoreFallback.includes('API-Football'));
assert.ok(external>=2);
await mod.scheduledSportsIngestion(env);
const fetched=external;
for(const path of ['/sports/football/live','/sports/cricket/live','/sports/cricket/history','/cricket/health','/cricket/provider-status','/sports/cache-status','/sports/football/match/xx','/sports/cricket/team/omans']){
  response=await r(path);assert.ok([200,404].includes(response.status));await response.json();
}
assert.equal(external,fetched,'NO upstream from user GET');
// Paused: Cron should make NO new provider calls.
response=await r('/admin/sports/settings','PATCH',{paused:true},true);assert.equal(response.status,200);
await mod.scheduledSportsIngestion(env);assert.equal(external,fetched);
response=await r('/admin/sports/queue-refresh','POST',{sport:'football',bucket:'live'},true);assert.equal(response.status,200);
response=await r('/admin/sports/sources','GET',null,true);json=await response.json();assert.ok(json.sources.find(x=>x.source_id==='api_football').used_today>=1);
// History archive: disabled by default, and import requires explicit opt-in.
const sample={id:'cricsheet:cricket:fixture001',provider:'Cricsheet',sport:'cricket',
 name:'Bangladesh vs India',status:'FINISHED',time:'2026-11-01T00:00:00Z',
 home:{name:'Bangladesh',score:'185/8'},away:{name:'India',score:'186/5'}};
response=await r('/admin/sports/cricsheet/import','POST',{matches:[sample]},true);assert.equal(response.status,400);
response=await r('/admin/sports/source/cricsheet','PATCH',{enabled:true,license_approved:true},true);assert.equal(response.status,200);
response=await r('/admin/sports/cricsheet/import','POST',{matches:[sample]},true);assert.equal((await response.json()).saved,1);
response=await r('/sports/cricket/history');json=await response.json();assert.equal(json.matches.length,1);
assert.equal(json.matches[0].archiveOnly,true);
assert.equal(external,fetched,'History D1 GET must not contact upstream');
// Enabling unsupported legacy CricketData as Cron source must be blocked.
response=await r('/admin/sports/source/cricketdata','PATCH',{enabled:true},true);assert.equal(response.status,400);
// Admin page should be available for logging in, without exposing values.
response=await r('/admin/sports');assert.equal(response.status,200);
assert.match(await response.text(),/Sports Source Control/);
console.log('PASS: admin token, 8 source controls, score fallback, quota, pause, queue, Cricsheet import, 0 upstream on user GET. Calls:',external);
