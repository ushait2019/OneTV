import assert from 'node:assert/strict';
import fs from 'node:fs';
const file=fs.readFileSync(new URL('../src/index.js',import.meta.url),'utf8');
const mod=await import('data:text/javascript;base64,'+Buffer.from(file+`
export {normalizeExternalMatch,mergeSportsSources,readStoredDetails,carryPriorVerifiedScores,externalFixtureMatch};`).toString('base64'));
const time='2026-11-05T10:00:00Z';
const raw={id:848623,startTime:time,status:{type:'inprogress',period:'inning1',description:'1st innings (away)'},
  battingSide:'away',home:{id:168856,name:'Afghanistan',image:'https://example.com/afg.png'},
  away:{id:274451,name:'Zimbabwe',image:'https://example.com/zim.png'},
  homeScore:{current:null,innings:{}},
  awayScore:{current:271,innings:{inning1:{runs:271,wickets:3,overs:73,runRate:3.71}}},league:{name:'Test Tour'}};
const mapped=mod.normalizeExternalMatch(raw,'cricket','sportsapi');
assert.equal(mapped.id,'sportsapi:cricket:848623');
assert.equal(mapped.home.id,'168856');assert.equal(mapped.away.id,'274451');
assert.equal(mapped.home.score,'');assert.equal(mapped.away.score,'271/3');
assert.equal(mapped.away.wickets,'3');assert.equal(mapped.away.overs,'73');
assert.equal(mapped.away.runRate,'3.71');assert.equal(mapped.current_over,'73');
assert.equal(mapped.statusText,'1st innings (away)');
assert.equal(mapped.innings.length,1);
const sportscore={id:'sportscore:cricket:afghanistan-vs-zimbabwe:'+time,
  provider:'SportScore',providerMatchId:'afghanistan-vs-zimbabwe:'+time,
  sport:'cricket',time,status:'LIVE',statusText:'LIVE',
  home:{name:'Afghanistan',score:'-'},away:{name:'Zimbabwe',score:'271'}};
const result=mod.mergeSportsSources([sportscore],[mapped],'SportsAPI.app');
assert.equal(result.length,1);
assert.equal(result[0].away.score,'271/3');
assert.equal(result[0].away.overs,'73');
assert.equal(result[0].dataSources.scoreFallback,'SportsAPI.app');
// Same teams on another day must not borrow score from first fixture.
const tomorrow={...mapped,time:'2026-11-06T10:00:00Z'};
assert.equal(mod.externalFixtureMatch(sportscore,tomorrow),false);
const wrong={...mapped,home:{...mapped.home,name:'Bangladesh'},away:{...mapped.away,name:'West Indies'}};
assert.equal(mod.externalFixtureMatch(sportscore,wrong),false);
const clean=mod.mergeSportsSources([sportscore],[wrong],'SportsAPI.app');
assert.equal(clean[0].away.score,'271');
// D1 detail newer feed merge must map teams correctly even if home/away reversed.
const reversed={...mapped,home:mapped.away,away:mapped.home,
  id:sportscore.id};
const db={prepare(sql){return {bind(...args){this.args=args;return this},async first(){if(sql.includes('sports_match_snapshots'))return {
 payload_json:JSON.stringify({...sportscore,home:{name:'Afghanistan',score:'-1'},away:{name:'Zimbabwe',score:'-1'}}),provider:'SportScore',fetched_at:100,detail_available:1};
 if(sql.includes('sports_feed_snapshots'))return {payload_json:JSON.stringify([reversed]),provider:'SportScore + SportsAPI.app',fetched_at:200};return null;}}}};
const detail=await mod.readStoredDetails({DB:db},'cricket',sportscore.id);
assert.equal(detail.match.away.score,'271/3');
assert.equal(detail.match.home.score,'-1');
// No carrying ancient score into live fixture.
const expired={...sportscore,scoreVerifiedAt:'2020-01-01T00:00:00Z',home:{name:'Afghanistan',score:'220/2'},away:{name:'Zimbabwe',score:'80/1'}};
const carried=mod.carryPriorVerifiedScores([expired],[{...sportscore,home:{name:'Afghanistan',score:''},away:{name:'Zimbabwe',score:''}}]);
assert.equal(carried[0].home.score,'');assert.equal(carried[0].away.score,'');
console.log('PASS: SportsAPI cricket innings, fixture identity, D1 side mapping and expired score guard');
