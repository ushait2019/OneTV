import assert from 'node:assert/strict';
import fs from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
let widgetMode='valid', calls=[];
const kickoff='2026-11-05T11:15:00Z';
globalThis.fetch=async url=>{
  const u=new URL(url); calls.push(u.pathname);
  if(u.pathname==='/api/v1/fixtures/') return new Response(JSON.stringify({matches:[{
    sport:'cricket', slug:'kathmandu-gurkhas-vs-biratnagar-kings',
    home:'Kathmandu Gurkhas',away:'Biratnagar Kings',
    status:'live',status_text:'1st innings (home)',time:kickoff,
    home_score:'-',away_score:'-', competition:'Nepal Premier League'}]}));
  if(u.pathname==='/api/widget/matches/') return new Response(JSON.stringify({matches:[{
    sport:'cricket',slug:'widget-biratnagar-kings-11-05',
    home:'Biratnagar Kings',away:'Kathmandu Gurkhas',
    time:widgetMode==='wrong-time'?'2026-11-04T11:15:00Z':kickoff,
    status:'live',status_text:'In progress',home_score:'38/7',away_score:'-',
    home_overs:'10.4',home_wickets:7},
    {sport:'cricket',home:'India',away:'Bangladesh',time:kickoff,
     status:'live',home_score:'999/0',away_score:'0/0'}]}));
  throw new Error('Unexpected request '+url);
};
const content=fs.readFileSync(new URL('../src/index.js',import.meta.url),'utf8');
const mod=await import('data:text/javascript;base64,'+Buffer.from(content+'\nexport {sourceFeedFor,ensureSportsControlSchema,activeSourcesFor};').toString('base64'));
const db=new DatabaseSync(':memory:');
const env={DB:{prepare(sql){const stmt=db.prepare(sql);let args=[];return {
  bind(...values){args=values;return this},async run(){const r=stmt.run(...args);return {meta:{changes:r.changes}}},
  async first(){return stmt.get(...args)||null},async all(){return {results:stmt.all(...args)}}};}}};
await mod.ensureSportsControlSchema(env);
const sources=await mod.activeSourcesFor(env,'cricket','live');
const source=sources.find(s=>s.source_id==='sportscore');
assert.ok(source,'Primary SportScore source available');
const output=await mod.sourceFeedFor(source,env,'cricket','live');
assert.equal(output.length,1,'Only verified primary fixtures included');
assert.equal(output[0].id,'sportscore:cricket:kathmandu-gurkhas-vs-biratnagar-kings');
assert.equal(output[0].away.score,'38/7','Reversed-side verified widget score assigned to Biratnagar');
assert.equal(output[0].away.overs,'10.4');
assert.equal(output[0].away.wickets,'7');
assert.equal(output[0].home.score,'','No invented Kathmandu runs');
assert.equal(output[0].statusText,'1st innings (home)','Primary match phase preserved');
assert.ok(output[0].dataSources?.scoreFallback?.includes('SportScore live widget'));
assert.ok(calls.includes('/api/widget/matches/'));
widgetMode='wrong-time';
// Other example with fresh source reservation, so widget request isn't throttled.
// Direct function test avoids the scheduled provider call budget on purpose.
const separate=await import('data:text/javascript;base64,'+Buffer.from(content+'\nexport {sportScoreMatches,sameCricketFixture,mergeSportsSources};').toString('base64'));
const rawFixture={matches:[{status:'live',time:kickoff,home:'Kathmandu Gurkhas',away:'Biratnagar Kings',home_score:'-',away_score:'-'}]};
const rawDifferent={matches:[{status:'live',time:'2026-11-04T11:15:00Z',home:'Biratnagar Kings',away:'Kathmandu Gurkhas',home_score:'38/7'}]};
const fixtures=separate.sportScoreMatches(rawFixture,'cricket');
const others=separate.sportScoreMatches(rawDifferent,'cricket');
assert.equal(separate.sameCricketFixture(fixtures[0],others[0]),false);
const safeCandidates=others.filter(m=>fixtures.some(x=>separate.sameCricketFixture(x,m)));
assert.equal(safeCandidates.length,0,'Previous-day same-team match must be rejected');
console.log('PASS: Cron-only widget enrichment, 38/7 overs, reversed-team alignment, unrelated fixtures excluded, wrong-day rejection.');
