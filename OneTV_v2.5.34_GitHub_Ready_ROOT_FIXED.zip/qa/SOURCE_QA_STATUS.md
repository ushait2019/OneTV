# Source-level verification

- ZIP source baseline: **2.5.13** (latest user ZIP).
- Ad method integrity: **PASS** (byte-for-byte compared with v2.5.13).
- Java syntax parse via javac: **NO syntax errors detected**; full Android compile NOT performed because SDK classes/dependencies are unavailable here.
- Cloudflare backend `node --check`: **PASS**.
- Desktop control scripts `node --check`: **PASS**.
- Main Android package/app ID unchanged: `com.ushait.onetv`: **PASS**.
- Project PDFs unchanged: **PASS**.
- Real provider/network availability, ad/no-ad, splash animation frame timing, reminder delivery, offline freshness, screen visual pixel parity, playback and device lifecycle: **NOT TESTED / NOT CERTIFIED**.
- Complete PDF page-by-page acceptance: **INCOMPLETE**. Continue incrementally with the updated ZIP as the next baseline.
