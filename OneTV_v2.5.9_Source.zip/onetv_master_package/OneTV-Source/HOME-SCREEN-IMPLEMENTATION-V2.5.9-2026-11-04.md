# OneTV Home Screen implementation — v2.5.9 (2026-11-04)

## Scope
First visual implementation increment from the latest v2.5.8 backend-first baseline. Home is aligned more closely to page 6 of the supplied 72-page Visual Design PDF.

## Changes
- Reworked Home composition around a featured match region and three large destination tiles: Sports, Entertainment, News.
- Added restrained blue, purple and red gradient tile treatments, consistent rounded corners, readable title/subtitle hierarchy and clear tap targets.
- Featured match and match lists continue to use the existing backend sports endpoints and provider data only.
- No fabricated match, score, team image, news image or video was introduced.
- Preserved existing app header, route handlers, Photo Stories route, sports routes, refresh behavior and global footer/copyright.
- Reduced the Android AdView container to one global footer placement (`home_footer`) instead of creating two parallel AdViews (`home_1`, `home_2`). This is a single banner placement, not yet sequential Banner/Video rotation.

## Version
- versionName: 2.5.9
- versionCode: 49

## Verification
- Source-level review and ZIP integrity verification performed.
- Android APK build/device QA not performed in this environment. Do not treat this source ZIP as a verified APK or production release.

## Known limitations
- The featured region uses the existing verified match card/gradient treatment. A true image-led hero requires a licensed, exact-match image URL in the backend payload; no substitute image is shown.
- The complete 72-page PDF route inventory remains incomplete and will be implemented in later increments.
- Only the existing AdMob banner SDK is integrated. Sequential banner/video rotation and the other configured ad networks are not claimed as implemented.
